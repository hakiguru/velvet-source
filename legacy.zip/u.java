package org.velvet;

@FunctionalInterface
public interface u {
   void a(f_ var1);
}
