package org.velvet;

import java.util.Objects;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.GlStateManager.DestFactor;
import net.minecraft.client.renderer.GlStateManager.SourceFactor;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import org.lwjgl.opengl.GL11;
import software.bernie.geckolib3.core.util.Color;
import software.bernie.geckolib3.geo.render.built.GeoBone;
import software.bernie.geckolib3.model.AnimatedGeoModel;
import software.bernie.geckolib3.renderers.geo.IGeoRenderer;

public class dm extends d_ {
   public static boolean v = false;
   ItemStack s = ItemStack.field_190927_a;
   ItemStack x = ItemStack.field_190927_a;
   boolean r = false;
   boolean u = false;
   protected ei w;
   protected float y;
   float t = 0.0F;

   public dm(RenderManager var1, AnimatedGeoModel var2) {
      super(var1, var2, 0.0);
   }

   public void func_76979_b(Entity var1, double var2, double var4, double var6, float var8, float var9) {
   }

   boolean a(em var1) {
      try {
         if (var1.h()) {
            return true;
         }
      } catch (IllegalStateException var3) {
         throw b(var3);
      }

      boolean var2 = v;
      v = false;
      return var2;
   }

   @Override
   public void a(em var1, double var2, double var4, double var6, float var8, float var9) {
      try {
         if (!this.a(var1)) {
            return;
         }
      } catch (IllegalStateException var15) {
         throw b(var15);
      }

      ei var10 = (ei)var1;

      try {
         if (var10.m() == null) {
            return;
         }
      } catch (IllegalStateException var14) {
         throw b(var14);
      }

      EntityPlayer var11 = Minecraft.func_71410_x().field_71439_g.field_70170_p.func_152378_a(var10.m());

      try {
         if (var11 == null) {
            return;
         }
      } catch (IllegalStateException var12) {
         throw b(var12);
      }

      try {
         this.s = var11.func_184614_ca();
         this.x = var11.func_184592_cb();
         this.u = var10.ah;
         this.r = var10.ad;
         this.w = (ei)var1;
         this.y = var9;
         var10.f(var11);
         if (this.a(var11, var1)) {
            this.func_147906_a(var1, var11.func_70005_c_(), var2, var4 + var10.i(), var6, 300);
         }
      } catch (IllegalStateException var13) {
         throw b(var13);
      }

      super.a(var1, var2, var4, var6, var8, var9);
   }

   @Override
   public Entity c(em var1) {
      try {
         if (!(var1 instanceof ei)) {
            return var1;
         }
      } catch (IllegalStateException var5) {
         throw b(var5);
      }

      ei var2 = (ei)var1;
      EntityPlayer var3 = var2.k();

      try {
         return (Entity)(var3 == null ? var1 : var3);
      } catch (IllegalStateException var4) {
         throw b(var4);
      }
   }

   boolean a(EntityPlayer var1, em var2) {
      try {
         if (var1.getPersistentID().equals(Minecraft.func_71410_x().field_71439_g.getPersistentID())) {
            return false;
         }
      } catch (IllegalStateException var6) {
         throw b(var6);
      }

      fp var3 = var2.y();

      try {
         if (var3 == null) {
            return true;
         }
      } catch (IllegalStateException var4) {
         throw b(var4);
      }

      try {
         if (!var3.hideNameTag) {
            return true;
         }
      } catch (IllegalStateException var5) {
         throw b(var5);
      }

      return false;
   }

   protected void a(String var1, GeoBone var2) {
   }

   protected void a(String var1, GeoBone var2, ei var3, BufferBuilder var4) {
   }

   @Override
   public void renderRecursively(BufferBuilder param1, GeoBone param2, float param3, float param4, float param5, float param6) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 000: aload 2
      // 001: invokevirtual software/bernie/geckolib3/geo/render/built/GeoBone.getName ()Ljava/lang/String;
      // 004: astore 7
      // 006: aload 0
      // 007: getfield com/trolmastercard/velvet/dm.r Z
      // 00a: ifeq 04c
      // 00d: aload 7
      // 00f: ldc "upperBody"
      // 011: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 014: ifeq 030
      // 017: goto 01e
      // 01a: invokestatic com/trolmastercard/velvet/dm.b (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 01d: athrow
      // 01e: aload 2
      // 01f: aload 2
      // 020: invokevirtual software/bernie/geckolib3/geo/render/built/GeoBone.getRotationX ()F
      // 023: ldc 0.5
      // 025: fsub
      // 026: invokevirtual software/bernie/geckolib3/geo/render/built/GeoBone.setRotationX (F)V
      // 029: goto 030
      // 02c: invokestatic com/trolmastercard/velvet/dm.b (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 02f: athrow
      // 030: aload 7
      // 032: ldc "head"
      // 034: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 037: ifeq 04c
      // 03a: aload 2
      // 03b: aload 2
      // 03c: invokevirtual software/bernie/geckolib3/geo/render/built/GeoBone.getRotationX ()F
      // 03f: ldc 0.5
      // 041: fadd
      // 042: invokevirtual software/bernie/geckolib3/geo/render/built/GeoBone.setRotationX (F)V
      // 045: goto 04c
      // 048: invokestatic com/trolmastercard/velvet/dm.b (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 04b: athrow
      // 04c: aload 7
      // 04e: ldc "head"
      // 050: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 053: ifeq 06b
      // 056: aload 0
      // 057: aload 1
      // 058: aload 2
      // 059: fload 3
      // 05a: fload 4
      // 05c: fload 5
      // 05e: invokestatic software/bernie/geckolib3/core/util/Color.ofRGB (FFF)Lsoftware/bernie/geckolib3/core/util/Color;
      // 061: invokevirtual com/trolmastercard/velvet/dm.a (Lnet/minecraft/client/renderer/BufferBuilder;Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;Lsoftware/bernie/geckolib3/core/util/Color;)V
      // 064: goto 06b
      // 067: invokestatic com/trolmastercard/velvet/dm.b (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 06a: athrow
      // 06b: aload 0
      // 06c: aload 7
      // 06e: aload 2
      // 06f: invokevirtual com/trolmastercard/velvet/dm.a (Ljava/lang/String;Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;)V
      // 072: aload 0
      // 073: aload 7
      // 075: aload 2
      // 076: aload 0
      // 077: getfield com/trolmastercard/velvet/dm.w Lcom/trolmastercard/velvet/ei;
      // 07a: aload 1
      // 07b: invokevirtual com/trolmastercard/velvet/dm.a (Ljava/lang/String;Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;Lcom/trolmastercard/velvet/ei;Lnet/minecraft/client/renderer/BufferBuilder;)V
      // 07e: aload 0
      // 07f: getfield com/trolmastercard/velvet/dm.u Z
      // 082: ifeq 11d
      // 085: aload 0
      // 086: getfield com/trolmastercard/velvet/dm.s Lnet/minecraft/item/ItemStack;
      // 089: invokevirtual net/minecraft/item/ItemStack.func_77973_b ()Lnet/minecraft/item/Item;
      // 08c: instanceof net/minecraft/item/ItemBow
      // 08f: ifne 0ad
      // 092: goto 099
      // 095: invokestatic com/trolmastercard/velvet/dm.b (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 098: athrow
      // 099: aload 0
      // 09a: getfield com/trolmastercard/velvet/dm.x Lnet/minecraft/item/ItemStack;
      // 09d: invokevirtual net/minecraft/item/ItemStack.func_77973_b ()Lnet/minecraft/item/Item;
      // 0a0: instanceof net/minecraft/item/ItemBow
      // 0a3: ifeq 11d
      // 0a6: goto 0ad
      // 0a9: invokestatic com/trolmastercard/velvet/dm.b (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 0ac: athrow
      // 0ad: aload 7
      // 0af: ldc "armR"
      // 0b1: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 0b4: ifeq 0d8
      // 0b7: goto 0be
      // 0ba: invokestatic com/trolmastercard/velvet/dm.b (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 0bd: athrow
      // 0be: aload 2
      // 0bf: aload 2
      // 0c0: invokevirtual software/bernie/geckolib3/geo/render/built/GeoBone.getRotationX ()F
      // 0c3: aload 0
      // 0c4: getfield com/trolmastercard/velvet/dm.j Lcom/trolmastercard/velvet/em;
      // 0c7: getfield com/trolmastercard/velvet/em.field_70125_A F
      // 0ca: ldc 50.0
      // 0cc: fdiv
      // 0cd: fsub
      // 0ce: invokevirtual software/bernie/geckolib3/geo/render/built/GeoBone.setRotationX (F)V
      // 0d1: goto 0d8
      // 0d4: invokestatic com/trolmastercard/velvet/dm.b (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 0d7: athrow
      // 0d8: aload 7
      // 0da: ldc "armL"
      // 0dc: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 0df: ifeq 0fc
      // 0e2: aload 2
      // 0e3: aload 2
      // 0e4: invokevirtual software/bernie/geckolib3/geo/render/built/GeoBone.getRotationY ()F
      // 0e7: aload 0
      // 0e8: getfield com/trolmastercard/velvet/dm.j Lcom/trolmastercard/velvet/em;
      // 0eb: getfield com/trolmastercard/velvet/em.field_70125_A F
      // 0ee: ldc 50.0
      // 0f0: fdiv
      // 0f1: fsub
      // 0f2: invokevirtual software/bernie/geckolib3/geo/render/built/GeoBone.setRotationY (F)V
      // 0f5: goto 0fc
      // 0f8: invokestatic com/trolmastercard/velvet/dm.b (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 0fb: athrow
      // 0fc: aload 0
      // 0fd: getfield com/trolmastercard/velvet/dm.x Lnet/minecraft/item/ItemStack;
      // 100: invokevirtual net/minecraft/item/ItemStack.func_77973_b ()Lnet/minecraft/item/Item;
      // 103: instanceof net/minecraft/item/ItemBow
      // 106: ifeq 11d
      // 109: aload 0
      // 10a: getfield com/trolmastercard/velvet/dm.x Lnet/minecraft/item/ItemStack;
      // 10d: astore 8
      // 10f: aload 0
      // 110: aload 0
      // 111: getfield com/trolmastercard/velvet/dm.s Lnet/minecraft/item/ItemStack;
      // 114: putfield com/trolmastercard/velvet/dm.x Lnet/minecraft/item/ItemStack;
      // 117: aload 0
      // 118: aload 8
      // 11a: putfield com/trolmastercard/velvet/dm.s Lnet/minecraft/item/ItemStack;
      // 11d: aload 0
      // 11e: getfield com/trolmastercard/velvet/dm.u Z
      // 121: ifeq 18b
      // 124: aload 0
      // 125: getfield com/trolmastercard/velvet/dm.s Lnet/minecraft/item/ItemStack;
      // 128: invokevirtual net/minecraft/item/ItemStack.func_77973_b ()Lnet/minecraft/item/Item;
      // 12b: instanceof net/minecraft/item/ItemShield
      // 12e: ifeq 18b
      // 131: goto 138
      // 134: invokestatic com/trolmastercard/velvet/dm.b (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 137: athrow
      // 138: aload 7
      // 13a: ldc "armR"
      // 13c: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 13f: ifeq 15b
      // 142: goto 149
      // 145: invokestatic com/trolmastercard/velvet/dm.b (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 148: athrow
      // 149: aload 2
      // 14a: fconst_0
      // 14b: invokevirtual software/bernie/geckolib3/geo/render/built/GeoBone.setRotationZ (F)V
      // 14e: aload 2
      // 14f: ldc 0.5
      // 151: invokevirtual software/bernie/geckolib3/geo/render/built/GeoBone.setRotationX (F)V
      // 154: goto 18b
      // 157: invokestatic com/trolmastercard/velvet/dm.b (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 15a: athrow
      // 15b: aload 0
      // 15c: getfield com/trolmastercard/velvet/dm.x Lnet/minecraft/item/ItemStack;
      // 15f: invokevirtual net/minecraft/item/ItemStack.func_77973_b ()Lnet/minecraft/item/Item;
      // 162: instanceof net/minecraft/item/ItemShield
      // 165: ifeq 18b
      // 168: aload 7
      // 16a: ldc "armL"
      // 16c: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 16f: ifeq 18b
      // 172: goto 179
      // 175: invokestatic com/trolmastercard/velvet/dm.b (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 178: athrow
      // 179: aload 2
      // 17a: fconst_0
      // 17b: invokevirtual software/bernie/geckolib3/geo/render/built/GeoBone.setRotationZ (F)V
      // 17e: aload 2
      // 17f: ldc 0.5
      // 181: invokevirtual software/bernie/geckolib3/geo/render/built/GeoBone.setRotationX (F)V
      // 184: goto 18b
      // 187: invokestatic com/trolmastercard/velvet/dm.b (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 18a: athrow
      // 18b: aload 7
      // 18d: ldc "weapon"
      // 18f: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 192: ifeq 1b4
      // 195: aload 0
      // 196: getfield com/trolmastercard/velvet/dm.s Lnet/minecraft/item/ItemStack;
      // 199: invokevirtual net/minecraft/item/ItemStack.func_190926_b ()Z
      // 19c: ifne 1b4
      // 19f: goto 1a6
      // 1a2: invokestatic com/trolmastercard/velvet/dm.b (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 1a5: athrow
      // 1a6: aload 0
      // 1a7: aload 1
      // 1a8: aload 2
      // 1a9: bipush 0
      // 1aa: invokevirtual com/trolmastercard/velvet/dm.a (Lnet/minecraft/client/renderer/BufferBuilder;Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;Z)V
      // 1ad: goto 1b4
      // 1b0: invokestatic com/trolmastercard/velvet/dm.b (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 1b3: athrow
      // 1b4: aload 7
      // 1b6: ldc "offhand"
      // 1b8: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 1bb: ifeq 1dd
      // 1be: aload 0
      // 1bf: getfield com/trolmastercard/velvet/dm.x Lnet/minecraft/item/ItemStack;
      // 1c2: invokevirtual net/minecraft/item/ItemStack.func_190926_b ()Z
      // 1c5: ifne 1dd
      // 1c8: goto 1cf
      // 1cb: invokestatic com/trolmastercard/velvet/dm.b (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 1ce: athrow
      // 1cf: aload 0
      // 1d0: aload 1
      // 1d1: aload 2
      // 1d2: bipush 1
      // 1d3: invokevirtual com/trolmastercard/velvet/dm.a (Lnet/minecraft/client/renderer/BufferBuilder;Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;Z)V
      // 1d6: goto 1dd
      // 1d9: invokestatic com/trolmastercard/velvet/dm.b (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 1dc: athrow
      // 1dd: getstatic com/trolmastercard/velvet/dm.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 1e0: invokevirtual software/bernie/geckolib3/util/MatrixStack.push ()V
      // 1e3: getstatic com/trolmastercard/velvet/dm.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 1e6: aload 2
      // 1e7: invokevirtual software/bernie/geckolib3/util/MatrixStack.translate (Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;)V
      // 1ea: getstatic com/trolmastercard/velvet/dm.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 1ed: aload 2
      // 1ee: invokevirtual software/bernie/geckolib3/util/MatrixStack.moveToPivot (Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;)V
      // 1f1: getstatic com/trolmastercard/velvet/dm.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 1f4: aload 2
      // 1f5: invokevirtual software/bernie/geckolib3/util/MatrixStack.rotate (Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;)V
      // 1f8: getstatic com/trolmastercard/velvet/dm.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 1fb: aload 2
      // 1fc: invokevirtual software/bernie/geckolib3/util/MatrixStack.scale (Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;)V
      // 1ff: getstatic com/trolmastercard/velvet/dm.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 202: aload 2
      // 203: invokevirtual software/bernie/geckolib3/util/MatrixStack.moveBackFromPivot (Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;)V
      // 206: ldc_w "Head2"
      // 209: aload 7
      // 20b: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 20e: ifeq 22a
      // 211: aload 0
      // 212: invokevirtual com/trolmastercard/velvet/dm.c ()Z
      // 215: ifne 22a
      // 218: goto 21f
      // 21b: invokestatic com/trolmastercard/velvet/dm.b (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 21e: athrow
      // 21f: getstatic com/trolmastercard/velvet/dm.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 222: invokevirtual software/bernie/geckolib3/util/MatrixStack.pop ()V
      // 225: return
      // 226: invokestatic com/trolmastercard/velvet/dm.b (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 229: athrow
      // 22a: ldc_w "neck"
      // 22d: aload 7
      // 22f: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 232: ifne 246
      // 235: ldc "head"
      // 237: aload 7
      // 239: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 23c: ifeq 25f
      // 23f: goto 246
      // 242: invokestatic com/trolmastercard/velvet/dm.b (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 245: athrow
      // 246: aload 0
      // 247: invokevirtual com/trolmastercard/velvet/dm.a ()Z
      // 24a: ifne 25f
      // 24d: goto 254
      // 250: invokestatic com/trolmastercard/velvet/dm.b (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 253: athrow
      // 254: getstatic com/trolmastercard/velvet/dm.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 257: invokevirtual software/bernie/geckolib3/util/MatrixStack.pop ()V
      // 25a: return
      // 25b: invokestatic com/trolmastercard/velvet/dm.b (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 25e: athrow
      // 25f: aload 2
      // 260: getfield software/bernie/geckolib3/geo/render/built/GeoBone.isHidden Z
      // 263: ifne 336
      // 266: aload 0
      // 267: aload 7
      // 269: fload 3
      // 26a: fload 4
      // 26c: fload 5
      // 26e: invokevirtual com/trolmastercard/velvet/dm.a (Ljava/lang/String;FFF)Ljavax/vecmath/Vector4f;
      // 271: astore 8
      // 273: aload 8
      // 275: getfield javax/vecmath/Vector4f.x F
      // 278: fstore 3
      // 279: aload 8
      // 27b: getfield javax/vecmath/Vector4f.y F
      // 27e: fstore 4
      // 280: aload 8
      // 282: getfield javax/vecmath/Vector4f.z F
      // 285: fstore 5
      // 287: aload 8
      // 289: getfield javax/vecmath/Vector4f.w F
      // 28c: f2d
      // 28d: dstore 9
      // 28f: aload 0
      // 290: getfield com/trolmastercard/velvet/dm.p Ljava/util/HashSet;
      // 293: aload 7
      // 295: invokevirtual java/util/HashSet.contains (Ljava/lang/Object;)Z
      // 298: ifne 2e6
      // 29b: aload 2
      // 29c: getfield software/bernie/geckolib3/geo/render/built/GeoBone.childCubes Ljava/util/List;
      // 29f: invokeinterface java/util/List.iterator ()Ljava/util/Iterator; 1
      // 2a4: astore 11
      // 2a6: aload 11
      // 2a8: invokeinterface java/util/Iterator.hasNext ()Z 1
      // 2ad: ifeq 2e6
      // 2b0: aload 11
      // 2b2: invokeinterface java/util/Iterator.next ()Ljava/lang/Object; 1
      // 2b7: checkcast software/bernie/geckolib3/geo/render/built/GeoCube
      // 2ba: astore 12
      // 2bc: getstatic com/trolmastercard/velvet/dm.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 2bf: invokevirtual software/bernie/geckolib3/util/MatrixStack.push ()V
      // 2c2: invokestatic net/minecraft/client/renderer/GlStateManager.func_179094_E ()V
      // 2c5: aload 0
      // 2c6: aload 2
      // 2c7: putfield com/trolmastercard/velvet/dm.q Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;
      // 2ca: aload 0
      // 2cb: aload 1
      // 2cc: aload 12
      // 2ce: fload 3
      // 2cf: fload 4
      // 2d1: fload 5
      // 2d3: fload 6
      // 2d5: dload 9
      // 2d7: invokevirtual com/trolmastercard/velvet/dm.a (Lnet/minecraft/client/renderer/BufferBuilder;Lsoftware/bernie/geckolib3/geo/render/built/GeoCube;FFFFD)V
      // 2da: invokestatic net/minecraft/client/renderer/GlStateManager.func_179121_F ()V
      // 2dd: getstatic com/trolmastercard/velvet/dm.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 2e0: invokevirtual software/bernie/geckolib3/util/MatrixStack.pop ()V
      // 2e3: goto 2a6
      // 2e6: aload 2
      // 2e7: getfield software/bernie/geckolib3/geo/render/built/GeoBone.childBones Ljava/util/List;
      // 2ea: invokeinterface java/util/List.iterator ()Ljava/util/Iterator; 1
      // 2ef: astore 11
      // 2f1: aload 11
      // 2f3: invokeinterface java/util/Iterator.hasNext ()Z 1
      // 2f8: ifeq 336
      // 2fb: aload 11
      // 2fd: invokeinterface java/util/Iterator.next ()Ljava/lang/Object; 1
      // 302: checkcast software/bernie/geckolib3/geo/render/built/GeoBone
      // 305: astore 12
      // 307: dload 9
      // 309: dconst_0
      // 30a: dcmpl
      // 30b: ifne 323
      // 30e: aload 0
      // 30f: aload 1
      // 310: aload 12
      // 312: fload 3
      // 313: fload 4
      // 315: fload 5
      // 317: fload 6
      // 319: invokevirtual com/trolmastercard/velvet/dm.renderRecursively (Lnet/minecraft/client/renderer/BufferBuilder;Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;FFFF)V
      // 31c: goto 333
      // 31f: invokestatic com/trolmastercard/velvet/dm.b (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 322: athrow
      // 323: aload 0
      // 324: aload 1
      // 325: aload 12
      // 327: fload 3
      // 328: fload 4
      // 32a: fload 5
      // 32c: fload 6
      // 32e: dload 9
      // 330: invokevirtual com/trolmastercard/velvet/dm.a (Lnet/minecraft/client/renderer/BufferBuilder;Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;FFFFD)V
      // 333: goto 2f1
      // 336: getstatic com/trolmastercard/velvet/dm.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 339: invokevirtual software/bernie/geckolib3/util/MatrixStack.pop ()V
      // 33c: goto 341
      // 33f: astore 8
      // 341: return
      // try (341 -> 354): 354 java/lang/IllegalStateException
      // try (261 -> 270): 270 java/lang/IllegalStateException
      // try (254 -> 264): 265 java/lang/IllegalStateException
      // try (250 -> 258): 259 java/lang/IllegalStateException
      // try (239 -> 248): 248 java/lang/IllegalStateException
      // try (218 -> 242): 243 java/lang/IllegalStateException
      // try (203 -> 215): 216 java/lang/IllegalStateException
      // try (199 -> 207): 208 java/lang/IllegalStateException
      // try (184 -> 196): 197 java/lang/IllegalStateException
      // try (180 -> 188): 189 java/lang/IllegalStateException
      // try (164 -> 177): 178 java/lang/IllegalStateException
      // try (159 -> 168): 169 java/lang/IllegalStateException
      // try (143 -> 157): 157 java/lang/IllegalStateException
      // try (135 -> 147): 148 java/lang/IllegalStateException
      // try (132 -> 140): 141 java/lang/IllegalStateException
      // try (100 -> 114): 115 java/lang/IllegalStateException
      // try (80 -> 97): 98 java/lang/IllegalStateException
      // try (72 -> 84): 85 java/lang/IllegalStateException
      // try (64 -> 77): 78 java/lang/IllegalStateException
      // try (50 -> 69): 70 java/lang/IllegalStateException
      // try (35 -> 47): 48 java/lang/IllegalStateException
      // try (22 -> 32): 33 java/lang/IllegalStateException
      // try (6 -> 19): 20 java/lang/IllegalStateException
      // try (3 -> 10): 11 java/lang/IllegalStateException
      // try (366 -> 368): 369 java/lang/IllegalStateException
   }

   boolean a() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 00: aload 0
      // 01: getfield com/trolmastercard/velvet/dm.j Lcom/trolmastercard/velvet/em;
      // 04: checkcast com/trolmastercard/velvet/ei
      // 07: invokevirtual com/trolmastercard/velvet/ei.f ()Z
      // 0a: ifne 13
      // 0d: bipush 1
      // 0e: ireturn
      // 0f: invokestatic com/trolmastercard/velvet/dm.b (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 12: athrow
      // 13: getstatic com/trolmastercard/velvet/dm.i Lnet/minecraft/client/Minecraft;
      // 16: getfield net/minecraft/client/Minecraft.field_71474_y Lnet/minecraft/client/settings/GameSettings;
      // 19: getfield net/minecraft/client/settings/GameSettings.field_74320_O I
      // 1c: ifeq 25
      // 1f: bipush 1
      // 20: ireturn
      // 21: invokestatic com/trolmastercard/velvet/dm.b (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 24: athrow
      // 25: getstatic com/trolmastercard/velvet/dm.i Lnet/minecraft/client/Minecraft;
      // 28: getfield net/minecraft/client/Minecraft.field_71462_r Lnet/minecraft/client/gui/GuiScreen;
      // 2b: instanceof net/minecraft/client/gui/inventory/GuiInventory
      // 2e: ifne 44
      // 31: getstatic com/trolmastercard/velvet/dm.i Lnet/minecraft/client/Minecraft;
      // 34: getfield net/minecraft/client/Minecraft.field_71462_r Lnet/minecraft/client/gui/GuiScreen;
      // 37: instanceof net/minecraft/client/gui/inventory/GuiContainerCreative
      // 3a: ifeq 4c
      // 3d: goto 44
      // 40: invokestatic com/trolmastercard/velvet/dm.b (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 43: athrow
      // 44: bipush 1
      // 45: goto 4d
      // 48: invokestatic com/trolmastercard/velvet/dm.b (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 4b: athrow
      // 4c: bipush 0
      // 4d: ireturn
      // try (0 -> 7): 7 java/lang/IllegalStateException
      // try (9 -> 15): 15 java/lang/IllegalStateException
      // try (17 -> 25): 26 java/lang/IllegalStateException
      // try (21 -> 30): 30 java/lang/IllegalStateException
   }

   void a(BufferBuilder var1, GeoBone var2, Color var3) {
      GlStateManager.func_179094_E();
      Tessellator.func_178181_a().func_78381_a();
      org.velvet.p.a(IGeoRenderer.MATRIX_STACK, var2);
      GL11.glEnable(2896);
      this.c();
      new bu(this).render(this.j, this.j.field_184619_aG, this.j.field_70721_aZ, this.y, 0.0F, 0.0F, 0.0F, var3);
      this.func_110776_a(Objects.requireNonNull(this.getEntityTexture(this.j)));
      var1.func_181668_a(7, DefaultVertexFormats.field_181712_l);
      GlStateManager.func_179147_l();
      GlStateManager.func_187401_a(SourceFactor.SRC_ALPHA, DestFactor.ONE_MINUS_SRC_ALPHA);
      GL11.glDisable(2896);
      GlStateManager.func_179121_F();
   }

   protected void c() {
   }

   void a(BufferBuilder param1, GeoBone param2, boolean param3) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 000: invokestatic net/minecraft/client/Minecraft.func_71410_x ()Lnet/minecraft/client/Minecraft;
      // 003: invokevirtual net/minecraft/client/Minecraft.func_175597_ag ()Lnet/minecraft/client/renderer/ItemRenderer;
      // 006: astore 4
      // 008: invokestatic net/minecraft/client/renderer/GlStateManager.func_179094_E ()V
      // 00b: invokestatic net/minecraft/client/renderer/Tessellator.func_178181_a ()Lnet/minecraft/client/renderer/Tessellator;
      // 00e: invokevirtual net/minecraft/client/renderer/Tessellator.func_78381_a ()V
      // 011: getstatic software/bernie/geckolib3/renderers/geo/IGeoRenderer.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 014: aload 2
      // 015: invokestatic com/trolmastercard/velvet/p.a (Lsoftware/bernie/geckolib3/util/MatrixStack;Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;)V
      // 018: sipush 2896
      // 01b: invokestatic org/lwjgl/opengl/GL11.glEnable (I)V
      // 01e: invokestatic net/minecraft/client/renderer/GlStateManager.func_179147_l ()V
      // 021: getstatic net/minecraft/client/renderer/GlStateManager$SourceFactor.SRC_ALPHA Lnet/minecraft/client/renderer/GlStateManager$SourceFactor;
      // 024: getstatic net/minecraft/client/renderer/GlStateManager$DestFactor.ONE_MINUS_SRC_ALPHA Lnet/minecraft/client/renderer/GlStateManager$DestFactor;
      // 027: invokestatic net/minecraft/client/renderer/GlStateManager.func_187401_a (Lnet/minecraft/client/renderer/GlStateManager$SourceFactor;Lnet/minecraft/client/renderer/GlStateManager$DestFactor;)V
      // 02a: iload 3
      // 02b: ifeq 039
      // 02e: aload 0
      // 02f: getfield com/trolmastercard/velvet/dm.x Lnet/minecraft/item/ItemStack;
      // 032: goto 03d
      // 035: invokestatic com/trolmastercard/velvet/dm.b (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 038: athrow
      // 039: aload 0
      // 03a: getfield com/trolmastercard/velvet/dm.s Lnet/minecraft/item/ItemStack;
      // 03d: astore 5
      // 03f: getstatic com/trolmastercard/velvet/dm$a.a [I
      // 042: aload 5
      // 044: invokevirtual net/minecraft/item/ItemStack.func_77973_b ()Lnet/minecraft/item/Item;
      // 047: aload 5
      // 049: invokevirtual net/minecraft/item/Item.func_77661_b (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/EnumAction;
      // 04c: invokevirtual net/minecraft/item/EnumAction.ordinal ()I
      // 04f: iaload
      // 050: lookupswitch 49 2 1 28 2 40
      // 06c: aload 0
      // 06d: iload 3
      // 06e: invokevirtual com/trolmastercard/velvet/dm.a (Z)V
      // 071: goto 081
      // 074: invokestatic com/trolmastercard/velvet/dm.b (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 077: athrow
      // 078: aload 0
      // 079: iload 3
      // 07a: aload 0
      // 07b: getfield com/trolmastercard/velvet/dm.u Z
      // 07e: invokevirtual com/trolmastercard/velvet/dm.a (ZZ)V
      // 081: aload 0
      // 082: getfield com/trolmastercard/velvet/dm.u Z
      // 085: ifeq 0ec
      // 088: iload 3
      // 089: ifne 0ec
      // 08c: goto 093
      // 08f: invokestatic com/trolmastercard/velvet/dm.b (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 092: athrow
      // 093: aload 5
      // 095: invokevirtual net/minecraft/item/ItemStack.func_77973_b ()Lnet/minecraft/item/Item;
      // 098: instanceof net/minecraft/item/ItemBow
      // 09b: ifeq 0ec
      // 09e: goto 0a5
      // 0a1: invokestatic com/trolmastercard/velvet/dm.b (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 0a4: athrow
      // 0a5: aload 0
      // 0a6: dup
      // 0a7: getfield com/trolmastercard/velvet/dm.t F
      // 0aa: ldc_w 0.015
      // 0ad: fadd
      // 0ae: putfield com/trolmastercard/velvet/dm.t F
      // 0b1: aload 0
      // 0b2: getfield com/trolmastercard/velvet/dm.j Lcom/trolmastercard/velvet/em;
      // 0b5: aload 0
      // 0b6: getfield com/trolmastercard/velvet/dm.t F
      // 0b9: fneg
      // 0ba: ldc_w 20.0
      // 0bd: fmul
      // 0be: aload 5
      // 0c0: invokevirtual net/minecraft/item/ItemStack.func_77988_m ()I
      // 0c3: i2f
      // 0c4: fadd
      // 0c5: invokestatic java/lang/Math.round (F)I
      // 0c8: invokevirtual com/trolmastercard/velvet/em.d (I)V
      // 0cb: aload 0
      // 0cc: getfield com/trolmastercard/velvet/dm.j Lcom/trolmastercard/velvet/em;
      // 0cf: aload 5
      // 0d1: invokevirtual com/trolmastercard/velvet/em.a (Lnet/minecraft/item/ItemStack;)V
      // 0d4: aload 0
      // 0d5: getfield com/trolmastercard/velvet/dm.j Lcom/trolmastercard/velvet/em;
      // 0d8: getstatic net/minecraft/util/EnumHand.MAIN_HAND Lnet/minecraft/util/EnumHand;
      // 0db: invokevirtual com/trolmastercard/velvet/em.func_184598_c (Lnet/minecraft/util/EnumHand;)V
      // 0de: aload 0
      // 0df: getfield com/trolmastercard/velvet/dm.j Lcom/trolmastercard/velvet/em;
      // 0e2: invokevirtual com/trolmastercard/velvet/em.W ()V
      // 0e5: goto 10a
      // 0e8: invokestatic com/trolmastercard/velvet/dm.b (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 0eb: athrow
      // 0ec: aload 0
      // 0ed: fconst_0
      // 0ee: putfield com/trolmastercard/velvet/dm.t F
      // 0f1: aload 0
      // 0f2: getfield com/trolmastercard/velvet/dm.j Lcom/trolmastercard/velvet/em;
      // 0f5: bipush 0
      // 0f6: invokevirtual com/trolmastercard/velvet/em.d (I)V
      // 0f9: aload 0
      // 0fa: getfield com/trolmastercard/velvet/dm.j Lcom/trolmastercard/velvet/em;
      // 0fd: getstatic net/minecraft/item/ItemStack.field_190927_a Lnet/minecraft/item/ItemStack;
      // 100: invokevirtual com/trolmastercard/velvet/em.a (Lnet/minecraft/item/ItemStack;)V
      // 103: aload 0
      // 104: getfield com/trolmastercard/velvet/dm.j Lcom/trolmastercard/velvet/em;
      // 107: invokevirtual com/trolmastercard/velvet/em.W ()V
      // 10a: aload 0
      // 10b: iload 3
      // 10c: aload 5
      // 10e: invokevirtual com/trolmastercard/velvet/dm.a (ZLnet/minecraft/item/ItemStack;)V
      // 111: ldc_w 0.75
      // 114: ldc_w 0.75
      // 117: ldc_w 0.75
      // 11a: invokestatic net/minecraft/client/renderer/GlStateManager.func_179152_a (FFF)V
      // 11d: aload 4
      // 11f: aload 0
      // 120: getfield com/trolmastercard/velvet/dm.j Lcom/trolmastercard/velvet/em;
      // 123: aload 5
      // 125: getstatic net/minecraft/client/renderer/block/model/ItemCameraTransforms$TransformType.THIRD_PERSON_RIGHT_HAND Lnet/minecraft/client/renderer/block/model/ItemCameraTransforms$TransformType;
      // 128: invokevirtual net/minecraft/client/renderer/ItemRenderer.func_178099_a (Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/item/ItemStack;Lnet/minecraft/client/renderer/block/model/ItemCameraTransforms$TransformType;)V
      // 12b: aload 1
      // 12c: bipush 7
      // 12e: getstatic net/minecraft/client/renderer/vertex/DefaultVertexFormats.field_181712_l Lnet/minecraft/client/renderer/vertex/VertexFormat;
      // 131: invokevirtual net/minecraft/client/renderer/BufferBuilder.func_181668_a (ILnet/minecraft/client/renderer/vertex/VertexFormat;)V
      // 134: aload 0
      // 135: aload 0
      // 136: aload 0
      // 137: getfield com/trolmastercard/velvet/dm.j Lcom/trolmastercard/velvet/em;
      // 13a: invokevirtual com/trolmastercard/velvet/dm.getEntityTexture (Lnet/minecraft/entity/EntityLivingBase;)Lnet/minecraft/util/ResourceLocation;
      // 13d: invokestatic java/util/Objects.requireNonNull (Ljava/lang/Object;)Ljava/lang/Object;
      // 140: checkcast net/minecraft/util/ResourceLocation
      // 143: invokevirtual com/trolmastercard/velvet/dm.func_110776_a (Lnet/minecraft/util/ResourceLocation;)V
      // 146: sipush 2896
      // 149: invokestatic org/lwjgl/opengl/GL11.glDisable (I)V
      // 14c: invokestatic net/minecraft/client/renderer/GlStateManager.func_179121_F ()V
      // 14f: invokestatic net/minecraft/client/renderer/GlStateManager.func_179147_l ()V
      // 152: getstatic net/minecraft/client/renderer/GlStateManager$SourceFactor.SRC_ALPHA Lnet/minecraft/client/renderer/GlStateManager$SourceFactor;
      // 155: getstatic net/minecraft/client/renderer/GlStateManager$DestFactor.ONE_MINUS_SRC_ALPHA Lnet/minecraft/client/renderer/GlStateManager$DestFactor;
      // 158: invokestatic net/minecraft/client/renderer/GlStateManager.func_187401_a (Lnet/minecraft/client/renderer/GlStateManager$SourceFactor;Lnet/minecraft/client/renderer/GlStateManager$DestFactor;)V
      // 15b: return
      // try (3 -> 20): 20 java/lang/IllegalStateException
      // try (25 -> 37): 37 java/lang/IllegalStateException
      // try (44 -> 49): 50 java/lang/IllegalStateException
      // try (47 -> 56): 57 java/lang/IllegalStateException
      // try (52 -> 90): 90 java/lang/IllegalStateException
   }

   protected void a(boolean var1, ItemStack var2) {
      float var10000;
      label16: {
         try {
            if (var1) {
               var10000 = 200.0F;
               break label16;
            }
         } catch (IllegalStateException var3) {
            throw b(var3);
         }

         var10000 = 90.0F;
      }

      GlStateManager.func_179114_b(var10000, 1.0F, 0.0F, 0.0F);
   }

   protected void a(boolean var1) {
      GlStateManager.func_179114_b(20.0F, 1.0F, 0.0F, 0.0F);
   }

   protected void a(boolean param1, boolean param2) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 00: iload 1
      // 01: ifeq 4b
      // 04: ldc_w 180.0
      // 07: fconst_0
      // 08: fconst_1
      // 09: fconst_0
      // 0a: invokestatic net/minecraft/client/renderer/GlStateManager.func_179114_b (FFFF)V
      // 0d: ldc_w 90.0
      // 10: fconst_1
      // 11: fconst_0
      // 12: fconst_0
      // 13: invokestatic net/minecraft/client/renderer/GlStateManager.func_179114_b (FFFF)V
      // 16: iload 2
      // 17: ifeq 70
      // 1a: goto 21
      // 1d: invokestatic com/trolmastercard/velvet/dm.b (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 20: athrow
      // 21: ldc_w -90.0
      // 24: fconst_0
      // 25: fconst_1
      // 26: fconst_0
      // 27: invokestatic net/minecraft/client/renderer/GlStateManager.func_179114_b (FFFF)V
      // 2a: ldc_w 35.0
      // 2d: fconst_0
      // 2e: fconst_0
      // 2f: fconst_1
      // 30: invokestatic net/minecraft/client/renderer/GlStateManager.func_179114_b (FFFF)V
      // 33: ldc_w -20.0
      // 36: fconst_1
      // 37: fconst_0
      // 38: fconst_0
      // 39: invokestatic net/minecraft/client/renderer/GlStateManager.func_179114_b (FFFF)V
      // 3c: fconst_0
      // 3d: fconst_0
      // 3e: ldc_w 0.228
      // 41: invokestatic net/minecraft/client/renderer/GlStateManager.func_179109_b (FFF)V
      // 44: goto 70
      // 47: invokestatic com/trolmastercard/velvet/dm.b (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 4a: athrow
      // 4b: iload 2
      // 4c: ifeq 70
      // 4f: ldc_w -90.0
      // 52: fconst_1
      // 53: fconst_0
      // 54: fconst_0
      // 55: invokestatic net/minecraft/client/renderer/GlStateManager.func_179114_b (FFFF)V
      // 58: ldc_w -90.0
      // 5b: fconst_0
      // 5c: fconst_0
      // 5d: fconst_1
      // 5e: invokestatic net/minecraft/client/renderer/GlStateManager.func_179114_b (FFFF)V
      // 61: fconst_0
      // 62: ldc_w 0.165
      // 65: fconst_0
      // 66: invokestatic net/minecraft/client/renderer/GlStateManager.func_179109_b (FFF)V
      // 69: goto 70
      // 6c: invokestatic com/trolmastercard/velvet/dm.b (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 6f: athrow
      // 70: return
      // try (0 -> 14): 15 java/lang/IllegalStateException
      // try (2 -> 37): 37 java/lang/IllegalStateException
      // try (39 -> 55): 56 java/lang/IllegalStateException
   }

   private static IllegalStateException b(IllegalStateException var0) {
      return var0;
   }
}
