package org.velvet;

import net.minecraft.util.ResourceLocation;
import software.bernie.geckolib3.model.AnimatedGeoModel;

public class as extends AnimatedGeoModel<cc> {
   public ResourceLocation b(cc var1) {
      return new ResourceLocation("velvet", "geo/galath/galath_coin.geo.json");
   }

   public ResourceLocation a(cc var1) {
      return new ResourceLocation("velvet", "textures/items/galath_coin/galath_coin.png");
   }

   public ResourceLocation c(cc var1) {
      return new ResourceLocation("velvet", "animations/galath/galath_coin.animation.json");
   }
}
