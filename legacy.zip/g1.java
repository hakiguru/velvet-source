package org.velvet;

@FunctionalInterface
public interface g1 {
   boolean a(f_ var1);
}
