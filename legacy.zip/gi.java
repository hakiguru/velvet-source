package org.velvet;

import com.google.common.base.Optional;
import java.util.UUID;
import net.minecraft.entity.Entity;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class gi extends Entity {
   public static final int m = 15;
   private static final DataParameter<Integer> g = EntityDataManager.func_187226_a(gi.class, DataSerializers.field_187192_b).func_187156_b().func_187161_a(111);
   private static final DataParameter<Optional<UUID>> f = EntityDataManager.func_187226_a(gi.class, DataSerializers.field_187203_m)
      .func_187156_b()
      .func_187161_a(110);
   private boolean k;
   private int l;
   private int h;
   public int d;
   private int c;
   private int j;
   private float e;
   public Entity i;
   private gi.a n = gi.a.FLYING;
   private int a;
   private int o;
   public static eb b = null;

   public gi(World var1, eb var2, double var3) {
      super(var1);
      this.a(var2);
      this.a(var3);
   }

   public gi(World var1) {
      super(var1);
   }

   private void a(eb var1) {
      this.func_70105_a(0.25F, 0.25F);
      this.field_70158_ak = true;
      var1.av = this;
   }

   protected void func_70088_a() {
      this.func_184212_Q().func_187214_a(g, 0);
      this.func_184212_Q().func_187214_a(f, Optional.of(b.f()));
   }

   public AxisAlignedBB func_184177_bl() {
      return this.func_174813_aQ().func_186662_g(10.0);
   }

   eb b() {
      Optional var1 = (Optional)this.field_70180_af.func_187225_a(f);

      try {
         if (!var1.isPresent()) {
            return null;
         }
      } catch (RuntimeException var5) {
         throw a(var5);
      }

      em var2 = em.a((UUID)var1.get());

      try {
         if (var2 == null) {
            return null;
         }
      } catch (RuntimeException var3) {
         throw a(var3);
      }

      try {
         if (!(var2 instanceof eb)) {
            return null;
         }
      } catch (RuntimeException var4) {
         throw a(var4);
      }

      return (eb)var2;
   }

   eb g() {
      Optional var1 = (Optional)this.field_70180_af.func_187225_a(f);

      try {
         if (!var1.isPresent()) {
            return null;
         }
      } catch (RuntimeException var4) {
         throw a(var4);
      }

      em var2 = em.b((UUID)var1.get());

      try {
         if (!(var2 instanceof eb)) {
            return null;
         }
      } catch (RuntimeException var3) {
         throw a(var3);
      }

      return (eb)var2;
   }

   public void b(int var1) {
      this.o = var1;
   }

   public void a(int var1) {
      this.a = var1;
   }

   public void func_70030_z() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 00: aload 0
      // 01: invokespecial net/minecraft/entity/Entity.func_70030_z ()V
      // 04: aload 0
      // 05: getfield com/trolmastercard/velvet/gi.field_70170_p Lnet/minecraft/world/World;
      // 08: getfield net/minecraft/world/World.field_72995_K Z
      // 0b: ifeq 13
      // 0e: return
      // 0f: invokestatic com/trolmastercard/velvet/gi.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 12: athrow
      // 13: aload 0
      // 14: getfield com/trolmastercard/velvet/gi.i Lnet/minecraft/entity/Entity;
      // 17: ifnonnull 28
      // 1a: aload 0
      // 1b: getfield com/trolmastercard/velvet/gi.field_70122_E Z
      // 1e: ifeq 44
      // 21: goto 28
      // 24: invokestatic com/trolmastercard/velvet/gi.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 27: athrow
      // 28: aload 0
      // 29: getfield com/trolmastercard/velvet/gi.d I
      // 2c: ifne 44
      // 2f: goto 36
      // 32: invokestatic com/trolmastercard/velvet/gi.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 35: athrow
      // 36: aload 0
      // 37: invokevirtual com/trolmastercard/velvet/gi.b ()Lcom/trolmastercard/velvet/eb;
      // 3a: invokevirtual com/trolmastercard/velvet/eb.o ()V
      // 3d: goto 44
      // 40: invokestatic com/trolmastercard/velvet/gi.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 43: athrow
      // 44: return
      // try (0 -> 7): 7 java/lang/RuntimeException
      // try (9 -> 15): 16 java/lang/RuntimeException
      // try (12 -> 21): 22 java/lang/RuntimeException
      // try (18 -> 27): 28 java/lang/RuntimeException
   }

   public void a(double var1) {
      eb var3 = this.b();

      try {
         if (var3 == null) {
            return;
         }
      } catch (RuntimeException var20) {
         throw a(var20);
      }

      BlockPos var4 = var3.ai;
      float var5 = (float)Math.sqrt(var3.func_174791_d().func_186679_c(var4.func_177958_n(), var4.func_177956_o(), var4.func_177952_p()));
      float var6 = -22.5F + 45.0F * (var5 / 7.0F);
      float var7 = var3.I();
      float var8 = MathHelper.func_76134_b(-var7 * (float) (Math.PI / 180.0) - (float) Math.PI);
      float var9 = MathHelper.func_76126_a(-var7 * (float) (Math.PI / 180.0) - (float) Math.PI);
      float var10 = -MathHelper.func_76134_b(-var6 * (float) (Math.PI / 180.0));
      float var11 = MathHelper.func_76126_a(-var6 * (float) (Math.PI / 180.0));
      double var12 = var3.field_70169_q + (var3.field_70165_t - var3.field_70169_q) - var9 * 0.3;
      double var14 = var3.field_70167_r + (var3.field_70163_u - var3.field_70167_r) + var3.func_70047_e();
      double var16 = var3.field_70166_s + (var3.field_70161_v - var3.field_70166_s) - var8 * 0.3;
      this.func_70012_b(var12, var14, var16, var7, var6);
      this.field_70159_w = var1 * -var9;
      this.field_70181_x = var1 * MathHelper.func_76131_a(-(var11 / var10), -5.0F, 5.0F);
      this.field_70179_y = var1 * -var8;
      float var18 = MathHelper.func_76133_a(
         this.field_70159_w * this.field_70159_w + this.field_70181_x * this.field_70181_x + this.field_70179_y * this.field_70179_y
      );
      this.field_70159_w = this.field_70159_w * (0.6 / var18 + 0.5 + this.field_70146_Z.nextGaussian() * 0.0045);
      this.field_70181_x = this.field_70181_x * (0.6 / var18 + 0.5 + this.field_70146_Z.nextGaussian() * 0.0045);
      this.field_70179_y = this.field_70179_y * (0.6 / var18 + 0.5 + this.field_70146_Z.nextGaussian() * 0.0045);
      float var19 = MathHelper.func_76133_a(this.field_70159_w * this.field_70159_w + this.field_70179_y * this.field_70179_y);
      this.field_70177_z = (float)(MathHelper.func_181159_b(this.field_70159_w, this.field_70179_y) * (180.0 / Math.PI));
      this.field_70125_A = (float)(MathHelper.func_181159_b(this.field_70181_x, var19) * (180.0 / Math.PI));
      this.field_70126_B = this.field_70177_z;
      this.field_70127_C = this.field_70125_A;
   }

   public void func_184206_a(DataParameter<?> var1) {
      if (g.equals(var1)) {
         int var2 = (Integer)this.func_184212_Q().func_187225_a(g);

         gi var10000;
         Entity var10001;
         label19: {
            try {
               var10000 = this;
               if (var2 > 0) {
                  var10001 = this.field_70170_p.func_73045_a(var2 - 1);
                  break label19;
               }
            } catch (RuntimeException var3) {
               throw a(var3);
            }

            var10001 = null;
         }

         var10000.i = var10001;
      }

      super.func_184206_a(var1);
   }

   @SideOnly(Side.CLIENT)
   public boolean func_70112_a(double var1) {
      double var3 = 64.0;

      try {
         if (var1 < 4096.0) {
            return true;
         }
      } catch (RuntimeException var5) {
         throw a(var5);
      }

      return false;
   }

   @SideOnly(Side.CLIENT)
   public void func_180426_a(double var1, double var3, double var5, float var7, float var8, int var9, boolean var10) {
   }

   public void func_70071_h_() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 000: aload 0
      // 001: invokespecial net/minecraft/entity/Entity.func_70071_h_ ()V
      // 004: aload 0
      // 005: invokevirtual com/trolmastercard/velvet/gi.b ()Lcom/trolmastercard/velvet/eb;
      // 008: ifnonnull 016
      // 00b: aload 0
      // 00c: invokevirtual com/trolmastercard/velvet/gi.func_70106_y ()V
      // 00f: goto 2cf
      // 012: invokestatic com/trolmastercard/velvet/gi.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 015: athrow
      // 016: aload 0
      // 017: getfield com/trolmastercard/velvet/gi.field_70170_p Lnet/minecraft/world/World;
      // 01a: getfield net/minecraft/world/World.field_72995_K Z
      // 01d: ifne 02e
      // 020: aload 0
      // 021: invokespecial com/trolmastercard/velvet/gi.f ()Z
      // 024: ifne 2cf
      // 027: goto 02e
      // 02a: invokestatic com/trolmastercard/velvet/gi.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 02d: athrow
      // 02e: aload 0
      // 02f: getfield com/trolmastercard/velvet/gi.k Z
      // 032: ifeq 060
      // 035: goto 03c
      // 038: invokestatic com/trolmastercard/velvet/gi.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 03b: athrow
      // 03c: aload 0
      // 03d: dup
      // 03e: getfield com/trolmastercard/velvet/gi.l I
      // 041: bipush 1
      // 042: iadd
      // 043: putfield com/trolmastercard/velvet/gi.l I
      // 046: aload 0
      // 047: getfield com/trolmastercard/velvet/gi.l I
      // 04a: sipush 1200
      // 04d: if_icmplt 060
      // 050: goto 057
      // 053: invokestatic com/trolmastercard/velvet/gi.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 056: athrow
      // 057: aload 0
      // 058: invokevirtual com/trolmastercard/velvet/gi.func_70106_y ()V
      // 05b: return
      // 05c: invokestatic com/trolmastercard/velvet/gi.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 05f: athrow
      // 060: fconst_0
      // 061: fstore 1
      // 062: new net/minecraft/util/math/BlockPos
      // 065: dup
      // 066: aload 0
      // 067: invokespecial net/minecraft/util/math/BlockPos.<init> (Lnet/minecraft/entity/Entity;)V
      // 06a: astore 2
      // 06b: aload 0
      // 06c: getfield com/trolmastercard/velvet/gi.field_70170_p Lnet/minecraft/world/World;
      // 06f: aload 2
      // 070: invokevirtual net/minecraft/world/World.func_180495_p (Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/state/IBlockState;
      // 073: astore 3
      // 074: aload 3
      // 075: invokeinterface net/minecraft/block/state/IBlockState.func_185904_a ()Lnet/minecraft/block/material/Material; 1
      // 07a: getstatic net/minecraft/block/material/Material.field_151586_h Lnet/minecraft/block/material/Material;
      // 07d: if_acmpne 08a
      // 080: aload 3
      // 081: aload 0
      // 082: getfield com/trolmastercard/velvet/gi.field_70170_p Lnet/minecraft/world/World;
      // 085: aload 2
      // 086: invokestatic net/minecraft/block/BlockLiquid.func_190973_f (Lnet/minecraft/block/state/IBlockState;Lnet/minecraft/world/IBlockAccess;Lnet/minecraft/util/math/BlockPos;)F
      // 089: fstore 1
      // 08a: aload 0
      // 08b: getfield com/trolmastercard/velvet/gi.n Lcom/trolmastercard/velvet/gi$a;
      // 08e: getstatic com/trolmastercard/velvet/gi$a.FLYING Lcom/trolmastercard/velvet/gi$a;
      // 091: if_acmpne 153
      // 094: aload 0
      // 095: getfield com/trolmastercard/velvet/gi.i Lnet/minecraft/entity/Entity;
      // 098: ifnull 0bd
      // 09b: goto 0a2
      // 09e: invokestatic com/trolmastercard/velvet/gi.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 0a1: athrow
      // 0a2: aload 0
      // 0a3: dconst_0
      // 0a4: putfield com/trolmastercard/velvet/gi.field_70159_w D
      // 0a7: aload 0
      // 0a8: dconst_0
      // 0a9: putfield com/trolmastercard/velvet/gi.field_70181_x D
      // 0ac: aload 0
      // 0ad: dconst_0
      // 0ae: putfield com/trolmastercard/velvet/gi.field_70179_y D
      // 0b1: aload 0
      // 0b2: getstatic com/trolmastercard/velvet/gi$a.HOOKED_IN_ENTITY Lcom/trolmastercard/velvet/gi$a;
      // 0b5: putfield com/trolmastercard/velvet/gi.n Lcom/trolmastercard/velvet/gi$a;
      // 0b8: return
      // 0b9: invokestatic com/trolmastercard/velvet/gi.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 0bc: athrow
      // 0bd: fload 1
      // 0be: fconst_0
      // 0bf: fcmpl
      // 0c0: ifle 0f3
      // 0c3: aload 0
      // 0c4: dup
      // 0c5: getfield com/trolmastercard/velvet/gi.field_70159_w D
      // 0c8: ldc2_w 0.3
      // 0cb: dmul
      // 0cc: putfield com/trolmastercard/velvet/gi.field_70159_w D
      // 0cf: aload 0
      // 0d0: dup
      // 0d1: getfield com/trolmastercard/velvet/gi.field_70181_x D
      // 0d4: ldc2_w 0.2
      // 0d7: dmul
      // 0d8: putfield com/trolmastercard/velvet/gi.field_70181_x D
      // 0db: aload 0
      // 0dc: dup
      // 0dd: getfield com/trolmastercard/velvet/gi.field_70179_y D
      // 0e0: ldc2_w 0.3
      // 0e3: dmul
      // 0e4: putfield com/trolmastercard/velvet/gi.field_70179_y D
      // 0e7: aload 0
      // 0e8: getstatic com/trolmastercard/velvet/gi$a.BOBBING Lcom/trolmastercard/velvet/gi$a;
      // 0eb: putfield com/trolmastercard/velvet/gi.n Lcom/trolmastercard/velvet/gi$a;
      // 0ee: return
      // 0ef: invokestatic com/trolmastercard/velvet/gi.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 0f2: athrow
      // 0f3: aload 0
      // 0f4: getfield com/trolmastercard/velvet/gi.field_70170_p Lnet/minecraft/world/World;
      // 0f7: getfield net/minecraft/world/World.field_72995_K Z
      // 0fa: ifne 108
      // 0fd: aload 0
      // 0fe: invokespecial com/trolmastercard/velvet/gi.e ()V
      // 101: goto 108
      // 104: invokestatic com/trolmastercard/velvet/gi.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 107: athrow
      // 108: aload 0
      // 109: getfield com/trolmastercard/velvet/gi.k Z
      // 10c: ifne 13c
      // 10f: aload 0
      // 110: getfield com/trolmastercard/velvet/gi.field_70122_E Z
      // 113: ifne 13c
      // 116: goto 11d
      // 119: invokestatic com/trolmastercard/velvet/gi.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 11c: athrow
      // 11d: aload 0
      // 11e: getfield com/trolmastercard/velvet/gi.field_70123_F Z
      // 121: ifne 13c
      // 124: goto 12b
      // 127: invokestatic com/trolmastercard/velvet/gi.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 12a: athrow
      // 12b: aload 0
      // 12c: dup
      // 12d: getfield com/trolmastercard/velvet/gi.h I
      // 130: bipush 1
      // 131: iadd
      // 132: putfield com/trolmastercard/velvet/gi.h I
      // 135: goto 260
      // 138: invokestatic com/trolmastercard/velvet/gi.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 13b: athrow
      // 13c: aload 0
      // 13d: bipush 0
      // 13e: putfield com/trolmastercard/velvet/gi.h I
      // 141: aload 0
      // 142: dconst_0
      // 143: putfield com/trolmastercard/velvet/gi.field_70159_w D
      // 146: aload 0
      // 147: dconst_0
      // 148: putfield com/trolmastercard/velvet/gi.field_70181_x D
      // 14b: aload 0
      // 14c: dconst_0
      // 14d: putfield com/trolmastercard/velvet/gi.field_70179_y D
      // 150: goto 260
      // 153: aload 0
      // 154: getfield com/trolmastercard/velvet/gi.n Lcom/trolmastercard/velvet/gi$a;
      // 157: getstatic com/trolmastercard/velvet/gi$a.HOOKED_IN_ENTITY Lcom/trolmastercard/velvet/gi$a;
      // 15a: if_acmpne 1d5
      // 15d: aload 0
      // 15e: getfield com/trolmastercard/velvet/gi.i Lnet/minecraft/entity/Entity;
      // 161: ifnull 1d4
      // 164: goto 16b
      // 167: invokestatic com/trolmastercard/velvet/gi.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 16a: athrow
      // 16b: aload 0
      // 16c: getfield com/trolmastercard/velvet/gi.i Lnet/minecraft/entity/Entity;
      // 16f: getfield net/minecraft/entity/Entity.field_70128_L Z
      // 172: ifeq 18f
      // 175: goto 17c
      // 178: invokestatic com/trolmastercard/velvet/gi.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 17b: athrow
      // 17c: aload 0
      // 17d: aconst_null
      // 17e: putfield com/trolmastercard/velvet/gi.i Lnet/minecraft/entity/Entity;
      // 181: aload 0
      // 182: getstatic com/trolmastercard/velvet/gi$a.FLYING Lcom/trolmastercard/velvet/gi$a;
      // 185: putfield com/trolmastercard/velvet/gi.n Lcom/trolmastercard/velvet/gi$a;
      // 188: goto 1d4
      // 18b: invokestatic com/trolmastercard/velvet/gi.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 18e: athrow
      // 18f: aload 0
      // 190: aload 0
      // 191: getfield com/trolmastercard/velvet/gi.i Lnet/minecraft/entity/Entity;
      // 194: getfield net/minecraft/entity/Entity.field_70165_t D
      // 197: putfield com/trolmastercard/velvet/gi.field_70165_t D
      // 19a: aload 0
      // 19b: getfield com/trolmastercard/velvet/gi.i Lnet/minecraft/entity/Entity;
      // 19e: getfield net/minecraft/entity/Entity.field_70131_O F
      // 1a1: f2d
      // 1a2: dstore 4
      // 1a4: aload 0
      // 1a5: aload 0
      // 1a6: getfield com/trolmastercard/velvet/gi.i Lnet/minecraft/entity/Entity;
      // 1a9: invokevirtual net/minecraft/entity/Entity.func_174813_aQ ()Lnet/minecraft/util/math/AxisAlignedBB;
      // 1ac: getfield net/minecraft/util/math/AxisAlignedBB.field_72338_b D
      // 1af: dload 4
      // 1b1: ldc2_w 0.8
      // 1b4: dmul
      // 1b5: dadd
      // 1b6: putfield com/trolmastercard/velvet/gi.field_70163_u D
      // 1b9: aload 0
      // 1ba: aload 0
      // 1bb: getfield com/trolmastercard/velvet/gi.i Lnet/minecraft/entity/Entity;
      // 1be: getfield net/minecraft/entity/Entity.field_70161_v D
      // 1c1: putfield com/trolmastercard/velvet/gi.field_70161_v D
      // 1c4: aload 0
      // 1c5: aload 0
      // 1c6: getfield com/trolmastercard/velvet/gi.field_70165_t D
      // 1c9: aload 0
      // 1ca: getfield com/trolmastercard/velvet/gi.field_70163_u D
      // 1cd: aload 0
      // 1ce: getfield com/trolmastercard/velvet/gi.field_70161_v D
      // 1d1: invokevirtual com/trolmastercard/velvet/gi.func_70107_b (DDD)V
      // 1d4: return
      // 1d5: aload 0
      // 1d6: getfield com/trolmastercard/velvet/gi.n Lcom/trolmastercard/velvet/gi$a;
      // 1d9: getstatic com/trolmastercard/velvet/gi$a.BOBBING Lcom/trolmastercard/velvet/gi$a;
      // 1dc: if_acmpne 260
      // 1df: aload 0
      // 1e0: dup
      // 1e1: getfield com/trolmastercard/velvet/gi.field_70159_w D
      // 1e4: ldc2_w 0.9
      // 1e7: dmul
      // 1e8: putfield com/trolmastercard/velvet/gi.field_70159_w D
      // 1eb: aload 0
      // 1ec: dup
      // 1ed: getfield com/trolmastercard/velvet/gi.field_70179_y D
      // 1f0: ldc2_w 0.9
      // 1f3: dmul
      // 1f4: putfield com/trolmastercard/velvet/gi.field_70179_y D
      // 1f7: aload 0
      // 1f8: getfield com/trolmastercard/velvet/gi.field_70163_u D
      // 1fb: aload 0
      // 1fc: getfield com/trolmastercard/velvet/gi.field_70181_x D
      // 1ff: dadd
      // 200: aload 2
      // 201: invokevirtual net/minecraft/util/math/BlockPos.func_177956_o ()I
      // 204: i2d
      // 205: dsub
      // 206: fload 1
      // 207: f2d
      // 208: dsub
      // 209: dstore 4
      // 20b: dload 4
      // 20d: invokestatic java/lang/Math.abs (D)D
      // 210: ldc2_w 0.01
      // 213: dcmpg
      // 214: ifge 225
      // 217: dload 4
      // 219: dload 4
      // 21b: invokestatic java/lang/Math.signum (D)D
      // 21e: ldc2_w 0.1
      // 221: dmul
      // 222: dadd
      // 223: dstore 4
      // 225: aload 0
      // 226: dup
      // 227: getfield com/trolmastercard/velvet/gi.field_70181_x D
      // 22a: dload 4
      // 22c: aload 0
      // 22d: getfield com/trolmastercard/velvet/gi.field_70146_Z Ljava/util/Random;
      // 230: invokevirtual java/util/Random.nextFloat ()F
      // 233: f2d
      // 234: dmul
      // 235: ldc2_w 0.2
      // 238: dmul
      // 239: dsub
      // 23a: putfield com/trolmastercard/velvet/gi.field_70181_x D
      // 23d: aload 0
      // 23e: getfield com/trolmastercard/velvet/gi.field_70170_p Lnet/minecraft/world/World;
      // 241: getfield net/minecraft/world/World.field_72995_K Z
      // 244: ifne 260
      // 247: fload 1
      // 248: fconst_0
      // 249: fcmpl
      // 24a: ifle 260
      // 24d: goto 254
      // 250: invokestatic com/trolmastercard/velvet/gi.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 253: athrow
      // 254: aload 0
      // 255: aload 2
      // 256: invokespecial com/trolmastercard/velvet/gi.a (Lnet/minecraft/util/math/BlockPos;)V
      // 259: goto 260
      // 25c: invokestatic com/trolmastercard/velvet/gi.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 25f: athrow
      // 260: aload 3
      // 261: invokeinterface net/minecraft/block/state/IBlockState.func_185904_a ()Lnet/minecraft/block/material/Material; 1
      // 266: getstatic net/minecraft/block/material/Material.field_151586_h Lnet/minecraft/block/material/Material;
      // 269: if_acmpeq 27f
      // 26c: aload 0
      // 26d: dup
      // 26e: getfield com/trolmastercard/velvet/gi.field_70181_x D
      // 271: ldc2_w 0.03
      // 274: dsub
      // 275: putfield com/trolmastercard/velvet/gi.field_70181_x D
      // 278: goto 27f
      // 27b: invokestatic com/trolmastercard/velvet/gi.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 27e: athrow
      // 27f: aload 0
      // 280: getstatic net/minecraft/entity/MoverType.SELF Lnet/minecraft/entity/MoverType;
      // 283: aload 0
      // 284: getfield com/trolmastercard/velvet/gi.field_70159_w D
      // 287: aload 0
      // 288: getfield com/trolmastercard/velvet/gi.field_70181_x D
      // 28b: aload 0
      // 28c: getfield com/trolmastercard/velvet/gi.field_70179_y D
      // 28f: invokevirtual com/trolmastercard/velvet/gi.func_70091_d (Lnet/minecraft/entity/MoverType;DDD)V
      // 292: aload 0
      // 293: invokespecial com/trolmastercard/velvet/gi.h ()V
      // 296: ldc2_w 0.92
      // 299: dstore 4
      // 29b: aload 0
      // 29c: dup
      // 29d: getfield com/trolmastercard/velvet/gi.field_70159_w D
      // 2a0: ldc2_w 0.92
      // 2a3: dmul
      // 2a4: putfield com/trolmastercard/velvet/gi.field_70159_w D
      // 2a7: aload 0
      // 2a8: dup
      // 2a9: getfield com/trolmastercard/velvet/gi.field_70181_x D
      // 2ac: ldc2_w 0.92
      // 2af: dmul
      // 2b0: putfield com/trolmastercard/velvet/gi.field_70181_x D
      // 2b3: aload 0
      // 2b4: dup
      // 2b5: getfield com/trolmastercard/velvet/gi.field_70179_y D
      // 2b8: ldc2_w 0.92
      // 2bb: dmul
      // 2bc: putfield com/trolmastercard/velvet/gi.field_70179_y D
      // 2bf: aload 0
      // 2c0: aload 0
      // 2c1: getfield com/trolmastercard/velvet/gi.field_70165_t D
      // 2c4: aload 0
      // 2c5: getfield com/trolmastercard/velvet/gi.field_70163_u D
      // 2c8: aload 0
      // 2c9: getfield com/trolmastercard/velvet/gi.field_70161_v D
      // 2cc: invokevirtual com/trolmastercard/velvet/gi.func_70107_b (DDD)V
      // 2cf: return
      // try (0 -> 8): 8 java/lang/RuntimeException
      // try (10 -> 17): 18 java/lang/RuntimeException
      // try (14 -> 23): 24 java/lang/RuntimeException
      // try (20 -> 36): 37 java/lang/RuntimeException
      // try (26 -> 42): 42 java/lang/RuntimeException
      // try (66 -> 73): 74 java/lang/RuntimeException
      // try (70 -> 89): 89 java/lang/RuntimeException
      // try (91 -> 117): 117 java/lang/RuntimeException
      // try (119 -> 125): 126 java/lang/RuntimeException
      // try (128 -> 134): 135 java/lang/RuntimeException
      // try (131 -> 140): 141 java/lang/RuntimeException
      // try (137 -> 150): 150 java/lang/RuntimeException
      // try (165 -> 172): 173 java/lang/RuntimeException
      // try (169 -> 179): 180 java/lang/RuntimeException
      // try (175 -> 189): 189 java/lang/RuntimeException
      // try (266 -> 287): 288 java/lang/RuntimeException
      // try (283 -> 293): 294 java/lang/RuntimeException
      // try (296 -> 306): 307 java/lang/RuntimeException
   }

   private boolean f() {
      return false;
   }

   private void h() {
      float var1 = MathHelper.func_76133_a(this.field_70159_w * this.field_70159_w + this.field_70179_y * this.field_70179_y);
      this.field_70177_z = (float)(MathHelper.func_181159_b(this.field_70159_w, this.field_70179_y) * (180.0 / Math.PI));
      this.field_70125_A = (float)(MathHelper.func_181159_b(this.field_70181_x, var1) * (180.0 / Math.PI));

      try {
         while (this.field_70125_A - this.field_70127_C < -180.0F) {
            this.field_70127_C -= 360.0F;
         }
      } catch (RuntimeException var5) {
         throw a(var5);
      }

      try {
         while (this.field_70125_A - this.field_70127_C >= 180.0F) {
            this.field_70127_C += 360.0F;
         }
      } catch (RuntimeException var4) {
         throw a(var4);
      }

      try {
         while (this.field_70177_z - this.field_70126_B < -180.0F) {
            this.field_70126_B -= 360.0F;
         }
      } catch (RuntimeException var3) {
         throw a(var3);
      }

      try {
         while (this.field_70177_z - this.field_70126_B >= 180.0F) {
            this.field_70126_B += 360.0F;
         }
      } catch (RuntimeException var2) {
         throw a(var2);
      }

      this.field_70125_A = this.field_70127_C + (this.field_70125_A - this.field_70127_C) * 0.2F;
      this.field_70177_z = this.field_70126_B + (this.field_70177_z - this.field_70126_B) * 0.2F;
   }

   private void e() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 000: new net/minecraft/util/math/Vec3d
      // 003: dup
      // 004: aload 0
      // 005: getfield com/trolmastercard/velvet/gi.field_70165_t D
      // 008: aload 0
      // 009: getfield com/trolmastercard/velvet/gi.field_70163_u D
      // 00c: aload 0
      // 00d: getfield com/trolmastercard/velvet/gi.field_70161_v D
      // 010: invokespecial net/minecraft/util/math/Vec3d.<init> (DDD)V
      // 013: astore 1
      // 014: new net/minecraft/util/math/Vec3d
      // 017: dup
      // 018: aload 0
      // 019: getfield com/trolmastercard/velvet/gi.field_70165_t D
      // 01c: aload 0
      // 01d: getfield com/trolmastercard/velvet/gi.field_70159_w D
      // 020: dadd
      // 021: aload 0
      // 022: getfield com/trolmastercard/velvet/gi.field_70163_u D
      // 025: aload 0
      // 026: getfield com/trolmastercard/velvet/gi.field_70181_x D
      // 029: dadd
      // 02a: aload 0
      // 02b: getfield com/trolmastercard/velvet/gi.field_70161_v D
      // 02e: aload 0
      // 02f: getfield com/trolmastercard/velvet/gi.field_70179_y D
      // 032: dadd
      // 033: invokespecial net/minecraft/util/math/Vec3d.<init> (DDD)V
      // 036: astore 2
      // 037: aload 0
      // 038: getfield com/trolmastercard/velvet/gi.field_70170_p Lnet/minecraft/world/World;
      // 03b: aload 1
      // 03c: aload 2
      // 03d: bipush 0
      // 03e: bipush 1
      // 03f: bipush 0
      // 040: invokevirtual net/minecraft/world/World.func_147447_a (Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/math/Vec3d;ZZZ)Lnet/minecraft/util/math/RayTraceResult;
      // 043: astore 3
      // 044: new net/minecraft/util/math/Vec3d
      // 047: dup
      // 048: aload 0
      // 049: getfield com/trolmastercard/velvet/gi.field_70165_t D
      // 04c: aload 0
      // 04d: getfield com/trolmastercard/velvet/gi.field_70163_u D
      // 050: aload 0
      // 051: getfield com/trolmastercard/velvet/gi.field_70161_v D
      // 054: invokespecial net/minecraft/util/math/Vec3d.<init> (DDD)V
      // 057: astore 1
      // 058: new net/minecraft/util/math/Vec3d
      // 05b: dup
      // 05c: aload 0
      // 05d: getfield com/trolmastercard/velvet/gi.field_70165_t D
      // 060: aload 0
      // 061: getfield com/trolmastercard/velvet/gi.field_70159_w D
      // 064: dadd
      // 065: aload 0
      // 066: getfield com/trolmastercard/velvet/gi.field_70163_u D
      // 069: aload 0
      // 06a: getfield com/trolmastercard/velvet/gi.field_70181_x D
      // 06d: dadd
      // 06e: aload 0
      // 06f: getfield com/trolmastercard/velvet/gi.field_70161_v D
      // 072: aload 0
      // 073: getfield com/trolmastercard/velvet/gi.field_70179_y D
      // 076: dadd
      // 077: invokespecial net/minecraft/util/math/Vec3d.<init> (DDD)V
      // 07a: astore 2
      // 07b: aload 3
      // 07c: ifnull 09c
      // 07f: new net/minecraft/util/math/Vec3d
      // 082: dup
      // 083: aload 3
      // 084: getfield net/minecraft/util/math/RayTraceResult.field_72307_f Lnet/minecraft/util/math/Vec3d;
      // 087: getfield net/minecraft/util/math/Vec3d.field_72450_a D
      // 08a: aload 3
      // 08b: getfield net/minecraft/util/math/RayTraceResult.field_72307_f Lnet/minecraft/util/math/Vec3d;
      // 08e: getfield net/minecraft/util/math/Vec3d.field_72448_b D
      // 091: aload 3
      // 092: getfield net/minecraft/util/math/RayTraceResult.field_72307_f Lnet/minecraft/util/math/Vec3d;
      // 095: getfield net/minecraft/util/math/Vec3d.field_72449_c D
      // 098: invokespecial net/minecraft/util/math/Vec3d.<init> (DDD)V
      // 09b: astore 2
      // 09c: aconst_null
      // 09d: astore 4
      // 09f: aload 0
      // 0a0: getfield com/trolmastercard/velvet/gi.field_70170_p Lnet/minecraft/world/World;
      // 0a3: aload 0
      // 0a4: aload 0
      // 0a5: invokevirtual com/trolmastercard/velvet/gi.func_174813_aQ ()Lnet/minecraft/util/math/AxisAlignedBB;
      // 0a8: aload 0
      // 0a9: getfield com/trolmastercard/velvet/gi.field_70159_w D
      // 0ac: aload 0
      // 0ad: getfield com/trolmastercard/velvet/gi.field_70181_x D
      // 0b0: aload 0
      // 0b1: getfield com/trolmastercard/velvet/gi.field_70179_y D
      // 0b4: invokevirtual net/minecraft/util/math/AxisAlignedBB.func_72321_a (DDD)Lnet/minecraft/util/math/AxisAlignedBB;
      // 0b7: dconst_1
      // 0b8: invokevirtual net/minecraft/util/math/AxisAlignedBB.func_186662_g (D)Lnet/minecraft/util/math/AxisAlignedBB;
      // 0bb: invokevirtual net/minecraft/world/World.func_72839_b (Lnet/minecraft/entity/Entity;Lnet/minecraft/util/math/AxisAlignedBB;)Ljava/util/List;
      // 0be: astore 5
      // 0c0: dconst_0
      // 0c1: dstore 6
      // 0c3: aload 5
      // 0c5: invokeinterface java/util/List.iterator ()Ljava/util/Iterator; 1
      // 0ca: astore 8
      // 0cc: aload 8
      // 0ce: invokeinterface java/util/Iterator.hasNext ()Z 1
      // 0d3: ifeq 151
      // 0d6: aload 8
      // 0d8: invokeinterface java/util/Iterator.next ()Ljava/lang/Object; 1
      // 0dd: checkcast net/minecraft/entity/Entity
      // 0e0: astore 9
      // 0e2: aload 0
      // 0e3: aload 9
      // 0e5: invokevirtual com/trolmastercard/velvet/gi.a (Lnet/minecraft/entity/Entity;)Z
      // 0e8: ifeq 14e
      // 0eb: aload 9
      // 0ed: aload 0
      // 0ee: invokevirtual com/trolmastercard/velvet/gi.b ()Lcom/trolmastercard/velvet/eb;
      // 0f1: if_acmpne 10a
      // 0f4: goto 0fb
      // 0f7: invokestatic com/trolmastercard/velvet/gi.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 0fa: athrow
      // 0fb: aload 0
      // 0fc: getfield com/trolmastercard/velvet/gi.h I
      // 0ff: bipush 5
      // 100: if_icmplt 14e
      // 103: goto 10a
      // 106: invokestatic com/trolmastercard/velvet/gi.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 109: athrow
      // 10a: aload 9
      // 10c: invokevirtual net/minecraft/entity/Entity.func_174813_aQ ()Lnet/minecraft/util/math/AxisAlignedBB;
      // 10f: ldc2_w 0.30000001192092896
      // 112: invokevirtual net/minecraft/util/math/AxisAlignedBB.func_186662_g (D)Lnet/minecraft/util/math/AxisAlignedBB;
      // 115: astore 10
      // 117: aload 10
      // 119: aload 1
      // 11a: aload 2
      // 11b: invokevirtual net/minecraft/util/math/AxisAlignedBB.func_72327_a (Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/math/Vec3d;)Lnet/minecraft/util/math/RayTraceResult;
      // 11e: astore 11
      // 120: aload 11
      // 122: ifnull 14e
      // 125: aload 1
      // 126: aload 11
      // 128: getfield net/minecraft/util/math/RayTraceResult.field_72307_f Lnet/minecraft/util/math/Vec3d;
      // 12b: invokevirtual net/minecraft/util/math/Vec3d.func_72436_e (Lnet/minecraft/util/math/Vec3d;)D
      // 12e: dstore 12
      // 130: dload 12
      // 132: dload 6
      // 134: dcmpg
      // 135: iflt 146
      // 138: dload 6
      // 13a: dconst_0
      // 13b: dcmpl
      // 13c: ifne 14e
      // 13f: goto 146
      // 142: invokestatic com/trolmastercard/velvet/gi.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 145: athrow
      // 146: aload 9
      // 148: astore 4
      // 14a: dload 12
      // 14c: dstore 6
      // 14e: goto 0cc
      // 151: aload 4
      // 153: ifnull 160
      // 156: new net/minecraft/util/math/RayTraceResult
      // 159: dup
      // 15a: aload 4
      // 15c: invokespecial net/minecraft/util/math/RayTraceResult.<init> (Lnet/minecraft/entity/Entity;)V
      // 15f: astore 3
      // 160: aload 3
      // 161: ifnull 19e
      // 164: aload 3
      // 165: getfield net/minecraft/util/math/RayTraceResult.field_72313_a Lnet/minecraft/util/math/RayTraceResult$Type;
      // 168: getstatic net/minecraft/util/math/RayTraceResult$Type.MISS Lnet/minecraft/util/math/RayTraceResult$Type;
      // 16b: if_acmpeq 19e
      // 16e: goto 175
      // 171: invokestatic com/trolmastercard/velvet/gi.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 174: athrow
      // 175: aload 3
      // 176: getfield net/minecraft/util/math/RayTraceResult.field_72313_a Lnet/minecraft/util/math/RayTraceResult$Type;
      // 179: getstatic net/minecraft/util/math/RayTraceResult$Type.ENTITY Lnet/minecraft/util/math/RayTraceResult$Type;
      // 17c: if_acmpne 199
      // 17f: goto 186
      // 182: invokestatic com/trolmastercard/velvet/gi.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 185: athrow
      // 186: aload 0
      // 187: aload 3
      // 188: getfield net/minecraft/util/math/RayTraceResult.field_72308_g Lnet/minecraft/entity/Entity;
      // 18b: putfield com/trolmastercard/velvet/gi.i Lnet/minecraft/entity/Entity;
      // 18e: aload 0
      // 18f: invokespecial com/trolmastercard/velvet/gi.a ()V
      // 192: goto 19e
      // 195: invokestatic com/trolmastercard/velvet/gi.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 198: athrow
      // 199: aload 0
      // 19a: bipush 1
      // 19b: putfield com/trolmastercard/velvet/gi.k Z
      // 19e: return
      // try (112 -> 120): 121 java/lang/RuntimeException
      // try (116 -> 127): 128 java/lang/RuntimeException
      // try (147 -> 155): 156 java/lang/RuntimeException
      // try (170 -> 176): 177 java/lang/RuntimeException
      // try (172 -> 183): 184 java/lang/RuntimeException
      // try (179 -> 193): 193 java/lang/RuntimeException
   }

   private void a() {
      this.func_184212_Q().func_187227_b(g, this.i.func_145782_y() + 1);
   }

   private void a(BlockPos param1) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 000: aload 0
      // 001: getfield com/trolmastercard/velvet/gi.field_70170_p Lnet/minecraft/world/World;
      // 004: checkcast net/minecraft/world/WorldServer
      // 007: astore 2
      // 008: bipush 1
      // 009: istore 3
      // 00a: aload 1
      // 00b: invokevirtual net/minecraft/util/math/BlockPos.func_177984_a ()Lnet/minecraft/util/math/BlockPos;
      // 00e: astore 4
      // 010: aload 0
      // 011: getfield com/trolmastercard/velvet/gi.field_70146_Z Ljava/util/Random;
      // 014: invokevirtual java/util/Random.nextFloat ()F
      // 017: ldc 0.25
      // 019: fcmpg
      // 01a: ifge 03a
      // 01d: aload 0
      // 01e: getfield com/trolmastercard/velvet/gi.field_70170_p Lnet/minecraft/world/World;
      // 021: aload 4
      // 023: invokevirtual net/minecraft/world/World.func_175727_C (Lnet/minecraft/util/math/BlockPos;)Z
      // 026: ifeq 03a
      // 029: goto 030
      // 02c: invokestatic com/trolmastercard/velvet/gi.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 02f: athrow
      // 030: iinc 3 1
      // 033: goto 03a
      // 036: invokestatic com/trolmastercard/velvet/gi.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 039: athrow
      // 03a: aload 0
      // 03b: getfield com/trolmastercard/velvet/gi.field_70146_Z Ljava/util/Random;
      // 03e: invokevirtual java/util/Random.nextFloat ()F
      // 041: ldc_w 0.5
      // 044: fcmpg
      // 045: ifge 065
      // 048: aload 0
      // 049: getfield com/trolmastercard/velvet/gi.field_70170_p Lnet/minecraft/world/World;
      // 04c: aload 4
      // 04e: invokevirtual net/minecraft/world/World.func_175678_i (Lnet/minecraft/util/math/BlockPos;)Z
      // 051: ifne 065
      // 054: goto 05b
      // 057: invokestatic com/trolmastercard/velvet/gi.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 05a: athrow
      // 05b: iinc 3 -1
      // 05e: goto 065
      // 061: invokestatic com/trolmastercard/velvet/gi.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 064: athrow
      // 065: aload 0
      // 066: getfield com/trolmastercard/velvet/gi.d I
      // 069: ifle 0b6
      // 06c: aload 0
      // 06d: dup
      // 06e: getfield com/trolmastercard/velvet/gi.d I
      // 071: bipush 1
      // 072: isub
      // 073: putfield com/trolmastercard/velvet/gi.d I
      // 076: aload 0
      // 077: getfield com/trolmastercard/velvet/gi.d I
      // 07a: ifgt 095
      // 07d: goto 084
      // 080: invokestatic com/trolmastercard/velvet/gi.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 083: athrow
      // 084: aload 0
      // 085: bipush 0
      // 086: putfield com/trolmastercard/velvet/gi.c I
      // 089: aload 0
      // 08a: bipush 0
      // 08b: putfield com/trolmastercard/velvet/gi.j I
      // 08e: goto 400
      // 091: invokestatic com/trolmastercard/velvet/gi.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 094: athrow
      // 095: aload 0
      // 096: dup
      // 097: getfield com/trolmastercard/velvet/gi.field_70181_x D
      // 09a: ldc2_w 0.2
      // 09d: aload 0
      // 09e: getfield com/trolmastercard/velvet/gi.field_70146_Z Ljava/util/Random;
      // 0a1: invokevirtual java/util/Random.nextFloat ()F
      // 0a4: f2d
      // 0a5: dmul
      // 0a6: aload 0
      // 0a7: getfield com/trolmastercard/velvet/gi.field_70146_Z Ljava/util/Random;
      // 0aa: invokevirtual java/util/Random.nextFloat ()F
      // 0ad: f2d
      // 0ae: dmul
      // 0af: dsub
      // 0b0: putfield com/trolmastercard/velvet/gi.field_70181_x D
      // 0b3: goto 400
      // 0b6: aload 0
      // 0b7: getfield com/trolmastercard/velvet/gi.j I
      // 0ba: ifle 28d
      // 0bd: aload 0
      // 0be: dup
      // 0bf: getfield com/trolmastercard/velvet/gi.j I
      // 0c2: iload 3
      // 0c3: isub
      // 0c4: putfield com/trolmastercard/velvet/gi.j I
      // 0c7: aload 0
      // 0c8: getfield com/trolmastercard/velvet/gi.j I
      // 0cb: ifle 1e2
      // 0ce: goto 0d5
      // 0d1: invokestatic com/trolmastercard/velvet/gi.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 0d4: athrow
      // 0d5: aload 0
      // 0d6: aload 0
      // 0d7: getfield com/trolmastercard/velvet/gi.e F
      // 0da: f2d
      // 0db: aload 0
      // 0dc: getfield com/trolmastercard/velvet/gi.field_70146_Z Ljava/util/Random;
      // 0df: invokevirtual java/util/Random.nextGaussian ()D
      // 0e2: ldc2_w 4.0
      // 0e5: dmul
      // 0e6: dadd
      // 0e7: d2f
      // 0e8: putfield com/trolmastercard/velvet/gi.e F
      // 0eb: aload 0
      // 0ec: getfield com/trolmastercard/velvet/gi.e F
      // 0ef: ldc 0.017453292
      // 0f1: fmul
      // 0f2: fstore 5
      // 0f4: fload 5
      // 0f6: invokestatic net/minecraft/util/math/MathHelper.func_76126_a (F)F
      // 0f9: fstore 6
      // 0fb: fload 5
      // 0fd: invokestatic net/minecraft/util/math/MathHelper.func_76134_b (F)F
      // 100: fstore 7
      // 102: aload 0
      // 103: getfield com/trolmastercard/velvet/gi.field_70165_t D
      // 106: fload 6
      // 108: aload 0
      // 109: getfield com/trolmastercard/velvet/gi.j I
      // 10c: i2f
      // 10d: fmul
      // 10e: ldc_w 0.1
      // 111: fmul
      // 112: f2d
      // 113: dadd
      // 114: dstore 8
      // 116: aload 0
      // 117: invokevirtual com/trolmastercard/velvet/gi.func_174813_aQ ()Lnet/minecraft/util/math/AxisAlignedBB;
      // 11a: getfield net/minecraft/util/math/AxisAlignedBB.field_72338_b D
      // 11d: invokestatic net/minecraft/util/math/MathHelper.func_76128_c (D)I
      // 120: i2f
      // 121: fconst_1
      // 122: fadd
      // 123: f2d
      // 124: dstore 10
      // 126: aload 0
      // 127: getfield com/trolmastercard/velvet/gi.field_70161_v D
      // 12a: fload 7
      // 12c: aload 0
      // 12d: getfield com/trolmastercard/velvet/gi.j I
      // 130: i2f
      // 131: fmul
      // 132: ldc_w 0.1
      // 135: fmul
      // 136: f2d
      // 137: dadd
      // 138: dstore 12
      // 13a: aload 2
      // 13b: new net/minecraft/util/math/BlockPos
      // 13e: dup
      // 13f: dload 8
      // 141: dload 10
      // 143: dconst_1
      // 144: dsub
      // 145: dload 12
      // 147: invokespecial net/minecraft/util/math/BlockPos.<init> (DDD)V
      // 14a: invokevirtual net/minecraft/world/WorldServer.func_180495_p (Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/state/IBlockState;
      // 14d: astore 14
      // 14f: aload 14
      // 151: invokeinterface net/minecraft/block/state/IBlockState.func_185904_a ()Lnet/minecraft/block/material/Material; 1
      // 156: getstatic net/minecraft/block/material/Material.field_151586_h Lnet/minecraft/block/material/Material;
      // 159: if_acmpne 1df
      // 15c: aload 0
      // 15d: getfield com/trolmastercard/velvet/gi.field_70146_Z Ljava/util/Random;
      // 160: invokevirtual java/util/Random.nextFloat ()F
      // 163: ldc_w 0.15
      // 166: fcmpg
      // 167: ifge 197
      // 16a: goto 171
      // 16d: invokestatic com/trolmastercard/velvet/gi.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 170: athrow
      // 171: aload 2
      // 172: getstatic net/minecraft/util/EnumParticleTypes.WATER_BUBBLE Lnet/minecraft/util/EnumParticleTypes;
      // 175: dload 8
      // 177: dload 10
      // 179: ldc2_w 0.10000000149011612
      // 17c: dsub
      // 17d: dload 12
      // 17f: bipush 1
      // 180: fload 6
      // 182: f2d
      // 183: ldc2_w 0.1
      // 186: fload 7
      // 188: f2d
      // 189: dconst_0
      // 18a: bipush 0
      // 18b: newarray 10
      // 18d: invokevirtual net/minecraft/world/WorldServer.func_175739_a (Lnet/minecraft/util/EnumParticleTypes;DDDIDDDD[I)V
      // 190: goto 197
      // 193: invokestatic com/trolmastercard/velvet/gi.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 196: athrow
      // 197: fload 6
      // 199: ldc_w 0.04
      // 19c: fmul
      // 19d: fstore 15
      // 19f: fload 7
      // 1a1: ldc_w 0.04
      // 1a4: fmul
      // 1a5: fstore 16
      // 1a7: aload 2
      // 1a8: getstatic net/minecraft/util/EnumParticleTypes.WATER_WAKE Lnet/minecraft/util/EnumParticleTypes;
      // 1ab: dload 8
      // 1ad: dload 10
      // 1af: dload 12
      // 1b1: bipush 0
      // 1b2: fload 16
      // 1b4: f2d
      // 1b5: ldc2_w 0.01
      // 1b8: fload 15
      // 1ba: fneg
      // 1bb: f2d
      // 1bc: dconst_1
      // 1bd: bipush 0
      // 1be: newarray 10
      // 1c0: invokevirtual net/minecraft/world/WorldServer.func_175739_a (Lnet/minecraft/util/EnumParticleTypes;DDDIDDDD[I)V
      // 1c3: aload 2
      // 1c4: getstatic net/minecraft/util/EnumParticleTypes.WATER_WAKE Lnet/minecraft/util/EnumParticleTypes;
      // 1c7: dload 8
      // 1c9: dload 10
      // 1cb: dload 12
      // 1cd: bipush 0
      // 1ce: fload 16
      // 1d0: fneg
      // 1d1: f2d
      // 1d2: ldc2_w 0.01
      // 1d5: fload 15
      // 1d7: f2d
      // 1d8: dconst_1
      // 1d9: bipush 0
      // 1da: newarray 10
      // 1dc: invokevirtual net/minecraft/world/WorldServer.func_175739_a (Lnet/minecraft/util/EnumParticleTypes;DDDIDDDD[I)V
      // 1df: goto 400
      // 1e2: aload 0
      // 1e3: ldc_w -0.4
      // 1e6: aload 0
      // 1e7: getfield com/trolmastercard/velvet/gi.field_70146_Z Ljava/util/Random;
      // 1ea: ldc_w 0.6
      // 1ed: fconst_1
      // 1ee: invokestatic net/minecraft/util/math/MathHelper.func_151240_a (Ljava/util/Random;FF)F
      // 1f1: fmul
      // 1f2: f2d
      // 1f3: putfield com/trolmastercard/velvet/gi.field_70181_x D
      // 1f6: aload 0
      // 1f7: getstatic net/minecraft/init/SoundEvents.field_187609_F Lnet/minecraft/util/SoundEvent;
      // 1fa: ldc 0.25
      // 1fc: fconst_1
      // 1fd: aload 0
      // 1fe: getfield com/trolmastercard/velvet/gi.field_70146_Z Ljava/util/Random;
      // 201: invokevirtual java/util/Random.nextFloat ()F
      // 204: aload 0
      // 205: getfield com/trolmastercard/velvet/gi.field_70146_Z Ljava/util/Random;
      // 208: invokevirtual java/util/Random.nextFloat ()F
      // 20b: fsub
      // 20c: ldc_w 0.4
      // 20f: fmul
      // 210: fadd
      // 211: invokevirtual com/trolmastercard/velvet/gi.func_184185_a (Lnet/minecraft/util/SoundEvent;FF)V
      // 214: aload 0
      // 215: invokevirtual com/trolmastercard/velvet/gi.func_174813_aQ ()Lnet/minecraft/util/math/AxisAlignedBB;
      // 218: getfield net/minecraft/util/math/AxisAlignedBB.field_72338_b D
      // 21b: ldc2_w 0.5
      // 21e: dadd
      // 21f: dstore 5
      // 221: aload 2
      // 222: getstatic net/minecraft/util/EnumParticleTypes.WATER_BUBBLE Lnet/minecraft/util/EnumParticleTypes;
      // 225: aload 0
      // 226: getfield com/trolmastercard/velvet/gi.field_70165_t D
      // 229: dload 5
      // 22b: aload 0
      // 22c: getfield com/trolmastercard/velvet/gi.field_70161_v D
      // 22f: fconst_1
      // 230: aload 0
      // 231: getfield com/trolmastercard/velvet/gi.field_70130_N F
      // 234: ldc_w 20.0
      // 237: fmul
      // 238: fadd
      // 239: f2i
      // 23a: aload 0
      // 23b: getfield com/trolmastercard/velvet/gi.field_70130_N F
      // 23e: f2d
      // 23f: dconst_0
      // 240: aload 0
      // 241: getfield com/trolmastercard/velvet/gi.field_70130_N F
      // 244: f2d
      // 245: ldc2_w 0.20000000298023224
      // 248: bipush 0
      // 249: newarray 10
      // 24b: invokevirtual net/minecraft/world/WorldServer.func_175739_a (Lnet/minecraft/util/EnumParticleTypes;DDDIDDDD[I)V
      // 24e: aload 2
      // 24f: getstatic net/minecraft/util/EnumParticleTypes.WATER_WAKE Lnet/minecraft/util/EnumParticleTypes;
      // 252: aload 0
      // 253: getfield com/trolmastercard/velvet/gi.field_70165_t D
      // 256: dload 5
      // 258: aload 0
      // 259: getfield com/trolmastercard/velvet/gi.field_70161_v D
      // 25c: fconst_1
      // 25d: aload 0
      // 25e: getfield com/trolmastercard/velvet/gi.field_70130_N F
      // 261: ldc_w 20.0
      // 264: fmul
      // 265: fadd
      // 266: f2i
      // 267: aload 0
      // 268: getfield com/trolmastercard/velvet/gi.field_70130_N F
      // 26b: f2d
      // 26c: dconst_0
      // 26d: aload 0
      // 26e: getfield com/trolmastercard/velvet/gi.field_70130_N F
      // 271: f2d
      // 272: ldc2_w 0.20000000298023224
      // 275: bipush 0
      // 276: newarray 10
      // 278: invokevirtual net/minecraft/world/WorldServer.func_175739_a (Lnet/minecraft/util/EnumParticleTypes;DDDIDDDD[I)V
      // 27b: aload 0
      // 27c: aload 0
      // 27d: getfield com/trolmastercard/velvet/gi.field_70146_Z Ljava/util/Random;
      // 280: bipush 20
      // 282: bipush 40
      // 284: invokestatic net/minecraft/util/math/MathHelper.func_76136_a (Ljava/util/Random;II)I
      // 287: putfield com/trolmastercard/velvet/gi.d I
      // 28a: goto 400
      // 28d: aload 0
      // 28e: getfield com/trolmastercard/velvet/gi.c I
      // 291: ifle 3de
      // 294: aload 0
      // 295: dup
      // 296: getfield com/trolmastercard/velvet/gi.c I
      // 299: iload 3
      // 29a: isub
      // 29b: putfield com/trolmastercard/velvet/gi.c I
      // 29e: ldc_w 0.15
      // 2a1: fstore 5
      // 2a3: aload 0
      // 2a4: getfield com/trolmastercard/velvet/gi.c I
      // 2a7: bipush 20
      // 2a9: if_icmpge 2c2
      // 2ac: fload 5
      // 2ae: f2d
      // 2af: bipush 20
      // 2b1: aload 0
      // 2b2: getfield com/trolmastercard/velvet/gi.c I
      // 2b5: isub
      // 2b6: i2d
      // 2b7: ldc2_w 0.05
      // 2ba: dmul
      // 2bb: dadd
      // 2bc: d2f
      // 2bd: fstore 5
      // 2bf: goto 2fd
      // 2c2: aload 0
      // 2c3: getfield com/trolmastercard/velvet/gi.c I
      // 2c6: bipush 40
      // 2c8: if_icmpge 2e1
      // 2cb: fload 5
      // 2cd: f2d
      // 2ce: bipush 40
      // 2d0: aload 0
      // 2d1: getfield com/trolmastercard/velvet/gi.c I
      // 2d4: isub
      // 2d5: i2d
      // 2d6: ldc2_w 0.02
      // 2d9: dmul
      // 2da: dadd
      // 2db: d2f
      // 2dc: fstore 5
      // 2de: goto 2fd
      // 2e1: aload 0
      // 2e2: getfield com/trolmastercard/velvet/gi.c I
      // 2e5: bipush 60
      // 2e7: if_icmpge 2fd
      // 2ea: fload 5
      // 2ec: f2d
      // 2ed: bipush 60
      // 2ef: aload 0
      // 2f0: getfield com/trolmastercard/velvet/gi.c I
      // 2f3: isub
      // 2f4: i2d
      // 2f5: ldc2_w 0.01
      // 2f8: dmul
      // 2f9: dadd
      // 2fa: d2f
      // 2fb: fstore 5
      // 2fd: aload 0
      // 2fe: getfield com/trolmastercard/velvet/gi.field_70146_Z Ljava/util/Random;
      // 301: invokevirtual java/util/Random.nextFloat ()F
      // 304: fload 5
      // 306: fcmpg
      // 307: ifge 3af
      // 30a: aload 0
      // 30b: getfield com/trolmastercard/velvet/gi.field_70146_Z Ljava/util/Random;
      // 30e: fconst_0
      // 30f: ldc_w 360.0
      // 312: invokestatic net/minecraft/util/math/MathHelper.func_151240_a (Ljava/util/Random;FF)F
      // 315: ldc 0.017453292
      // 317: fmul
      // 318: fstore 6
      // 31a: aload 0
      // 31b: getfield com/trolmastercard/velvet/gi.field_70146_Z Ljava/util/Random;
      // 31e: ldc_w 25.0
      // 321: ldc_w 60.0
      // 324: invokestatic net/minecraft/util/math/MathHelper.func_151240_a (Ljava/util/Random;FF)F
      // 327: fstore 7
      // 329: aload 0
      // 32a: getfield com/trolmastercard/velvet/gi.field_70165_t D
      // 32d: fload 6
      // 32f: invokestatic net/minecraft/util/math/MathHelper.func_76126_a (F)F
      // 332: fload 7
      // 334: fmul
      // 335: ldc_w 0.1
      // 338: fmul
      // 339: f2d
      // 33a: dadd
      // 33b: dstore 8
      // 33d: aload 0
      // 33e: invokevirtual com/trolmastercard/velvet/gi.func_174813_aQ ()Lnet/minecraft/util/math/AxisAlignedBB;
      // 341: getfield net/minecraft/util/math/AxisAlignedBB.field_72338_b D
      // 344: invokestatic net/minecraft/util/math/MathHelper.func_76128_c (D)I
      // 347: i2f
      // 348: fconst_1
      // 349: fadd
      // 34a: f2d
      // 34b: dstore 10
      // 34d: aload 0
      // 34e: getfield com/trolmastercard/velvet/gi.field_70161_v D
      // 351: fload 6
      // 353: invokestatic net/minecraft/util/math/MathHelper.func_76134_b (F)F
      // 356: fload 7
      // 358: fmul
      // 359: ldc_w 0.1
      // 35c: fmul
      // 35d: f2d
      // 35e: dadd
      // 35f: dstore 12
      // 361: aload 2
      // 362: new net/minecraft/util/math/BlockPos
      // 365: dup
      // 366: dload 8
      // 368: d2i
      // 369: dload 10
      // 36b: d2i
      // 36c: bipush 1
      // 36d: isub
      // 36e: dload 12
      // 370: d2i
      // 371: invokespecial net/minecraft/util/math/BlockPos.<init> (III)V
      // 374: invokevirtual net/minecraft/world/WorldServer.func_180495_p (Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/state/IBlockState;
      // 377: astore 14
      // 379: aload 14
      // 37b: invokeinterface net/minecraft/block/state/IBlockState.func_185904_a ()Lnet/minecraft/block/material/Material; 1
      // 380: getstatic net/minecraft/block/material/Material.field_151586_h Lnet/minecraft/block/material/Material;
      // 383: if_acmpne 3af
      // 386: aload 2
      // 387: getstatic net/minecraft/util/EnumParticleTypes.WATER_SPLASH Lnet/minecraft/util/EnumParticleTypes;
      // 38a: dload 8
      // 38c: dload 10
      // 38e: dload 12
      // 390: bipush 2
      // 391: aload 0
      // 392: getfield com/trolmastercard/velvet/gi.field_70146_Z Ljava/util/Random;
      // 395: bipush 2
      // 396: invokevirtual java/util/Random.nextInt (I)I
      // 399: iadd
      // 39a: ldc2_w 0.10000000149011612
      // 39d: dconst_0
      // 39e: ldc2_w 0.10000000149011612
      // 3a1: dconst_0
      // 3a2: bipush 0
      // 3a3: newarray 10
      // 3a5: invokevirtual net/minecraft/world/WorldServer.func_175739_a (Lnet/minecraft/util/EnumParticleTypes;DDDIDDDD[I)V
      // 3a8: goto 3af
      // 3ab: invokestatic com/trolmastercard/velvet/gi.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 3ae: athrow
      // 3af: aload 0
      // 3b0: getfield com/trolmastercard/velvet/gi.c I
      // 3b3: ifgt 3db
      // 3b6: aload 0
      // 3b7: aload 0
      // 3b8: getfield com/trolmastercard/velvet/gi.field_70146_Z Ljava/util/Random;
      // 3bb: fconst_0
      // 3bc: ldc_w 360.0
      // 3bf: invokestatic net/minecraft/util/math/MathHelper.func_151240_a (Ljava/util/Random;FF)F
      // 3c2: putfield com/trolmastercard/velvet/gi.e F
      // 3c5: aload 0
      // 3c6: aload 0
      // 3c7: getfield com/trolmastercard/velvet/gi.field_70146_Z Ljava/util/Random;
      // 3ca: bipush 20
      // 3cc: bipush 80
      // 3ce: invokestatic net/minecraft/util/math/MathHelper.func_76136_a (Ljava/util/Random;II)I
      // 3d1: putfield com/trolmastercard/velvet/gi.j I
      // 3d4: goto 3db
      // 3d7: invokestatic com/trolmastercard/velvet/gi.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 3da: athrow
      // 3db: goto 400
      // 3de: aload 0
      // 3df: aload 0
      // 3e0: getfield com/trolmastercard/velvet/gi.field_70146_Z Ljava/util/Random;
      // 3e3: bipush 100
      // 3e5: sipush 600
      // 3e8: invokestatic net/minecraft/util/math/MathHelper.func_76136_a (Ljava/util/Random;II)I
      // 3eb: putfield com/trolmastercard/velvet/gi.c I
      // 3ee: aload 0
      // 3ef: dup
      // 3f0: getfield com/trolmastercard/velvet/gi.c I
      // 3f3: aload 0
      // 3f4: getfield com/trolmastercard/velvet/gi.o I
      // 3f7: bipush 20
      // 3f9: imul
      // 3fa: bipush 5
      // 3fb: imul
      // 3fc: isub
      // 3fd: putfield com/trolmastercard/velvet/gi.c I
      // 400: return
      // try (9 -> 20): 21 java/lang/RuntimeException
      // try (15 -> 24): 25 java/lang/RuntimeException
      // try (27 -> 38): 39 java/lang/RuntimeException
      // try (33 -> 42): 43 java/lang/RuntimeException
      // try (45 -> 57): 58 java/lang/RuntimeException
      // try (48 -> 67): 67 java/lang/RuntimeException
      // try (86 -> 98): 99 java/lang/RuntimeException
      // try (168 -> 178): 179 java/lang/RuntimeException
      // try (172 -> 198): 199 java/lang/RuntimeException
      // try (457 -> 479): 480 java/lang/RuntimeException
      // try (482 -> 499): 500 java/lang/RuntimeException
   }

   protected boolean a(Entity param1) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 00: aload 1
      // 01: invokevirtual net/minecraft/entity/Entity.func_70067_L ()Z
      // 04: ifne 15
      // 07: aload 1
      // 08: instanceof net/minecraft/entity/item/EntityItem
      // 0b: ifeq 1d
      // 0e: goto 15
      // 11: invokestatic com/trolmastercard/velvet/gi.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 14: athrow
      // 15: bipush 1
      // 16: goto 1e
      // 19: invokestatic com/trolmastercard/velvet/gi.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 1c: athrow
      // 1d: bipush 0
      // 1e: ireturn
      // try (0 -> 6): 7 java/lang/RuntimeException
      // try (3 -> 11): 11 java/lang/RuntimeException
   }

   public void func_70014_b(NBTTagCompound var1) {
   }

   public void func_70037_a(NBTTagCompound var1) {
   }

   public int c() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 00: aload 0
      // 01: getfield com/trolmastercard/velvet/gi.field_70170_p Lnet/minecraft/world/World;
      // 04: getfield net/minecraft/world/World.field_72995_K Z
      // 07: ifne d1
      // 0a: aload 0
      // 0b: invokevirtual com/trolmastercard/velvet/gi.b ()Lcom/trolmastercard/velvet/eb;
      // 0e: ifnull d1
      // 11: goto 18
      // 14: invokestatic com/trolmastercard/velvet/gi.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 17: athrow
      // 18: bipush 0
      // 19: istore 1
      // 1a: aconst_null
      // 1b: astore 2
      // 1c: aload 0
      // 1d: getfield com/trolmastercard/velvet/gi.i Lnet/minecraft/entity/Entity;
      // 20: ifnull 4f
      // 23: aload 0
      // 24: invokevirtual com/trolmastercard/velvet/gi.d ()V
      // 27: aload 0
      // 28: getfield com/trolmastercard/velvet/gi.field_70170_p Lnet/minecraft/world/World;
      // 2b: aload 0
      // 2c: bipush 31
      // 2e: invokevirtual net/minecraft/world/World.func_72960_a (Lnet/minecraft/entity/Entity;B)V
      // 31: aload 0
      // 32: getfield com/trolmastercard/velvet/gi.i Lnet/minecraft/entity/Entity;
      // 35: instanceof net/minecraft/entity/item/EntityItem
      // 38: ifeq 4a
      // 3b: goto 42
      // 3e: invokestatic com/trolmastercard/velvet/gi.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 41: athrow
      // 42: bipush 3
      // 43: goto 4b
      // 46: invokestatic com/trolmastercard/velvet/gi.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 49: athrow
      // 4a: bipush 5
      // 4b: istore 1
      // 4c: goto b7
      // 4f: aload 0
      // 50: getfield com/trolmastercard/velvet/gi.d I
      // 53: ifle b7
      // 56: new net/minecraft/world/storage/loot/LootContext$Builder
      // 59: dup
      // 5a: aload 0
      // 5b: getfield com/trolmastercard/velvet/gi.field_70170_p Lnet/minecraft/world/World;
      // 5e: checkcast net/minecraft/world/WorldServer
      // 61: invokespecial net/minecraft/world/storage/loot/LootContext$Builder.<init> (Lnet/minecraft/world/WorldServer;)V
      // 64: astore 3
      // 65: aload 0
      // 66: getfield com/trolmastercard/velvet/gi.field_70170_p Lnet/minecraft/world/World;
      // 69: invokevirtual net/minecraft/world/World.func_184146_ak ()Lnet/minecraft/world/storage/loot/LootTableManager;
      // 6c: getstatic net/minecraft/world/storage/loot/LootTableList.field_186387_al Lnet/minecraft/util/ResourceLocation;
      // 6f: invokevirtual net/minecraft/world/storage/loot/LootTableManager.func_186521_a (Lnet/minecraft/util/ResourceLocation;)Lnet/minecraft/world/storage/loot/LootTable;
      // 72: aload 0
      // 73: getfield com/trolmastercard/velvet/gi.field_70146_Z Ljava/util/Random;
      // 76: aload 3
      // 77: invokevirtual net/minecraft/world/storage/loot/LootContext$Builder.func_186471_a ()Lnet/minecraft/world/storage/loot/LootContext;
      // 7a: invokevirtual net/minecraft/world/storage/loot/LootTable.func_186462_a (Ljava/util/Random;Lnet/minecraft/world/storage/loot/LootContext;)Ljava/util/List;
      // 7d: astore 4
      // 7f: aload 4
      // 81: invokeinterface java/util/List.iterator ()Ljava/util/Iterator; 1
      // 86: astore 5
      // 88: aload 5
      // 8a: invokeinterface java/util/Iterator.hasNext ()Z 1
      // 8f: ifeq ae
      // 92: aload 5
      // 94: invokeinterface java/util/Iterator.next ()Ljava/lang/Object; 1
      // 99: checkcast net/minecraft/item/ItemStack
      // 9c: astore 6
      // 9e: aload 0
      // 9f: invokevirtual com/trolmastercard/velvet/gi.b ()Lcom/trolmastercard/velvet/eb;
      // a2: astore 7
      // a4: aload 7
      // a6: aload 6
      // a8: invokevirtual com/trolmastercard/velvet/eb.b (Lnet/minecraft/item/ItemStack;)V
      // ab: goto 88
      // ae: aload 0
      // af: sipush 9999
      // b2: putfield com/trolmastercard/velvet/gi.d I
      // b5: bipush 1
      // b6: istore 1
      // b7: aload 0
      // b8: getfield com/trolmastercard/velvet/gi.k Z
      // bb: ifeq c0
      // be: bipush 2
      // bf: istore 1
      // c0: aload 2
      // c1: ifnonnull cc
      // c4: iload 1
      // c5: goto d0
      // c8: invokestatic com/trolmastercard/velvet/gi.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // cb: athrow
      // cc: aload 2
      // cd: invokevirtual net/minecraftforge/event/entity/player/ItemFishedEvent.getRodDamage ()I
      // d0: ireturn
      // d1: bipush 0
      // d2: ireturn
      // try (0 -> 7): 8 java/lang/RuntimeException
      // try (14 -> 28): 29 java/lang/RuntimeException
      // try (17 -> 33): 33 java/lang/RuntimeException
      // try (86 -> 90): 90 java/lang/RuntimeException
   }

   protected void d() {
      eb var1 = this.b();
      if (var1 != null) {
         double var2 = var1.field_70165_t - this.field_70165_t;
         double var4 = var1.field_70163_u - this.field_70163_u;
         double var6 = var1.field_70161_v - this.field_70161_v;
         double var8 = 0.1;
         this.i.field_70159_w += var2 * 0.1;
         this.i.field_70181_x += var4 * 0.1;
         this.i.field_70179_y += var6 * 0.1;
      }
   }

   protected boolean func_70041_e_() {
      return false;
   }

   public void func_70020_e(NBTTagCompound var1) {
   }

   public NBTTagCompound func_189511_e(NBTTagCompound var1) {
      return null;
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   enum a {
      FLYING,
      HOOKED_IN_ENTITY,
      BOBBING;
   }
}
