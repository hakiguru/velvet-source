package org.velvet;

public enum c8 {
   DEFAULT,
   velvet,
   NONE;
}
