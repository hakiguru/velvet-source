package org.velvet;

public enum gr {
   W,
   A,
   S,
   D;
}
