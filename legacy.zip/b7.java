package org.velvet;

public interface b7 {
   f2 d();

   boolean c();

   boolean a();

   boolean b();
}
