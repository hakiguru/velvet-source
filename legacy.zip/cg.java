package org.velvet;

import net.minecraft.util.ResourceLocation;

public class cg extends cv {
   @Override
   protected ResourceLocation[] a() {
      return new ResourceLocation[]{new ResourceLocation("velvet", "geo/cat/cat.geo.json"), new ResourceLocation("velvet", "geo/cat/cat.geo.json")};
   }

   @Override
   public ResourceLocation b() {
      return new ResourceLocation("velvet", "textures/entity/cat/cat.png");
   }

   @Override
   public ResourceLocation b(em var1) {
      return new ResourceLocation("velvet", "animations/cat/cat.animation.json");
   }

   @Override
   public String[] c() {
      return new String[]{"armorHelmet"};
   }

   @Override
   public String[] f() {
      return new String[]{"armorShoulderR", "armorShoulderL", "armorChest", "armorBoobs"};
   }

   @Override
   public String[] a() {
      return new String[]{"boobsFlesh", "cloth"};
   }

   @Override
   public String[] h() {
      return new String[]{"armorBootyR", "armorBootyL", "armorPantsLowL", "armorPantsLowR", "armorPantsLowR", "armorPantsUpR", "armorPantsUpL", "armorHip"};
   }

   @Override
   public String[] e() {
      return new String[]{"fleshL", "fleshR", "vagina", "curvesL", "curvesR", "kneeL", "kneeR", "cloth"};
   }

   @Override
   public String[] b() {
      return new String[]{"armorShoesL", "armorShoesR"};
   }
}
