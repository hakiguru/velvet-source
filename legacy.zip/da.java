package org.velvet;

import java.io.IOException;
import java.util.HashSet;
import java.util.Objects;
import javax.annotation.Nullable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.opengl.GL11;
import software.bernie.geckolib3.geo.render.built.GeoBone;
import software.bernie.geckolib3.geo.render.built.GeoCube;
import software.bernie.geckolib3.geo.render.built.GeoModel;
import software.bernie.geckolib3.model.AnimatedGeoModel;

public class da extends d_<f_> implements c3 {
   public static final int D = 14;
   public static final HashSet<String> E = new HashSet<String>() {
      {
         this.add("static");
         this.add("turnable");
         this.add("slip");
         this.add("boobs");
         this.add("booty");
         this.add("vagina");
         this.add("fuckhole");
         this.add("futaBallLR");
         this.add("futaBallLL");
         this.add("coin");
         this.add("pentagram");
      }
   };
   public static final f7 y = new f7(0.0F, 0.0F, 0.0F);
   static final gv H = new gv(152, 45, 62, 255);
   static final gv I = new gv(84, 66, 88, 255);
   static final bm C = new bm(0.25F, 0.125F);
   static final bm x = new bm(0.375F, 0.125F);
   static final float F = 0.125F;
   static final ResourceLocation w = new ResourceLocation("velvet", "textures/star.png");
   static final int v = 105;
   static final int A = 125;
   static final float B = 0.0296875F;
   static final float J = 0.06484375F;
   static final float z = 0.026124999F;
   static final float u = 0.0570625F;
   static final ef.b G = new ef.b(
      H,
      0.1F,
      12,
      0.035F,
      (var0, var1) -> (float)(Math.sin(var1 * 0.3 + -0.2 * var0) * 15.0),
      (var0, var1) -> (float)(Math.sin(var1 * -0.15 + -0.2 * var0) * 3.0),
      (var0, var1) -> 0.0F,
      0.03F,
      0.005F
   );
   static final ef.b t = new ef.b(
      H,
      0.0F,
      12,
      0.0F,
      (var0, var1) -> (float)(Math.sin(var1 * 0.3 + -0.2 * var0) * 15.0),
      (var0, var1) -> (float)(Math.sin(var1 * -0.15 + -0.2 * var0) * 3.0),
      (var0, var1) -> 0.0F,
      0.03F,
      0.005F
   );
   boolean r = false;
   float s = 0.0F;

   public da(RenderManager var1, AnimatedGeoModel var2, double var3) {
      super(var1, var2, var3);
   }

   @Nullable
   protected f7 a(f_ var1) {
      try {
         if (var1.field_70170_p instanceof gj) {
            return null;
         }
      } catch (RuntimeException var2) {
         throw a(var2);
      }

      try {
         if (var1.bb) {
            return null;
         }
      } catch (RuntimeException var3) {
         throw a(var3);
      }

      return y;
   }

   @Override
   public HashSet<String> a() {
      try {
         if (!this.r) {
            E.addAll(gx.a);
            E.addAll(dh.B);
            this.r = true;
         }
      } catch (RuntimeException var1) {
         throw a(var1);
      }

      return E;
   }

   @Override
   protected void b(Tessellator var1, BufferBuilder var2, em var3, f7 var4, float var5) {
      a(var1, var2, var3, var4, var5);
   }

   protected void b(f_ var1) {
      try {
         if (var1.y() != fp.MASTERBATE) {
            return;
         }
      } catch (RuntimeException var3) {
         throw a(var3);
      }

      float var2 = var1.I();
      var1.field_70177_z = var2;
      var1.field_70760_ar = var2;
      var1.field_70761_aq = var2;
      var1.field_70758_at = var2;
      var1.field_70759_as = var2;
   }

   public void a(f_ var1, double var2, double var4, double var6, float var8, float var9) {
      Vec3d var10 = a(var1, var9);

      try {
         if (var10 != null) {
            var1.a(var10);
         }
      } catch (RuntimeException var12) {
         throw a(var12);
      }

      try {
         var1.aG = var10;
         f_.a(var1, var9);
         this.d(var1);
         this.c(var1);
         super.a(var1, var2, var4, var6, var8, var9);
         a((em)var1, var9);
         if (var1.b()) {
            dh.a((em)var1, var9);
         }
      } catch (RuntimeException var11) {
         throw a(var11);
      }
   }

   void c(f_ var1) {
      try {
         if (var1.y() != fp.RAPE_CHARGE) {
            return;
         }
      } catch (RuntimeException var2) {
         throw a(var2);
      }

      var1.field_70761_aq = var1.I();
      var1.field_70760_ar = var1.field_70761_aq;
   }

   void d(f_ var1) {
      try {
         if (!(Boolean)var1.func_184212_Q().func_187225_a(f_.bP)) {
            return;
         }
      } catch (RuntimeException var8) {
         throw a(var8);
      }

      Vec3d var2 = new Vec3d(var1.field_70142_S, var1.field_70137_T, var1.field_70136_U);
      Vec3d var3 = var1.func_174791_d().func_178788_d(var2);

      boolean var10000;
      label35: {
         try {
            if (Math.abs(var3.field_72450_a) + Math.abs(var3.field_72449_c) < 0.05F) {
               var10000 = true;
               break label35;
            }
         } catch (RuntimeException var7) {
            throw a(var7);
         }

         var10000 = false;
      }

      boolean var4 = var10000;

      try {
         if (var4) {
            var1.field_70761_aq = this.s;
            var1.field_70760_ar = this.s;
            return;
         }
      } catch (RuntimeException var6) {
         throw a(var6);
      }

      float var5 = (float)(gc.b(Math.atan2(var3.field_72449_c, var3.field_72450_a)) - 90.0);
      var1.field_70761_aq = var5;
      var1.field_70760_ar = var5;
      this.s = var5;
   }

   @Nullable
   public static Vec3d a(f_ param0, float param1) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 000: aload 0
      // 001: invokevirtual com/trolmastercard/velvet/f_.az ()I
      // 004: i2f
      // 005: fstore 2
      // 006: fload 2
      // 007: ldc -1.0
      // 009: fcmpl
      // 00a: ifne 021
      // 00d: aload 0
      // 00e: ldc2_w -1
      // 011: putfield com/trolmastercard/velvet/f_.af J
      // 014: aload 0
      // 015: ldc2_w -1
      // 018: putfield com/trolmastercard/velvet/f_.aH J
      // 01b: aconst_null
      // 01c: areturn
      // 01d: invokestatic com/trolmastercard/velvet/da.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 020: athrow
      // 021: aload 0
      // 022: invokevirtual com/trolmastercard/velvet/f_.M ()Lnet/minecraft/entity/EntityLivingBase;
      // 025: astore 3
      // 026: aload 3
      // 027: ifnonnull 030
      // 02a: aconst_null
      // 02b: areturn
      // 02c: invokestatic com/trolmastercard/velvet/da.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 02f: athrow
      // 030: new net/minecraft/util/math/Vec3d
      // 033: dup
      // 034: aload 3
      // 035: getfield net/minecraft/entity/EntityLivingBase.field_70169_q D
      // 038: aload 3
      // 039: getfield net/minecraft/entity/EntityLivingBase.field_70167_r D
      // 03c: aload 3
      // 03d: getfield net/minecraft/entity/EntityLivingBase.field_70166_s D
      // 040: invokespecial net/minecraft/util/math/Vec3d.<init> (DDD)V
      // 043: aload 3
      // 044: invokevirtual net/minecraft/entity/EntityLivingBase.func_174791_d ()Lnet/minecraft/util/math/Vec3d;
      // 047: fload 1
      // 048: f2d
      // 049: invokestatic com/trolmastercard/velvet/b6.a (Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/math/Vec3d;D)Lnet/minecraft/util/math/Vec3d;
      // 04c: astore 4
      // 04e: fload 2
      // 04f: ldc_w 24.0
      // 052: fcmpl
      // 053: ifne 088
      // 056: aload 0
      // 057: getfield com/trolmastercard/velvet/f_.af J
      // 05a: ldc2_w -1
      // 05d: lcmp
      // 05e: ifne 088
      // 061: goto 068
      // 064: invokestatic com/trolmastercard/velvet/da.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 067: athrow
      // 068: aload 0
      // 069: getstatic com/trolmastercard/velvet/da.i Lnet/minecraft/client/Minecraft;
      // 06c: getfield net/minecraft/client/Minecraft.field_71441_e Lnet/minecraft/client/multiplayer/WorldClient;
      // 06f: invokevirtual net/minecraft/client/multiplayer/WorldClient.func_82737_E ()J
      // 072: putfield com/trolmastercard/velvet/f_.af J
      // 075: aload 0
      // 076: aload 0
      // 077: getfield com/trolmastercard/velvet/f_.af J
      // 07a: ldc2_w 8
      // 07d: ladd
      // 07e: putfield com/trolmastercard/velvet/f_.aH J
      // 081: goto 088
      // 084: invokestatic com/trolmastercard/velvet/da.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 087: athrow
      // 088: fload 2
      // 089: f2d
      // 08a: ldc2_w 24.0
      // 08d: ldc2_w 32.0
      // 090: invokestatic com/trolmastercard/velvet/be.a (DDD)Z
      // 093: ifeq 0f5
      // 096: new net/minecraft/util/math/Vec3d
      // 099: dup
      // 09a: dconst_0
      // 09b: dconst_0
      // 09c: ldc2_w 3.0
      // 09f: invokespecial net/minecraft/util/math/Vec3d.<init> (DDD)V
      // 0a2: aload 0
      // 0a3: invokevirtual com/trolmastercard/velvet/f_.I ()Ljava/lang/Float;
      // 0a6: invokevirtual java/lang/Float.floatValue ()F
      // 0a9: ldc_w 180.0
      // 0ac: fadd
      // 0ad: invokestatic com/trolmastercard/velvet/ck.a (Lnet/minecraft/util/math/Vec3d;F)Lnet/minecraft/util/math/Vec3d;
      // 0b0: astore 5
      // 0b2: aload 0
      // 0b3: invokevirtual com/trolmastercard/velvet/f_.B ()Lnet/minecraft/util/math/Vec3d;
      // 0b6: astore 6
      // 0b8: aload 4
      // 0ba: dconst_0
      // 0bb: aload 3
      // 0bc: invokevirtual net/minecraft/entity/EntityLivingBase.func_70047_e ()F
      // 0bf: f2d
      // 0c0: dconst_0
      // 0c1: invokevirtual net/minecraft/util/math/Vec3d.func_72441_c (DDD)Lnet/minecraft/util/math/Vec3d;
      // 0c4: aload 5
      // 0c6: invokevirtual net/minecraft/util/math/Vec3d.func_178787_e (Lnet/minecraft/util/math/Vec3d;)Lnet/minecraft/util/math/Vec3d;
      // 0c9: astore 7
      // 0cb: getstatic com/trolmastercard/velvet/da.i Lnet/minecraft/client/Minecraft;
      // 0ce: getfield net/minecraft/client/Minecraft.field_71441_e Lnet/minecraft/client/multiplayer/WorldClient;
      // 0d1: invokevirtual net/minecraft/client/multiplayer/WorldClient.func_82737_E ()J
      // 0d4: l2f
      // 0d5: fload 1
      // 0d6: fadd
      // 0d7: aload 0
      // 0d8: getfield com/trolmastercard/velvet/f_.af J
      // 0db: l2f
      // 0dc: fsub
      // 0dd: aload 0
      // 0de: getfield com/trolmastercard/velvet/f_.aH J
      // 0e1: aload 0
      // 0e2: getfield com/trolmastercard/velvet/f_.af J
      // 0e5: lsub
      // 0e6: l2f
      // 0e7: fdiv
      // 0e8: fstore 8
      // 0ea: aload 6
      // 0ec: aload 7
      // 0ee: fload 8
      // 0f0: f2d
      // 0f1: invokestatic com/trolmastercard/velvet/b6.a (Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/math/Vec3d;D)Lnet/minecraft/util/math/Vec3d;
      // 0f4: areturn
      // 0f5: fload 2
      // 0f6: f2d
      // 0f7: ldc2_w 32.0
      // 0fa: ldc2_w 54.0
      // 0fd: invokestatic com/trolmastercard/velvet/be.a (DDD)Z
      // 100: ifeq 127
      // 103: new net/minecraft/util/math/Vec3d
      // 106: dup
      // 107: dconst_0
      // 108: dconst_0
      // 109: ldc2_w 1.5
      // 10c: invokespecial net/minecraft/util/math/Vec3d.<init> (DDD)V
      // 10f: aload 0
      // 110: invokevirtual com/trolmastercard/velvet/f_.I ()Ljava/lang/Float;
      // 113: invokevirtual java/lang/Float.floatValue ()F
      // 116: ldc_w 180.0
      // 119: fadd
      // 11a: invokestatic com/trolmastercard/velvet/ck.a (Lnet/minecraft/util/math/Vec3d;F)Lnet/minecraft/util/math/Vec3d;
      // 11d: astore 5
      // 11f: aload 4
      // 121: aload 5
      // 123: invokevirtual net/minecraft/util/math/Vec3d.func_178787_e (Lnet/minecraft/util/math/Vec3d;)Lnet/minecraft/util/math/Vec3d;
      // 126: areturn
      // 127: aconst_null
      // 128: areturn
      // try (4 -> 16): 16 java/lang/RuntimeException
      // try (21 -> 25): 25 java/lang/RuntimeException
      // try (42 -> 51): 52 java/lang/RuntimeException
      // try (46 -> 65): 66 java/lang/RuntimeException
   }

   public static void a(em var0, float var1) {
      EntityPlayerSP var2 = i.field_71439_g;

      try {
         if (var2 == null) {
            return;
         }
      } catch (RuntimeException var5) {
         throw a(var5);
      }

      Tessellator var3 = Tessellator.func_178181_a();
      BufferBuilder var4 = var3.func_178180_c();
      GlStateManager.func_179094_E();
      af.a(i, var0, var1);
      i.func_110434_K().func_110577_a(e);
      GlStateManager.func_179129_p();
      GlStateManager.func_179140_f();
      a(var0, var4, var3, b6.a(var0.field_70760_ar, var0.field_70761_aq, var1));
      b(var0, var4, var3, var1);
      a(var0, var4, var3);
      GlStateManager.func_179121_F();
      GlStateManager.func_179089_o();
      GlStateManager.func_179145_e();
   }

   static void b(em var0, BufferBuilder var1, Tessellator var2, float var3) {
      try {
         if (!(var0 instanceof f_)) {
            return;
         }
      } catch (RuntimeException var18) {
         throw a(var18);
      }

      try {
         if (!(Boolean)var0.func_184212_Q().func_187225_a(f_.bP)) {
            return;
         }
      } catch (RuntimeException var16) {
         throw a(var16);
      }

      try {
         if ((Boolean)var0.func_184212_Q().func_187225_a(f_.L)) {
            return;
         }
      } catch (RuntimeException var17) {
         throw a(var17);
      }

      GlStateManager.func_179094_E();
      Vec3d var4 = var0.b("stars");
      GlStateManager.func_179137_b(var4.field_72450_a, var4.field_72448_b, var4.field_72449_c);
      float var5 = (float)i.field_71441_e.func_82737_E() + var3;
      float var6 = (float)(Math.sin(var5 * 0.2) * 5.0);
      float var7 = (float)(Math.cos(var5 * 0.2) * 5.0);
      float var8 = (float)(var5 * 3.0);
      GlStateManager.func_179114_b(var6, 1.0F, 0.0F, 0.0F);
      GlStateManager.func_179114_b(var8, 0.0F, 1.0F, 0.0F);
      GlStateManager.func_179114_b(var7, 0.0F, 0.0F, 1.0F);
      float var9 = gc.c(9.0);
      f7 var10 = f_.aa;
      i.func_110434_K().func_110577_a(e);
      var1.func_181668_a(3, DefaultVertexFormats.field_181709_i);
      GlStateManager.func_187441_d(a(var0, var3, 1.0F, 3.0F));

      for (float var11 = 0.0F; var11 < Math.PI * 2; var11 += var9) {
         double var12 = Math.sin(var11) * 0.3F;
         double var14 = Math.cos(var11) * 0.3F;
         var1.func_181662_b(var12, 0.0, var14).func_187315_a(0.0, 0.0).func_181666_a(var10.a, var10.c, var10.b, 1.0F).func_181675_d();
      }

      var2.func_78381_a();
      i.func_110434_K().func_110577_a(w);
      var1.func_181668_a(7, DefaultVertexFormats.field_181709_i);
      var9 = gc.c(60.0);

      for (float var20 = 0.0F; var20 < Math.PI * 2; var20 += var9) {
         double var21 = Math.sin(var20) * 0.3F;
         double var22 = Math.cos(var20) * 0.3F;
         var1.func_181662_b(var21 - 0.1F, 0.1F, var22).func_187315_a(0.0, 0.0).func_181666_a(1.0F, 1.0F, 1.0F, 1.0F).func_181675_d();
         var1.func_181662_b(var21 + 0.1F, 0.1F, var22).func_187315_a(1.0, 0.0).func_181666_a(1.0F, 1.0F, 1.0F, 1.0F).func_181675_d();
         var1.func_181662_b(var21 + 0.1F, -0.1F, var22).func_187315_a(1.0, 1.0).func_181666_a(1.0F, 1.0F, 1.0F, 1.0F).func_181675_d();
         var1.func_181662_b(var21 - 0.1F, -0.1F, var22).func_187315_a(0.0, 1.0).func_181666_a(1.0F, 1.0F, 1.0F, 1.0F).func_181675_d();
      }

      var2.func_78381_a();
      GlStateManager.func_179121_F();
   }

   static void a(em param0, BufferBuilder param1, Tessellator param2, float param3) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 00: aload 0
      // 01: invokevirtual com/trolmastercard/velvet/em.y ()Lcom/trolmastercard/velvet/fp;
      // 04: getstatic com/trolmastercard/velvet/fp.GIVE_COIN Lcom/trolmastercard/velvet/fp;
      // 07: if_acmpne 23
      // 0a: getstatic com/trolmastercard/velvet/fp.GIVE_COIN Lcom/trolmastercard/velvet/fp;
      // 0d: getfield com/trolmastercard/velvet/fp.ticksPlaying [I
      // 10: bipush 1
      // 11: iaload
      // 12: bipush 100
      // 14: if_icmple 23
      // 17: goto 1e
      // 1a: invokestatic com/trolmastercard/velvet/da.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 1d: athrow
      // 1e: return
      // 1f: invokestatic com/trolmastercard/velvet/da.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 22: athrow
      // 23: aload 1
      // 24: bipush 7
      // 26: getstatic net/minecraft/client/renderer/vertex/DefaultVertexFormats.field_181709_i Lnet/minecraft/client/renderer/vertex/VertexFormat;
      // 29: invokevirtual net/minecraft/client/renderer/BufferBuilder.func_181668_a (ILnet/minecraft/client/renderer/vertex/VertexFormat;)V
      // 2c: aload 0
      // 2d: fload 3
      // 2e: ldc_w "hairStrandStartR"
      // 31: ldc_w "hairStrandMidR"
      // 34: ldc_w "hairStrandEndR"
      // 37: ldc 0.0296875
      // 39: ldc 0.06484375
      // 3b: ldc 0.026124999
      // 3d: ldc 0.0570625
      // 3f: ldc_w "head"
      // 42: invokestatic com/trolmastercard/velvet/af.a (Lcom/trolmastercard/velvet/em;FLjava/lang/String;Ljava/lang/String;Ljava/lang/String;FFFFLjava/lang/String;)[[Lnet/minecraft/util/math/Vec3d;
      // 45: astore 4
      // 47: aload 0
      // 48: fload 3
      // 49: ldc_w "hairStrandStartL"
      // 4c: ldc_w "hairStrandMidL"
      // 4f: ldc_w "hairStrandEndL"
      // 52: ldc 0.0296875
      // 54: ldc 0.06484375
      // 56: ldc 0.026124999
      // 58: ldc 0.0570625
      // 5a: ldc_w "head"
      // 5d: invokestatic com/trolmastercard/velvet/af.a (Lcom/trolmastercard/velvet/em;FLjava/lang/String;Ljava/lang/String;Ljava/lang/String;FFFFLjava/lang/String;)[[Lnet/minecraft/util/math/Vec3d;
      // 60: astore 5
      // 62: aload 1
      // 63: aload 4
      // 65: getstatic com/trolmastercard/velvet/da.I Lcom/trolmastercard/velvet/gv;
      // 68: invokestatic com/trolmastercard/velvet/af.a (Lnet/minecraft/client/renderer/BufferBuilder;[[Lnet/minecraft/util/math/Vec3d;Lcom/trolmastercard/velvet/gv;)V
      // 6b: aload 1
      // 6c: aload 5
      // 6e: getstatic com/trolmastercard/velvet/da.I Lcom/trolmastercard/velvet/gv;
      // 71: invokestatic com/trolmastercard/velvet/af.a (Lnet/minecraft/client/renderer/BufferBuilder;[[Lnet/minecraft/util/math/Vec3d;Lcom/trolmastercard/velvet/gv;)V
      // 74: aload 2
      // 75: invokevirtual net/minecraft/client/renderer/Tessellator.func_78381_a ()V
      // 78: return
      // try (0 -> 10): 11 java/lang/RuntimeException
      // try (4 -> 14): 14 java/lang/RuntimeException
   }

   static void a(em var0, BufferBuilder var1, Tessellator var2) {
      try {
         if (!((b7)var0).a()) {
            return;
         }
      } catch (RuntimeException var7) {
         throw a(var7);
      }

      i.func_110434_K().func_110577_a(cb.h);
      Vec3d[] var3 = new Vec3d[14];
      Vec3d[] var4 = new Vec3d[14];
      int var5 = 0;

      try {
         while (var5 < 14) {
            var3[var5] = var0.b("wingRV" + var5);
            var4[var5] = var0.b("wingLV" + var5);
            var5++;
         }
      } catch (RuntimeException var6) {
         throw a(var6);
      }

      a(var1, var2, var3);
      a(var1, var2, var4);
   }

   static void a(BufferBuilder var0, Tessellator var1, Vec3d[] var2) {
      var0.func_181668_a(4, DefaultVertexFormats.field_181709_i);
      var0.func_181662_b(var2[0].field_72450_a, var2[0].field_72448_b, var2[0].field_72449_c)
         .func_187315_a(C.c, C.a)
         .func_181669_b(255, 255, 255, 255)
         .func_181675_d();
      var0.func_181662_b(var2[1].field_72450_a, var2[1].field_72448_b, var2[1].field_72449_c)
         .func_187315_a(C.c + 0.125F, C.a)
         .func_181669_b(255, 255, 255, 255)
         .func_181675_d();
      var0.func_181662_b(var2[2].field_72450_a, var2[2].field_72448_b, var2[2].field_72449_c)
         .func_187315_a(C.c + 0.125F, C.a + 0.125F)
         .func_181669_b(255, 255, 255, 255)
         .func_181675_d();
      var0.func_181662_b(var2[11].field_72450_a, var2[11].field_72448_b, var2[11].field_72449_c)
         .func_187315_a(C.c, C.a)
         .func_181669_b(255, 255, 255, 255)
         .func_181675_d();
      var0.func_181662_b(var2[12].field_72450_a, var2[12].field_72448_b, var2[12].field_72449_c)
         .func_187315_a(C.c + 0.125F, C.a)
         .func_181669_b(255, 255, 255, 255)
         .func_181675_d();
      var0.func_181662_b(var2[13].field_72450_a, var2[13].field_72448_b, var2[13].field_72449_c)
         .func_187315_a(C.c + 0.125F, C.a + 0.125F)
         .func_181669_b(255, 255, 255, 255)
         .func_181675_d();
      var1.func_78381_a();
      var0.func_181668_a(7, DefaultVertexFormats.field_181709_i);
      var0.func_181662_b(var2[3].field_72450_a, var2[3].field_72448_b, var2[3].field_72449_c)
         .func_187315_a(x.c, x.a + 0.125F)
         .func_181669_b(255, 255, 255, 255)
         .func_181675_d();
      var0.func_181662_b(var2[4].field_72450_a, var2[4].field_72448_b, var2[4].field_72449_c)
         .func_187315_a(x.c, x.a)
         .func_181669_b(255, 255, 255, 255)
         .func_181675_d();
      var0.func_181662_b(var2[5].field_72450_a, var2[5].field_72448_b, var2[5].field_72449_c)
         .func_187315_a(x.c + 0.125F, x.a)
         .func_181669_b(255, 255, 255, 255)
         .func_181675_d();
      var0.func_181662_b(var2[6].field_72450_a, var2[6].field_72448_b, var2[6].field_72449_c)
         .func_187315_a(x.c + 0.125F, x.a + 0.125F)
         .func_181669_b(255, 255, 255, 255)
         .func_181675_d();
      var0.func_181662_b(var2[7].field_72450_a, var2[7].field_72448_b, var2[7].field_72449_c)
         .func_187315_a(x.c, x.a + 0.125F)
         .func_181669_b(255, 255, 255, 255)
         .func_181675_d();
      var0.func_181662_b(var2[8].field_72450_a, var2[8].field_72448_b, var2[8].field_72449_c)
         .func_187315_a(x.c, x.a)
         .func_181669_b(255, 255, 255, 255)
         .func_181675_d();
      var0.func_181662_b(var2[9].field_72450_a, var2[9].field_72448_b, var2[9].field_72449_c)
         .func_187315_a(x.c + 0.125F, x.a)
         .func_181669_b(255, 255, 255, 255)
         .func_181675_d();
      var0.func_181662_b(var2[10].field_72450_a, var2[10].field_72448_b, var2[10].field_72449_c)
         .func_187315_a(x.c + 0.125F, x.a + 0.125F)
         .func_181669_b(255, 255, 255, 255)
         .func_181675_d();
      var1.func_78381_a();
   }

   protected void a(GeoModel var1, BufferBuilder var2, f_ var3, float var4, float var5, float var6, float var7, float var8) {
      GeoBone var9 = var1.topLevelBones.get(0);
      GeoBone var10 = null;
      GeoBone var11 = null;
      GeoBone var12 = null;
      GeoBone var13 = null;

      for (GeoBone var15 : var9.childBones) {
         String var16 = var15.getName();
         byte var17 = -1;

         label68: {
            label67: {
               label66: {
                  label65: {
                     try {
                        switch (var16.hashCode()) {
                           case 3029410:
                              break;
                           case 3059345:
                              break label65;
                           case 93911760:
                              break label66;
                           case 109761491:
                              if (!var16.equals("steve")) {
                                 break label68;
                              }
                              break label67;
                           default:
                              break label68;
                        }
                     } catch (IOException var20) {
                        throw a(var20);
                     }

                     if (var16.equals("body")) {
                        var17 = 1;
                     }
                     break label68;
                  }

                  if (var16.equals("coin")) {
                     var17 = 2;
                  }
                  break label68;
               }

               if (var16.equals("body2")) {
                  var17 = 3;
               }
               break label68;
            }

            var17 = 0;
         }

         switch (var17) {
            case 0:
               var12 = var15;
               break;
            case 1:
               var10 = var15;
               break;
            case 2:
               var11 = var15;
               break;
            case 3:
               var13 = var15;
         }
      }

      MATRIX_STACK.push();
      MATRIX_STACK.translate(var9);
      MATRIX_STACK.moveToPivot(var9);
      MATRIX_STACK.rotate(var9);
      MATRIX_STACK.scale(var9);
      MATRIX_STACK.moveBackFromPivot(var9);
      this.renderRecursively(var2, var10, var4, var5, var6, var7);
      Tessellator.func_178181_a().func_78381_a();
      this.a(var2, var11, var3, var8);
      var2.func_181668_a(7, DefaultVertexFormats.field_181712_l);

      try {
         Minecraft.func_71410_x().field_71446_o.func_110577_a(this.d(this.j));
      } catch (IOException var18) {
         var18.printStackTrace();
      }

      try {
         this.renderRecursively(var2, var12, var4, var5, var6, this.j.v());
         Tessellator.func_178181_a().func_78381_a();
         if (var13 != null) {
            var2.func_181668_a(7, DefaultVertexFormats.field_181712_l);
            Minecraft.func_71410_x().field_71446_o.func_110577_a(ce.j);
            this.renderRecursively(var2, var13, var4, var5, var6, this.j.v());
            Tessellator.func_178181_a().func_78381_a();
         }
      } catch (IOException var19) {
         throw a(var19);
      }

      MATRIX_STACK.pop();
   }

   @Override
   protected void a(BufferBuilder param1, String param2, GeoBone param3) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 000: aload 2
      // 001: astore 4
      // 003: bipush -1
      // 004: istore 5
      // 006: aload 4
      // 008: invokevirtual java/lang/String.hashCode ()I
      // 00b: lookupswitch 371 14 -1304612943 230 -868095228 213 -791821796 196 -129402903 121 3002736 338 3002742 356 3198432 179 99151443 248 100470425 266 100470431 284 1358970225 302 1358970226 320 1851354257 145 1851354263 162
      // 084: aload 4
      // 086: ldc_w "hairBack"
      // 089: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 08c: ifeq 17e
      // 08f: goto 096
      // 092: invokestatic com/trolmastercard/velvet/da.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 095: athrow
      // 096: bipush 0
      // 097: istore 5
      // 099: goto 17e
      // 09c: aload 4
      // 09e: ldc_w "hairDownSideL"
      // 0a1: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 0a4: ifeq 17e
      // 0a7: bipush 1
      // 0a8: istore 5
      // 0aa: goto 17e
      // 0ad: aload 4
      // 0af: ldc_w "hairDownSideR"
      // 0b2: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 0b5: ifeq 17e
      // 0b8: bipush 2
      // 0b9: istore 5
      // 0bb: goto 17e
      // 0be: aload 4
      // 0c0: ldc_w "head"
      // 0c3: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 0c6: ifeq 17e
      // 0c9: bipush 3
      // 0ca: istore 5
      // 0cc: goto 17e
      // 0cf: aload 4
      // 0d1: ldc_w "weapon"
      // 0d4: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 0d7: ifeq 17e
      // 0da: bipush 4
      // 0db: istore 5
      // 0dd: goto 17e
      // 0e0: aload 4
      // 0e2: ldc_w "tongue"
      // 0e5: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 0e8: ifeq 17e
      // 0eb: bipush 5
      // 0ec: istore 5
      // 0ee: goto 17e
      // 0f1: aload 4
      // 0f3: ldc_w "mangTongue"
      // 0f6: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 0f9: ifeq 17e
      // 0fc: bipush 6
      // 0fe: istore 5
      // 100: goto 17e
      // 103: aload 4
      // 105: ldc_w "head3"
      // 108: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 10b: ifeq 17e
      // 10e: bipush 7
      // 110: istore 5
      // 112: goto 17e
      // 115: aload 4
      // 117: ldc_w "irisL"
      // 11a: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 11d: ifeq 17e
      // 120: bipush 8
      // 122: istore 5
      // 124: goto 17e
      // 127: aload 4
      // 129: ldc_w "irisR"
      // 12c: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 12f: ifeq 17e
      // 132: bipush 9
      // 134: istore 5
      // 136: goto 17e
      // 139: aload 4
      // 13b: ldc_w "irsisFaceR2"
      // 13e: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 141: ifeq 17e
      // 144: bipush 10
      // 146: istore 5
      // 148: goto 17e
      // 14b: aload 4
      // 14d: ldc_w "irsisFaceR3"
      // 150: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 153: ifeq 17e
      // 156: bipush 11
      // 158: istore 5
      // 15a: goto 17e
      // 15d: aload 4
      // 15f: ldc_w "armL"
      // 162: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 165: ifeq 17e
      // 168: bipush 12
      // 16a: istore 5
      // 16c: goto 17e
      // 16f: aload 4
      // 171: ldc_w "armR"
      // 174: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 177: ifeq 17e
      // 17a: bipush 13
      // 17c: istore 5
      // 17e: iload 5
      // 180: tableswitch 815 0 13 72 189 189 297 518 652 661 670 678 678 686 686 694 694
      // 1c8: getstatic com/trolmastercard/velvet/da.i Lnet/minecraft/client/Minecraft;
      // 1cb: invokevirtual net/minecraft/client/Minecraft.func_147113_T ()Z
      // 1ce: ifeq 1df
      // 1d1: goto 1d8
      // 1d4: invokestatic com/trolmastercard/velvet/da.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 1d7: athrow
      // 1d8: goto 4af
      // 1db: invokestatic com/trolmastercard/velvet/da.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 1de: athrow
      // 1df: aload 0
      // 1e0: getfield com/trolmastercard/velvet/da.j Lcom/trolmastercard/velvet/em;
      // 1e3: checkcast com/trolmastercard/velvet/f_
      // 1e6: invokevirtual com/trolmastercard/velvet/f_.b ()Lsoftware/bernie/geckolib3/core/processor/AnimationProcessor;
      // 1e9: ldc_w "head"
      // 1ec: invokevirtual software/bernie/geckolib3/core/processor/AnimationProcessor.getBone (Ljava/lang/String;)Lsoftware/bernie/geckolib3/core/processor/IBone;
      // 1ef: astore 6
      // 1f1: aload 6
      // 1f3: invokeinterface software/bernie/geckolib3/core/processor/IBone.getRotationX ()F 1
      // 1f8: invokestatic com/trolmastercard/velvet/gc.d (F)F
      // 1fb: fstore 7
      // 1fd: fload 7
      // 1ff: fconst_0
      // 200: fcmpg
      // 201: ifge 215
      // 204: aload 3
      // 205: fload 7
      // 207: fneg
      // 208: invokestatic com/trolmastercard/velvet/gc.c (F)F
      // 20b: invokevirtual software/bernie/geckolib3/geo/render/built/GeoBone.setRotationX (F)V
      // 20e: goto 4af
      // 211: invokestatic com/trolmastercard/velvet/da.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 214: athrow
      // 215: fconst_1
      // 216: fload 7
      // 218: ldc_w 45.0
      // 21b: fdiv
      // 21c: invokestatic java/lang/Math.min (FF)F
      // 21f: fstore 8
      // 221: aload 3
      // 222: fload 7
      // 224: fneg
      // 225: invokestatic com/trolmastercard/velvet/gc.c (F)F
      // 228: invokevirtual software/bernie/geckolib3/geo/render/built/GeoBone.setRotationX (F)V
      // 22b: aload 3
      // 22c: aload 3
      // 22d: invokevirtual software/bernie/geckolib3/geo/render/built/GeoBone.getPositionY ()F
      // 230: fload 8
      // 232: ldc_w 1.5
      // 235: fmul
      // 236: fadd
      // 237: invokevirtual software/bernie/geckolib3/geo/render/built/GeoBone.setPositionY (F)V
      // 23a: goto 4af
      // 23d: getstatic com/trolmastercard/velvet/da.i Lnet/minecraft/client/Minecraft;
      // 240: invokevirtual net/minecraft/client/Minecraft.func_147113_T ()Z
      // 243: ifeq 24d
      // 246: goto 4af
      // 249: invokestatic com/trolmastercard/velvet/da.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 24c: athrow
      // 24d: aload 0
      // 24e: getfield com/trolmastercard/velvet/da.j Lcom/trolmastercard/velvet/em;
      // 251: checkcast com/trolmastercard/velvet/f_
      // 254: invokevirtual com/trolmastercard/velvet/f_.b ()Lsoftware/bernie/geckolib3/core/processor/AnimationProcessor;
      // 257: ldc_w "head"
      // 25a: invokevirtual software/bernie/geckolib3/core/processor/AnimationProcessor.getBone (Ljava/lang/String;)Lsoftware/bernie/geckolib3/core/processor/IBone;
      // 25d: astore 6
      // 25f: aload 6
      // 261: invokeinterface software/bernie/geckolib3/core/processor/IBone.getRotationX ()F 1
      // 266: invokestatic com/trolmastercard/velvet/gc.d (F)F
      // 269: fstore 7
      // 26b: fload 7
      // 26d: fconst_0
      // 26e: fcmpg
      // 26f: ifge 285
      // 272: aload 3
      // 273: fload 7
      // 275: fneg
      // 276: fconst_2
      // 277: fdiv
      // 278: invokestatic com/trolmastercard/velvet/gc.c (F)F
      // 27b: invokevirtual software/bernie/geckolib3/geo/render/built/GeoBone.setRotationX (F)V
      // 27e: goto 4af
      // 281: invokestatic com/trolmastercard/velvet/da.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 284: athrow
      // 285: fconst_1
      // 286: fload 7
      // 288: ldc_w 45.0
      // 28b: fdiv
      // 28c: invokestatic java/lang/Math.min (FF)F
      // 28f: fstore 8
      // 291: aload 3
      // 292: fload 7
      // 294: fneg
      // 295: invokestatic com/trolmastercard/velvet/gc.c (F)F
      // 298: invokevirtual software/bernie/geckolib3/geo/render/built/GeoBone.setRotationX (F)V
      // 29b: aload 3
      // 29c: aload 3
      // 29d: invokevirtual software/bernie/geckolib3/geo/render/built/GeoBone.getPositionY ()F
      // 2a0: fload 8
      // 2a2: fadd
      // 2a3: invokevirtual software/bernie/geckolib3/geo/render/built/GeoBone.setPositionY (F)V
      // 2a6: goto 4af
      // 2a9: aload 0
      // 2aa: aload 3
      // 2ab: invokevirtual com/trolmastercard/velvet/da.c (Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;)V
      // 2ae: aload 0
      // 2af: getfield com/trolmastercard/velvet/da.j Lcom/trolmastercard/velvet/em;
      // 2b2: checkcast com/trolmastercard/velvet/f_
      // 2b5: invokevirtual com/trolmastercard/velvet/f_.y ()Lcom/trolmastercard/velvet/fp;
      // 2b8: astore 8
      // 2ba: aload 8
      // 2bc: getstatic com/trolmastercard/velvet/fp.FLY Lcom/trolmastercard/velvet/fp;
      // 2bf: if_acmpeq 2d8
      // 2c2: aload 8
      // 2c4: getstatic com/trolmastercard/velvet/fp.ATTACK_SWORD Lcom/trolmastercard/velvet/fp;
      // 2c7: if_acmpeq 2d8
      // 2ca: goto 2d1
      // 2cd: invokestatic com/trolmastercard/velvet/da.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 2d0: athrow
      // 2d1: goto 4af
      // 2d4: invokestatic com/trolmastercard/velvet/da.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 2d7: athrow
      // 2d8: aload 0
      // 2d9: getfield com/trolmastercard/velvet/da.j Lcom/trolmastercard/velvet/em;
      // 2dc: checkcast com/trolmastercard/velvet/f_
      // 2df: invokevirtual com/trolmastercard/velvet/f_.M ()Lnet/minecraft/entity/EntityLivingBase;
      // 2e2: astore 9
      // 2e4: aload 9
      // 2e6: ifnonnull 2f0
      // 2e9: goto 4af
      // 2ec: invokestatic com/trolmastercard/velvet/da.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 2ef: athrow
      // 2f0: getstatic com/trolmastercard/velvet/da.i Lnet/minecraft/client/Minecraft;
      // 2f3: invokevirtual net/minecraft/client/Minecraft.func_184121_ak ()F
      // 2f6: fstore 10
      // 2f8: new net/minecraft/util/math/Vec3d
      // 2fb: dup
      // 2fc: aload 0
      // 2fd: getfield com/trolmastercard/velvet/da.j Lcom/trolmastercard/velvet/em;
      // 300: checkcast com/trolmastercard/velvet/f_
      // 303: getfield com/trolmastercard/velvet/f_.field_70142_S D
      // 306: aload 0
      // 307: getfield com/trolmastercard/velvet/da.j Lcom/trolmastercard/velvet/em;
      // 30a: checkcast com/trolmastercard/velvet/f_
      // 30d: getfield com/trolmastercard/velvet/f_.field_70137_T D
      // 310: aload 0
      // 311: getfield com/trolmastercard/velvet/da.j Lcom/trolmastercard/velvet/em;
      // 314: checkcast com/trolmastercard/velvet/f_
      // 317: getfield com/trolmastercard/velvet/f_.field_70136_U D
      // 31a: invokespecial net/minecraft/util/math/Vec3d.<init> (DDD)V
      // 31d: aload 0
      // 31e: getfield com/trolmastercard/velvet/da.j Lcom/trolmastercard/velvet/em;
      // 321: checkcast com/trolmastercard/velvet/f_
      // 324: invokevirtual com/trolmastercard/velvet/f_.func_174791_d ()Lnet/minecraft/util/math/Vec3d;
      // 327: fload 10
      // 329: f2d
      // 32a: invokestatic com/trolmastercard/velvet/b6.a (Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/math/Vec3d;D)Lnet/minecraft/util/math/Vec3d;
      // 32d: astore 11
      // 32f: new net/minecraft/util/math/Vec3d
      // 332: dup
      // 333: aload 9
      // 335: getfield net/minecraft/entity/EntityLivingBase.field_70142_S D
      // 338: aload 9
      // 33a: getfield net/minecraft/entity/EntityLivingBase.field_70137_T D
      // 33d: aload 9
      // 33f: getfield net/minecraft/entity/EntityLivingBase.field_70136_U D
      // 342: invokespecial net/minecraft/util/math/Vec3d.<init> (DDD)V
      // 345: aload 0
      // 346: getfield com/trolmastercard/velvet/da.j Lcom/trolmastercard/velvet/em;
      // 349: checkcast com/trolmastercard/velvet/f_
      // 34c: invokevirtual com/trolmastercard/velvet/f_.func_174791_d ()Lnet/minecraft/util/math/Vec3d;
      // 34f: fload 10
      // 351: f2d
      // 352: invokestatic com/trolmastercard/velvet/b6.a (Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/math/Vec3d;D)Lnet/minecraft/util/math/Vec3d;
      // 355: astore 12
      // 357: aload 11
      // 359: aload 12
      // 35b: invokevirtual net/minecraft/util/math/Vec3d.func_178788_d (Lnet/minecraft/util/math/Vec3d;)Lnet/minecraft/util/math/Vec3d;
      // 35e: astore 13
      // 360: aload 13
      // 362: aload 0
      // 363: getfield com/trolmastercard/velvet/da.j Lcom/trolmastercard/velvet/em;
      // 366: checkcast com/trolmastercard/velvet/f_
      // 369: getfield com/trolmastercard/velvet/f_.field_70761_aq F
      // 36c: invokestatic com/trolmastercard/velvet/ck.a (Lnet/minecraft/util/math/Vec3d;F)Lnet/minecraft/util/math/Vec3d;
      // 36f: getfield net/minecraft/util/math/Vec3d.field_72449_c D
      // 372: d2f
      // 373: fstore 14
      // 375: aload 13
      // 377: getfield net/minecraft/util/math/Vec3d.field_72448_b D
      // 37a: fload 14
      // 37c: f2d
      // 37d: invokestatic java/lang/Math.atan2 (DD)D
      // 380: d2f
      // 381: fstore 7
      // 383: goto 4af
      // 386: aload 0
      // 387: getfield com/trolmastercard/velvet/da.j Lcom/trolmastercard/velvet/em;
      // 38a: checkcast com/trolmastercard/velvet/f_
      // 38d: getfield com/trolmastercard/velvet/f_.ap Z
      // 390: ifne 39a
      // 393: goto 4af
      // 396: invokestatic com/trolmastercard/velvet/da.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 399: athrow
      // 39a: invokestatic net/minecraft/client/renderer/GlStateManager.func_179094_E ()V
      // 39d: invokestatic net/minecraft/client/renderer/Tessellator.func_178181_a ()Lnet/minecraft/client/renderer/Tessellator;
      // 3a0: invokevirtual net/minecraft/client/renderer/Tessellator.func_78381_a ()V
      // 3a3: getstatic com/trolmastercard/velvet/da.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 3a6: aload 3
      // 3a7: invokestatic com/trolmastercard/velvet/p.a (Lsoftware/bernie/geckolib3/util/MatrixStack;Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;)V
      // 3aa: sipush 2896
      // 3ad: invokestatic org/lwjgl/opengl/GL11.glEnable (I)V
      // 3b0: ldc2_w 1.5
      // 3b3: dconst_1
      // 3b4: ldc2_w 2.0
      // 3b7: invokestatic net/minecraft/client/renderer/GlStateManager.func_179139_a (DDD)V
      // 3ba: dconst_0
      // 3bb: dconst_0
      // 3bc: ldc2_w 0.05
      // 3bf: invokestatic net/minecraft/client/renderer/GlStateManager.func_179137_b (DDD)V
      // 3c2: ldc_w 110.0
      // 3c5: fconst_1
      // 3c6: fconst_0
      // 3c7: fconst_0
      // 3c8: invokestatic net/minecraft/client/renderer/GlStateManager.func_179114_b (FFFF)V
      // 3cb: invokestatic net/minecraft/client/Minecraft.func_71410_x ()Lnet/minecraft/client/Minecraft;
      // 3ce: invokevirtual net/minecraft/client/Minecraft.func_175597_ag ()Lnet/minecraft/client/renderer/ItemRenderer;
      // 3d1: aload 0
      // 3d2: getfield com/trolmastercard/velvet/da.j Lcom/trolmastercard/velvet/em;
      // 3d5: new net/minecraft/item/ItemStack
      // 3d8: dup
      // 3d9: getstatic net/minecraft/init/Items.field_151040_l Lnet/minecraft/item/Item;
      // 3dc: invokespecial net/minecraft/item/ItemStack.<init> (Lnet/minecraft/item/Item;)V
      // 3df: getstatic net/minecraft/client/renderer/block/model/ItemCameraTransforms$TransformType.THIRD_PERSON_RIGHT_HAND Lnet/minecraft/client/renderer/block/model/ItemCameraTransforms$TransformType;
      // 3e2: invokevirtual net/minecraft/client/renderer/ItemRenderer.func_178099_a (Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/item/ItemStack;Lnet/minecraft/client/renderer/block/model/ItemCameraTransforms$TransformType;)V
      // 3e5: aload 0
      // 3e6: aload 0
      // 3e7: aload 0
      // 3e8: getfield com/trolmastercard/velvet/da.j Lcom/trolmastercard/velvet/em;
      // 3eb: invokevirtual com/trolmastercard/velvet/da.getEntityTexture (Lnet/minecraft/entity/EntityLivingBase;)Lnet/minecraft/util/ResourceLocation;
      // 3ee: invokestatic java/util/Objects.requireNonNull (Ljava/lang/Object;)Ljava/lang/Object;
      // 3f1: checkcast net/minecraft/util/ResourceLocation
      // 3f4: invokevirtual com/trolmastercard/velvet/da.func_110776_a (Lnet/minecraft/util/ResourceLocation;)V
      // 3f7: aload 1
      // 3f8: bipush 7
      // 3fa: getstatic net/minecraft/client/renderer/vertex/DefaultVertexFormats.field_181712_l Lnet/minecraft/client/renderer/vertex/VertexFormat;
      // 3fd: invokevirtual net/minecraft/client/renderer/BufferBuilder.func_181668_a (ILnet/minecraft/client/renderer/vertex/VertexFormat;)V
      // 400: sipush 2896
      // 403: invokestatic org/lwjgl/opengl/GL11.glDisable (I)V
      // 406: invokestatic net/minecraft/client/renderer/GlStateManager.func_179121_F ()V
      // 409: goto 4af
      // 40c: aload 0
      // 40d: aload 1
      // 40e: aload 3
      // 40f: invokevirtual com/trolmastercard/velvet/da.e (Lnet/minecraft/client/renderer/BufferBuilder;Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;)V
      // 412: goto 4af
      // 415: aload 0
      // 416: aload 1
      // 417: aload 3
      // 418: invokevirtual com/trolmastercard/velvet/da.c (Lnet/minecraft/client/renderer/BufferBuilder;Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;)V
      // 41b: goto 4af
      // 41e: aload 0
      // 41f: aload 3
      // 420: invokevirtual com/trolmastercard/velvet/da.d (Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;)V
      // 423: goto 4af
      // 426: aload 0
      // 427: aload 3
      // 428: invokevirtual com/trolmastercard/velvet/da.a (Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;)V
      // 42b: goto 4af
      // 42e: aload 0
      // 42f: aload 3
      // 430: invokevirtual com/trolmastercard/velvet/da.b (Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;)V
      // 433: goto 4af
      // 436: aload 0
      // 437: getfield com/trolmastercard/velvet/da.j Lcom/trolmastercard/velvet/em;
      // 43a: checkcast com/trolmastercard/velvet/f_
      // 43d: invokevirtual com/trolmastercard/velvet/f_.y ()Lcom/trolmastercard/velvet/fp;
      // 440: getstatic com/trolmastercard/velvet/fp.RAPE_CHARGE Lcom/trolmastercard/velvet/fp;
      // 443: if_acmpeq 44d
      // 446: goto 4af
      // 449: invokestatic com/trolmastercard/velvet/da.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 44c: athrow
      // 44d: aload 0
      // 44e: getfield com/trolmastercard/velvet/da.j Lcom/trolmastercard/velvet/em;
      // 451: checkcast com/trolmastercard/velvet/f_
      // 454: invokevirtual com/trolmastercard/velvet/f_.M ()Lnet/minecraft/entity/EntityLivingBase;
      // 457: astore 9
      // 459: aload 9
      // 45b: ifnonnull 465
      // 45e: goto 4af
      // 461: invokestatic com/trolmastercard/velvet/da.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 464: athrow
      // 465: aload 0
      // 466: getfield com/trolmastercard/velvet/da.j Lcom/trolmastercard/velvet/em;
      // 469: checkcast com/trolmastercard/velvet/f_
      // 46c: getfield com/trolmastercard/velvet/f_.field_70761_aq F
      // 46f: fstore 15
      // 471: aload 9
      // 473: invokevirtual net/minecraft/entity/EntityLivingBase.func_174791_d ()Lnet/minecraft/util/math/Vec3d;
      // 476: aload 0
      // 477: getfield com/trolmastercard/velvet/da.j Lcom/trolmastercard/velvet/em;
      // 47a: checkcast com/trolmastercard/velvet/f_
      // 47d: invokevirtual com/trolmastercard/velvet/f_.func_174791_d ()Lnet/minecraft/util/math/Vec3d;
      // 480: invokevirtual net/minecraft/util/math/Vec3d.func_178788_d (Lnet/minecraft/util/math/Vec3d;)Lnet/minecraft/util/math/Vec3d;
      // 483: astore 13
      // 485: aload 13
      // 487: fload 15
      // 489: invokestatic com/trolmastercard/velvet/ck.a (Lnet/minecraft/util/math/Vec3d;F)Lnet/minecraft/util/math/Vec3d;
      // 48c: astore 13
      // 48e: aload 13
      // 490: getfield net/minecraft/util/math/Vec3d.field_72450_a D
      // 493: ldc2_w -1.0
      // 496: dconst_1
      // 497: invokestatic com/trolmastercard/velvet/be.b (DDD)D
      // 49a: dneg
      // 49b: dstore 16
      // 49d: aload 3
      // 49e: aload 3
      // 49f: invokevirtual software/bernie/geckolib3/geo/render/built/GeoBone.getRotationZ ()F
      // 4a2: ldc2_w 45.0
      // 4a5: dload 16
      // 4a7: dmul
      // 4a8: invokestatic com/trolmastercard/velvet/gc.c (D)F
      // 4ab: fadd
      // 4ac: invokevirtual software/bernie/geckolib3/geo/render/built/GeoBone.setRotationZ (F)V
      // 4af: aload 0
      // 4b0: getfield com/trolmastercard/velvet/da.j Lcom/trolmastercard/velvet/em;
      // 4b3: checkcast com/trolmastercard/velvet/f_
      // 4b6: invokevirtual com/trolmastercard/velvet/f_.b ()Z
      // 4b9: ifeq 4cd
      // 4bc: aload 0
      // 4bd: getfield com/trolmastercard/velvet/da.j Lcom/trolmastercard/velvet/em;
      // 4c0: aload 2
      // 4c1: aload 3
      // 4c2: bipush 1
      // 4c3: invokestatic com/trolmastercard/velvet/dh.a (Lcom/trolmastercard/velvet/em;Ljava/lang/String;Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;Z)V
      // 4c6: goto 4cd
      // 4c9: invokestatic com/trolmastercard/velvet/da.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 4cc: athrow
      // 4cd: return
      // try (4 -> 11): 12 java/lang/RuntimeException
      // try (107 -> 112): 113 java/lang/RuntimeException
      // try (109 -> 116): 116 java/lang/RuntimeException
      // try (129 -> 139): 139 java/lang/RuntimeException
      // try (161 -> 165): 165 java/lang/RuntimeException
      // try (178 -> 190): 190 java/lang/RuntimeException
      // try (218 -> 224): 225 java/lang/RuntimeException
      // try (221 -> 228): 228 java/lang/RuntimeException
      // try (235 -> 238): 238 java/lang/RuntimeException
      // try (304 -> 310): 310 java/lang/RuntimeException
      // try (381 -> 388): 388 java/lang/RuntimeException
      // try (395 -> 398): 398 java/lang/RuntimeException
      // try (433 -> 444): 445 java/lang/RuntimeException
   }

   void e(BufferBuilder var1, GeoBone var2) {
      try {
         if (fp.a(this.j, fp.PUSSY_LICKING, fp.MASTERBATE_SITTING)) {
            this.f(var1, var2);
            return;
         }
      } catch (RuntimeException var4) {
         throw a(var4);
      }

      try {
         if (fp.a(this.j, fp.MORNING_BLOWJOB_SLOW)) {
            this.d(var1, var2);
         }
      } catch (RuntimeException var3) {
         throw a(var3);
      }
   }

   void c(BufferBuilder param1, GeoBone param2) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 00: aload 0
      // 01: getfield com/trolmastercard/velvet/da.j Lcom/trolmastercard/velvet/em;
      // 04: bipush 1
      // 05: anewarray 118
      // 08: dup
      // 09: bipush 0
      // 0a: getstatic com/trolmastercard/velvet/fp.MORNING_BLOWJOB_SLOW Lcom/trolmastercard/velvet/fp;
      // 0d: aastore
      // 0e: invokestatic com/trolmastercard/velvet/fp.a (Lcom/trolmastercard/velvet/em;[Lcom/trolmastercard/velvet/fp;)Z
      // 11: ifne 2d
      // 14: aload 0
      // 15: getfield com/trolmastercard/velvet/da.j Lcom/trolmastercard/velvet/em;
      // 18: checkcast com/trolmastercard/velvet/f_
      // 1b: getfield com/trolmastercard/velvet/f_.aD Z
      // 1e: ifne 2d
      // 21: goto 28
      // 24: invokestatic com/trolmastercard/velvet/da.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 27: athrow
      // 28: return
      // 29: invokestatic com/trolmastercard/velvet/da.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 2c: athrow
      // 2d: aload 0
      // 2e: getfield com/trolmastercard/velvet/da.j Lcom/trolmastercard/velvet/em;
      // 31: checkcast com/trolmastercard/velvet/f_
      // 34: getfield com/trolmastercard/velvet/f_.aD Z
      // 37: ifeq 5a
      // 3a: fconst_1
      // 3b: ldc_w 0.29
      // 3e: aload 0
      // 3f: getfield com/trolmastercard/velvet/da.j Lcom/trolmastercard/velvet/em;
      // 42: getstatic com/trolmastercard/velvet/da.i Lnet/minecraft/client/Minecraft;
      // 45: invokevirtual net/minecraft/client/Minecraft.func_184121_ak ()F
      // 48: invokestatic com/trolmastercard/velvet/fp.a (Lcom/trolmastercard/velvet/em;F)F
      // 4b: invokestatic java/lang/Math.min (FF)F
      // 4e: ldc_w 0.29
      // 51: fdiv
      // 52: fsub
      // 53: goto 5b
      // 56: invokestatic com/trolmastercard/velvet/da.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 59: athrow
      // 5a: fconst_1
      // 5b: fstore 3
      // 5c: aload 0
      // 5d: aload 1
      // 5e: aload 2
      // 5f: fload 3
      // 60: invokevirtual com/trolmastercard/velvet/da.a (Lnet/minecraft/client/renderer/BufferBuilder;Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;F)V
      // 63: aload 0
      // 64: getstatic com/trolmastercard/velvet/ce.j Lnet/minecraft/util/ResourceLocation;
      // 67: invokevirtual com/trolmastercard/velvet/da.func_110776_a (Lnet/minecraft/util/ResourceLocation;)V
      // 6a: return
      // try (0 -> 15): 16 java/lang/RuntimeException
      // try (10 -> 19): 19 java/lang/RuntimeException
      // try (21 -> 38): 38 java/lang/RuntimeException
   }

   void d(GeoBone var1) {
      try {
         if (!fp.a(this.j, fp.MORNING_BLOWJOB_SLOW, fp.MORNING_BLOWJOB_FAST)) {
            return;
         }
      } catch (RuntimeException var7) {
         throw a(var7);
      }

      try {
         if (i.func_147113_T()) {
            return;
         }
      } catch (RuntimeException var9) {
         throw a(var9);
      }

      float var2 = i.field_71439_g.field_70173_aa + i.func_184121_ak();
      float var3 = (float)(Math.sin(var2 * 0.1F) * 0.1F) + 0.2F;
      float var4 = (float)Math.sin(var2 * 0.1F) * 0.1F;

      try {
         if (fp.a(this.j, fp.MORNING_BLOWJOB_SLOW)) {
            var1.setRotationY(var1.getRotationY() + var3);
            var1.setRotationZ(var1.getRotationZ() + var4);
            return;
         }
      } catch (RuntimeException var6) {
         throw a(var6);
      }

      try {
         if (!this.j.aD) {
            return;
         }
      } catch (RuntimeException var8) {
         throw a(var8);
      }

      float var5 = 1.0F - Math.min(0.5F, fp.a(this.j, i.func_184121_ak())) / 0.5F;
      var1.setRotationY(var1.getRotationY() + var3 * var5);
      var1.setRotationZ(var1.getRotationZ() + var4 * var5);
   }

   void c(GeoBone var1) {
      try {
         if (!fp.a(this.j, fp.MORNING_BLOWJOB_SLOW, fp.MORNING_BLOWJOB_FAST)) {
            return;
         }
      } catch (RuntimeException var7) {
         throw a(var7);
      }

      try {
         if (i.func_147113_T()) {
            return;
         }
      } catch (RuntimeException var9) {
         throw a(var9);
      }

      float var2 = i.field_71439_g.field_70173_aa + i.func_184121_ak();
      float var3 = (float)Math.sin(var2 * -0.1F) * 0.1F;
      float var4 = (float)Math.sin(var2 * 0.1F) * 0.1F;

      try {
         if (fp.a(this.j, fp.MORNING_BLOWJOB_SLOW)) {
            var1.setRotationY(var1.getRotationY() + var3);
            var1.setRotationZ(var1.getRotationZ() + var4);
            return;
         }
      } catch (RuntimeException var6) {
         throw a(var6);
      }

      try {
         if (!this.j.aD) {
            return;
         }
      } catch (RuntimeException var8) {
         throw a(var8);
      }

      float var5 = Math.min(0.5F, fp.a(this.j, i.func_184121_ak())) / 0.5F;
      var1.setRotationY(var1.getRotationY() + var3 * var5);
      var1.setRotationZ(var1.getRotationZ() + var4 * var5);
   }

   void a(GeoBone var1) {
      try {
         if (!fp.a(this.j, fp.MORNING_BLOWJOB_SLOW)) {
            return;
         }
      } catch (RuntimeException var3) {
         throw a(var3);
      }

      try {
         if (i.func_147113_T()) {
            return;
         }
      } catch (RuntimeException var4) {
         throw a(var4);
      }

      float var2 = i.field_71439_g.field_70173_aa + i.func_184121_ak();
      var1.setPositionX((float)(var1.getPositionX() + Math.sin(var2 * 0.1F) * -0.1F));
   }

   void b(GeoBone var1) {
      try {
         if (!fp.a(this.j, fp.MORNING_BLOWJOB_SLOW)) {
            return;
         }
      } catch (RuntimeException var3) {
         throw a(var3);
      }

      try {
         if (i.func_147113_T()) {
            return;
         }
      } catch (RuntimeException var4) {
         throw a(var4);
      }

      float var2 = i.field_71439_g.field_70173_aa + i.func_184121_ak();
      var1.setPositionX((float)(var1.getPositionX() + Math.sin(var2 * 0.1F) * -0.15F));
   }

   void a(BufferBuilder var1, GeoBone var2, float var3) {
      float var4 = fp.d(this.j, i.func_184121_ak());
      float var5 = var3 * (float)(0.02F * (-0.4F * Math.cos((Math.PI * 2) * var4 + 1.05) + 0.6F));
      ef.b var6 = new ef.b(
         H,
         0.0F,
         12,
         var5,
         (var2x, var3x) -> var3 * (float)(Math.cos((Math.PI * 2) * var4 + 0.35F + -0.2F * var2x) * -10.0),
         (var0, var1x) -> 0.0F,
         (var2x, var3x) -> var3 * (float)(Math.cos((Math.PI * 2) * var4 + 1.25 + -0.1F * var2x) * -5.0),
         0.03F,
         0.005F
      );
      this.a(var1, var2, var6);
   }

   void d(BufferBuilder var1, GeoBone var2) {
      float var3 = fp.d(this.j, i.func_184121_ak());
      ef.b var4 = new ef.b(
         H,
         0.0F,
         12,
         0.02F,
         (var1x, var2x) -> (float)(Math.cos((Math.PI * 2) * var3 + -0.2F * var1x) * 15.0),
         (var1x, var2x) -> (float)(Math.cos((Math.PI * 2) * var3 + -0.2F * var1x) * 5.0),
         (var0, var1x) -> 0.0F,
         0.03F,
         0.005F
      );
      this.a(var1, var2, var4);
   }

   void f(BufferBuilder var1, GeoBone var2) {
      float var3 = this.j.b(i.func_184121_ak());

      try {
         if (var3 == 0.0F) {
            this.a(var1, var2, G);
            return;
         }
      } catch (RuntimeException var5) {
         throw a(var5);
      }

      try {
         if (var3 == 1.0F) {
            this.a(var1, var2, t);
            return;
         }
      } catch (RuntimeException var6) {
         throw a(var6);
      }

      ef.b var4 = G.a();
      var4.g = b6.a(G.g, 0.0F, var3);
      var4.e = b6.a(G.e, 0.0F, var3);
      this.a(var1, var2, var4);
   }

   void a(BufferBuilder var1, GeoBone var2, ef.b var3) {
      GlStateManager.func_179094_E();
      Tessellator.func_178181_a().func_78381_a();
      org.velvet.p.a(MATRIX_STACK, var2);
      GlStateManager.func_179129_p();
      this.func_110776_a(e);
      ef.a(var1, Tessellator.func_178181_a(), i, var3);
      this.func_110776_a(Objects.requireNonNull(this.getEntityTexture(this.j)));
      var1.func_181668_a(7, DefaultVertexFormats.field_181712_l);
      GlStateManager.func_179089_o();
      GlStateManager.func_179121_F();
   }

   void a(BufferBuilder var1, GeoBone var2, f_ var3, float var4) {
      try {
         if (var3.y() != fp.GIVE_COIN) {
            return;
         }
      } catch (RuntimeException var14) {
         throw a(var14);
      }

      n = var1;
      var1.func_181668_a(7, DefaultVertexFormats.field_181712_l);
      MATRIX_STACK.push();
      MATRIX_STACK.translate(var2);
      MATRIX_STACK.moveToPivot(var2);
      MATRIX_STACK.rotate(var2);
      MATRIX_STACK.scale(var2);
      MATRIX_STACK.moveBackFromPivot(var2);
      if (!this.p.contains(var2.getName())) {
         for (GeoCube var6 : var2.childCubes) {
            MATRIX_STACK.push();
            GlStateManager.func_179094_E();
            this.q = var2;
            this.a(var1, var6, 1.0F, 1.0F, 1.0F, 1.0F, (double)0.0);
            GlStateManager.func_179121_F();
            MATRIX_STACK.pop();
         }
      }

      Tessellator.func_178181_a().func_78381_a();
      GeoBone var15 = var2.childBones.get(0);
      var1.func_181668_a(7, DefaultVertexFormats.field_181712_l);
      GL11.glDisable(2896);
      float var16 = be.b(fp.GIVE_COIN.ticksPlaying[1] + var4, 105.0F, 125.0F);
      float var7 = (var16 - 105.0F) / 20.0F;
      float var8 = b6.a(120.0F, 240.0F, var7);
      f7 var9 = b6.a(av.f, av.e, var7);
      float var10 = OpenGlHelper.lastBrightnessX;
      float var11 = OpenGlHelper.lastBrightnessY;
      OpenGlHelper.func_77475_a(OpenGlHelper.field_77476_b, var8, var8);
      MATRIX_STACK.push();
      MATRIX_STACK.translate(var15);
      MATRIX_STACK.moveToPivot(var15);
      MATRIX_STACK.rotate(var15);
      MATRIX_STACK.scale(var15);
      MATRIX_STACK.moveBackFromPivot(var15);
      if (!this.p.contains(var15.getName())) {
         for (GeoCube var13 : var15.childCubes) {
            MATRIX_STACK.push();
            GlStateManager.func_179094_E();
            this.q = var15;
            this.a(var1, var13, var9.a, var9.c, var9.b, 1.0F, (double)0.0);
            GlStateManager.func_179121_F();
            MATRIX_STACK.pop();
         }
      }

      MATRIX_STACK.pop();
      MATRIX_STACK.pop();
      Tessellator.func_178181_a().func_78381_a();
      GL11.glEnable(2896);
      OpenGlHelper.func_77475_a(OpenGlHelper.field_77476_b, var10, var11);
   }

   protected Vec3d a(f_ var1, float var2, Vec3d var3) {
      if (var1.y() == fp.RUN) {
         float var4 = var1.I();
         var1.field_70177_z = var4;
         var1.field_70760_ar = var4;
         var1.field_70761_aq = var4;
         var1.field_70758_at = var4;
         var1.field_70759_as = var4;
      }

      return var3;
   }

   private static Exception a(Exception var0) {
      return var0;
   }
}
