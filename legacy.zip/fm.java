package org.velvet;

public enum fm {
   ACTIVE,
   REST;
}
