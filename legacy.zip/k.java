package org.velvet;

import net.minecraft.util.ResourceLocation;
import software.bernie.geckolib3.model.AnimatedGeoModel;

public class k extends AnimatedGeoModel<i> {
   public ResourceLocation b(i var1) {
      return new ResourceLocation("velvet", "geo/kobold/koboldegg.geo.json");
   }

   public ResourceLocation c(i var1) {
      return new ResourceLocation("velvet", "textures/entity/kobold/koboldegg.png");
   }

   public ResourceLocation a(i var1) {
      return new ResourceLocation("velvet", "animations/kobold/egg.animation.json");
   }
}
