package org.velvet;

import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class m extends GuiScreen {
   final em g;
   final EntityPlayer i;
   final String[] h;
   @Nullable
   final ItemStack[] f;
   static final ResourceLocation c = new ResourceLocation("velvet", "textures/gui/girlinventory.png");
   EntityDataManager l;
   final boolean k;
   float m = 0.0F;
   float n = 0.0F;
   String[] a = new String[]{"action.names.followme", "action.names.stopfollowme", "action.names.gohome", "action.names.setnewhome", "action.names.equipment"};
   int[] d = new int[]{0, 0, 0, 0, 0};
   int[] j = new int[]{64, 80, 47, 32, 96};
   int[] b = new int[]{4, 4, 5, 5, 4};
   int[] e = new int[]{50, 90, 50, 80, 60};

   public m(em var1, EntityPlayer var2) {
      this.g = var1;
      this.i = var2;
      this.h = new String[0];
      this.f = new ItemStack[0];
      this.k = true;
      this.l = var1.func_184212_Q();
   }

   public m(em var1, EntityPlayer var2, String[] var3, @Nullable ItemStack[] var4, boolean var5) {
      this.g = var1;
      this.i = var2;
      this.h = var3;
      this.f = var4;
      this.k = var5;
      this.l = var1.func_184212_Q();
   }

   public boolean func_73868_f() {
      return false;
   }

   @SideOnly(Side.CLIENT)
   public void func_146281_b() {
      super.func_146281_b();
      this.g.ac();
   }

   protected void func_146284_a(GuiButton param1) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 000: aload 1
      // 001: getfield net/minecraft/client/gui/GuiButton.field_146127_k I
      // 004: bipush 5
      // 005: if_icmplt 03f
      // 008: aload 0
      // 009: getfield com/trolmastercard/velvet/m.f [Lnet/minecraft/item/ItemStack;
      // 00c: ifnull 03f
      // 00f: goto 016
      // 012: invokestatic com/trolmastercard/velvet/m.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 015: athrow
      // 016: aload 0
      // 017: getfield com/trolmastercard/velvet/m.f [Lnet/minecraft/item/ItemStack;
      // 01a: aload 1
      // 01b: getfield net/minecraft/client/gui/GuiButton.field_146127_k I
      // 01e: bipush 5
      // 01f: isub
      // 020: aaload
      // 021: ifnull 03f
      // 024: goto 02b
      // 027: invokestatic com/trolmastercard/velvet/m.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 02a: athrow
      // 02b: aload 0
      // 02c: getfield com/trolmastercard/velvet/m.i Lnet/minecraft/entity/player/EntityPlayer;
      // 02f: getfield net/minecraft/entity/player/EntityPlayer.field_71075_bZ Lnet/minecraft/entity/player/PlayerCapabilities;
      // 032: getfield net/minecraft/entity/player/PlayerCapabilities.field_75098_d Z
      // 035: ifeq 049
      // 038: goto 03f
      // 03b: invokestatic com/trolmastercard/velvet/m.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 03e: athrow
      // 03f: aload 0
      // 040: aload 1
      // 041: invokevirtual com/trolmastercard/velvet/m.a (Lnet/minecraft/client/gui/GuiButton;)V
      // 044: return
      // 045: invokestatic com/trolmastercard/velvet/m.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 048: athrow
      // 049: aload 0
      // 04a: getfield com/trolmastercard/velvet/m.i Lnet/minecraft/entity/player/EntityPlayer;
      // 04d: getfield net/minecraft/entity/player/EntityPlayer.field_71071_by Lnet/minecraft/entity/player/InventoryPlayer;
      // 050: getfield net/minecraft/entity/player/InventoryPlayer.field_70462_a Lnet/minecraft/util/NonNullList;
      // 053: invokevirtual net/minecraft/util/NonNullList.iterator ()Ljava/util/Iterator;
      // 056: astore 2
      // 057: aload 2
      // 058: invokeinterface java/util/Iterator.hasNext ()Z 1
      // 05d: ifeq 0e6
      // 060: aload 2
      // 061: invokeinterface java/util/Iterator.next ()Ljava/lang/Object; 1
      // 066: checkcast net/minecraft/item/ItemStack
      // 069: astore 3
      // 06a: aload 3
      // 06b: invokevirtual net/minecraft/item/ItemStack.func_77973_b ()Lnet/minecraft/item/Item;
      // 06e: aload 0
      // 06f: getfield com/trolmastercard/velvet/m.f [Lnet/minecraft/item/ItemStack;
      // 072: aload 1
      // 073: getfield net/minecraft/client/gui/GuiButton.field_146127_k I
      // 076: bipush 5
      // 077: isub
      // 078: aaload
      // 079: invokevirtual net/minecraft/item/ItemStack.func_77973_b ()Lnet/minecraft/item/Item;
      // 07c: invokevirtual java/lang/Object.equals (Ljava/lang/Object;)Z
      // 07f: ifeq 0e3
      // 082: aload 3
      // 083: invokevirtual net/minecraft/item/ItemStack.func_190916_E ()I
      // 086: aload 0
      // 087: getfield com/trolmastercard/velvet/m.f [Lnet/minecraft/item/ItemStack;
      // 08a: aload 1
      // 08b: getfield net/minecraft/client/gui/GuiButton.field_146127_k I
      // 08e: bipush 5
      // 08f: isub
      // 090: aaload
      // 091: invokevirtual net/minecraft/item/ItemStack.func_190916_E ()I
      // 094: if_icmplt 0e3
      // 097: goto 09e
      // 09a: invokestatic com/trolmastercard/velvet/m.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 09d: athrow
      // 09e: aload 3
      // 09f: invokevirtual net/minecraft/item/ItemStack.func_77960_j ()I
      // 0a2: aload 0
      // 0a3: getfield com/trolmastercard/velvet/m.f [Lnet/minecraft/item/ItemStack;
      // 0a6: aload 1
      // 0a7: getfield net/minecraft/client/gui/GuiButton.field_146127_k I
      // 0aa: bipush 5
      // 0ab: isub
      // 0ac: aaload
      // 0ad: invokevirtual net/minecraft/item/ItemStack.func_77960_j ()I
      // 0b0: if_icmpne 0e3
      // 0b3: goto 0ba
      // 0b6: invokestatic com/trolmastercard/velvet/m.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 0b9: athrow
      // 0ba: getstatic com/trolmastercard/velvet/ge.b Lnet/minecraftforge/fml/common/network/simpleimpl/SimpleNetworkWrapper;
      // 0bd: new com/trolmastercard/velvet/t
      // 0c0: dup
      // 0c1: aload 0
      // 0c2: getfield com/trolmastercard/velvet/m.i Lnet/minecraft/entity/player/EntityPlayer;
      // 0c5: invokevirtual net/minecraft/entity/player/EntityPlayer.getPersistentID ()Ljava/util/UUID;
      // 0c8: aload 0
      // 0c9: getfield com/trolmastercard/velvet/m.f [Lnet/minecraft/item/ItemStack;
      // 0cc: aload 1
      // 0cd: getfield net/minecraft/client/gui/GuiButton.field_146127_k I
      // 0d0: bipush 5
      // 0d1: isub
      // 0d2: aaload
      // 0d3: invokespecial com/trolmastercard/velvet/t.<init> (Ljava/util/UUID;Lnet/minecraft/item/ItemStack;)V
      // 0d6: invokevirtual net/minecraftforge/fml/common/network/simpleimpl/SimpleNetworkWrapper.sendToServer (Lnet/minecraftforge/fml/common/network/simpleimpl/IMessage;)V
      // 0d9: aload 0
      // 0da: aload 1
      // 0db: invokevirtual com/trolmastercard/velvet/m.a (Lnet/minecraft/client/gui/GuiButton;)V
      // 0de: return
      // 0df: invokestatic com/trolmastercard/velvet/m.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 0e2: athrow
      // 0e3: goto 057
      // 0e6: aload 0
      // 0e7: getfield com/trolmastercard/velvet/m.i Lnet/minecraft/entity/player/EntityPlayer;
      // 0ea: new net/minecraft/util/text/TextComponentString
      // 0ed: dup
      // 0ee: new java/lang/StringBuilder
      // 0f1: dup
      // 0f2: invokespecial java/lang/StringBuilder.<init> ()V
      // 0f5: ldc "<"
      // 0f7: invokevirtual java/lang/StringBuilder.append (Ljava/lang/String;)Ljava/lang/StringBuilder;
      // 0fa: aload 0
      // 0fb: getfield com/trolmastercard/velvet/m.g Lcom/trolmastercard/velvet/em;
      // 0fe: invokevirtual com/trolmastercard/velvet/em.func_70005_c_ ()Ljava/lang/String;
      // 101: invokevirtual java/lang/StringBuilder.append (Ljava/lang/String;)Ljava/lang/StringBuilder;
      // 104: ldc "> you cannot afford that..."
      // 106: invokevirtual java/lang/StringBuilder.append (Ljava/lang/String;)Ljava/lang/StringBuilder;
      // 109: invokevirtual java/lang/StringBuilder.toString ()Ljava/lang/String;
      // 10c: invokespecial net/minecraft/util/text/TextComponentString.<init> (Ljava/lang/String;)V
      // 10f: invokevirtual net/minecraft/entity/player/EntityPlayer.func_145747_a (Lnet/minecraft/util/text/ITextComponent;)V
      // 112: aload 0
      // 113: getfield com/trolmastercard/velvet/m.g Lcom/trolmastercard/velvet/em;
      // 116: getstatic com/trolmastercard/velvet/c.GIRLS_JENNY_SADOH [Lnet/minecraft/util/SoundEvent;
      // 119: bipush 1
      // 11a: aaload
      // 11b: invokevirtual com/trolmastercard/velvet/em.a (Lnet/minecraft/util/SoundEvent;)V
      // 11e: return
      // try (0 -> 7): 8 java/lang/RuntimeException
      // try (4 -> 18): 19 java/lang/RuntimeException
      // try (10 -> 26): 27 java/lang/RuntimeException
      // try (21 -> 33): 33 java/lang/RuntimeException
      // try (48 -> 71): 72 java/lang/RuntimeException
      // try (60 -> 85): 86 java/lang/RuntimeException
      // try (74 -> 107): 107 java/lang/RuntimeException
   }

   void a(GuiButton var1) {
      String var2;
      if (var1.field_146127_k < 5) {
         var2 = this.a[var1.field_146127_k];
      } else {
         var2 = this.h[var1.field_146127_k - 5];
      }

      this.g.a(var2, this.i.getPersistentID());
      Minecraft.func_71410_x().field_71439_g.func_71053_j();
   }

   public void func_73863_a(int param1, int param2, float param3) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 000: aload 0
      // 001: iload 1
      // 002: iload 2
      // 003: fload 3
      // 004: invokespecial net/minecraft/client/gui/GuiScreen.func_73863_a (IIF)V
      // 007: aload 0
      // 008: getfield com/trolmastercard/velvet/m.field_146292_n Ljava/util/List;
      // 00b: invokeinterface java/util/List.clear ()V 1
      // 010: new net/minecraft/client/gui/ScaledResolution
      // 013: dup
      // 014: aload 0
      // 015: getfield com/trolmastercard/velvet/m.field_146297_k Lnet/minecraft/client/Minecraft;
      // 018: invokespecial net/minecraft/client/gui/ScaledResolution.<init> (Lnet/minecraft/client/Minecraft;)V
      // 01b: astore 4
      // 01d: aload 4
      // 01f: invokevirtual net/minecraft/client/gui/ScaledResolution.func_78326_a ()I
      // 022: istore 5
      // 024: aload 4
      // 026: invokevirtual net/minecraft/client/gui/ScaledResolution.func_78328_b ()I
      // 029: istore 6
      // 02b: aload 0
      // 02c: fconst_1
      // 02d: aload 0
      // 02e: getfield com/trolmastercard/velvet/m.m F
      // 031: aload 0
      // 032: getfield com/trolmastercard/velvet/m.field_146297_k Lnet/minecraft/client/Minecraft;
      // 035: invokevirtual net/minecraft/client/Minecraft.func_193989_ak ()F
      // 038: ldc_w 5.0
      // 03b: fdiv
      // 03c: fadd
      // 03d: invokestatic java/lang/Math.min (FF)F
      // 040: putfield com/trolmastercard/velvet/m.m F
      // 043: aload 0
      // 044: getfield com/trolmastercard/velvet/m.m F
      // 047: fconst_1
      // 048: fcmpl
      // 049: ifne 06b
      // 04c: aload 0
      // 04d: fconst_1
      // 04e: aload 0
      // 04f: getfield com/trolmastercard/velvet/m.n F
      // 052: aload 0
      // 053: getfield com/trolmastercard/velvet/m.field_146297_k Lnet/minecraft/client/Minecraft;
      // 056: invokevirtual net/minecraft/client/Minecraft.func_193989_ak ()F
      // 059: ldc_w 5.0
      // 05c: fdiv
      // 05d: fadd
      // 05e: invokestatic java/lang/Math.min (FF)F
      // 061: putfield com/trolmastercard/velvet/m.n F
      // 064: goto 06b
      // 067: invokestatic com/trolmastercard/velvet/m.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 06a: athrow
      // 06b: ldc_w 115.0
      // 06e: ldc_w 161.0
      // 071: aload 0
      // 072: getfield com/trolmastercard/velvet/m.n F
      // 075: invokestatic com/trolmastercard/velvet/b6.a (FFF)F
      // 078: f2i
      // 079: istore 7
      // 07b: ldc_w 91.0
      // 07e: ldc_w 137.0
      // 081: aload 0
      // 082: getfield com/trolmastercard/velvet/m.n F
      // 085: invokestatic com/trolmastercard/velvet/b6.a (FFF)F
      // 088: f2i
      // 089: istore 8
      // 08b: ldc_w -30.0
      // 08e: ldc_w 120.0
      // 091: aload 0
      // 092: getfield com/trolmastercard/velvet/m.m F
      // 095: invokestatic com/trolmastercard/velvet/b6.a (FFF)F
      // 098: f2i
      // 099: istore 9
      // 09b: bipush 70
      // 09d: istore 10
      // 09f: bipush 52
      // 0a1: istore 11
      // 0a3: bipush 68
      // 0a5: istore 12
      // 0a7: bipush 5
      // 0a8: istore 13
      // 0aa: iload 13
      // 0ac: aload 0
      // 0ad: getfield com/trolmastercard/velvet/m.h [Ljava/lang/String;
      // 0b0: arraylength
      // 0b1: bipush 5
      // 0b2: iadd
      // 0b3: if_icmpge 1b7
      // 0b6: aload 0
      // 0b7: getfield com/trolmastercard/velvet/m.n F
      // 0ba: fconst_0
      // 0bb: fcmpl
      // 0bc: ifle 177
      // 0bf: goto 0c6
      // 0c2: invokestatic com/trolmastercard/velvet/m.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 0c5: athrow
      // 0c6: aload 0
      // 0c7: getfield com/trolmastercard/velvet/m.f [Lnet/minecraft/item/ItemStack;
      // 0ca: ifnull 177
      // 0cd: goto 0d4
      // 0d0: invokestatic com/trolmastercard/velvet/m.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 0d3: athrow
      // 0d4: aload 0
      // 0d5: getfield com/trolmastercard/velvet/m.f [Lnet/minecraft/item/ItemStack;
      // 0d8: iload 13
      // 0da: bipush 5
      // 0db: isub
      // 0dc: aaload
      // 0dd: ifnull 177
      // 0e0: goto 0e7
      // 0e3: invokestatic com/trolmastercard/velvet/m.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 0e6: athrow
      // 0e7: aload 0
      // 0e8: getfield com/trolmastercard/velvet/m.f [Lnet/minecraft/item/ItemStack;
      // 0eb: iload 13
      // 0ed: bipush 5
      // 0ee: isub
      // 0ef: aaload
      // 0f0: invokevirtual net/minecraft/item/ItemStack.func_190916_E ()I
      // 0f3: ifeq 177
      // 0f6: goto 0fd
      // 0f9: invokestatic com/trolmastercard/velvet/m.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 0fc: athrow
      // 0fd: aload 0
      // 0fe: ldc_w -300.0
      // 101: putfield com/trolmastercard/velvet/m.field_73735_i F
      // 104: aload 0
      // 105: getfield com/trolmastercard/velvet/m.field_146296_j Lnet/minecraft/client/renderer/RenderItem;
      // 108: ldc_w -300.0
      // 10b: putfield net/minecraft/client/renderer/RenderItem.field_77023_b F
      // 10e: aload 0
      // 10f: bipush 1
      // 110: anewarray 40
      // 113: dup
      // 114: bipush 0
      // 115: new java/lang/StringBuilder
      // 118: dup
      // 119: invokespecial java/lang/StringBuilder.<init> ()V
      // 11c: aload 0
      // 11d: getfield com/trolmastercard/velvet/m.f [Lnet/minecraft/item/ItemStack;
      // 120: iload 13
      // 122: bipush 5
      // 123: isub
      // 124: aaload
      // 125: invokevirtual net/minecraft/item/ItemStack.func_190916_E ()I
      // 128: invokevirtual java/lang/StringBuilder.append (I)Ljava/lang/StringBuilder;
      // 12b: ldc_w "x    "
      // 12e: invokevirtual java/lang/StringBuilder.append (Ljava/lang/String;)Ljava/lang/StringBuilder;
      // 131: invokevirtual java/lang/StringBuilder.toString ()Ljava/lang/String;
      // 134: aastore
      // 135: invokestatic java/util/Arrays.asList ([Ljava/lang/Object;)Ljava/util/List;
      // 138: iload 5
      // 13a: iload 7
      // 13c: isub
      // 13d: iload 6
      // 13f: iload 11
      // 141: isub
      // 142: aload 0
      // 143: getfield com/trolmastercard/velvet/m.field_146289_q Lnet/minecraft/client/gui/FontRenderer;
      // 146: invokevirtual com/trolmastercard/velvet/m.a (Ljava/util/List;IILnet/minecraft/client/gui/FontRenderer;)V
      // 149: aload 0
      // 14a: getfield com/trolmastercard/velvet/m.field_146296_j Lnet/minecraft/client/renderer/RenderItem;
      // 14d: aload 0
      // 14e: getfield com/trolmastercard/velvet/m.f [Lnet/minecraft/item/ItemStack;
      // 151: iload 13
      // 153: bipush 5
      // 154: isub
      // 155: aaload
      // 156: iload 5
      // 158: iload 8
      // 15a: isub
      // 15b: iload 6
      // 15d: iload 12
      // 15f: isub
      // 160: invokevirtual net/minecraft/client/renderer/RenderItem.func_175042_a (Lnet/minecraft/item/ItemStack;II)V
      // 163: aload 0
      // 164: fconst_0
      // 165: putfield com/trolmastercard/velvet/m.field_73735_i F
      // 168: aload 0
      // 169: getfield com/trolmastercard/velvet/m.field_146296_j Lnet/minecraft/client/renderer/RenderItem;
      // 16c: fconst_0
      // 16d: putfield net/minecraft/client/renderer/RenderItem.field_77023_b F
      // 170: goto 177
      // 173: invokestatic com/trolmastercard/velvet/m.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 176: athrow
      // 177: aload 0
      // 178: getfield com/trolmastercard/velvet/m.field_146292_n Ljava/util/List;
      // 17b: new net/minecraft/client/gui/GuiButton
      // 17e: dup
      // 17f: iload 13
      // 181: iload 5
      // 183: iload 9
      // 185: isub
      // 186: iload 6
      // 188: iload 10
      // 18a: isub
      // 18b: bipush 100
      // 18d: bipush 20
      // 18f: aload 0
      // 190: getfield com/trolmastercard/velvet/m.h [Ljava/lang/String;
      // 193: iload 13
      // 195: bipush 5
      // 196: isub
      // 197: aaload
      // 198: bipush 0
      // 199: anewarray 150
      // 19c: invokestatic net/minecraft/client/resources/I18n.func_135052_a (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
      // 19f: invokespecial net/minecraft/client/gui/GuiButton.<init> (IIIIILjava/lang/String;)V
      // 1a2: invokeinterface java/util/List.add (Ljava/lang/Object;)Z 2
      // 1a7: pop
      // 1a8: iinc 10 30
      // 1ab: iinc 11 30
      // 1ae: iinc 12 30
      // 1b1: iinc 13 1
      // 1b4: goto 0aa
      // 1b7: aload 0
      // 1b8: getfield com/trolmastercard/velvet/m.k Z
      // 1bb: ifeq 1cb
      // 1be: aload 0
      // 1bf: iload 1
      // 1c0: iload 2
      // 1c1: invokevirtual com/trolmastercard/velvet/m.a (II)V
      // 1c4: goto 1cb
      // 1c7: invokestatic com/trolmastercard/velvet/m.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 1ca: athrow
      // 1cb: return
      // try (20 -> 49): 50 java/lang/RuntimeException
      // try (81 -> 93): 94 java/lang/RuntimeException
      // try (88 -> 99): 100 java/lang/RuntimeException
      // try (96 -> 109): 110 java/lang/RuntimeException
      // try (102 -> 120): 121 java/lang/RuntimeException
      // try (112 -> 182): 183 java/lang/RuntimeException
      // try (215 -> 222): 223 java/lang/RuntimeException
   }

   void a(int param1, int param2) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 000: ldc_w -30.0
      // 003: ldc_w 120.0
      // 006: aload 0
      // 007: getfield com/trolmastercard/velvet/m.m F
      // 00a: invokestatic com/trolmastercard/velvet/b6.a (FFF)F
      // 00d: f2i
      // 00e: istore 3
      // 00f: aload 0
      // 010: getfield com/trolmastercard/velvet/m.field_146296_j Lnet/minecraft/client/renderer/RenderItem;
      // 013: aload 0
      // 014: getfield com/trolmastercard/velvet/m.l Lnet/minecraft/network/datasync/EntityDataManager;
      // 017: getstatic com/trolmastercard/velvet/e2.L Lnet/minecraft/network/datasync/DataParameter;
      // 01a: invokevirtual net/minecraft/network/datasync/EntityDataManager.func_187225_a (Lnet/minecraft/network/datasync/DataParameter;)Ljava/lang/Object;
      // 01d: checkcast net/minecraft/item/ItemStack
      // 020: iload 3
      // 021: bipush 105
      // 023: isub
      // 024: bipush 68
      // 026: invokevirtual net/minecraft/client/renderer/RenderItem.func_175042_a (Lnet/minecraft/item/ItemStack;II)V
      // 029: aload 0
      // 02a: getfield com/trolmastercard/velvet/m.field_146296_j Lnet/minecraft/client/renderer/RenderItem;
      // 02d: aload 0
      // 02e: getfield com/trolmastercard/velvet/m.l Lnet/minecraft/network/datasync/EntityDataManager;
      // 031: getstatic com/trolmastercard/velvet/e2.R Lnet/minecraft/network/datasync/DataParameter;
      // 034: invokevirtual net/minecraft/network/datasync/EntityDataManager.func_187225_a (Lnet/minecraft/network/datasync/DataParameter;)Ljava/lang/Object;
      // 037: checkcast net/minecraft/item/ItemStack
      // 03a: iload 3
      // 03b: bipush 105
      // 03d: isub
      // 03e: bipush 87
      // 040: invokevirtual net/minecraft/client/renderer/RenderItem.func_175042_a (Lnet/minecraft/item/ItemStack;II)V
      // 043: aload 0
      // 044: getfield com/trolmastercard/velvet/m.field_146296_j Lnet/minecraft/client/renderer/RenderItem;
      // 047: aload 0
      // 048: getfield com/trolmastercard/velvet/m.l Lnet/minecraft/network/datasync/EntityDataManager;
      // 04b: getstatic com/trolmastercard/velvet/e2.X Lnet/minecraft/network/datasync/DataParameter;
      // 04e: invokevirtual net/minecraft/network/datasync/EntityDataManager.func_187225_a (Lnet/minecraft/network/datasync/DataParameter;)Ljava/lang/Object;
      // 051: checkcast net/minecraft/item/ItemStack
      // 054: iload 3
      // 055: bipush 105
      // 057: isub
      // 058: bipush 109
      // 05a: invokevirtual net/minecraft/client/renderer/RenderItem.func_175042_a (Lnet/minecraft/item/ItemStack;II)V
      // 05d: aload 0
      // 05e: getfield com/trolmastercard/velvet/m.field_146296_j Lnet/minecraft/client/renderer/RenderItem;
      // 061: aload 0
      // 062: getfield com/trolmastercard/velvet/m.l Lnet/minecraft/network/datasync/EntityDataManager;
      // 065: getstatic com/trolmastercard/velvet/e2.T Lnet/minecraft/network/datasync/DataParameter;
      // 068: invokevirtual net/minecraft/network/datasync/EntityDataManager.func_187225_a (Lnet/minecraft/network/datasync/DataParameter;)Ljava/lang/Object;
      // 06b: checkcast net/minecraft/item/ItemStack
      // 06e: iload 3
      // 06f: bipush 105
      // 071: isub
      // 072: bipush 127
      // 074: invokevirtual net/minecraft/client/renderer/RenderItem.func_175042_a (Lnet/minecraft/item/ItemStack;II)V
      // 077: aload 0
      // 078: getfield com/trolmastercard/velvet/m.field_146296_j Lnet/minecraft/client/renderer/RenderItem;
      // 07b: aload 0
      // 07c: getfield com/trolmastercard/velvet/m.l Lnet/minecraft/network/datasync/EntityDataManager;
      // 07f: getstatic com/trolmastercard/velvet/e2.U Lnet/minecraft/network/datasync/DataParameter;
      // 082: invokevirtual net/minecraft/network/datasync/EntityDataManager.func_187225_a (Lnet/minecraft/network/datasync/DataParameter;)Ljava/lang/Object;
      // 085: checkcast net/minecraft/item/ItemStack
      // 088: iload 3
      // 089: bipush 105
      // 08b: isub
      // 08c: sipush 146
      // 08f: invokevirtual net/minecraft/client/renderer/RenderItem.func_175042_a (Lnet/minecraft/item/ItemStack;II)V
      // 092: aload 0
      // 093: getfield com/trolmastercard/velvet/m.field_146296_j Lnet/minecraft/client/renderer/RenderItem;
      // 096: aload 0
      // 097: getfield com/trolmastercard/velvet/m.l Lnet/minecraft/network/datasync/EntityDataManager;
      // 09a: getstatic com/trolmastercard/velvet/e2.W Lnet/minecraft/network/datasync/DataParameter;
      // 09d: invokevirtual net/minecraft/network/datasync/EntityDataManager.func_187225_a (Lnet/minecraft/network/datasync/DataParameter;)Ljava/lang/Object;
      // 0a0: checkcast net/minecraft/item/ItemStack
      // 0a3: iload 3
      // 0a4: bipush 105
      // 0a6: isub
      // 0a7: sipush 166
      // 0aa: invokevirtual net/minecraft/client/renderer/RenderItem.func_175042_a (Lnet/minecraft/item/ItemStack;II)V
      // 0ad: aload 0
      // 0ae: getfield com/trolmastercard/velvet/m.n F
      // 0b1: fconst_0
      // 0b2: fcmpl
      // 0b3: ifne 0bb
      // 0b6: return
      // 0b7: invokestatic com/trolmastercard/velvet/m.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 0ba: athrow
      // 0bb: aload 0
      // 0bc: getfield com/trolmastercard/velvet/m.l Lnet/minecraft/network/datasync/EntityDataManager;
      // 0bf: getstatic com/trolmastercard/velvet/em.v Lnet/minecraft/network/datasync/DataParameter;
      // 0c2: invokevirtual net/minecraft/network/datasync/EntityDataManager.func_187225_a (Lnet/minecraft/network/datasync/DataParameter;)Ljava/lang/Object;
      // 0c5: checkcast java/lang/String
      // 0c8: ldc_w ""
      // 0cb: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 0ce: ifne 0d9
      // 0d1: bipush 1
      // 0d2: goto 0da
      // 0d5: invokestatic com/trolmastercard/velvet/m.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 0d8: athrow
      // 0d9: bipush 0
      // 0da: istore 4
      // 0dc: bipush 35
      // 0de: istore 5
      // 0e0: bipush 70
      // 0e2: istore 6
      // 0e4: bipush 0
      // 0e5: istore 7
      // 0e7: iload 7
      // 0e9: bipush 5
      // 0ea: if_icmpge 25a
      // 0ed: iload 7
      // 0ef: ifne 10b
      // 0f2: goto 0f9
      // 0f5: invokestatic com/trolmastercard/velvet/m.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 0f8: athrow
      // 0f9: iload 4
      // 0fb: ifeq 10b
      // 0fe: goto 105
      // 101: invokestatic com/trolmastercard/velvet/m.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 104: athrow
      // 105: bipush 1
      // 106: istore 7
      // 108: goto 120
      // 10b: iload 7
      // 10d: bipush 1
      // 10e: if_icmpne 120
      // 111: iload 4
      // 113: ifne 120
      // 116: goto 11d
      // 119: invokestatic com/trolmastercard/velvet/m.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 11c: athrow
      // 11d: bipush 2
      // 11e: istore 7
      // 120: iload 1
      // 121: iload 5
      // 123: if_icmplt 17d
      // 126: iload 1
      // 127: iload 5
      // 129: bipush 23
      // 12b: iadd
      // 12c: aload 0
      // 12d: getfield com/trolmastercard/velvet/m.d [I
      // 130: iload 7
      // 132: iaload
      // 133: iadd
      // 134: if_icmpgt 17d
      // 137: goto 13e
      // 13a: invokestatic com/trolmastercard/velvet/m.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 13d: athrow
      // 13e: iload 2
      // 13f: iload 6
      // 141: if_icmplt 17d
      // 144: goto 14b
      // 147: invokestatic com/trolmastercard/velvet/m.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 14a: athrow
      // 14b: iload 2
      // 14c: iload 6
      // 14e: bipush 20
      // 150: iadd
      // 151: if_icmpgt 17d
      // 154: goto 15b
      // 157: invokestatic com/trolmastercard/velvet/m.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 15a: athrow
      // 15b: aload 0
      // 15c: getfield com/trolmastercard/velvet/m.d [I
      // 15f: iload 7
      // 161: aload 0
      // 162: getfield com/trolmastercard/velvet/m.e [I
      // 165: iload 7
      // 167: iaload
      // 168: aload 0
      // 169: getfield com/trolmastercard/velvet/m.d [I
      // 16c: iload 7
      // 16e: iaload
      // 16f: bipush 7
      // 171: iadd
      // 172: invokestatic java/lang/Math.min (II)I
      // 175: iastore
      // 176: goto 192
      // 179: invokestatic com/trolmastercard/velvet/m.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 17c: athrow
      // 17d: aload 0
      // 17e: getfield com/trolmastercard/velvet/m.d [I
      // 181: iload 7
      // 183: bipush 0
      // 184: aload 0
      // 185: getfield com/trolmastercard/velvet/m.d [I
      // 188: iload 7
      // 18a: iaload
      // 18b: bipush 7
      // 18d: isub
      // 18e: invokestatic java/lang/Math.max (II)I
      // 191: iastore
      // 192: new java/lang/StringBuilder
      // 195: dup
      // 196: aload 0
      // 197: getfield com/trolmastercard/velvet/m.a [Ljava/lang/String;
      // 19a: iload 7
      // 19c: aaload
      // 19d: bipush 0
      // 19e: anewarray 150
      // 1a1: invokestatic net/minecraft/client/resources/I18n.func_135052_a (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
      // 1a4: invokespecial java/lang/StringBuilder.<init> (Ljava/lang/String;)V
      // 1a7: astore 8
      // 1a9: bipush 0
      // 1aa: istore 9
      // 1ac: iload 9
      // 1ae: aload 0
      // 1af: getfield com/trolmastercard/velvet/m.b [I
      // 1b2: iload 7
      // 1b4: iaload
      // 1b5: if_icmpge 1cb
      // 1b8: aload 8
      // 1ba: ldc_w " "
      // 1bd: invokevirtual java/lang/StringBuilder.append (Ljava/lang/String;)Ljava/lang/StringBuilder;
      // 1c0: pop
      // 1c1: iinc 9 1
      // 1c4: goto 1ac
      // 1c7: invokestatic com/trolmastercard/velvet/m.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 1ca: athrow
      // 1cb: aload 0
      // 1cc: getfield com/trolmastercard/velvet/m.field_146297_k Lnet/minecraft/client/Minecraft;
      // 1cf: getfield net/minecraft/client/Minecraft.field_71446_o Lnet/minecraft/client/renderer/texture/TextureManager;
      // 1d2: getstatic com/trolmastercard/velvet/m.c Lnet/minecraft/util/ResourceLocation;
      // 1d5: invokevirtual net/minecraft/client/renderer/texture/TextureManager.func_110577_a (Lnet/minecraft/util/ResourceLocation;)V
      // 1d8: aload 0
      // 1d9: aload 0
      // 1da: getfield com/trolmastercard/velvet/m.d [I
      // 1dd: iload 7
      // 1df: iaload
      // 1e0: iload 5
      // 1e2: iadd
      // 1e3: bipush 18
      // 1e5: isub
      // 1e6: fconst_0
      // 1e7: ldc_w 23.0
      // 1ea: aload 0
      // 1eb: getfield com/trolmastercard/velvet/m.n F
      // 1ee: invokestatic com/trolmastercard/velvet/b6.a (FFF)F
      // 1f1: f2i
      // 1f2: iadd
      // 1f3: iload 6
      // 1f5: bipush 2
      // 1f6: iadd
      // 1f7: aload 0
      // 1f8: getfield com/trolmastercard/velvet/m.j [I
      // 1fb: iload 7
      // 1fd: iaload
      // 1fe: bipush 0
      // 1ff: bipush 16
      // 201: bipush 16
      // 203: invokevirtual com/trolmastercard/velvet/m.func_73729_b (IIIIII)V
      // 206: aload 0
      // 207: getfield com/trolmastercard/velvet/m.field_146292_n Ljava/util/List;
      // 20a: new net/minecraft/client/gui/GuiButton
      // 20d: dup
      // 20e: iload 7
      // 210: iload 5
      // 212: bipush 1
      // 213: iadd
      // 214: iload 6
      // 216: fconst_0
      // 217: ldc_w 23.0
      // 21a: aload 0
      // 21b: getfield com/trolmastercard/velvet/m.n F
      // 21e: invokestatic com/trolmastercard/velvet/b6.a (FFF)F
      // 221: aload 0
      // 222: getfield com/trolmastercard/velvet/m.d [I
      // 225: iload 7
      // 227: iaload
      // 228: i2f
      // 229: fadd
      // 22a: f2i
      // 22b: bipush 20
      // 22d: aload 0
      // 22e: getfield com/trolmastercard/velvet/m.d [I
      // 231: iload 7
      // 233: iaload
      // 234: bipush 14
      // 236: if_icmpgt 243
      // 239: ldc_w ""
      // 23c: goto 248
      // 23f: invokestatic com/trolmastercard/velvet/m.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 242: athrow
      // 243: aload 8
      // 245: invokevirtual java/lang/StringBuilder.toString ()Ljava/lang/String;
      // 248: invokespecial net/minecraft/client/gui/GuiButton.<init> (IIIIILjava/lang/String;)V
      // 24b: invokeinterface java/util/List.add (Ljava/lang/Object;)Z 2
      // 250: pop
      // 251: iinc 6 30
      // 254: iinc 7 1
      // 257: goto 0e7
      // 25a: aload 0
      // 25b: getfield com/trolmastercard/velvet/m.field_146297_k Lnet/minecraft/client/Minecraft;
      // 25e: getfield net/minecraft/client/Minecraft.field_71446_o Lnet/minecraft/client/renderer/texture/TextureManager;
      // 261: getstatic com/trolmastercard/velvet/m.c Lnet/minecraft/util/ResourceLocation;
      // 264: invokevirtual net/minecraft/client/renderer/texture/TextureManager.func_110577_a (Lnet/minecraft/util/ResourceLocation;)V
      // 267: aload 0
      // 268: iload 3
      // 269: bipush 113
      // 26b: isub
      // 26c: bipush 60
      // 26e: bipush 0
      // 26f: bipush 0
      // 270: bipush 32
      // 272: sipush 130
      // 275: invokevirtual com/trolmastercard/velvet/m.func_73729_b (IIIIII)V
      // 278: return
      // try (7 -> 85): 85 java/lang/RuntimeException
      // try (87 -> 97): 97 java/lang/RuntimeException
      // try (107 -> 112): 113 java/lang/RuntimeException
      // try (110 -> 117): 118 java/lang/RuntimeException
      // try (123 -> 128): 129 java/lang/RuntimeException
      // try (133 -> 146): 147 java/lang/RuntimeException
      // try (136 -> 152): 153 java/lang/RuntimeException
      // try (149 -> 160): 161 java/lang/RuntimeException
      // try (155 -> 179): 179 java/lang/RuntimeException
      // try (206 -> 218): 218 java/lang/RuntimeException
      // try (220 -> 282): 282 java/lang/RuntimeException
   }

   void a(List<String> var1, int var2, int var3, FontRenderer var4) {
      GlStateManager.func_179101_C();
      RenderHelper.func_74518_a();
      GlStateManager.func_179140_f();
      int var5 = 0;

      for (String var7 : var1) {
         int var8 = this.field_146289_q.func_78256_a(var7);
         if (var8 > var5) {
            var5 = var8;
         }
      }

      int var12 = var2 + 12;
      int var13 = var3 - 12;
      int var14 = 8;
      if (var1.size() > 1) {
         var14 += 2 + (var1.size() - 1) * 10;
      }

      if (var12 + var5 > this.field_146294_l) {
         var12 -= 28 + var5;
      }

      if (var13 + var14 + 6 > this.field_146295_m) {
         var13 = this.field_146295_m - var14 - 6;
      }

      this.func_73733_a(var12 - 3, var13 - 4, var12 + var5 + 3, var13 - 3, -267386864, -267386864);
      this.func_73733_a(var12 - 3, var13 + var14 + 3, var12 + var5 + 3, var13 + var14 + 4, -267386864, -267386864);
      this.func_73733_a(var12 - 3, var13 - 3, var12 + var5 + 3, var13 + var14 + 3, -267386864, -267386864);
      this.func_73733_a(var12 - 4, var13 - 3, var12 - 3, var13 + var14 + 3, -267386864, -267386864);
      this.func_73733_a(var12 + var5 + 3, var13 - 3, var12 + var5 + 4, var13 + var14 + 3, -267386864, -267386864);
      this.func_73733_a(var12 - 3, var13 - 3 + 1, var12 - 3 + 1, var13 + var14 + 3 - 1, 1347420415, 1344798847);
      this.func_73733_a(var12 + var5 + 2, var13 - 3 + 1, var12 + var5 + 3, var13 + var14 + 3 - 1, 1347420415, 1344798847);
      this.func_73733_a(var12 - 3, var13 - 3, var12 + var5 + 3, var13 - 3 + 1, 1347420415, 1347420415);
      this.func_73733_a(var12 - 3, var13 + var14 + 2, var12 + var5 + 3, var13 + var14 + 3, 1344798847, 1344798847);

      for (int var9 = 0; var9 < var1.size(); var9++) {
         String var10 = (String)var1.get(var9);

         try {
            this.field_146289_q.func_175063_a(var10, var12, var13, -1);
            if (var9 == 0) {
               var13 += 2;
            }
         } catch (RuntimeException var11) {
            throw a(var11);
         }

         var13 += 10;
      }

      GlStateManager.func_179145_e();
      RenderHelper.func_74519_b();
      GlStateManager.func_179091_B();
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }
}
