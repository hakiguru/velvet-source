package org.velvet;

public interface fg {
   void a();
}
