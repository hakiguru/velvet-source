package org.velvet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.UUID;
import javax.annotation.Nullable;
import javax.vecmath.Vector4f;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Vec3i;
import net.minecraft.world.World;
import software.bernie.geckolib3.geo.render.built.GeoBone;
import software.bernie.geckolib3.geo.render.built.GeoCube;
import software.bernie.geckolib3.geo.render.built.GeoModel;
import software.bernie.geckolib3.model.AnimatedGeoModel;

public class dy extends d6<e3> {
   static final Vec3i w = new Vec3i(255, 255, 255);
   static final float K = -420.69F;
   static final float A = 8.0F;
   static final float L = 3.0F;
   static final Vec3d G = new Vec3d(10.0, -20.0, -10.0);
   static final float J = 0.1F;
   static final HashSet<String> D = new HashSet<>(
      Arrays.asList(
         "meatTorso",
         "meatCheekR",
         "meatCheekL",
         "meatFootR",
         "meatFootL",
         "meatShinR",
         "meatShinL",
         "meatLegL",
         "meatLegR",
         "nippleR",
         "nippleL",
         "preggy",
         "shoeL",
         "shoeR",
         "frontAndInside",
         "Lside",
         "Rside",
         "cheekR",
         "cheekL",
         "fuckhole",
         "head",
         "nose",
         "neck",
         "armL",
         "lowerArmL",
         "armR",
         "lowerArmR",
         "torso",
         "LegL",
         "LegR",
         "shinL",
         "shinR"
      )
   );
   static final HashSet<String> M = new HashSet<>(Arrays.asList("lashR", "lashL", "closedR", "closedL", "browL", "browR", "closedL", "closedL"));
   static final HashSet<String> C = new HashSet<>(Arrays.asList("meatLegR", "meatShinR", "meatFootR", "boobR", "boobR1", "boobR2"));
   static Minecraft y;
   float v = 0.0F;
   boolean u = false;
   boolean F = false;
   static float B = 0.0F;
   float z = 0.0F;
   static float H = 0.0F;
   static float t = 0.0F;
   static float I = 0.0F;
   static float E = 0.0F;
   static float N = 0.0F;
   static float x = 0.0F;

   public dy(RenderManager var1, AnimatedGeoModel var2, double var3) {
      super(var1, var2, var3);
      y = Minecraft.func_71410_x();
   }

   protected ResourceLocation a(e3 var1) throws IOException {
      UUID var3 = var1.ae();
      if (var3 == null) {
         var3 = var1.e();
      }

      label43: {
         try {
            if (!(var1.field_70170_p instanceof gj) && var3 != null) {
               break label43;
            }
         } catch (IOException var6) {
            throw a(var6);
         }

         ResourceLocation var2 = l.get(y.func_110432_I().func_148256_e().getId());

         try {
            if (var2 == null) {
               return this.a(y.func_110432_I().func_148256_e().getId(), var1.field_70170_p);
            }

            return var2;
         } catch (IOException var5) {
            throw a(var5);
         }
      }

      ResourceLocation var7 = l.get(var3);

      try {
         if (var7 == null) {
            return this.a(var3, var1.field_70170_p);
         }
      } catch (IOException var4) {
         throw a(var4);
      }

      return var7;
   }

   public static void a(em var0, float var1) {
      y.func_175598_ae().func_188391_a(var0, 0.0, 0.0, 0.0, -420.69F, var1, false);
   }

   public static void a(float var0) {
      try {
         if (!(y.func_175606_aa() instanceof EntityPlayer)) {
            return;
         }
      } catch (RuntimeException var6) {
         throw a(var6);
      }

      EntityPlayer var1 = (EntityPlayer)y.func_175606_aa();
      float var2 = var1.field_70140_Q - var1.field_70141_P;
      float var3 = -(var1.field_70140_Q + var2 * var0);
      float var4 = var1.field_71107_bF + (var1.field_71109_bG - var1.field_71107_bF) * var0;
      float var5 = MathHelper.func_76126_a(var3 * (float) Math.PI) * var4 * 0.5F;
      GlStateManager.func_179137_b(
         Math.cos(y.field_71439_g.field_70177_z * (Math.PI / 180.0)) * var5,
         Math.abs(MathHelper.func_76134_b(var3 * (float) Math.PI) * var4),
         Math.sin(y.field_71439_g.field_70177_z * (Math.PI / 180.0)) * var5
      );
   }

   public void a(GeoModel var1, e3 var2, float var3, float var4, float var5, float var6, float var7) {
      super.a(var1, var2, var3, var4, var5, var6, var2.ar);
   }

   public void func_76979_b(Entity param1, double param2, double param4, double param6, float param8, float param9) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 00: aload 1
      // 01: instanceof com/trolmastercard/velvet/e3
      // 04: ifne 1a
      // 07: aload 0
      // 08: aload 1
      // 09: dload 2
      // 0a: dload 4
      // 0c: dload 6
      // 0e: fload 8
      // 10: fload 9
      // 12: invokespecial com/trolmastercard/velvet/d6.func_76979_b (Lnet/minecraft/entity/Entity;DDDFF)V
      // 15: return
      // 16: invokestatic com/trolmastercard/velvet/dy.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 19: athrow
      // 1a: aload 1
      // 1b: checkcast com/trolmastercard/velvet/e3
      // 1e: astore 10
      // 20: aload 10
      // 22: invokevirtual com/trolmastercard/velvet/e3.y ()Lcom/trolmastercard/velvet/fp;
      // 25: getstatic com/trolmastercard/velvet/fp.PICK_UP Lcom/trolmastercard/velvet/fp;
      // 28: if_acmpeq 3d
      // 2b: aload 10
      // 2d: invokevirtual com/trolmastercard/velvet/e3.y ()Lcom/trolmastercard/velvet/fp;
      // 30: getstatic com/trolmastercard/velvet/fp.SHOULDER_IDLE Lcom/trolmastercard/velvet/fp;
      // 33: if_acmpne 42
      // 36: goto 3d
      // 39: invokestatic com/trolmastercard/velvet/dy.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 3c: athrow
      // 3d: return
      // 3e: invokestatic com/trolmastercard/velvet/dy.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 41: athrow
      // 42: aload 0
      // 43: aload 1
      // 44: dload 2
      // 45: dload 4
      // 47: dload 6
      // 49: fload 8
      // 4b: fload 9
      // 4d: invokespecial com/trolmastercard/velvet/d6.func_76979_b (Lnet/minecraft/entity/Entity;DDDFF)V
      // 50: return
      // try (0 -> 12): 12 java/lang/RuntimeException
      // try (17 -> 25): 26 java/lang/RuntimeException
      // try (21 -> 29): 29 java/lang/RuntimeException
   }

   public static Vec3d a(World var0, em var1, UUID var2, double var3, double var5, double var7) {
      try {
         if (var0 == null) {
            return new Vec3d(var3, var5, var7);
         }
      } catch (RuntimeException var15) {
         throw a(var15);
      }

      try {
         if (var2 == null) {
            return new Vec3d(var3, var5, var7);
         }
      } catch (RuntimeException var12) {
         throw a(var12);
      }

      try {
         if (var1 == null) {
            return new Vec3d(var3, var5, var7);
         }
      } catch (RuntimeException var14) {
         throw a(var14);
      }

      EntityPlayer var9 = var0.func_152378_a(var2);

      try {
         if (var9 == null) {
            return new Vec3d(var3, var5, var7);
         }
      } catch (RuntimeException var13) {
         throw a(var13);
      }

      Vec3d var10 = var9.func_174791_d();
      Vec3d var11 = y.field_71439_g.func_174791_d();
      var1.field_70760_ar = var9.field_70758_at;
      var1.field_70761_aq = var9.field_70759_as;
      var1.b(fp.START_THROWING);
      return var10.func_178788_d(var11);
   }

   public void a(e3 param1, double param2, double param4, double param6, float param8, float param9) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 000: aload 0
      // 001: aload 1
      // 002: putfield com/trolmastercard/velvet/dy.j Lcom/trolmastercard/velvet/em;
      // 005: aload 0
      // 006: ldc -420.69
      // 008: fload 8
      // 00a: fcmpl
      // 00b: ifne 027
      // 00e: aload 1
      // 00f: invokevirtual com/trolmastercard/velvet/e3.y ()Lcom/trolmastercard/velvet/fp;
      // 012: getstatic com/trolmastercard/velvet/fp.SHOULDER_IDLE Lcom/trolmastercard/velvet/fp;
      // 015: if_acmpne 027
      // 018: goto 01f
      // 01b: invokestatic com/trolmastercard/velvet/dy.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 01e: athrow
      // 01f: bipush 1
      // 020: goto 028
      // 023: invokestatic com/trolmastercard/velvet/dy.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 026: athrow
      // 027: bipush 0
      // 028: putfield com/trolmastercard/velvet/dy.u Z
      // 02b: aload 0
      // 02c: ldc -420.69
      // 02e: fload 8
      // 030: fcmpl
      // 031: ifne 04d
      // 034: aload 1
      // 035: invokevirtual com/trolmastercard/velvet/e3.y ()Lcom/trolmastercard/velvet/fp;
      // 038: getstatic com/trolmastercard/velvet/fp.PICK_UP Lcom/trolmastercard/velvet/fp;
      // 03b: if_acmpne 04d
      // 03e: goto 045
      // 041: invokestatic com/trolmastercard/velvet/dy.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 044: athrow
      // 045: bipush 1
      // 046: goto 04e
      // 049: invokestatic com/trolmastercard/velvet/dy.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 04c: athrow
      // 04d: bipush 0
      // 04e: putfield com/trolmastercard/velvet/dy.F Z
      // 051: aload 0
      // 052: aload 1
      // 053: getfield com/trolmastercard/velvet/e3.field_70170_p Lnet/minecraft/world/World;
      // 056: aload 1
      // 057: invokevirtual com/trolmastercard/velvet/e3.func_180425_c ()Lnet/minecraft/util/math/BlockPos;
      // 05a: bipush 1
      // 05b: invokevirtual net/minecraft/world/World.func_175721_c (Lnet/minecraft/util/math/BlockPos;Z)I
      // 05e: i2f
      // 05f: putfield com/trolmastercard/velvet/dy.z F
      // 062: aload 0
      // 063: fload 9
      // 065: putfield com/trolmastercard/velvet/dy.v F
      // 068: fload 8
      // 06a: putstatic com/trolmastercard/velvet/dy.B F
      // 06d: aload 1
      // 06e: invokevirtual com/trolmastercard/velvet/e3.y ()Lcom/trolmastercard/velvet/fp;
      // 071: astore 10
      // 073: aload 1
      // 074: invokevirtual com/trolmastercard/velvet/e3.e ()Ljava/util/UUID;
      // 077: astore 11
      // 079: aload 1
      // 07a: invokevirtual com/trolmastercard/velvet/e3.h ()Z
      // 07d: ifeq 0a5
      // 080: aload 1
      // 081: getfield com/trolmastercard/velvet/e3.field_70170_p Lnet/minecraft/world/World;
      // 084: aload 1
      // 085: aload 11
      // 087: dload 2
      // 088: dload 4
      // 08a: dload 6
      // 08c: invokestatic com/trolmastercard/velvet/dy.a (Lnet/minecraft/world/World;Lcom/trolmastercard/velvet/em;Ljava/util/UUID;DDD)Lnet/minecraft/util/math/Vec3d;
      // 08f: astore 12
      // 091: aload 12
      // 093: getfield net/minecraft/util/math/Vec3d.field_72450_a D
      // 096: dstore 2
      // 097: aload 12
      // 099: getfield net/minecraft/util/math/Vec3d.field_72448_b D
      // 09c: dstore 4
      // 09e: aload 12
      // 0a0: getfield net/minecraft/util/math/Vec3d.field_72449_c D
      // 0a3: dstore 6
      // 0a5: aload 10
      // 0a7: getstatic com/trolmastercard/velvet/fp.THROWN Lcom/trolmastercard/velvet/fp;
      // 0aa: if_acmpeq 0bc
      // 0ad: aload 10
      // 0af: getstatic com/trolmastercard/velvet/fp.START_THROWING Lcom/trolmastercard/velvet/fp;
      // 0b2: if_acmpne 10d
      // 0b5: goto 0bc
      // 0b8: invokestatic com/trolmastercard/velvet/dy.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 0bb: athrow
      // 0bc: getstatic com/trolmastercard/velvet/dy.y Lnet/minecraft/client/Minecraft;
      // 0bf: getfield net/minecraft/client/Minecraft.field_71474_y Lnet/minecraft/client/settings/GameSettings;
      // 0c2: getfield net/minecraft/client/settings/GameSettings.field_74320_O I
      // 0c5: ifne 0f1
      // 0c8: goto 0cf
      // 0cb: invokestatic com/trolmastercard/velvet/dy.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 0ce: athrow
      // 0cf: fload 8
      // 0d1: ldc -420.69
      // 0d3: fcmpl
      // 0d4: ifne 0f1
      // 0d7: goto 0de
      // 0da: invokestatic com/trolmastercard/velvet/dy.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 0dd: athrow
      // 0de: aload 1
      // 0df: invokevirtual com/trolmastercard/velvet/e3.h ()Z
      // 0e2: ifne 0f1
      // 0e5: goto 0ec
      // 0e8: invokestatic com/trolmastercard/velvet/dy.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 0eb: athrow
      // 0ec: return
      // 0ed: invokestatic com/trolmastercard/velvet/dy.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 0f0: athrow
      // 0f1: aload 1
      // 0f2: invokevirtual com/trolmastercard/velvet/e3.h ()Z
      // 0f5: ifne 10d
      // 0f8: aload 1
      // 0f9: invokevirtual com/trolmastercard/velvet/e3.I ()Ljava/lang/Float;
      // 0fc: invokevirtual java/lang/Float.floatValue ()F
      // 0ff: fstore 12
      // 101: aload 1
      // 102: fload 12
      // 104: putfield com/trolmastercard/velvet/e3.field_70760_ar F
      // 107: aload 1
      // 108: fload 12
      // 10a: putfield com/trolmastercard/velvet/e3.field_70761_aq F
      // 10d: aload 1
      // 10e: aload 10
      // 110: invokestatic com/trolmastercard/velvet/dy.a (Lcom/trolmastercard/velvet/em;Lcom/trolmastercard/velvet/fp;)Z
      // 113: ifeq 290
      // 116: getstatic com/trolmastercard/velvet/dy.y Lnet/minecraft/client/Minecraft;
      // 119: getfield net/minecraft/client/Minecraft.field_71439_g Lnet/minecraft/client/entity/EntityPlayerSP;
      // 11c: invokevirtual net/minecraft/client/entity/EntityPlayerSP.getPersistentID ()Ljava/util/UUID;
      // 11f: aload 11
      // 121: invokevirtual java/util/UUID.equals (Ljava/lang/Object;)Z
      // 124: ifeq 1d8
      // 127: goto 12e
      // 12a: invokestatic com/trolmastercard/velvet/dy.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 12d: athrow
      // 12e: ldc -420.69
      // 130: fload 8
      // 132: fcmpl
      // 133: ifeq 142
      // 136: goto 13d
      // 139: invokestatic com/trolmastercard/velvet/dy.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 13c: athrow
      // 13d: return
      // 13e: invokestatic com/trolmastercard/velvet/dy.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 141: athrow
      // 142: aload 1
      // 143: getstatic com/trolmastercard/velvet/dy.y Lnet/minecraft/client/Minecraft;
      // 146: getfield net/minecraft/client/Minecraft.field_71439_g Lnet/minecraft/client/entity/EntityPlayerSP;
      // 149: getfield net/minecraft/client/entity/EntityPlayerSP.field_70177_z F
      // 14c: ldc_w 180.0
      // 14f: fadd
      // 150: putfield com/trolmastercard/velvet/e3.field_70761_aq F
      // 153: aload 1
      // 154: getstatic com/trolmastercard/velvet/dy.y Lnet/minecraft/client/Minecraft;
      // 157: getfield net/minecraft/client/Minecraft.field_71439_g Lnet/minecraft/client/entity/EntityPlayerSP;
      // 15a: getfield net/minecraft/client/entity/EntityPlayerSP.field_70177_z F
      // 15d: ldc_w 180.0
      // 160: fadd
      // 161: putfield com/trolmastercard/velvet/e3.field_70760_ar F
      // 164: getstatic com/trolmastercard/velvet/dy.y Lnet/minecraft/client/Minecraft;
      // 167: getfield net/minecraft/client/Minecraft.field_71439_g Lnet/minecraft/client/entity/EntityPlayerSP;
      // 16a: invokevirtual net/minecraft/client/entity/EntityPlayerSP.func_70040_Z ()Lnet/minecraft/util/math/Vec3d;
      // 16d: astore 12
      // 16f: invokestatic net/minecraft/client/renderer/GlStateManager.func_179094_E ()V
      // 172: aload 12
      // 174: getfield net/minecraft/util/math/Vec3d.field_72450_a D
      // 177: aload 12
      // 179: getfield net/minecraft/util/math/Vec3d.field_72448_b D
      // 17c: getstatic com/trolmastercard/velvet/dy.y Lnet/minecraft/client/Minecraft;
      // 17f: getfield net/minecraft/client/Minecraft.field_71439_g Lnet/minecraft/client/entity/EntityPlayerSP;
      // 182: invokevirtual net/minecraft/client/entity/EntityPlayerSP.func_70047_e ()F
      // 185: f2d
      // 186: dadd
      // 187: aload 12
      // 189: getfield net/minecraft/util/math/Vec3d.field_72449_c D
      // 18c: invokestatic net/minecraft/client/renderer/GlStateManager.func_179137_b (DDD)V
      // 18f: new net/minecraft/util/math/Vec3d
      // 192: dup
      // 193: getstatic com/trolmastercard/velvet/dy.y Lnet/minecraft/client/Minecraft;
      // 196: getfield net/minecraft/client/Minecraft.field_71439_g Lnet/minecraft/client/entity/EntityPlayerSP;
      // 199: getfield net/minecraft/client/entity/EntityPlayerSP.field_70125_A F
      // 19c: invokestatic java/lang/Math.abs (F)F
      // 19f: fneg
      // 1a0: f2d
      // 1a1: dconst_0
      // 1a2: dconst_0
      // 1a3: invokespecial net/minecraft/util/math/Vec3d.<init> (DDD)V
      // 1a6: getstatic com/trolmastercard/velvet/dy.y Lnet/minecraft/client/Minecraft;
      // 1a9: getfield net/minecraft/client/Minecraft.field_71439_g Lnet/minecraft/client/entity/EntityPlayerSP;
      // 1ac: getfield net/minecraft/client/entity/EntityPlayerSP.field_70177_z F
      // 1af: invokestatic com/trolmastercard/velvet/e3.b (Lnet/minecraft/util/math/Vec3d;F)Lnet/minecraft/util/math/Vec3d;
      // 1b2: astore 13
      // 1b4: getstatic com/trolmastercard/velvet/dy.y Lnet/minecraft/client/Minecraft;
      // 1b7: getfield net/minecraft/client/Minecraft.field_71439_g Lnet/minecraft/client/entity/EntityPlayerSP;
      // 1ba: getfield net/minecraft/client/entity/EntityPlayerSP.field_70125_A F
      // 1bd: aload 13
      // 1bf: getfield net/minecraft/util/math/Vec3d.field_72450_a D
      // 1c2: d2f
      // 1c3: fconst_0
      // 1c4: aload 13
      // 1c6: getfield net/minecraft/util/math/Vec3d.field_72449_c D
      // 1c9: d2f
      // 1ca: invokestatic net/minecraft/client/renderer/GlStateManager.func_179114_b (FFFF)V
      // 1cd: dconst_0
      // 1ce: dstore 2
      // 1cf: dconst_0
      // 1d0: dstore 4
      // 1d2: dconst_0
      // 1d3: dstore 6
      // 1d5: goto 3e3
      // 1d8: aload 1
      // 1d9: invokevirtual com/trolmastercard/velvet/e3.h ()Z
      // 1dc: ifeq 203
      // 1df: aload 11
      // 1e1: ifnull 203
      // 1e4: goto 1eb
      // 1e7: invokestatic com/trolmastercard/velvet/dy.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 1ea: athrow
      // 1eb: getstatic com/trolmastercard/velvet/dy.y Lnet/minecraft/client/Minecraft;
      // 1ee: getfield net/minecraft/client/Minecraft.field_71439_g Lnet/minecraft/client/entity/EntityPlayerSP;
      // 1f1: invokevirtual net/minecraft/client/entity/EntityPlayerSP.getPersistentID ()Ljava/util/UUID;
      // 1f4: aload 11
      // 1f6: invokevirtual java/util/UUID.equals (Ljava/lang/Object;)Z
      // 1f9: ifeq 26d
      // 1fc: goto 203
      // 1ff: invokestatic com/trolmastercard/velvet/dy.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 202: athrow
      // 203: aload 11
      // 205: ifnull 253
      // 208: goto 20f
      // 20b: invokestatic com/trolmastercard/velvet/dy.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 20e: athrow
      // 20f: getstatic com/trolmastercard/velvet/dy.y Lnet/minecraft/client/Minecraft;
      // 212: getfield net/minecraft/client/Minecraft.field_71439_g Lnet/minecraft/client/entity/EntityPlayerSP;
      // 215: invokevirtual net/minecraft/client/entity/EntityPlayerSP.getPersistentID ()Ljava/util/UUID;
      // 218: aload 11
      // 21a: invokevirtual java/util/UUID.equals (Ljava/lang/Object;)Z
      // 21d: ifne 253
      // 220: goto 227
      // 223: invokestatic com/trolmastercard/velvet/dy.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 226: athrow
      // 227: aload 1
      // 228: getfield com/trolmastercard/velvet/e3.field_70170_p Lnet/minecraft/world/World;
      // 22b: aload 11
      // 22d: invokevirtual net/minecraft/world/World.func_152378_a (Ljava/util/UUID;)Lnet/minecraft/entity/player/EntityPlayer;
      // 230: astore 12
      // 232: aload 12
      // 234: ifnull 250
      // 237: aload 1
      // 238: aload 12
      // 23a: getfield net/minecraft/entity/player/EntityPlayer.field_70177_z F
      // 23d: putfield com/trolmastercard/velvet/e3.field_70761_aq F
      // 240: aload 1
      // 241: aload 12
      // 243: getfield net/minecraft/entity/player/EntityPlayer.field_70177_z F
      // 246: putfield com/trolmastercard/velvet/e3.field_70760_ar F
      // 249: goto 250
      // 24c: invokestatic com/trolmastercard/velvet/dy.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 24f: athrow
      // 250: goto 26d
      // 253: aload 1
      // 254: getstatic com/trolmastercard/velvet/dy.y Lnet/minecraft/client/Minecraft;
      // 257: getfield net/minecraft/client/Minecraft.field_71439_g Lnet/minecraft/client/entity/EntityPlayerSP;
      // 25a: getfield net/minecraft/client/entity/EntityPlayerSP.field_70177_z F
      // 25d: putfield com/trolmastercard/velvet/e3.field_70761_aq F
      // 260: aload 1
      // 261: getstatic com/trolmastercard/velvet/dy.y Lnet/minecraft/client/Minecraft;
      // 264: getfield net/minecraft/client/Minecraft.field_71439_g Lnet/minecraft/client/entity/EntityPlayerSP;
      // 267: getfield net/minecraft/client/entity/EntityPlayerSP.field_70177_z F
      // 26a: putfield com/trolmastercard/velvet/e3.field_70760_ar F
      // 26d: aload 1
      // 26e: aload 1
      // 26f: invokevirtual com/trolmastercard/velvet/e3.e ()Ljava/util/UUID;
      // 272: fload 9
      // 274: invokestatic com/trolmastercard/velvet/dy.a (Lcom/trolmastercard/velvet/em;Ljava/util/UUID;F)Lnet/minecraft/util/math/Vec3d;
      // 277: astore 12
      // 279: aload 12
      // 27b: getfield net/minecraft/util/math/Vec3d.field_72450_a D
      // 27e: dstore 2
      // 27f: aload 12
      // 281: getfield net/minecraft/util/math/Vec3d.field_72448_b D
      // 284: dstore 4
      // 286: aload 12
      // 288: getfield net/minecraft/util/math/Vec3d.field_72449_c D
      // 28b: dstore 6
      // 28d: goto 3e3
      // 290: aload 0
      // 291: getfield com/trolmastercard/velvet/dy.u Z
      // 294: ifeq 313
      // 297: fload 9
      // 299: invokestatic com/trolmastercard/velvet/dy.a (F)V
      // 29c: new net/minecraft/util/math/Vec3d
      // 29f: dup
      // 2a0: ldc_w -0.1
      // 2a3: ldc_w 0.2
      // 2a6: getstatic com/trolmastercard/velvet/dy.y Lnet/minecraft/client/Minecraft;
      // 2a9: getfield net/minecraft/client/Minecraft.field_71474_y Lnet/minecraft/client/settings/GameSettings;
      // 2ac: getfield net/minecraft/client/settings/GameSettings.field_74334_X F
      // 2af: ldc_w 110.0
      // 2b2: fdiv
      // 2b3: invokestatic com/trolmastercard/velvet/b6.a (FFF)F
      // 2b6: f2d
      // 2b7: dconst_0
      // 2b8: dconst_0
      // 2b9: invokespecial net/minecraft/util/math/Vec3d.<init> (DDD)V
      // 2bc: astore 12
      // 2be: aload 12
      // 2c0: getstatic com/trolmastercard/velvet/dy.y Lnet/minecraft/client/Minecraft;
      // 2c3: getfield net/minecraft/client/Minecraft.field_71439_g Lnet/minecraft/client/entity/EntityPlayerSP;
      // 2c6: getfield net/minecraft/client/entity/EntityPlayerSP.field_70177_z F
      // 2c9: invokestatic com/trolmastercard/velvet/e3.b (Lnet/minecraft/util/math/Vec3d;F)Lnet/minecraft/util/math/Vec3d;
      // 2cc: astore 12
      // 2ce: aload 12
      // 2d0: getfield net/minecraft/util/math/Vec3d.field_72450_a D
      // 2d3: dstore 2
      // 2d4: aload 12
      // 2d6: getfield net/minecraft/util/math/Vec3d.field_72448_b D
      // 2d9: dstore 4
      // 2db: aload 12
      // 2dd: getfield net/minecraft/util/math/Vec3d.field_72449_c D
      // 2e0: dstore 6
      // 2e2: aload 1
      // 2e3: getstatic com/trolmastercard/velvet/dy.y Lnet/minecraft/client/Minecraft;
      // 2e6: getfield net/minecraft/client/Minecraft.field_71439_g Lnet/minecraft/client/entity/EntityPlayerSP;
      // 2e9: getfield net/minecraft/client/entity/EntityPlayerSP.field_70177_z F
      // 2ec: putfield com/trolmastercard/velvet/e3.field_70761_aq F
      // 2ef: aload 1
      // 2f0: getstatic com/trolmastercard/velvet/dy.y Lnet/minecraft/client/Minecraft;
      // 2f3: getfield net/minecraft/client/Minecraft.field_71439_g Lnet/minecraft/client/entity/EntityPlayerSP;
      // 2f6: getfield net/minecraft/client/entity/EntityPlayerSP.field_70126_B F
      // 2f9: putfield com/trolmastercard/velvet/e3.field_70760_ar F
      // 2fc: getstatic com/trolmastercard/velvet/dy.y Lnet/minecraft/client/Minecraft;
      // 2ff: getfield net/minecraft/client/Minecraft.field_71439_g Lnet/minecraft/client/entity/EntityPlayerSP;
      // 302: invokevirtual net/minecraft/client/entity/EntityPlayerSP.func_70093_af ()Z
      // 305: ifeq 310
      // 308: dload 4
      // 30a: ldc2_w 0.075
      // 30d: dsub
      // 30e: dstore 4
      // 310: goto 3e3
      // 313: aload 10
      // 315: getstatic com/trolmastercard/velvet/fp.SHOULDER_IDLE Lcom/trolmastercard/velvet/fp;
      // 318: if_acmpne 3a6
      // 31b: aload 11
      // 31d: ifnonnull 32c
      // 320: goto 327
      // 323: invokestatic com/trolmastercard/velvet/dy.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 326: athrow
      // 327: return
      // 328: invokestatic com/trolmastercard/velvet/dy.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 32b: athrow
      // 32c: getstatic com/trolmastercard/velvet/dy.y Lnet/minecraft/client/Minecraft;
      // 32f: getfield net/minecraft/client/Minecraft.field_71439_g Lnet/minecraft/client/entity/EntityPlayerSP;
      // 332: invokevirtual net/minecraft/client/entity/EntityPlayerSP.getPersistentID ()Ljava/util/UUID;
      // 335: aload 11
      // 337: invokevirtual java/util/UUID.equals (Ljava/lang/Object;)Z
      // 33a: ifeq 355
      // 33d: getstatic com/trolmastercard/velvet/dy.y Lnet/minecraft/client/Minecraft;
      // 340: getfield net/minecraft/client/Minecraft.field_71474_y Lnet/minecraft/client/settings/GameSettings;
      // 343: getfield net/minecraft/client/settings/GameSettings.field_74320_O I
      // 346: ifne 355
      // 349: goto 350
      // 34c: invokestatic com/trolmastercard/velvet/dy.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 34f: athrow
      // 350: return
      // 351: invokestatic com/trolmastercard/velvet/dy.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 354: athrow
      // 355: aload 1
      // 356: getfield com/trolmastercard/velvet/e3.field_70170_p Lnet/minecraft/world/World;
      // 359: aload 11
      // 35b: invokevirtual net/minecraft/world/World.func_152378_a (Ljava/util/UUID;)Lnet/minecraft/entity/player/EntityPlayer;
      // 35e: astore 12
      // 360: aload 12
      // 362: ifnonnull 36a
      // 365: return
      // 366: invokestatic com/trolmastercard/velvet/dy.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 369: athrow
      // 36a: aload 12
      // 36c: fload 9
      // 36e: invokestatic com/trolmastercard/velvet/dy.a (Lnet/minecraft/entity/player/EntityPlayer;F)Ljavax/vecmath/Vector4f;
      // 371: astore 13
      // 373: aload 13
      // 375: getfield javax/vecmath/Vector4f.x F
      // 378: f2d
      // 379: dstore 2
      // 37a: aload 13
      // 37c: getfield javax/vecmath/Vector4f.y F
      // 37f: f2d
      // 380: dstore 4
      // 382: aload 13
      // 384: getfield javax/vecmath/Vector4f.z F
      // 387: f2d
      // 388: dstore 6
      // 38a: aload 1
      // 38b: aload 13
      // 38d: getfield javax/vecmath/Vector4f.w F
      // 390: putfield com/trolmastercard/velvet/e3.field_70761_aq F
      // 393: aload 12
      // 395: invokevirtual net/minecraft/entity/player/EntityPlayer.func_70093_af ()Z
      // 398: ifeq 3a3
      // 39b: dload 4
      // 39d: ldc2_w 0.32
      // 3a0: dsub
      // 3a1: dstore 4
      // 3a3: goto 3e3
      // 3a6: aload 10
      // 3a8: getstatic com/trolmastercard/velvet/fp.PICK_UP Lcom/trolmastercard/velvet/fp;
      // 3ab: if_acmpne 3e3
      // 3ae: aload 11
      // 3b0: ifnull 3e3
      // 3b3: goto 3ba
      // 3b6: invokestatic com/trolmastercard/velvet/dy.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 3b9: athrow
      // 3ba: aload 1
      // 3bb: getfield com/trolmastercard/velvet/e3.field_70170_p Lnet/minecraft/world/World;
      // 3be: aload 11
      // 3c0: invokevirtual net/minecraft/world/World.func_152378_a (Ljava/util/UUID;)Lnet/minecraft/entity/player/EntityPlayer;
      // 3c3: astore 12
      // 3c5: aload 12
      // 3c7: ifnull 3e3
      // 3ca: aload 1
      // 3cb: aload 12
      // 3cd: getfield net/minecraft/entity/player/EntityPlayer.field_70758_at F
      // 3d0: putfield com/trolmastercard/velvet/e3.field_70760_ar F
      // 3d3: aload 1
      // 3d4: aload 12
      // 3d6: getfield net/minecraft/entity/player/EntityPlayer.field_70759_as F
      // 3d9: putfield com/trolmastercard/velvet/e3.field_70761_aq F
      // 3dc: goto 3e3
      // 3df: invokestatic com/trolmastercard/velvet/dy.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 3e2: athrow
      // 3e3: aload 0
      // 3e4: aload 1
      // 3e5: dload 2
      // 3e6: dload 4
      // 3e8: dload 6
      // 3ea: fload 8
      // 3ec: fload 9
      // 3ee: invokespecial com/trolmastercard/velvet/d6.a (Lcom/trolmastercard/velvet/em;DDDFF)V
      // 3f1: aload 1
      // 3f2: aload 10
      // 3f4: invokestatic com/trolmastercard/velvet/dy.a (Lcom/trolmastercard/velvet/em;Lcom/trolmastercard/velvet/fp;)Z
      // 3f7: ifeq 42f
      // 3fa: getstatic com/trolmastercard/velvet/dy.y Lnet/minecraft/client/Minecraft;
      // 3fd: getfield net/minecraft/client/Minecraft.field_71474_y Lnet/minecraft/client/settings/GameSettings;
      // 400: getfield net/minecraft/client/settings/GameSettings.field_74320_O I
      // 403: ifne 42f
      // 406: goto 40d
      // 409: invokestatic com/trolmastercard/velvet/dy.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 40c: athrow
      // 40d: getstatic com/trolmastercard/velvet/dy.y Lnet/minecraft/client/Minecraft;
      // 410: getfield net/minecraft/client/Minecraft.field_71439_g Lnet/minecraft/client/entity/EntityPlayerSP;
      // 413: invokevirtual net/minecraft/client/entity/EntityPlayerSP.getPersistentID ()Ljava/util/UUID;
      // 416: aload 11
      // 418: invokevirtual java/util/UUID.equals (Ljava/lang/Object;)Z
      // 41b: ifeq 42f
      // 41e: goto 425
      // 421: invokestatic com/trolmastercard/velvet/dy.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 424: athrow
      // 425: invokestatic net/minecraft/client/renderer/GlStateManager.func_179121_F ()V
      // 428: goto 42f
      // 42b: invokestatic com/trolmastercard/velvet/dy.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 42e: athrow
      // 42f: return
      // try (0 -> 12): 13 java/lang/RuntimeException
      // try (8 -> 17): 17 java/lang/RuntimeException
      // try (20 -> 30): 31 java/lang/RuntimeException
      // try (26 -> 35): 35 java/lang/RuntimeException
      // try (80 -> 86): 87 java/lang/RuntimeException
      // try (83 -> 93): 94 java/lang/RuntimeException
      // try (89 -> 100): 101 java/lang/RuntimeException
      // try (96 -> 106): 107 java/lang/RuntimeException
      // try (103 -> 110): 110 java/lang/RuntimeException
      // try (125 -> 135): 136 java/lang/RuntimeException
      // try (129 -> 142): 143 java/lang/RuntimeException
      // try (138 -> 146): 146 java/lang/RuntimeException
      // try (213 -> 218): 219 java/lang/RuntimeException
      // try (216 -> 227): 228 java/lang/RuntimeException
      // try (221 -> 232): 233 java/lang/RuntimeException
      // try (230 -> 241): 242 java/lang/RuntimeException
      // try (249 -> 259): 260 java/lang/RuntimeException
      // try (343 -> 348): 349 java/lang/RuntimeException
      // try (346 -> 352): 352 java/lang/RuntimeException
      // try (354 -> 364): 365 java/lang/RuntimeException
      // try (360 -> 368): 368 java/lang/RuntimeException
      // try (375 -> 378): 378 java/lang/RuntimeException
      // try (408 -> 413): 414 java/lang/RuntimeException
      // try (421 -> 431): 432 java/lang/RuntimeException
      // try (434 -> 450): 451 java/lang/RuntimeException
      // try (446 -> 459): 460 java/lang/RuntimeException
      // try (453 -> 463): 464 java/lang/RuntimeException
   }

   public static boolean a(em param0, fp param1) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 00: aload 1
      // 01: getstatic com/trolmastercard/velvet/fp.START_THROWING Lcom/trolmastercard/velvet/fp;
      // 04: if_acmpne 1b
      // 07: aload 0
      // 08: invokevirtual com/trolmastercard/velvet/em.h ()Z
      // 0b: ifne 1b
      // 0e: goto 15
      // 11: invokestatic com/trolmastercard/velvet/dy.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 14: athrow
      // 15: bipush 0
      // 16: ireturn
      // 17: invokestatic com/trolmastercard/velvet/dy.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 1a: athrow
      // 1b: getstatic com/trolmastercard/velvet/dy.y Lnet/minecraft/client/Minecraft;
      // 1e: getfield net/minecraft/client/Minecraft.field_71474_y Lnet/minecraft/client/settings/GameSettings;
      // 21: getfield net/minecraft/client/settings/GameSettings.field_74320_O I
      // 24: ifeq 49
      // 27: aload 1
      // 28: getstatic com/trolmastercard/velvet/fp.START_THROWING Lcom/trolmastercard/velvet/fp;
      // 2b: if_acmpeq 43
      // 2e: goto 35
      // 31: invokestatic com/trolmastercard/velvet/dy.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 34: athrow
      // 35: aload 1
      // 36: getstatic com/trolmastercard/velvet/fp.PICK_UP Lcom/trolmastercard/velvet/fp;
      // 39: if_acmpne 49
      // 3c: goto 43
      // 3f: invokestatic com/trolmastercard/velvet/dy.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 42: athrow
      // 43: bipush 0
      // 44: ireturn
      // 45: invokestatic com/trolmastercard/velvet/dy.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 48: athrow
      // 49: getstatic com/trolmastercard/velvet/dy$a.a [I
      // 4c: aload 1
      // 4d: invokevirtual com/trolmastercard/velvet/fp.ordinal ()I
      // 50: iaload
      // 51: tableswitch 41 1 5 35 35 35 35 35
      // 74: bipush 1
      // 75: ireturn
      // 76: invokestatic com/trolmastercard/velvet/dy.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 79: athrow
      // 7a: bipush 0
      // 7b: ireturn
      // try (0 -> 6): 7 java/lang/RuntimeException
      // try (3 -> 11): 11 java/lang/RuntimeException
      // try (13 -> 20): 21 java/lang/RuntimeException
      // try (17 -> 26): 27 java/lang/RuntimeException
      // try (23 -> 31): 31 java/lang/RuntimeException
      // try (33 -> 40): 40 java/lang/RuntimeException
   }

   public static Vec3d a(em var0, UUID var1, float var2) {
      try {
         if (var1 == null) {
            return Vec3d.field_186680_a;
         }
      } catch (RuntimeException var7) {
         throw a(var7);
      }

      EntityPlayer var3 = var0.field_70170_p.func_152378_a(var1);

      try {
         if (var3 == null) {
            return Vec3d.field_186680_a;
         }
      } catch (RuntimeException var6) {
         throw a(var6);
      }

      Vec3d var4 = b6.a(new Vec3d(var3.field_70169_q, var3.field_70167_r, var3.field_70166_s), var3.func_174791_d(), var2);
      Vec3d var5 = b6.a(
         new Vec3d(y.field_71439_g.field_70169_q, y.field_71439_g.field_70167_r, y.field_71439_g.field_70166_s), y.field_71439_g.func_174791_d(), var2
      );
      return var4.func_178788_d(var5);
   }

   public static Vector4f a(EntityPlayer var0, float var1) {
      EntityPlayerSP var2 = y.field_71439_g;
      float var3 = b6.a(var0.field_70760_ar, var0.field_70761_aq, var1);
      Vec3d var4 = b6.a(new Vec3d(var0.field_70142_S, var0.field_70137_T, var0.field_70136_U), var0.func_174791_d(), var1);
      Vec3d var5 = b6.a(new Vec3d(var2.field_70142_S, var2.field_70137_T, var2.field_70136_U), var2.func_174791_d(), var1);
      Vec3d var6 = var4.func_178788_d(var5);
      return new Vector4f((float)var6.field_72450_a, (float)var6.field_72448_b, (float)var6.field_72449_c, var3);
   }

   @Override
   protected Vec3i a(String param1) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 00: aload 0
      // 01: getfield com/trolmastercard/velvet/dy.j Lcom/trolmastercard/velvet/em;
      // 04: invokestatic com/trolmastercard/velvet/e4.a (Lcom/trolmastercard/velvet/em;)[Ljava/lang/String;
      // 07: astore 2
      // 08: aload 2
      // 09: arraylength
      // 0a: bipush 8
      // 0c: if_icmpge 17
      // 0f: getstatic com/trolmastercard/velvet/dy.r Lnet/minecraft/util/math/Vec3i;
      // 12: areturn
      // 13: invokestatic com/trolmastercard/velvet/dy.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 16: athrow
      // 17: aload 1
      // 18: ldc_w "band"
      // 1b: invokevirtual java/lang/String.contains (Ljava/lang/CharSequence;)Z
      // 1e: ifeq 29
      // 21: getstatic com/trolmastercard/velvet/dy.w Lnet/minecraft/util/math/Vec3i;
      // 24: areturn
      // 25: invokestatic com/trolmastercard/velvet/dy.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 28: athrow
      // 29: aload 1
      // 2a: ldc_w "eyeColor"
      // 2d: invokevirtual java/lang/String.contains (Ljava/lang/CharSequence;)Z
      // 30: ifne 44
      // 33: aload 1
      // 34: ldc_w "eyeColor2"
      // 37: invokevirtual java/lang/String.contains (Ljava/lang/CharSequence;)Z
      // 3a: ifeq 50
      // 3d: goto 44
      // 40: invokestatic com/trolmastercard/velvet/dy.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 43: athrow
      // 44: aload 2
      // 45: bipush 8
      // 47: aaload
      // 48: invokestatic com/trolmastercard/velvet/dy.b (Ljava/lang/String;)Lnet/minecraft/util/math/Vec3i;
      // 4b: areturn
      // 4c: invokestatic com/trolmastercard/velvet/dy.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 4f: athrow
      // 50: aload 1
      // 51: ldc_w "variant"
      // 54: invokevirtual java/lang/String.contains (Ljava/lang/CharSequence;)Z
      // 57: ifne 6b
      // 5a: aload 1
      // 5b: ldc_w "boob"
      // 5e: invokevirtual java/lang/String.contains (Ljava/lang/CharSequence;)Z
      // 61: ifeq 77
      // 64: goto 6b
      // 67: invokestatic com/trolmastercard/velvet/dy.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 6a: athrow
      // 6b: aload 2
      // 6c: bipush 7
      // 6e: aaload
      // 6f: invokestatic com/trolmastercard/velvet/dy.c (Ljava/lang/String;)Lnet/minecraft/util/math/Vec3i;
      // 72: areturn
      // 73: invokestatic com/trolmastercard/velvet/dy.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 76: athrow
      // 77: aload 1
      // 78: ldc_w "hair"
      // 7b: invokevirtual java/lang/String.contains (Ljava/lang/CharSequence;)Z
      // 7e: ifeq 8d
      // 81: aload 2
      // 82: bipush 6
      // 84: aaload
      // 85: invokestatic com/trolmastercard/velvet/dy.d (Ljava/lang/String;)Lnet/minecraft/util/math/Vec3i;
      // 88: areturn
      // 89: invokestatic com/trolmastercard/velvet/dy.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 8c: athrow
      // 8d: getstatic com/trolmastercard/velvet/dy.D Ljava/util/HashSet;
      // 90: aload 1
      // 91: invokevirtual java/util/HashSet.contains (Ljava/lang/Object;)Z
      // 94: ifeq a3
      // 97: aload 2
      // 98: bipush 7
      // 9a: aaload
      // 9b: invokestatic com/trolmastercard/velvet/dy.c (Ljava/lang/String;)Lnet/minecraft/util/math/Vec3i;
      // 9e: areturn
      // 9f: invokestatic com/trolmastercard/velvet/dy.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // a2: athrow
      // a3: getstatic com/trolmastercard/velvet/dy.M Ljava/util/HashSet;
      // a6: aload 1
      // a7: invokevirtual java/util/HashSet.contains (Ljava/lang/Object;)Z
      // aa: ifeq b9
      // ad: aload 2
      // ae: bipush 6
      // b0: aaload
      // b1: invokestatic com/trolmastercard/velvet/dy.d (Ljava/lang/String;)Lnet/minecraft/util/math/Vec3i;
      // b4: areturn
      // b5: invokestatic com/trolmastercard/velvet/dy.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // b8: athrow
      // b9: getstatic com/trolmastercard/velvet/dy.r Lnet/minecraft/util/math/Vec3i;
      // bc: areturn
      // try (4 -> 10): 10 java/lang/RuntimeException
      // try (12 -> 18): 18 java/lang/RuntimeException
      // try (20 -> 28): 29 java/lang/RuntimeException
      // try (24 -> 36): 36 java/lang/RuntimeException
      // try (38 -> 46): 47 java/lang/RuntimeException
      // try (42 -> 54): 54 java/lang/RuntimeException
      // try (56 -> 65): 65 java/lang/RuntimeException
      // try (67 -> 76): 76 java/lang/RuntimeException
      // try (78 -> 87): 87 java/lang/RuntimeException
   }

   public static Vec3i b(String var0) {
      return eh.values()[Integer.parseInt(var0)].a();
   }

   public static Vec3i c(String var0) {
      return by.values()[Integer.parseInt(var0)].a();
   }

   public static Vec3i d(String var0) {
      return g5.values()[Integer.parseInt(var0)].a();
   }

   @Override
   protected void a(BufferBuilder var1, String var2, GeoBone var3) {
      try {
         if (this.j.field_70170_p instanceof gj) {
            return;
         }
      } catch (RuntimeException var11) {
         throw a(var11);
      }

      String[] var4 = e4.a(this.j);

      try {
         if (var4.length < 8) {
            return;
         }
      } catch (RuntimeException var10) {
         throw a(var10);
      }

      String var5 = var2;
      byte var6 = -1;

      label115: {
         label114: {
            label113: {
               label112: {
                  label111: {
                     label110: {
                        label109: {
                           label108: {
                              try {
                                 switch (var5.hashCode()) {
                                    case -1383396097:
                                       break label112;
                                    case -1383396096:
                                       break label113;
                                    case 2364452:
                                       break label110;
                                    case 3029410:
                                       break label109;
                                    case 3105718:
                                       if (!var5.equals("earL")) {
                                          break label115;
                                       }
                                       break label114;
                                    case 3105724:
                                       break;
                                    case 3194850:
                                       break label108;
                                    case 93921650:
                                       break label111;
                                    default:
                                       break label115;
                                 }
                              } catch (RuntimeException var9) {
                                 throw a(var9);
                              }

                              if (var5.equals("earR")) {
                                 var6 = 1;
                              }
                              break label115;
                           }

                           if (var5.equals("hair")) {
                              var6 = 2;
                           }
                           break label115;
                        }

                        if (var5.equals("body")) {
                           var6 = 3;
                        }
                        break label115;
                     }

                     if (var5.equals("LegR")) {
                        var6 = 4;
                     }
                     break label115;
                  }

                  if (var5.equals("boobR")) {
                     var6 = 5;
                  }
                  break label115;
               }

               if (var5.equals("boobR1")) {
                  var6 = 6;
               }
               break label115;
            }

            if (var5.equals("boobR2")) {
               var6 = 7;
            }
            break label115;
         }

         var6 = 0;
      }

      label86: {
         label85: {
            label84: {
               label83: {
                  label82: {
                     label81: {
                        label80: {
                           try {
                              switch (var6) {
                                 case 0:
                                    a(var3, var4[0], var4[1], var4[3]);
                                    break label86;
                                 case 1:
                                    break label85;
                                 case 2:
                                    break label84;
                                 case 3:
                                    break label83;
                                 case 4:
                                    break label82;
                                 case 5:
                                    break label81;
                                 case 6:
                                    break label80;
                                 case 7:
                                    break;
                                 default:
                                    break label86;
                              }
                           } catch (RuntimeException var8) {
                              throw a(var8);
                           }

                           a(this.u, var3, 5.0F, 3.0F);
                           break label86;
                        }

                        a(this.u, var3, 10.0F, 15.0F);
                        break label86;
                     }

                     a(this.u, var3, 30.0F, 30.0F);
                     break label86;
                  }

                  a(this.u, var3, 25.0F, 25.0F);
                  break label86;
               }

               var3.setPivotY(-0.15F);
               a(this.j, var3);
               break label86;
            }

            a(var3, var4[5]);
            break label86;
         }

         a(var3, var4[0], var4[2], var4[4]);
      }

      try {
         if (var2.contains("crown")) {
            a(this.j, var3, var4[9]);
         }
      } catch (RuntimeException var7) {
         throw a(var7);
      }
   }

   public static void a(em var0, GeoBone var1, String var2) {
      try {
         if (var0.h()) {
            var1.setHidden(true);
            return;
         }
      } catch (RuntimeException var6) {
         throw a(var6);
      }

      if (var0 instanceof e3) {
         int var3 = Integer.parseInt(var2);

         GeoBone var10000;
         boolean var10001;
         label30: {
            try {
               var10000 = var1;
               if (var3 == 0) {
                  var10001 = true;
                  break label30;
               }
            } catch (RuntimeException var5) {
               throw a(var5);
            }

            var10001 = false;
         }

         var10000.setHidden(var10001);
      } else {
         try {
            if (var0 instanceof eq) {
               var1.setHidden(((ItemStack)var0.func_184212_Q().func_187225_a(e2.X)).func_190926_b());
            }
         } catch (RuntimeException var4) {
            throw a(var4);
         }
      }
   }

   public static void a(boolean var0, GeoBone var1, float var2, float var3) {
      try {
         if (y.func_147113_T()) {
            return;
         }
      } catch (RuntimeException var4) {
         throw a(var4);
      }

      try {
         if (!var0) {
            return;
         }
      } catch (RuntimeException var5) {
         throw a(var5);
      }

      var1.setRotationX(var1.getRotationX() + gc.c(be.b(x, -var2, var2)));
      var1.setRotationZ(var1.getRotationZ() + gc.c(be.b(N, -var3, var3)));
   }

   public static void a(em param0, GeoBone param1) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 00: getstatic com/trolmastercard/velvet/dy.B F
      // 03: ldc -420.69
      // 05: fcmpl
      // 06: ifne 1a
      // 09: aload 0
      // 0a: invokevirtual com/trolmastercard/velvet/em.y ()Lcom/trolmastercard/velvet/fp;
      // 0d: getstatic com/trolmastercard/velvet/fp.SHOULDER_IDLE Lcom/trolmastercard/velvet/fp;
      // 10: if_acmpeq 1f
      // 13: goto 1a
      // 16: invokestatic com/trolmastercard/velvet/dy.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 19: athrow
      // 1a: return
      // 1b: invokestatic com/trolmastercard/velvet/dy.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 1e: athrow
      // 1f: getstatic com/trolmastercard/velvet/dy.y Lnet/minecraft/client/Minecraft;
      // 22: invokevirtual net/minecraft/client/Minecraft.func_175598_ae ()Lnet/minecraft/client/renderer/entity/RenderManager;
      // 25: getfield net/minecraft/client/renderer/entity/RenderManager.field_78732_j F
      // 28: fneg
      // 29: fstore 2
      // 2a: aload 1
      // 2b: ldc 8.0
      // 2d: invokevirtual software/bernie/geckolib3/geo/render/built/GeoBone.setPivotY (F)V
      // 30: getstatic com/trolmastercard/velvet/dy.y Lnet/minecraft/client/Minecraft;
      // 33: invokevirtual net/minecraft/client/Minecraft.func_147113_T ()Z
      // 36: ifeq 3e
      // 39: return
      // 3a: invokestatic com/trolmastercard/velvet/dy.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 3d: athrow
      // 3e: aload 1
      // 3f: aload 1
      // 40: invokevirtual software/bernie/geckolib3/geo/render/built/GeoBone.getRotationX ()F
      // 43: fload 2
      // 44: invokestatic com/trolmastercard/velvet/gc.c (F)F
      // 47: fadd
      // 48: invokevirtual software/bernie/geckolib3/geo/render/built/GeoBone.setRotationX (F)V
      // 4b: return
      // try (0 -> 8): 9 java/lang/RuntimeException
      // try (4 -> 12): 12 java/lang/RuntimeException
      // try (19 -> 26): 26 java/lang/RuntimeException
   }

   public static void a(GeoBone var0, String var1) {
      int var2 = Integer.parseInt(var1);
      a(var0, var2);
   }

   static HashSet<Integer> b(int var0, String var1) {
      int var2 = Integer.parseInt(var1);
      int var3 = var0 - 1;
      ArrayList var4 = a(var3);

      while (var2 >= var4.size()) {
         var2 -= var4.size();
      }

      return (HashSet<Integer>)var4.get(var2);
   }

   static ArrayList<HashSet<Integer>> a(int var0) {
      ArrayList var1 = new ArrayList();
      a(0, new HashSet<>(), var0, var1);
      return var1;
   }

   static void a(int var0, HashSet<Integer> var1, int var2, ArrayList<HashSet<Integer>> var3) {
      try {
         if (var0 > var2) {
            var3.add(var1);
            return;
         }
      } catch (RuntimeException var5) {
         throw a(var5);
      }

      HashSet var4 = new HashSet(var1);
      a(var0 + 1, var1, var2, var3);
      var4.add(var0);
      a(var0 + 1, var4, var2, var3);
   }

   static HashSet<Integer> a(int var0, String var1) {
      HashSet var2 = new HashSet();
      int var3 = Integer.parseInt(var1);
      var3 = (int)(0.01F * var3 * var3);
      int var4 = Math.round(var3 / 100.0F * var0);
      Random var5 = new Random(var3);

      for (int var6 = 0; var6 < var4; var6++) {
         int var7 = var5.nextInt(var0);

         try {
            if (!var2.contains(var7)) {
               var2.add(var7);
               continue;
            }
         } catch (RuntimeException var8) {
            throw a(var8);
         }

         var6--;
      }

      return var2;
   }

   static void a(GeoBone var0, String var1, String var2, String var3) {
      GeoBone var4 = a(var0, Integer.parseInt(var1));
      GeoBone var5 = a(var4, Integer.parseInt(var2));
      List var6 = var5.childBones;
      int var7 = var6.size();
      HashSet var8 = b(var7, var3);
      var5.childBones.forEach(var0x -> var0x.setHidden(true));
      var8.forEach(var1x -> b(var5, var1x));
   }

   @Override
   protected Vec3i a(Vec3i param1) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 00: aload 0
      // 01: getfield com/trolmastercard/velvet/dy.u Z
      // 04: ifne 1b
      // 07: aload 0
      // 08: getfield com/trolmastercard/velvet/dy.F Z
      // 0b: ifne 1b
      // 0e: goto 15
      // 11: invokestatic com/trolmastercard/velvet/dy.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 14: athrow
      // 15: aload 1
      // 16: areturn
      // 17: invokestatic com/trolmastercard/velvet/dy.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 1a: athrow
      // 1b: aload 0
      // 1c: getfield com/trolmastercard/velvet/dy.z F
      // 1f: fconst_2
      // 20: ldc_w 15.0
      // 23: invokestatic com/trolmastercard/velvet/be.b (FFF)F
      // 26: ldc_w 15.0
      // 29: fdiv
      // 2a: fstore 2
      // 2b: new net/minecraft/util/math/Vec3i
      // 2e: dup
      // 2f: aload 1
      // 30: invokevirtual net/minecraft/util/math/Vec3i.func_177958_n ()I
      // 33: i2f
      // 34: fload 2
      // 35: fmul
      // 36: f2d
      // 37: aload 1
      // 38: invokevirtual net/minecraft/util/math/Vec3i.func_177956_o ()I
      // 3b: i2f
      // 3c: fload 2
      // 3d: fmul
      // 3e: f2d
      // 3f: aload 1
      // 40: invokevirtual net/minecraft/util/math/Vec3i.func_177952_p ()I
      // 43: i2f
      // 44: fload 2
      // 45: fmul
      // 46: f2d
      // 47: invokespecial net/minecraft/util/math/Vec3i.<init> (DDD)V
      // 4a: areturn
      // try (0 -> 6): 7 java/lang/RuntimeException
      // try (3 -> 11): 11 java/lang/RuntimeException
   }

   @Override
   protected ItemStack a(@Nullable ItemStack param1) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 00: aload 0
      // 01: getfield com/trolmastercard/velvet/dy.j Lcom/trolmastercard/velvet/em;
      // 04: checkcast com/trolmastercard/velvet/e3
      // 07: invokevirtual com/trolmastercard/velvet/e3.y ()Lcom/trolmastercard/velvet/fp;
      // 0a: astore 2
      // 0b: aload 2
      // 0c: getstatic com/trolmastercard/velvet/fp.RUN Lcom/trolmastercard/velvet/fp;
      // 0f: if_acmpeq 20
      // 12: aload 2
      // 13: getstatic com/trolmastercard/velvet/fp.CATCH Lcom/trolmastercard/velvet/fp;
      // 16: if_acmpne 38
      // 19: goto 20
      // 1c: invokestatic com/trolmastercard/velvet/dy.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 1f: athrow
      // 20: aload 0
      // 21: getfield com/trolmastercard/velvet/dy.j Lcom/trolmastercard/velvet/em;
      // 24: checkcast com/trolmastercard/velvet/e3
      // 27: invokevirtual com/trolmastercard/velvet/e3.func_184212_Q ()Lnet/minecraft/network/datasync/EntityDataManager;
      // 2a: getstatic com/trolmastercard/velvet/e3.a0 Lnet/minecraft/network/datasync/DataParameter;
      // 2d: invokevirtual net/minecraft/network/datasync/EntityDataManager.func_187225_a (Lnet/minecraft/network/datasync/DataParameter;)Ljava/lang/Object;
      // 30: checkcast net/minecraft/item/ItemStack
      // 33: areturn
      // 34: invokestatic com/trolmastercard/velvet/dy.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 37: athrow
      // 38: aload 1
      // 39: areturn
      // try (5 -> 11): 12 java/lang/RuntimeException
      // try (8 -> 22): 22 java/lang/RuntimeException
   }

   @Override
   public HashSet<String> a() {
      return new HashSet<String>() {
         {
            this.add("boobs");
            this.add("booty");
            this.add("vagina");
            this.add("fuckhole");
            this.add("preggy");
            this.add("LegL");
            this.add("LegR");
            this.add("cheekR");
            this.add("cheekL");
         }
      };
   }

   @Override
   protected float a() {
      try {
         return this.j.y() == fp.CATCH ? 0.5F : 1.0F;
      } catch (RuntimeException var1) {
         throw a(var1);
      }
   }

   @Override
   protected Vec3d a(ItemStack param1) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 00: aload 1
      // 01: ifnonnull 0c
      // 04: getstatic net/minecraft/util/math/Vec3d.field_186680_a Lnet/minecraft/util/math/Vec3d;
      // 07: areturn
      // 08: invokestatic com/trolmastercard/velvet/dy.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 0b: athrow
      // 0c: aload 1
      // 0d: invokevirtual net/minecraft/item/ItemStack.func_77973_b ()Lnet/minecraft/item/Item;
      // 10: instanceof net/minecraft/item/ItemBlock
      // 13: ifne 25
      // 16: aload 1
      // 17: invokevirtual net/minecraft/item/ItemStack.func_77976_d ()I
      // 1a: bipush 1
      // 1b: if_icmpne 2f
      // 1e: goto 25
      // 21: invokestatic com/trolmastercard/velvet/dy.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 24: athrow
      // 25: aload 0
      // 26: aload 1
      // 27: invokespecial com/trolmastercard/velvet/d6.a (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/util/math/Vec3d;
      // 2a: areturn
      // 2b: invokestatic com/trolmastercard/velvet/dy.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 2e: athrow
      // 2f: new net/minecraft/util/math/Vec3d
      // 32: dup
      // 33: ldc2_w 180.0
      // 36: dconst_0
      // 37: dconst_0
      // 38: invokespecial net/minecraft/util/math/Vec3d.<init> (DDD)V
      // 3b: areturn
      // try (0 -> 4): 4 java/lang/RuntimeException
      // try (6 -> 14): 15 java/lang/RuntimeException
      // try (10 -> 21): 21 java/lang/RuntimeException
   }

   @Override
   public void a(BufferBuilder param1, GeoCube param2, GeoBone param3, float param4, float param5, float param6, float param7, double param8) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 00: aload 0
      // 01: getfield com/trolmastercard/velvet/dy.u Z
      // 04: ifeq 20
      // 07: getstatic com/trolmastercard/velvet/dy.C Ljava/util/HashSet;
      // 0a: aload 3
      // 0b: invokevirtual software/bernie/geckolib3/geo/render/built/GeoBone.getName ()Ljava/lang/String;
      // 0e: invokevirtual java/util/HashSet.contains (Ljava/lang/Object;)Z
      // 11: ifne 20
      // 14: goto 1b
      // 17: invokestatic com/trolmastercard/velvet/dy.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 1a: athrow
      // 1b: return
      // 1c: invokestatic com/trolmastercard/velvet/dy.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 1f: athrow
      // 20: aload 0
      // 21: getfield com/trolmastercard/velvet/dy.p Ljava/util/HashSet;
      // 24: aload 3
      // 25: invokevirtual software/bernie/geckolib3/geo/render/built/GeoBone.getName ()Ljava/lang/String;
      // 28: invokevirtual java/util/HashSet.contains (Ljava/lang/Object;)Z
      // 2b: ifeq 33
      // 2e: return
      // 2f: invokestatic com/trolmastercard/velvet/dy.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 32: athrow
      // 33: aload 0
      // 34: aload 3
      // 35: putfield com/trolmastercard/velvet/dy.q Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;
      // 38: aload 0
      // 39: aload 1
      // 3a: aload 2
      // 3b: aload 3
      // 3c: fload 4
      // 3e: fload 5
      // 40: fload 6
      // 42: fload 7
      // 44: dload 8
      // 46: invokespecial com/trolmastercard/velvet/d6.a (Lnet/minecraft/client/renderer/BufferBuilder;Lsoftware/bernie/geckolib3/geo/render/built/GeoCube;Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;FFFFD)V
      // 49: return
      // try (0 -> 8): 9 java/lang/RuntimeException
      // try (3 -> 12): 12 java/lang/RuntimeException
      // try (14 -> 21): 21 java/lang/RuntimeException
   }

   private static Exception a(Exception var0) {
      return var0;
   }
}
