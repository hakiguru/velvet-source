package org.velvet;

import net.minecraft.util.ResourceLocation;
import software.bernie.geckolib3.model.AnimatedGeoModel;

public class f6 extends AnimatedGeoModel<c7> {
   public ResourceLocation a(c7 var1) {
      return new ResourceLocation("velvet", "geo/kobold/koboldegg.geo.json");
   }

   public ResourceLocation b(c7 var1) {
      return new ResourceLocation("velvet", "textures/entity/kobold/koboldegg.png");
   }

   public ResourceLocation c(c7 var1) {
      return new ResourceLocation("velvet", "animations/kobold/egg.animation.json");
   }
}
