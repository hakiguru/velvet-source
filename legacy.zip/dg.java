package org.velvet;

import java.util.HashSet;
import javax.annotation.Nullable;
import javax.vecmath.Vector4f;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemArmor.ArmorMaterial;
import net.minecraft.util.math.Vec3i;
import software.bernie.geckolib3.geo.render.built.GeoBone;
import software.bernie.geckolib3.model.AnimatedGeoModel;

public class dg extends d9 {
   eq B = null;
   boolean C = false;
   boolean E = false;
   boolean D = false;

   public dg(RenderManager var1, AnimatedGeoModel var2) {
      super(var1, var2);
   }

   @Override
   protected Vec3i a(String param1) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 00: aload 0
      // 01: getfield com/trolmastercard/velvet/dg.j Lcom/trolmastercard/velvet/em;
      // 04: invokestatic com/trolmastercard/velvet/e4.a (Lcom/trolmastercard/velvet/em;)[Ljava/lang/String;
      // 07: astore 2
      // 08: aload 2
      // 09: arraylength
      // 0a: bipush 8
      // 0c: if_icmpge 17
      // 0f: getstatic com/trolmastercard/velvet/dg.z Lnet/minecraft/util/math/Vec3i;
      // 12: areturn
      // 13: invokestatic com/trolmastercard/velvet/dg.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 16: athrow
      // 17: aload 1
      // 18: ldc "band"
      // 1a: invokevirtual java/lang/String.contains (Ljava/lang/CharSequence;)Z
      // 1d: ifeq 28
      // 20: getstatic com/trolmastercard/velvet/dy.w Lnet/minecraft/util/math/Vec3i;
      // 23: areturn
      // 24: invokestatic com/trolmastercard/velvet/dg.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 27: athrow
      // 28: aload 1
      // 29: ldc "eyeColor"
      // 2b: invokevirtual java/lang/String.contains (Ljava/lang/CharSequence;)Z
      // 2e: ifne 41
      // 31: aload 1
      // 32: ldc "eyeColor2"
      // 34: invokevirtual java/lang/String.contains (Ljava/lang/CharSequence;)Z
      // 37: ifeq 4d
      // 3a: goto 41
      // 3d: invokestatic com/trolmastercard/velvet/dg.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 40: athrow
      // 41: aload 2
      // 42: bipush 8
      // 44: aaload
      // 45: invokestatic com/trolmastercard/velvet/dy.b (Ljava/lang/String;)Lnet/minecraft/util/math/Vec3i;
      // 48: areturn
      // 49: invokestatic com/trolmastercard/velvet/dg.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 4c: athrow
      // 4d: aload 1
      // 4e: ldc "variant"
      // 50: invokevirtual java/lang/String.contains (Ljava/lang/CharSequence;)Z
      // 53: ifne 66
      // 56: aload 1
      // 57: ldc "boob"
      // 59: invokevirtual java/lang/String.contains (Ljava/lang/CharSequence;)Z
      // 5c: ifeq 72
      // 5f: goto 66
      // 62: invokestatic com/trolmastercard/velvet/dg.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 65: athrow
      // 66: aload 2
      // 67: bipush 7
      // 69: aaload
      // 6a: invokestatic com/trolmastercard/velvet/dy.c (Ljava/lang/String;)Lnet/minecraft/util/math/Vec3i;
      // 6d: areturn
      // 6e: invokestatic com/trolmastercard/velvet/dg.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 71: athrow
      // 72: aload 1
      // 73: ldc "hair"
      // 75: invokevirtual java/lang/String.contains (Ljava/lang/CharSequence;)Z
      // 78: ifeq 87
      // 7b: aload 2
      // 7c: bipush 6
      // 7e: aaload
      // 7f: invokestatic com/trolmastercard/velvet/dy.d (Ljava/lang/String;)Lnet/minecraft/util/math/Vec3i;
      // 82: areturn
      // 83: invokestatic com/trolmastercard/velvet/dg.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 86: athrow
      // 87: getstatic com/trolmastercard/velvet/dy.D Ljava/util/HashSet;
      // 8a: aload 1
      // 8b: invokevirtual java/util/HashSet.contains (Ljava/lang/Object;)Z
      // 8e: ifeq 9d
      // 91: aload 2
      // 92: bipush 7
      // 94: aaload
      // 95: invokestatic com/trolmastercard/velvet/dy.c (Ljava/lang/String;)Lnet/minecraft/util/math/Vec3i;
      // 98: areturn
      // 99: invokestatic com/trolmastercard/velvet/dg.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 9c: athrow
      // 9d: getstatic com/trolmastercard/velvet/dy.M Ljava/util/HashSet;
      // a0: aload 1
      // a1: invokevirtual java/util/HashSet.contains (Ljava/lang/Object;)Z
      // a4: ifeq b3
      // a7: aload 2
      // a8: bipush 6
      // aa: aaload
      // ab: invokestatic com/trolmastercard/velvet/dy.d (Ljava/lang/String;)Lnet/minecraft/util/math/Vec3i;
      // ae: areturn
      // af: invokestatic com/trolmastercard/velvet/dg.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // b2: athrow
      // b3: getstatic com/trolmastercard/velvet/dg.z Lnet/minecraft/util/math/Vec3i;
      // b6: areturn
      // try (4 -> 10): 10 java/lang/RuntimeException
      // try (12 -> 18): 18 java/lang/RuntimeException
      // try (20 -> 28): 29 java/lang/RuntimeException
      // try (24 -> 36): 36 java/lang/RuntimeException
      // try (38 -> 46): 47 java/lang/RuntimeException
      // try (42 -> 54): 54 java/lang/RuntimeException
      // try (56 -> 65): 65 java/lang/RuntimeException
      // try (67 -> 76): 76 java/lang/RuntimeException
      // try (78 -> 87): 87 java/lang/RuntimeException
   }

   @Override
   protected Vector4f a(String var1, float var2, float var3, float var4) {
      if (var1.startsWith("crown")) {
         ItemStack var5 = (ItemStack)this.j.func_184212_Q().func_187225_a(e2.X);

         try {
            if (var5.func_190926_b()) {
               return super.a(var1, var2, var3, var4);
            }
         } catch (RuntimeException var13) {
            throw a(var13);
         }

         ItemArmor var6 = (ItemArmor)var5.func_77973_b();
         ArmorMaterial var7 = var6.func_82812_d();
         float var8 = 0.0F;
         switch (var7) {
            case GOLD:
               var8 = 1.0F;
               break;
            case CHAIN:
            case IRON:
               var8 = 2.0F;
               break;
            case LEATHER:
               var8 = 4.0F;
               int var9 = var6.func_82814_b(var5);
               float var10 = (var9 >> 16 & 0xFF) / 255.0F;
               float var11 = (var9 >> 8 & 0xFF) / 255.0F;
               float var12 = (var9 & 0xFF) / 255.0F;
               var2 = var10;
               var3 = var11;
               var4 = var12;
         }

         return new Vector4f(var2, var3, var4, 72.0F * var8 / 4096.0F);
      } else {
         return super.a(var1, var2, var3, var4);
      }
   }

   @Override
   protected boolean c(String var1) {
      try {
         if (var1.startsWith("crown")) {
            return true;
         }
      } catch (RuntimeException var2) {
         throw a(var2);
      }

      return super.c(var1);
   }

   @Override
   public HashSet<String> a() {
      return new HashSet<String>() {
         {
            this.add("boobs");
            this.add("booty");
            this.add("vagina");
            this.add("fuckhole");
            this.add("preggy");
            this.add("LegL");
            this.add("LegR");
            this.add("cheekR");
            this.add("cheekL");
         }
      };
   }

   @Override
   protected void a(String var1, GeoBone var2) {
      String[] var3 = e4.a(this.j);

      try {
         if (var3.length < 8) {
            return;
         }
      } catch (RuntimeException var9) {
         throw a(var9);
      }

      String var4 = var1;
      byte var5 = -1;

      label111: {
         label110: {
            label109: {
               label108: {
                  label107: {
                     label106: {
                        label105: {
                           label104: {
                              try {
                                 switch (var4.hashCode()) {
                                    case -1383396097:
                                       break label108;
                                    case -1383396096:
                                       break label109;
                                    case 2364452:
                                       break label106;
                                    case 3029410:
                                       break label105;
                                    case 3105718:
                                       if (!var4.equals("earL")) {
                                          break label111;
                                       }
                                       break label110;
                                    case 3105724:
                                       break;
                                    case 3194850:
                                       break label104;
                                    case 93921650:
                                       break label107;
                                    default:
                                       break label111;
                                 }
                              } catch (RuntimeException var8) {
                                 throw a(var8);
                              }

                              if (var4.equals("earR")) {
                                 var5 = 1;
                              }
                              break label111;
                           }

                           if (var4.equals("hair")) {
                              var5 = 2;
                           }
                           break label111;
                        }

                        if (var4.equals("body")) {
                           var5 = 3;
                        }
                        break label111;
                     }

                     if (var4.equals("LegR")) {
                        var5 = 4;
                     }
                     break label111;
                  }

                  if (var4.equals("boobR")) {
                     var5 = 5;
                  }
                  break label111;
               }

               if (var4.equals("boobR1")) {
                  var5 = 6;
               }
               break label111;
            }

            if (var4.equals("boobR2")) {
               var5 = 7;
            }
            break label111;
         }

         var5 = 0;
      }

      label82: {
         label81: {
            label80: {
               label79: {
                  label78: {
                     label77: {
                        label76: {
                           try {
                              switch (var5) {
                                 case 0:
                                    dy.a(var2, var3[0], var3[1], var3[3]);
                                    break label82;
                                 case 1:
                                    break label81;
                                 case 2:
                                    break label80;
                                 case 3:
                                    break label79;
                                 case 4:
                                    break label78;
                                 case 5:
                                    break label77;
                                 case 6:
                                    break label76;
                                 case 7:
                                    break;
                                 default:
                                    break label82;
                              }
                           } catch (RuntimeException var7) {
                              throw a(var7);
                           }

                           dy.a(this.C, var2, 5.0F, 3.0F);
                           break label82;
                        }

                        dy.a(this.C, var2, 10.0F, 15.0F);
                        break label82;
                     }

                     dy.a(this.C, var2, 30.0F, 30.0F);
                     break label82;
                  }

                  dy.a(this.C, var2, 25.0F, 25.0F);
                  break label82;
               }

               var2.setPivotY(-0.15F);
               dy.a(this.j, var2);
               break label82;
            }

            dy.a(var2, var3[5]);
            break label82;
         }

         dy.a(var2, var3[0], var3[2], var3[4]);
      }

      try {
         if (var1.contains("crown")) {
            dy.a(this.j, var2, var3[9]);
         }
      } catch (RuntimeException var6) {
         throw a(var6);
      }
   }

   @Override
   public void a(em param1, double param2, double param4, double param6, float param8, float param9) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 000: aload 0
      // 001: getstatic com/trolmastercard/velvet/dg.v Z
      // 004: putfield com/trolmastercard/velvet/dg.D Z
      // 007: aload 0
      // 008: aload 1
      // 009: checkcast com/trolmastercard/velvet/eq
      // 00c: putfield com/trolmastercard/velvet/dg.B Lcom/trolmastercard/velvet/eq;
      // 00f: aload 0
      // 010: ldc -420.69
      // 012: fload 8
      // 014: fcmpl
      // 015: ifne 031
      // 018: aload 1
      // 019: invokevirtual com/trolmastercard/velvet/em.y ()Lcom/trolmastercard/velvet/fp;
      // 01c: getstatic com/trolmastercard/velvet/fp.SHOULDER_IDLE Lcom/trolmastercard/velvet/fp;
      // 01f: if_acmpne 031
      // 022: goto 029
      // 025: invokestatic com/trolmastercard/velvet/dg.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 028: athrow
      // 029: bipush 1
      // 02a: goto 032
      // 02d: invokestatic com/trolmastercard/velvet/dg.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 030: athrow
      // 031: bipush 0
      // 032: putfield com/trolmastercard/velvet/dg.C Z
      // 035: aload 0
      // 036: ldc -420.69
      // 038: fload 8
      // 03a: fcmpl
      // 03b: ifne 057
      // 03e: aload 1
      // 03f: invokevirtual com/trolmastercard/velvet/em.y ()Lcom/trolmastercard/velvet/fp;
      // 042: getstatic com/trolmastercard/velvet/fp.PICK_UP Lcom/trolmastercard/velvet/fp;
      // 045: if_acmpne 057
      // 048: goto 04f
      // 04b: invokestatic com/trolmastercard/velvet/dg.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 04e: athrow
      // 04f: bipush 1
      // 050: goto 058
      // 053: invokestatic com/trolmastercard/velvet/dg.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 056: athrow
      // 057: bipush 0
      // 058: putfield com/trolmastercard/velvet/dg.E Z
      // 05b: aload 0
      // 05c: fload 9
      // 05e: putfield com/trolmastercard/velvet/dg.y F
      // 061: fload 8
      // 063: putstatic com/trolmastercard/velvet/dy.B F
      // 066: aload 1
      // 067: invokevirtual com/trolmastercard/velvet/em.y ()Lcom/trolmastercard/velvet/fp;
      // 06a: astore 10
      // 06c: aload 0
      // 06d: getfield com/trolmastercard/velvet/dg.B Lcom/trolmastercard/velvet/eq;
      // 070: invokevirtual com/trolmastercard/velvet/eq.e ()Ljava/util/UUID;
      // 073: astore 11
      // 075: aload 1
      // 076: invokevirtual com/trolmastercard/velvet/em.h ()Z
      // 079: ifeq 0a1
      // 07c: aload 1
      // 07d: getfield com/trolmastercard/velvet/em.field_70170_p Lnet/minecraft/world/World;
      // 080: aload 1
      // 081: aload 11
      // 083: dload 2
      // 084: dload 4
      // 086: dload 6
      // 088: invokestatic com/trolmastercard/velvet/dy.a (Lnet/minecraft/world/World;Lcom/trolmastercard/velvet/em;Ljava/util/UUID;DDD)Lnet/minecraft/util/math/Vec3d;
      // 08b: astore 12
      // 08d: aload 12
      // 08f: getfield net/minecraft/util/math/Vec3d.field_72450_a D
      // 092: dstore 2
      // 093: aload 12
      // 095: getfield net/minecraft/util/math/Vec3d.field_72448_b D
      // 098: dstore 4
      // 09a: aload 12
      // 09c: getfield net/minecraft/util/math/Vec3d.field_72449_c D
      // 09f: dstore 6
      // 0a1: aload 10
      // 0a3: getstatic com/trolmastercard/velvet/fp.THROWN Lcom/trolmastercard/velvet/fp;
      // 0a6: if_acmpeq 0b8
      // 0a9: aload 10
      // 0ab: getstatic com/trolmastercard/velvet/fp.START_THROWING Lcom/trolmastercard/velvet/fp;
      // 0ae: if_acmpne 109
      // 0b1: goto 0b8
      // 0b4: invokestatic com/trolmastercard/velvet/dg.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 0b7: athrow
      // 0b8: getstatic com/trolmastercard/velvet/dg.i Lnet/minecraft/client/Minecraft;
      // 0bb: getfield net/minecraft/client/Minecraft.field_71474_y Lnet/minecraft/client/settings/GameSettings;
      // 0be: getfield net/minecraft/client/settings/GameSettings.field_74320_O I
      // 0c1: ifne 0ed
      // 0c4: goto 0cb
      // 0c7: invokestatic com/trolmastercard/velvet/dg.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 0ca: athrow
      // 0cb: fload 8
      // 0cd: ldc -420.69
      // 0cf: fcmpl
      // 0d0: ifne 0ed
      // 0d3: goto 0da
      // 0d6: invokestatic com/trolmastercard/velvet/dg.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 0d9: athrow
      // 0da: aload 1
      // 0db: invokevirtual com/trolmastercard/velvet/em.h ()Z
      // 0de: ifne 0ed
      // 0e1: goto 0e8
      // 0e4: invokestatic com/trolmastercard/velvet/dg.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 0e7: athrow
      // 0e8: return
      // 0e9: invokestatic com/trolmastercard/velvet/dg.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 0ec: athrow
      // 0ed: aload 1
      // 0ee: invokevirtual com/trolmastercard/velvet/em.h ()Z
      // 0f1: ifne 109
      // 0f4: aload 1
      // 0f5: invokevirtual com/trolmastercard/velvet/em.I ()Ljava/lang/Float;
      // 0f8: invokevirtual java/lang/Float.floatValue ()F
      // 0fb: fstore 12
      // 0fd: aload 1
      // 0fe: fload 12
      // 100: putfield com/trolmastercard/velvet/em.field_70760_ar F
      // 103: aload 1
      // 104: fload 12
      // 106: putfield com/trolmastercard/velvet/em.field_70761_aq F
      // 109: aload 1
      // 10a: aload 10
      // 10c: invokestatic com/trolmastercard/velvet/dy.a (Lcom/trolmastercard/velvet/em;Lcom/trolmastercard/velvet/fp;)Z
      // 10f: ifeq 2ac
      // 112: getstatic com/trolmastercard/velvet/dg.i Lnet/minecraft/client/Minecraft;
      // 115: getfield net/minecraft/client/Minecraft.field_71439_g Lnet/minecraft/client/entity/EntityPlayerSP;
      // 118: invokevirtual net/minecraft/client/entity/EntityPlayerSP.getPersistentID ()Ljava/util/UUID;
      // 11b: aload 11
      // 11d: invokevirtual java/util/UUID.equals (Ljava/lang/Object;)Z
      // 120: ifeq 1d4
      // 123: goto 12a
      // 126: invokestatic com/trolmastercard/velvet/dg.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 129: athrow
      // 12a: ldc -420.69
      // 12c: fload 8
      // 12e: fcmpl
      // 12f: ifeq 13e
      // 132: goto 139
      // 135: invokestatic com/trolmastercard/velvet/dg.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 138: athrow
      // 139: return
      // 13a: invokestatic com/trolmastercard/velvet/dg.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 13d: athrow
      // 13e: aload 1
      // 13f: getstatic com/trolmastercard/velvet/dg.i Lnet/minecraft/client/Minecraft;
      // 142: getfield net/minecraft/client/Minecraft.field_71439_g Lnet/minecraft/client/entity/EntityPlayerSP;
      // 145: getfield net/minecraft/client/entity/EntityPlayerSP.field_70177_z F
      // 148: ldc_w 180.0
      // 14b: fadd
      // 14c: putfield com/trolmastercard/velvet/em.field_70761_aq F
      // 14f: aload 1
      // 150: getstatic com/trolmastercard/velvet/dg.i Lnet/minecraft/client/Minecraft;
      // 153: getfield net/minecraft/client/Minecraft.field_71439_g Lnet/minecraft/client/entity/EntityPlayerSP;
      // 156: getfield net/minecraft/client/entity/EntityPlayerSP.field_70177_z F
      // 159: ldc_w 180.0
      // 15c: fadd
      // 15d: putfield com/trolmastercard/velvet/em.field_70760_ar F
      // 160: getstatic com/trolmastercard/velvet/dg.i Lnet/minecraft/client/Minecraft;
      // 163: getfield net/minecraft/client/Minecraft.field_71439_g Lnet/minecraft/client/entity/EntityPlayerSP;
      // 166: invokevirtual net/minecraft/client/entity/EntityPlayerSP.func_70040_Z ()Lnet/minecraft/util/math/Vec3d;
      // 169: astore 12
      // 16b: invokestatic net/minecraft/client/renderer/GlStateManager.func_179094_E ()V
      // 16e: aload 12
      // 170: getfield net/minecraft/util/math/Vec3d.field_72450_a D
      // 173: aload 12
      // 175: getfield net/minecraft/util/math/Vec3d.field_72448_b D
      // 178: getstatic com/trolmastercard/velvet/dg.i Lnet/minecraft/client/Minecraft;
      // 17b: getfield net/minecraft/client/Minecraft.field_71439_g Lnet/minecraft/client/entity/EntityPlayerSP;
      // 17e: invokevirtual net/minecraft/client/entity/EntityPlayerSP.func_70047_e ()F
      // 181: f2d
      // 182: dadd
      // 183: aload 12
      // 185: getfield net/minecraft/util/math/Vec3d.field_72449_c D
      // 188: invokestatic net/minecraft/client/renderer/GlStateManager.func_179137_b (DDD)V
      // 18b: new net/minecraft/util/math/Vec3d
      // 18e: dup
      // 18f: getstatic com/trolmastercard/velvet/dg.i Lnet/minecraft/client/Minecraft;
      // 192: getfield net/minecraft/client/Minecraft.field_71439_g Lnet/minecraft/client/entity/EntityPlayerSP;
      // 195: getfield net/minecraft/client/entity/EntityPlayerSP.field_70125_A F
      // 198: invokestatic java/lang/Math.abs (F)F
      // 19b: fneg
      // 19c: f2d
      // 19d: dconst_0
      // 19e: dconst_0
      // 19f: invokespecial net/minecraft/util/math/Vec3d.<init> (DDD)V
      // 1a2: getstatic com/trolmastercard/velvet/dg.i Lnet/minecraft/client/Minecraft;
      // 1a5: getfield net/minecraft/client/Minecraft.field_71439_g Lnet/minecraft/client/entity/EntityPlayerSP;
      // 1a8: getfield net/minecraft/client/entity/EntityPlayerSP.field_70177_z F
      // 1ab: invokestatic com/trolmastercard/velvet/e3.b (Lnet/minecraft/util/math/Vec3d;F)Lnet/minecraft/util/math/Vec3d;
      // 1ae: astore 13
      // 1b0: getstatic com/trolmastercard/velvet/dg.i Lnet/minecraft/client/Minecraft;
      // 1b3: getfield net/minecraft/client/Minecraft.field_71439_g Lnet/minecraft/client/entity/EntityPlayerSP;
      // 1b6: getfield net/minecraft/client/entity/EntityPlayerSP.field_70125_A F
      // 1b9: aload 13
      // 1bb: getfield net/minecraft/util/math/Vec3d.field_72450_a D
      // 1be: d2f
      // 1bf: fconst_0
      // 1c0: aload 13
      // 1c2: getfield net/minecraft/util/math/Vec3d.field_72449_c D
      // 1c5: d2f
      // 1c6: invokestatic net/minecraft/client/renderer/GlStateManager.func_179114_b (FFFF)V
      // 1c9: dconst_0
      // 1ca: dstore 2
      // 1cb: dconst_0
      // 1cc: dstore 4
      // 1ce: dconst_0
      // 1cf: dstore 6
      // 1d1: goto 3ff
      // 1d4: aload 0
      // 1d5: getfield com/trolmastercard/velvet/dg.B Lcom/trolmastercard/velvet/eq;
      // 1d8: invokevirtual com/trolmastercard/velvet/eq.m ()Ljava/util/UUID;
      // 1db: getstatic com/trolmastercard/velvet/dg.i Lnet/minecraft/client/Minecraft;
      // 1de: getfield net/minecraft/client/Minecraft.field_71439_g Lnet/minecraft/client/entity/EntityPlayerSP;
      // 1e1: invokevirtual net/minecraft/client/entity/EntityPlayerSP.getPersistentID ()Ljava/util/UUID;
      // 1e4: invokevirtual java/util/UUID.equals (Ljava/lang/Object;)Z
      // 1e7: ifne 3ff
      // 1ea: aload 1
      // 1eb: invokevirtual com/trolmastercard/velvet/em.h ()Z
      // 1ee: ifeq 21c
      // 1f1: goto 1f8
      // 1f4: invokestatic com/trolmastercard/velvet/dg.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 1f7: athrow
      // 1f8: aload 11
      // 1fa: ifnull 21c
      // 1fd: goto 204
      // 200: invokestatic com/trolmastercard/velvet/dg.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 203: athrow
      // 204: getstatic com/trolmastercard/velvet/dg.i Lnet/minecraft/client/Minecraft;
      // 207: getfield net/minecraft/client/Minecraft.field_71439_g Lnet/minecraft/client/entity/EntityPlayerSP;
      // 20a: invokevirtual net/minecraft/client/entity/EntityPlayerSP.getPersistentID ()Ljava/util/UUID;
      // 20d: aload 11
      // 20f: invokevirtual java/util/UUID.equals (Ljava/lang/Object;)Z
      // 212: ifeq 286
      // 215: goto 21c
      // 218: invokestatic com/trolmastercard/velvet/dg.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 21b: athrow
      // 21c: aload 11
      // 21e: ifnull 26c
      // 221: goto 228
      // 224: invokestatic com/trolmastercard/velvet/dg.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 227: athrow
      // 228: getstatic com/trolmastercard/velvet/dg.i Lnet/minecraft/client/Minecraft;
      // 22b: getfield net/minecraft/client/Minecraft.field_71439_g Lnet/minecraft/client/entity/EntityPlayerSP;
      // 22e: invokevirtual net/minecraft/client/entity/EntityPlayerSP.getPersistentID ()Ljava/util/UUID;
      // 231: aload 11
      // 233: invokevirtual java/util/UUID.equals (Ljava/lang/Object;)Z
      // 236: ifne 26c
      // 239: goto 240
      // 23c: invokestatic com/trolmastercard/velvet/dg.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 23f: athrow
      // 240: aload 1
      // 241: getfield com/trolmastercard/velvet/em.field_70170_p Lnet/minecraft/world/World;
      // 244: aload 11
      // 246: invokevirtual net/minecraft/world/World.func_152378_a (Ljava/util/UUID;)Lnet/minecraft/entity/player/EntityPlayer;
      // 249: astore 12
      // 24b: aload 12
      // 24d: ifnull 269
      // 250: aload 1
      // 251: aload 12
      // 253: getfield net/minecraft/entity/player/EntityPlayer.field_70177_z F
      // 256: putfield com/trolmastercard/velvet/em.field_70761_aq F
      // 259: aload 1
      // 25a: aload 12
      // 25c: getfield net/minecraft/entity/player/EntityPlayer.field_70177_z F
      // 25f: putfield com/trolmastercard/velvet/em.field_70760_ar F
      // 262: goto 269
      // 265: invokestatic com/trolmastercard/velvet/dg.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 268: athrow
      // 269: goto 286
      // 26c: aload 1
      // 26d: getstatic com/trolmastercard/velvet/dg.i Lnet/minecraft/client/Minecraft;
      // 270: getfield net/minecraft/client/Minecraft.field_71439_g Lnet/minecraft/client/entity/EntityPlayerSP;
      // 273: getfield net/minecraft/client/entity/EntityPlayerSP.field_70177_z F
      // 276: putfield com/trolmastercard/velvet/em.field_70761_aq F
      // 279: aload 1
      // 27a: getstatic com/trolmastercard/velvet/dg.i Lnet/minecraft/client/Minecraft;
      // 27d: getfield net/minecraft/client/Minecraft.field_71439_g Lnet/minecraft/client/entity/EntityPlayerSP;
      // 280: getfield net/minecraft/client/entity/EntityPlayerSP.field_70177_z F
      // 283: putfield com/trolmastercard/velvet/em.field_70760_ar F
      // 286: aload 1
      // 287: aload 0
      // 288: getfield com/trolmastercard/velvet/dg.B Lcom/trolmastercard/velvet/eq;
      // 28b: invokevirtual com/trolmastercard/velvet/eq.e ()Ljava/util/UUID;
      // 28e: fload 9
      // 290: invokestatic com/trolmastercard/velvet/dy.a (Lcom/trolmastercard/velvet/em;Ljava/util/UUID;F)Lnet/minecraft/util/math/Vec3d;
      // 293: astore 12
      // 295: aload 12
      // 297: getfield net/minecraft/util/math/Vec3d.field_72450_a D
      // 29a: dstore 2
      // 29b: aload 12
      // 29d: getfield net/minecraft/util/math/Vec3d.field_72448_b D
      // 2a0: dstore 4
      // 2a2: aload 12
      // 2a4: getfield net/minecraft/util/math/Vec3d.field_72449_c D
      // 2a7: dstore 6
      // 2a9: goto 3ff
      // 2ac: aload 0
      // 2ad: getfield com/trolmastercard/velvet/dg.C Z
      // 2b0: ifeq 32f
      // 2b3: fload 9
      // 2b5: invokestatic com/trolmastercard/velvet/dy.a (F)V
      // 2b8: new net/minecraft/util/math/Vec3d
      // 2bb: dup
      // 2bc: ldc_w -0.1
      // 2bf: ldc_w 0.2
      // 2c2: getstatic com/trolmastercard/velvet/dg.i Lnet/minecraft/client/Minecraft;
      // 2c5: getfield net/minecraft/client/Minecraft.field_71474_y Lnet/minecraft/client/settings/GameSettings;
      // 2c8: getfield net/minecraft/client/settings/GameSettings.field_74334_X F
      // 2cb: ldc_w 110.0
      // 2ce: fdiv
      // 2cf: invokestatic com/trolmastercard/velvet/b6.a (FFF)F
      // 2d2: f2d
      // 2d3: dconst_0
      // 2d4: dconst_0
      // 2d5: invokespecial net/minecraft/util/math/Vec3d.<init> (DDD)V
      // 2d8: astore 12
      // 2da: aload 12
      // 2dc: getstatic com/trolmastercard/velvet/dg.i Lnet/minecraft/client/Minecraft;
      // 2df: getfield net/minecraft/client/Minecraft.field_71439_g Lnet/minecraft/client/entity/EntityPlayerSP;
      // 2e2: getfield net/minecraft/client/entity/EntityPlayerSP.field_70177_z F
      // 2e5: invokestatic com/trolmastercard/velvet/e3.b (Lnet/minecraft/util/math/Vec3d;F)Lnet/minecraft/util/math/Vec3d;
      // 2e8: astore 12
      // 2ea: aload 12
      // 2ec: getfield net/minecraft/util/math/Vec3d.field_72450_a D
      // 2ef: dstore 2
      // 2f0: aload 12
      // 2f2: getfield net/minecraft/util/math/Vec3d.field_72448_b D
      // 2f5: dstore 4
      // 2f7: aload 12
      // 2f9: getfield net/minecraft/util/math/Vec3d.field_72449_c D
      // 2fc: dstore 6
      // 2fe: aload 1
      // 2ff: getstatic com/trolmastercard/velvet/dg.i Lnet/minecraft/client/Minecraft;
      // 302: getfield net/minecraft/client/Minecraft.field_71439_g Lnet/minecraft/client/entity/EntityPlayerSP;
      // 305: getfield net/minecraft/client/entity/EntityPlayerSP.field_70177_z F
      // 308: putfield com/trolmastercard/velvet/em.field_70761_aq F
      // 30b: aload 1
      // 30c: getstatic com/trolmastercard/velvet/dg.i Lnet/minecraft/client/Minecraft;
      // 30f: getfield net/minecraft/client/Minecraft.field_71439_g Lnet/minecraft/client/entity/EntityPlayerSP;
      // 312: getfield net/minecraft/client/entity/EntityPlayerSP.field_70126_B F
      // 315: putfield com/trolmastercard/velvet/em.field_70760_ar F
      // 318: getstatic com/trolmastercard/velvet/dg.i Lnet/minecraft/client/Minecraft;
      // 31b: getfield net/minecraft/client/Minecraft.field_71439_g Lnet/minecraft/client/entity/EntityPlayerSP;
      // 31e: invokevirtual net/minecraft/client/entity/EntityPlayerSP.func_70093_af ()Z
      // 321: ifeq 32c
      // 324: dload 4
      // 326: ldc2_w 0.075
      // 329: dsub
      // 32a: dstore 4
      // 32c: goto 3ff
      // 32f: aload 10
      // 331: getstatic com/trolmastercard/velvet/fp.SHOULDER_IDLE Lcom/trolmastercard/velvet/fp;
      // 334: if_acmpne 3c2
      // 337: aload 11
      // 339: ifnonnull 348
      // 33c: goto 343
      // 33f: invokestatic com/trolmastercard/velvet/dg.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 342: athrow
      // 343: return
      // 344: invokestatic com/trolmastercard/velvet/dg.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 347: athrow
      // 348: getstatic com/trolmastercard/velvet/dg.i Lnet/minecraft/client/Minecraft;
      // 34b: getfield net/minecraft/client/Minecraft.field_71439_g Lnet/minecraft/client/entity/EntityPlayerSP;
      // 34e: invokevirtual net/minecraft/client/entity/EntityPlayerSP.getPersistentID ()Ljava/util/UUID;
      // 351: aload 11
      // 353: invokevirtual java/util/UUID.equals (Ljava/lang/Object;)Z
      // 356: ifeq 371
      // 359: getstatic com/trolmastercard/velvet/dg.i Lnet/minecraft/client/Minecraft;
      // 35c: getfield net/minecraft/client/Minecraft.field_71474_y Lnet/minecraft/client/settings/GameSettings;
      // 35f: getfield net/minecraft/client/settings/GameSettings.field_74320_O I
      // 362: ifne 371
      // 365: goto 36c
      // 368: invokestatic com/trolmastercard/velvet/dg.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 36b: athrow
      // 36c: return
      // 36d: invokestatic com/trolmastercard/velvet/dg.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 370: athrow
      // 371: aload 1
      // 372: getfield com/trolmastercard/velvet/em.field_70170_p Lnet/minecraft/world/World;
      // 375: aload 11
      // 377: invokevirtual net/minecraft/world/World.func_152378_a (Ljava/util/UUID;)Lnet/minecraft/entity/player/EntityPlayer;
      // 37a: astore 12
      // 37c: aload 12
      // 37e: ifnonnull 386
      // 381: return
      // 382: invokestatic com/trolmastercard/velvet/dg.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 385: athrow
      // 386: aload 12
      // 388: fload 9
      // 38a: invokestatic com/trolmastercard/velvet/dy.a (Lnet/minecraft/entity/player/EntityPlayer;F)Ljavax/vecmath/Vector4f;
      // 38d: astore 13
      // 38f: aload 13
      // 391: getfield javax/vecmath/Vector4f.x F
      // 394: f2d
      // 395: dstore 2
      // 396: aload 13
      // 398: getfield javax/vecmath/Vector4f.y F
      // 39b: f2d
      // 39c: dstore 4
      // 39e: aload 13
      // 3a0: getfield javax/vecmath/Vector4f.z F
      // 3a3: f2d
      // 3a4: dstore 6
      // 3a6: aload 1
      // 3a7: aload 13
      // 3a9: getfield javax/vecmath/Vector4f.w F
      // 3ac: putfield com/trolmastercard/velvet/em.field_70761_aq F
      // 3af: aload 12
      // 3b1: invokevirtual net/minecraft/entity/player/EntityPlayer.func_70093_af ()Z
      // 3b4: ifeq 3bf
      // 3b7: dload 4
      // 3b9: ldc2_w 0.32
      // 3bc: dsub
      // 3bd: dstore 4
      // 3bf: goto 3ff
      // 3c2: aload 10
      // 3c4: getstatic com/trolmastercard/velvet/fp.PICK_UP Lcom/trolmastercard/velvet/fp;
      // 3c7: if_acmpne 3ff
      // 3ca: aload 11
      // 3cc: ifnull 3ff
      // 3cf: goto 3d6
      // 3d2: invokestatic com/trolmastercard/velvet/dg.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 3d5: athrow
      // 3d6: aload 1
      // 3d7: getfield com/trolmastercard/velvet/em.field_70170_p Lnet/minecraft/world/World;
      // 3da: aload 11
      // 3dc: invokevirtual net/minecraft/world/World.func_152378_a (Ljava/util/UUID;)Lnet/minecraft/entity/player/EntityPlayer;
      // 3df: astore 12
      // 3e1: aload 12
      // 3e3: ifnull 3ff
      // 3e6: aload 1
      // 3e7: aload 12
      // 3e9: getfield net/minecraft/entity/player/EntityPlayer.field_70758_at F
      // 3ec: putfield com/trolmastercard/velvet/em.field_70760_ar F
      // 3ef: aload 1
      // 3f0: aload 12
      // 3f2: getfield net/minecraft/entity/player/EntityPlayer.field_70759_as F
      // 3f5: putfield com/trolmastercard/velvet/em.field_70761_aq F
      // 3f8: goto 3ff
      // 3fb: invokestatic com/trolmastercard/velvet/dg.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 3fe: athrow
      // 3ff: aload 0
      // 400: aload 1
      // 401: dload 2
      // 402: dload 4
      // 404: dload 6
      // 406: fload 8
      // 408: fload 9
      // 40a: invokespecial com/trolmastercard/velvet/d9.a (Lcom/trolmastercard/velvet/em;DDDFF)V
      // 40d: aload 1
      // 40e: aload 10
      // 410: invokestatic com/trolmastercard/velvet/dy.a (Lcom/trolmastercard/velvet/em;Lcom/trolmastercard/velvet/fp;)Z
      // 413: ifeq 44b
      // 416: getstatic com/trolmastercard/velvet/dg.i Lnet/minecraft/client/Minecraft;
      // 419: getfield net/minecraft/client/Minecraft.field_71474_y Lnet/minecraft/client/settings/GameSettings;
      // 41c: getfield net/minecraft/client/settings/GameSettings.field_74320_O I
      // 41f: ifne 44b
      // 422: goto 429
      // 425: invokestatic com/trolmastercard/velvet/dg.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 428: athrow
      // 429: getstatic com/trolmastercard/velvet/dg.i Lnet/minecraft/client/Minecraft;
      // 42c: getfield net/minecraft/client/Minecraft.field_71439_g Lnet/minecraft/client/entity/EntityPlayerSP;
      // 42f: invokevirtual net/minecraft/client/entity/EntityPlayerSP.getPersistentID ()Ljava/util/UUID;
      // 432: aload 11
      // 434: invokevirtual java/util/UUID.equals (Ljava/lang/Object;)Z
      // 437: ifeq 44b
      // 43a: goto 441
      // 43d: invokestatic com/trolmastercard/velvet/dg.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 440: athrow
      // 441: invokestatic net/minecraft/client/renderer/GlStateManager.func_179121_F ()V
      // 444: goto 44b
      // 447: invokestatic com/trolmastercard/velvet/dg.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 44a: athrow
      // 44b: return
      // try (0 -> 16): 17 java/lang/RuntimeException
      // try (12 -> 21): 21 java/lang/RuntimeException
      // try (24 -> 34): 35 java/lang/RuntimeException
      // try (30 -> 39): 39 java/lang/RuntimeException
      // try (76 -> 82): 83 java/lang/RuntimeException
      // try (79 -> 89): 90 java/lang/RuntimeException
      // try (85 -> 96): 97 java/lang/RuntimeException
      // try (92 -> 102): 103 java/lang/RuntimeException
      // try (99 -> 106): 106 java/lang/RuntimeException
      // try (121 -> 131): 132 java/lang/RuntimeException
      // try (125 -> 138): 139 java/lang/RuntimeException
      // try (134 -> 142): 142 java/lang/RuntimeException
      // try (209 -> 220): 221 java/lang/RuntimeException
      // try (217 -> 225): 226 java/lang/RuntimeException
      // try (223 -> 234): 235 java/lang/RuntimeException
      // try (228 -> 239): 240 java/lang/RuntimeException
      // try (237 -> 248): 249 java/lang/RuntimeException
      // try (256 -> 266): 267 java/lang/RuntimeException
      // try (351 -> 356): 357 java/lang/RuntimeException
      // try (354 -> 360): 360 java/lang/RuntimeException
      // try (362 -> 372): 373 java/lang/RuntimeException
      // try (368 -> 376): 376 java/lang/RuntimeException
      // try (383 -> 386): 386 java/lang/RuntimeException
      // try (416 -> 421): 422 java/lang/RuntimeException
      // try (429 -> 439): 440 java/lang/RuntimeException
      // try (442 -> 458): 459 java/lang/RuntimeException
      // try (454 -> 467): 468 java/lang/RuntimeException
      // try (461 -> 471): 472 java/lang/RuntimeException
   }

   @Override
   protected void b(Tessellator var1, BufferBuilder var2, em var3, f7 var4, float var5) {
      a(var1, var2, var3, var4, var5);
   }

   @Nullable
   @Override
   protected f7 e(em param1) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 000: aload 0
      // 001: getfield com/trolmastercard/velvet/dg.D Z
      // 004: ifne 00d
      // 007: aconst_null
      // 008: areturn
      // 009: invokestatic com/trolmastercard/velvet/dg.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 00c: athrow
      // 00d: aload 1
      // 00e: instanceof com/trolmastercard/velvet/eq
      // 011: ifne 01a
      // 014: aconst_null
      // 015: areturn
      // 016: invokestatic com/trolmastercard/velvet/dg.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 019: athrow
      // 01a: aload 1
      // 01b: checkcast com/trolmastercard/velvet/eq
      // 01e: astore 2
      // 01f: aload 2
      // 020: invokevirtual com/trolmastercard/velvet/eq.m ()Ljava/util/UUID;
      // 023: astore 3
      // 024: getstatic com/trolmastercard/velvet/dg.i Lnet/minecraft/client/Minecraft;
      // 027: getfield net/minecraft/client/Minecraft.field_71439_g Lnet/minecraft/client/entity/EntityPlayerSP;
      // 02a: astore 4
      // 02c: aload 3
      // 02d: ifnull 056
      // 030: getstatic com/trolmastercard/velvet/dg.i Lnet/minecraft/client/Minecraft;
      // 033: getfield net/minecraft/client/Minecraft.field_71474_y Lnet/minecraft/client/settings/GameSettings;
      // 036: getfield net/minecraft/client/settings/GameSettings.field_74320_O I
      // 039: ifne 05c
      // 03c: goto 043
      // 03f: invokestatic com/trolmastercard/velvet/dg.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 042: athrow
      // 043: aload 4
      // 045: invokevirtual net/minecraft/entity/player/EntityPlayer.getPersistentID ()Ljava/util/UUID;
      // 048: aload 3
      // 049: invokevirtual java/util/UUID.equals (Ljava/lang/Object;)Z
      // 04c: ifeq 05c
      // 04f: goto 056
      // 052: invokestatic com/trolmastercard/velvet/dg.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 055: athrow
      // 056: aconst_null
      // 057: areturn
      // 058: invokestatic com/trolmastercard/velvet/dg.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 05b: athrow
      // 05c: aload 2
      // 05d: invokevirtual com/trolmastercard/velvet/eq.k ()Lnet/minecraft/entity/player/EntityPlayer;
      // 060: astore 5
      // 062: aload 5
      // 064: ifnonnull 06d
      // 067: aconst_null
      // 068: areturn
      // 069: invokestatic com/trolmastercard/velvet/dg.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 06c: athrow
      // 06d: aload 2
      // 06e: invokevirtual com/trolmastercard/velvet/eq.func_184212_Q ()Lnet/minecraft/network/datasync/EntityDataManager;
      // 071: getstatic com/trolmastercard/velvet/e2.T Lnet/minecraft/network/datasync/DataParameter;
      // 074: invokevirtual net/minecraft/network/datasync/EntityDataManager.func_187225_a (Lnet/minecraft/network/datasync/DataParameter;)Ljava/lang/Object;
      // 077: checkcast net/minecraft/item/ItemStack
      // 07a: astore 6
      // 07c: aload 6
      // 07e: invokevirtual net/minecraft/item/ItemStack.func_190926_b ()Z
      // 081: ifeq 08a
      // 084: aconst_null
      // 085: areturn
      // 086: invokestatic com/trolmastercard/velvet/dg.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 089: athrow
      // 08a: aload 6
      // 08c: invokevirtual net/minecraft/item/ItemStack.func_77973_b ()Lnet/minecraft/item/Item;
      // 08f: instanceof net/minecraft/item/ItemArmor
      // 092: ifne 09b
      // 095: aconst_null
      // 096: areturn
      // 097: invokestatic com/trolmastercard/velvet/dg.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 09a: athrow
      // 09b: aload 6
      // 09d: invokevirtual net/minecraft/item/ItemStack.func_77973_b ()Lnet/minecraft/item/Item;
      // 0a0: checkcast net/minecraft/item/ItemArmor
      // 0a3: astore 7
      // 0a5: getstatic com/trolmastercard/velvet/dg$b.a [I
      // 0a8: aload 7
      // 0aa: invokevirtual net/minecraft/item/ItemArmor.func_82812_d ()Lnet/minecraft/item/ItemArmor$ArmorMaterial;
      // 0ad: invokevirtual net/minecraft/item/ItemArmor$ArmorMaterial.ordinal ()I
      // 0b0: iaload
      // 0b1: tableswitch 35 1 5 56 73 73 90 35
      // 0d4: new com/trolmastercard/velvet/f7
      // 0d7: dup
      // 0d8: ldc_w 23.0
      // 0db: ldc_w 100.0
      // 0de: ldc_w 93.0
      // 0e1: invokespecial com/trolmastercard/velvet/f7.<init> (FFF)V
      // 0e4: areturn
      // 0e5: invokestatic com/trolmastercard/velvet/dg.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 0e8: athrow
      // 0e9: new com/trolmastercard/velvet/f7
      // 0ec: dup
      // 0ed: ldc_w 99.0
      // 0f0: ldc_w 98.0
      // 0f3: ldc_w 14.0
      // 0f6: invokespecial com/trolmastercard/velvet/f7.<init> (FFF)V
      // 0f9: areturn
      // 0fa: new com/trolmastercard/velvet/f7
      // 0fd: dup
      // 0fe: ldc_w 85.0
      // 101: ldc_w 85.0
      // 104: ldc_w 85.0
      // 107: invokespecial com/trolmastercard/velvet/f7.<init> (FFF)V
      // 10a: areturn
      // 10b: aload 7
      // 10d: aload 6
      // 10f: invokevirtual net/minecraft/item/ItemArmor.func_82814_b (Lnet/minecraft/item/ItemStack;)I
      // 112: istore 8
      // 114: iload 8
      // 116: bipush 16
      // 118: ishr
      // 119: sipush 255
      // 11c: iand
      // 11d: i2f
      // 11e: fstore 9
      // 120: iload 8
      // 122: bipush 8
      // 124: ishr
      // 125: sipush 255
      // 128: iand
      // 129: i2f
      // 12a: fstore 10
      // 12c: iload 8
      // 12e: sipush 255
      // 131: iand
      // 132: i2f
      // 133: fstore 11
      // 135: new com/trolmastercard/velvet/f7
      // 138: dup
      // 139: fload 9
      // 13b: fload 10
      // 13d: fload 11
      // 13f: invokespecial com/trolmastercard/velvet/f7.<init> (FFF)V
      // 142: areturn
      // try (0 -> 5): 5 java/lang/RuntimeException
      // try (7 -> 12): 12 java/lang/RuntimeException
      // try (23 -> 29): 30 java/lang/RuntimeException
      // try (25 -> 37): 38 java/lang/RuntimeException
      // try (32 -> 42): 42 java/lang/RuntimeException
      // try (47 -> 51): 51 java/lang/RuntimeException
      // try (59 -> 64): 64 java/lang/RuntimeException
      // try (66 -> 72): 72 java/lang/RuntimeException
      // try (78 -> 91): 91 java/lang/RuntimeException
   }

   @Override
   protected void c() {
      GlStateManager.func_179137_b(0.0, -0.77, -0.05);
      GlStateManager.func_179139_a(0.5, 0.5, 0.5);
   }

   @Override
   protected void a(boolean param1, ItemStack param2) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 00: aload 0
      // 01: iload 1
      // 02: aload 2
      // 03: invokespecial com/trolmastercard/velvet/d9.a (ZLnet/minecraft/item/ItemStack;)V
      // 06: aload 2
      // 07: invokevirtual net/minecraft/item/ItemStack.func_77973_b ()Lnet/minecraft/item/Item;
      // 0a: aload 2
      // 0b: invokevirtual net/minecraft/item/Item.func_77661_b (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/EnumAction;
      // 0e: getstatic net/minecraft/item/EnumAction.BOW Lnet/minecraft/item/EnumAction;
      // 11: if_acmpne 41
      // 14: iload 1
      // 15: ifeq 37
      // 18: goto 1f
      // 1b: invokestatic com/trolmastercard/velvet/dg.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 1e: athrow
      // 1f: ldc_w 0.1
      // 22: fconst_0
      // 23: fconst_0
      // 24: invokestatic net/minecraft/client/renderer/GlStateManager.func_179109_b (FFF)V
      // 27: ldc_w 90.0
      // 2a: fconst_1
      // 2b: fconst_0
      // 2c: fconst_0
      // 2d: invokestatic net/minecraft/client/renderer/GlStateManager.func_179114_b (FFFF)V
      // 30: goto 40
      // 33: invokestatic com/trolmastercard/velvet/dg.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 36: athrow
      // 37: ldc_w 170.0
      // 3a: fconst_1
      // 3b: fconst_0
      // 3c: fconst_0
      // 3d: invokestatic net/minecraft/client/renderer/GlStateManager.func_179114_b (FFFF)V
      // 40: return
      // 41: iload 1
      // 42: ifeq 4f
      // 45: ldc_w 70.0
      // 48: goto 52
      // 4b: invokestatic com/trolmastercard/velvet/dg.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 4e: athrow
      // 4f: ldc_w 180.0
      // 52: fconst_1
      // 53: fconst_0
      // 54: fconst_0
      // 55: invokestatic net/minecraft/client/renderer/GlStateManager.func_179114_b (FFFF)V
      // 58: dconst_0
      // 59: ldc2_w 0.05
      // 5c: ldc2_w -0.03
      // 5f: invokestatic net/minecraft/client/renderer/GlStateManager.func_179137_b (DDD)V
      // 62: return
      // try (0 -> 12): 13 java/lang/RuntimeException
      // try (10 -> 25): 25 java/lang/RuntimeException
      // try (33 -> 37): 37 java/lang/RuntimeException
   }

   @Override
   protected void a(boolean var1) {
   }

   @Override
   protected void a(boolean param1, boolean param2) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 00: aload 0
      // 01: iload 1
      // 02: iload 2
      // 03: invokespecial com/trolmastercard/velvet/d9.a (ZZ)V
      // 06: iload 1
      // 07: ifeq 57
      // 0a: iload 2
      // 0b: ifeq 41
      // 0e: goto 15
      // 11: invokestatic com/trolmastercard/velvet/dg.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 14: athrow
      // 15: dconst_0
      // 16: ldc2_w 0.2
      // 19: ldc2_w -0.25
      // 1c: invokestatic net/minecraft/client/renderer/GlStateManager.func_179137_b (DDD)V
      // 1f: ldc_w 85.0
      // 22: fconst_0
      // 23: fconst_1
      // 24: fconst_0
      // 25: invokestatic net/minecraft/client/renderer/GlStateManager.func_179114_b (FFFF)V
      // 28: ldc_w 38.0
      // 2b: fconst_1
      // 2c: fconst_0
      // 2d: fconst_0
      // 2e: invokestatic net/minecraft/client/renderer/GlStateManager.func_179114_b (FFFF)V
      // 31: ldc_w 90.0
      // 34: fconst_0
      // 35: fconst_0
      // 36: fconst_1
      // 37: invokestatic net/minecraft/client/renderer/GlStateManager.func_179114_b (FFFF)V
      // 3a: goto 8f
      // 3d: invokestatic com/trolmastercard/velvet/dg.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 40: athrow
      // 41: ldc_w 90.0
      // 44: fconst_1
      // 45: fconst_0
      // 46: fconst_0
      // 47: invokestatic net/minecraft/client/renderer/GlStateManager.func_179114_b (FFFF)V
      // 4a: dconst_0
      // 4b: ldc2_w -0.265
      // 4e: ldc2_w -0.04
      // 51: invokestatic net/minecraft/client/renderer/GlStateManager.func_179137_b (DDD)V
      // 54: goto 8f
      // 57: iload 2
      // 58: ifeq 83
      // 5b: fconst_0
      // 5c: fconst_1
      // 5d: fconst_0
      // 5e: fconst_0
      // 5f: invokestatic net/minecraft/client/renderer/GlStateManager.func_179114_b (FFFF)V
      // 62: ldc_w 150.0
      // 65: fconst_0
      // 66: fconst_1
      // 67: fconst_0
      // 68: invokestatic net/minecraft/client/renderer/GlStateManager.func_179114_b (FFFF)V
      // 6b: fconst_0
      // 6c: fconst_0
      // 6d: fconst_0
      // 6e: fconst_1
      // 6f: invokestatic net/minecraft/client/renderer/GlStateManager.func_179114_b (FFFF)V
      // 72: dconst_0
      // 73: ldc2_w -0.33
      // 76: ldc2_w -0.1
      // 79: invokestatic net/minecraft/client/renderer/GlStateManager.func_179137_b (DDD)V
      // 7c: goto 8f
      // 7f: invokestatic com/trolmastercard/velvet/dg.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 82: athrow
      // 83: ldc2_w -0.02
      // 86: ldc2_w -0.05
      // 89: ldc2_w -0.05
      // 8c: invokestatic net/minecraft/client/renderer/GlStateManager.func_179137_b (DDD)V
      // 8f: return
      // try (0 -> 8): 9 java/lang/RuntimeException
      // try (6 -> 31): 31 java/lang/RuntimeException
      // try (43 -> 65): 65 java/lang/RuntimeException
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }
}
