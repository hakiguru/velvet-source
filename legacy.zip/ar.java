package org.velvet;

import net.minecraft.util.math.Vec3d;

@FunctionalInterface
public interface ar {
   Vec3d a(em var1);
}
