package org.velvet;

import java.util.ArrayList;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.IEntityLivingData;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.entity.ai.EntityMoveHelper;
import net.minecraft.entity.ai.EntityMoveHelper.Action;
import net.minecraft.init.Items;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.Item;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.pathfinding.PathNavigateGround;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.datafix.DataFixer;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.World;
import net.minecraft.world.storage.loot.LootTableList;

public class ay extends EntityLiving {
   public static int b = 8400;
   public static List<ay> g = new ArrayList<>();
   private static final DataParameter<Integer> d = EntityDataManager.func_187226_a(ay.class, DataSerializers.field_187192_b).func_187156_b().func_187161_a(111);
   private static final DataParameter<Integer> c = EntityDataManager.func_187226_a(ay.class, DataSerializers.field_187192_b).func_187156_b().func_187161_a(110);
   public float a;
   public float e;
   public float h;
   private boolean f;

   public ay(World var1) {
      super(var1);
      this.field_70765_h = new ay.b(this);
   }

   protected void func_184651_r() {
      this.field_70714_bg.func_75776_a(1, new ay.d(this));
      this.field_70714_bg.func_75776_a(5, new ay.c(this));
   }

   protected void func_70088_a() {
      super.func_70088_a();
      this.field_70180_af.func_187214_a(c, 1);
      this.field_70180_af.func_187214_a(d, 0);
   }

   public void func_180430_e(float var1, float var2) {
   }

   protected boolean func_70692_ba() {
      return false;
   }

   protected void a(int var1, boolean var2) {
      try {
         this.field_70180_af.func_187227_b(c, var1);
         this.func_70105_a(0.51000005F * var1, 0.51000005F * var1);
         this.func_70107_b(this.field_70165_t, this.field_70163_u, this.field_70161_v);
         this.func_110148_a(SharedMonsterAttributes.field_111267_a).func_111128_a(var1 * var1);
         this.func_110148_a(SharedMonsterAttributes.field_111263_d).func_111128_a(0.2F + 0.1F * var1);
         if (var2) {
            this.func_70606_j(this.func_110138_aP());
         }
      } catch (RuntimeException var3) {
         throw a(var3);
      }

      this.field_70728_aV = var1;
   }

   public int h() {
      return (Integer)this.field_70180_af.func_187225_a(c);
   }

   public static void a(DataFixer var0) {
      EntityLiving.func_189752_a(var0, ay.class);
   }

   public void func_70014_b(NBTTagCompound var1) {
      super.func_70014_b(var1);
      var1.func_74768_a("Size", this.h() - 1);
      var1.func_74757_a("wasOnGround", this.f);
      var1.func_74768_a("ageInTicks", (Integer)this.field_70180_af.func_187225_a(d));
   }

   public void func_70037_a(NBTTagCompound var1) {
      super.func_70037_a(var1);
      int var2 = var1.func_74762_e("Size");
      if (var2 < 0) {
         var2 = 0;
      }

      this.a(var2 + 1, false);
      this.f = var1.func_74767_n("wasOnGround");
      this.field_70180_af.func_187227_b(d, var1.func_74762_e("ageInTicks"));
   }

   public boolean j() {
      try {
         if (this.h() <= 1) {
            return true;
         }
      } catch (RuntimeException var1) {
         throw a(var1);
      }

      return false;
   }

   protected EnumParticleTypes g() {
      return EnumParticleTypes.SLIME;
   }

   public static ArrayList<ay> a(Vec3d var0) {
      ArrayList var1 = a(var0, 0.1);
      if (var1.isEmpty()) {
         var1 = a(var0, 0.5);
      }

      return var1;
   }

   private static ArrayList<ay> a(Vec3d param0, double param1) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 00: new java/util/ArrayList
      // 03: dup
      // 04: invokespecial java/util/ArrayList.<init> ()V
      // 07: astore 3
      // 08: getstatic com/trolmastercard/velvet/ay.g Ljava/util/List;
      // 0b: invokeinterface java/util/List.iterator ()Ljava/util/Iterator; 1
      // 10: astore 4
      // 12: aload 4
      // 14: invokeinterface java/util/Iterator.hasNext ()Z 1
      // 19: ifeq 86
      // 1c: aload 4
      // 1e: invokeinterface java/util/Iterator.next ()Ljava/lang/Object; 1
      // 23: checkcast com/trolmastercard/velvet/ay
      // 26: astore 5
      // 28: aload 5
      // 2a: ifnonnull 34
      // 2d: goto 12
      // 30: invokestatic com/trolmastercard/velvet/ay.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 33: athrow
      // 34: aload 5
      // 36: getfield com/trolmastercard/velvet/ay.field_70169_q D
      // 39: aload 0
      // 3a: getfield net/minecraft/util/math/Vec3d.field_72450_a D
      // 3d: dsub
      // 3e: invokestatic java/lang/Math.abs (D)D
      // 41: aload 5
      // 43: getfield com/trolmastercard/velvet/ay.field_70167_r D
      // 46: aload 0
      // 47: getfield net/minecraft/util/math/Vec3d.field_72448_b D
      // 4a: dsub
      // 4b: invokestatic java/lang/Math.abs (D)D
      // 4e: dadd
      // 4f: aload 5
      // 51: getfield com/trolmastercard/velvet/ay.field_70166_s D
      // 54: aload 0
      // 55: getfield net/minecraft/util/math/Vec3d.field_72449_c D
      // 58: dsub
      // 59: invokestatic java/lang/Math.abs (D)D
      // 5c: dadd
      // 5d: dstore 6
      // 5f: aload 5
      // 61: getfield com/trolmastercard/velvet/ay.field_70170_p Lnet/minecraft/world/World;
      // 64: ifnull 83
      // 67: dload 6
      // 69: dload 1
      // 6a: dcmpg
      // 6b: ifge 83
      // 6e: goto 75
      // 71: invokestatic com/trolmastercard/velvet/ay.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 74: athrow
      // 75: aload 3
      // 76: aload 5
      // 78: invokevirtual java/util/ArrayList.add (Ljava/lang/Object;)Z
      // 7b: pop
      // 7c: goto 83
      // 7f: invokestatic com/trolmastercard/velvet/ay.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 82: athrow
      // 83: goto 12
      // 86: goto a5
      // 89: astore 4
      // 8b: getstatic java/lang/System.out Ljava/io/PrintStream;
      // 8e: new java/lang/StringBuilder
      // 91: dup
      // 92: invokespecial java/lang/StringBuilder.<init> ()V
      // 95: ldc_w "couldnt find slimes at distance "
      // 98: invokevirtual java/lang/StringBuilder.append (Ljava/lang/String;)Ljava/lang/StringBuilder;
      // 9b: dload 1
      // 9c: invokevirtual java/lang/StringBuilder.append (D)Ljava/lang/StringBuilder;
      // 9f: invokevirtual java/lang/StringBuilder.toString ()Ljava/lang/String;
      // a2: invokevirtual java/io/PrintStream.println (Ljava/lang/String;)V
      // a5: aload 3
      // a6: areturn
      // try (43 -> 54): 55 java/lang/Exception
      // try (40 -> 47): 48 java/lang/Exception
      // try (14 -> 17): 17 java/lang/Exception
      // try (4 -> 58): 59 java/lang/Exception
   }

   public Vec3d e() {
      return new Vec3d(this.field_70169_q, this.field_70167_r, this.field_70166_s);
   }

   void a(EnumParticleTypes var1) {
      double var2 = r.f.nextGaussian() * 0.02;
      double var4 = r.f.nextGaussian() * 0.02;
      double var6 = r.f.nextGaussian() * 0.02;
      this.field_70170_p
         .func_175688_a(
            var1,
            this.field_70165_t + r.f.nextFloat() * this.field_70130_N * 2.0F - this.field_70130_N,
            this.field_70163_u + 0.15 + r.f.nextFloat() * this.field_70131_O,
            this.field_70161_v + r.f.nextFloat() * this.field_70130_N * 2.0F - this.field_70130_N,
            var2,
            var4,
            var6,
            new int[0]
         );
   }

   public void func_70071_h_() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 000: aload 0
      // 001: getfield com/trolmastercard/velvet/ay.field_70180_af Lnet/minecraft/network/datasync/EntityDataManager;
      // 004: getstatic com/trolmastercard/velvet/ay.d Lnet/minecraft/network/datasync/DataParameter;
      // 007: aload 0
      // 008: getfield com/trolmastercard/velvet/ay.field_70180_af Lnet/minecraft/network/datasync/EntityDataManager;
      // 00b: getstatic com/trolmastercard/velvet/ay.d Lnet/minecraft/network/datasync/DataParameter;
      // 00e: invokevirtual net/minecraft/network/datasync/EntityDataManager.func_187225_a (Lnet/minecraft/network/datasync/DataParameter;)Ljava/lang/Object;
      // 011: checkcast java/lang/Integer
      // 014: invokevirtual java/lang/Integer.intValue ()I
      // 017: bipush 1
      // 018: iadd
      // 019: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 01c: invokevirtual net/minecraft/network/datasync/EntityDataManager.func_187227_b (Lnet/minecraft/network/datasync/DataParameter;Ljava/lang/Object;)V
      // 01f: aload 0
      // 020: getfield com/trolmastercard/velvet/ay.field_70170_p Lnet/minecraft/world/World;
      // 023: getfield net/minecraft/world/World.field_72995_K Z
      // 026: ifeq 097
      // 029: aload 0
      // 02a: getfield com/trolmastercard/velvet/ay.field_70180_af Lnet/minecraft/network/datasync/EntityDataManager;
      // 02d: getstatic com/trolmastercard/velvet/ay.d Lnet/minecraft/network/datasync/DataParameter;
      // 030: invokevirtual net/minecraft/network/datasync/EntityDataManager.func_187225_a (Lnet/minecraft/network/datasync/DataParameter;)Ljava/lang/Object;
      // 033: checkcast java/lang/Integer
      // 036: invokevirtual java/lang/Integer.intValue ()I
      // 039: i2d
      // 03a: getstatic com/trolmastercard/velvet/ay.b I
      // 03d: i2d
      // 03e: ldc2_w 0.95
      // 041: dmul
      // 042: dcmpl
      // 043: ifle 05b
      // 046: goto 04d
      // 049: invokestatic com/trolmastercard/velvet/ay.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 04c: athrow
      // 04d: aload 0
      // 04e: getstatic net/minecraft/util/EnumParticleTypes.CLOUD Lnet/minecraft/util/EnumParticleTypes;
      // 051: invokevirtual com/trolmastercard/velvet/ay.a (Lnet/minecraft/util/EnumParticleTypes;)V
      // 054: goto 0e9
      // 057: invokestatic com/trolmastercard/velvet/ay.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 05a: athrow
      // 05b: aload 0
      // 05c: getfield com/trolmastercard/velvet/ay.field_70180_af Lnet/minecraft/network/datasync/EntityDataManager;
      // 05f: getstatic com/trolmastercard/velvet/ay.d Lnet/minecraft/network/datasync/DataParameter;
      // 062: invokevirtual net/minecraft/network/datasync/EntityDataManager.func_187225_a (Lnet/minecraft/network/datasync/DataParameter;)Ljava/lang/Object;
      // 065: checkcast java/lang/Integer
      // 068: invokevirtual java/lang/Integer.intValue ()I
      // 06b: i2d
      // 06c: getstatic com/trolmastercard/velvet/ay.b I
      // 06f: i2d
      // 070: ldc2_w 0.7
      // 073: dmul
      // 074: dcmpl
      // 075: ifle 0e9
      // 078: aload 0
      // 079: getfield com/trolmastercard/velvet/ay.field_70173_aa I
      // 07c: bipush 10
      // 07e: irem
      // 07f: ifne 0e9
      // 082: goto 089
      // 085: invokestatic com/trolmastercard/velvet/ay.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 088: athrow
      // 089: aload 0
      // 08a: getstatic net/minecraft/util/EnumParticleTypes.VILLAGER_HAPPY Lnet/minecraft/util/EnumParticleTypes;
      // 08d: invokevirtual com/trolmastercard/velvet/ay.a (Lnet/minecraft/util/EnumParticleTypes;)V
      // 090: goto 0e9
      // 093: invokestatic com/trolmastercard/velvet/ay.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 096: athrow
      // 097: aload 0
      // 098: getfield com/trolmastercard/velvet/ay.field_70180_af Lnet/minecraft/network/datasync/EntityDataManager;
      // 09b: getstatic com/trolmastercard/velvet/ay.d Lnet/minecraft/network/datasync/DataParameter;
      // 09e: invokevirtual net/minecraft/network/datasync/EntityDataManager.func_187225_a (Lnet/minecraft/network/datasync/DataParameter;)Ljava/lang/Object;
      // 0a1: checkcast java/lang/Integer
      // 0a4: invokevirtual java/lang/Integer.intValue ()I
      // 0a7: getstatic com/trolmastercard/velvet/ay.b I
      // 0aa: if_icmple 0e9
      // 0ad: new com/trolmastercard/velvet/fn
      // 0b0: dup
      // 0b1: aload 0
      // 0b2: getfield com/trolmastercard/velvet/ay.field_70170_p Lnet/minecraft/world/World;
      // 0b5: invokespecial com/trolmastercard/velvet/fn.<init> (Lnet/minecraft/world/World;)V
      // 0b8: astore 1
      // 0b9: aload 1
      // 0ba: aload 0
      // 0bb: getfield com/trolmastercard/velvet/ay.field_70165_t D
      // 0be: aload 0
      // 0bf: getfield com/trolmastercard/velvet/ay.field_70163_u D
      // 0c2: aload 0
      // 0c3: getfield com/trolmastercard/velvet/ay.field_70161_v D
      // 0c6: aload 0
      // 0c7: getfield com/trolmastercard/velvet/ay.field_70177_z F
      // 0ca: aload 0
      // 0cb: getfield com/trolmastercard/velvet/ay.field_70125_A F
      // 0ce: invokevirtual com/trolmastercard/velvet/fn.func_70080_a (DDDFF)V
      // 0d1: aload 0
      // 0d2: getfield com/trolmastercard/velvet/ay.field_70170_p Lnet/minecraft/world/World;
      // 0d5: aload 1
      // 0d6: invokevirtual net/minecraft/world/World.func_72838_d (Lnet/minecraft/entity/Entity;)Z
      // 0d9: pop
      // 0da: aload 1
      // 0db: getstatic net/minecraft/init/SoundEvents.field_187604_bf Lnet/minecraft/util/SoundEvent;
      // 0de: invokevirtual com/trolmastercard/velvet/fn.a (Lnet/minecraft/util/SoundEvent;)V
      // 0e1: aload 0
      // 0e2: getfield com/trolmastercard/velvet/ay.field_70170_p Lnet/minecraft/world/World;
      // 0e5: aload 0
      // 0e6: invokevirtual net/minecraft/world/World.func_72900_e (Lnet/minecraft/entity/Entity;)V
      // 0e9: aload 0
      // 0ea: dup
      // 0eb: getfield com/trolmastercard/velvet/ay.e F
      // 0ee: aload 0
      // 0ef: getfield com/trolmastercard/velvet/ay.a F
      // 0f2: aload 0
      // 0f3: getfield com/trolmastercard/velvet/ay.e F
      // 0f6: fsub
      // 0f7: ldc_w 0.5
      // 0fa: fmul
      // 0fb: fadd
      // 0fc: putfield com/trolmastercard/velvet/ay.e F
      // 0ff: aload 0
      // 100: aload 0
      // 101: getfield com/trolmastercard/velvet/ay.e F
      // 104: putfield com/trolmastercard/velvet/ay.h F
      // 107: aload 0
      // 108: invokespecial net/minecraft/entity/EntityLiving.func_70071_h_ ()V
      // 10b: aload 0
      // 10c: getfield com/trolmastercard/velvet/ay.field_70122_E Z
      // 10f: ifeq 1e1
      // 112: aload 0
      // 113: getfield com/trolmastercard/velvet/ay.f Z
      // 116: ifne 1e1
      // 119: goto 120
      // 11c: invokestatic com/trolmastercard/velvet/ay.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 11f: athrow
      // 120: aload 0
      // 121: invokevirtual com/trolmastercard/velvet/ay.h ()I
      // 124: istore 1
      // 125: aload 0
      // 126: invokevirtual com/trolmastercard/velvet/ay.k ()Z
      // 129: ifeq 12e
      // 12c: bipush 0
      // 12d: istore 1
      // 12e: bipush 0
      // 12f: istore 2
      // 130: iload 2
      // 131: iload 1
      // 132: bipush 8
      // 134: imul
      // 135: if_icmpge 1b3
      // 138: aload 0
      // 139: getfield com/trolmastercard/velvet/ay.field_70146_Z Ljava/util/Random;
      // 13c: invokevirtual java/util/Random.nextFloat ()F
      // 13f: ldc_w 6.2831855
      // 142: fmul
      // 143: fstore 3
      // 144: aload 0
      // 145: getfield com/trolmastercard/velvet/ay.field_70146_Z Ljava/util/Random;
      // 148: invokevirtual java/util/Random.nextFloat ()F
      // 14b: ldc_w 0.5
      // 14e: fmul
      // 14f: ldc_w 0.5
      // 152: fadd
      // 153: fstore 4
      // 155: fload 3
      // 156: invokestatic net/minecraft/util/math/MathHelper.func_76126_a (F)F
      // 159: iload 1
      // 15a: i2f
      // 15b: fmul
      // 15c: ldc_w 0.5
      // 15f: fmul
      // 160: fload 4
      // 162: fmul
      // 163: fstore 5
      // 165: fload 3
      // 166: invokestatic net/minecraft/util/math/MathHelper.func_76134_b (F)F
      // 169: iload 1
      // 16a: i2f
      // 16b: fmul
      // 16c: ldc_w 0.5
      // 16f: fmul
      // 170: fload 4
      // 172: fmul
      // 173: fstore 6
      // 175: aload 0
      // 176: getfield com/trolmastercard/velvet/ay.field_70170_p Lnet/minecraft/world/World;
      // 179: astore 7
      // 17b: aload 0
      // 17c: invokevirtual com/trolmastercard/velvet/ay.g ()Lnet/minecraft/util/EnumParticleTypes;
      // 17f: astore 8
      // 181: aload 0
      // 182: getfield com/trolmastercard/velvet/ay.field_70165_t D
      // 185: fload 5
      // 187: f2d
      // 188: dadd
      // 189: dstore 9
      // 18b: aload 0
      // 18c: getfield com/trolmastercard/velvet/ay.field_70161_v D
      // 18f: fload 6
      // 191: f2d
      // 192: dadd
      // 193: dstore 11
      // 195: aload 7
      // 197: aload 8
      // 199: dload 9
      // 19b: aload 0
      // 19c: invokevirtual com/trolmastercard/velvet/ay.func_174813_aQ ()Lnet/minecraft/util/math/AxisAlignedBB;
      // 19f: getfield net/minecraft/util/math/AxisAlignedBB.field_72338_b D
      // 1a2: dload 11
      // 1a4: dconst_0
      // 1a5: dconst_0
      // 1a6: dconst_0
      // 1a7: bipush 0
      // 1a8: newarray 10
      // 1aa: invokevirtual net/minecraft/world/World.func_175688_a (Lnet/minecraft/util/EnumParticleTypes;DDDDDD[I)V
      // 1ad: iinc 2 1
      // 1b0: goto 130
      // 1b3: aload 0
      // 1b4: aload 0
      // 1b5: invokevirtual com/trolmastercard/velvet/ay.f ()Lnet/minecraft/util/SoundEvent;
      // 1b8: aload 0
      // 1b9: invokevirtual com/trolmastercard/velvet/ay.func_70599_aP ()F
      // 1bc: aload 0
      // 1bd: getfield com/trolmastercard/velvet/ay.field_70146_Z Ljava/util/Random;
      // 1c0: invokevirtual java/util/Random.nextFloat ()F
      // 1c3: aload 0
      // 1c4: getfield com/trolmastercard/velvet/ay.field_70146_Z Ljava/util/Random;
      // 1c7: invokevirtual java/util/Random.nextFloat ()F
      // 1ca: fsub
      // 1cb: ldc 0.2
      // 1cd: fmul
      // 1ce: fconst_1
      // 1cf: fadd
      // 1d0: ldc_w 0.8
      // 1d3: fdiv
      // 1d4: invokevirtual com/trolmastercard/velvet/ay.func_184185_a (Lnet/minecraft/util/SoundEvent;FF)V
      // 1d7: aload 0
      // 1d8: ldc_w -0.5
      // 1db: putfield com/trolmastercard/velvet/ay.a F
      // 1de: goto 202
      // 1e1: aload 0
      // 1e2: getfield com/trolmastercard/velvet/ay.field_70122_E Z
      // 1e5: ifne 202
      // 1e8: aload 0
      // 1e9: getfield com/trolmastercard/velvet/ay.f Z
      // 1ec: ifeq 202
      // 1ef: goto 1f6
      // 1f2: invokestatic com/trolmastercard/velvet/ay.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 1f5: athrow
      // 1f6: aload 0
      // 1f7: fconst_1
      // 1f8: putfield com/trolmastercard/velvet/ay.a F
      // 1fb: goto 202
      // 1fe: invokestatic com/trolmastercard/velvet/ay.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 201: athrow
      // 202: aload 0
      // 203: aload 0
      // 204: getfield com/trolmastercard/velvet/ay.field_70122_E Z
      // 207: putfield com/trolmastercard/velvet/ay.f Z
      // 20a: aload 0
      // 20b: invokevirtual com/trolmastercard/velvet/ay.b ()V
      // 20e: return
      // try (0 -> 30): 31 java/lang/RuntimeException
      // try (17 -> 37): 37 java/lang/RuntimeException
      // try (39 -> 57): 58 java/lang/RuntimeException
      // try (52 -> 64): 64 java/lang/RuntimeException
      // try (104 -> 128): 129 java/lang/RuntimeException
      // try (236 -> 242): 243 java/lang/RuntimeException
      // try (239 -> 248): 249 java/lang/RuntimeException
   }

   protected void b() {
      this.a *= 0.6F;
   }

   protected int a() {
      return this.field_70146_Z.nextInt(100) + 50;
   }

   protected ay d() {
      return new ay(this.field_70170_p);
   }

   public void func_184206_a(DataParameter<?> param1) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 00: getstatic com/trolmastercard/velvet/ay.c Lnet/minecraft/network/datasync/DataParameter;
      // 03: aload 1
      // 04: invokevirtual net/minecraft/network/datasync/DataParameter.equals (Ljava/lang/Object;)Z
      // 07: ifeq 52
      // 0a: aload 0
      // 0b: invokevirtual com/trolmastercard/velvet/ay.h ()I
      // 0e: istore 2
      // 0f: aload 0
      // 10: ldc 0.51000005
      // 12: iload 2
      // 13: i2f
      // 14: fmul
      // 15: ldc 0.51000005
      // 17: iload 2
      // 18: i2f
      // 19: fmul
      // 1a: invokevirtual com/trolmastercard/velvet/ay.func_70105_a (FF)V
      // 1d: aload 0
      // 1e: aload 0
      // 1f: getfield com/trolmastercard/velvet/ay.field_70759_as F
      // 22: putfield com/trolmastercard/velvet/ay.field_70177_z F
      // 25: aload 0
      // 26: aload 0
      // 27: getfield com/trolmastercard/velvet/ay.field_70759_as F
      // 2a: putfield com/trolmastercard/velvet/ay.field_70761_aq F
      // 2d: aload 0
      // 2e: invokevirtual com/trolmastercard/velvet/ay.func_70090_H ()Z
      // 31: ifeq 52
      // 34: aload 0
      // 35: getfield com/trolmastercard/velvet/ay.field_70146_Z Ljava/util/Random;
      // 38: bipush 20
      // 3a: invokevirtual java/util/Random.nextInt (I)I
      // 3d: ifne 52
      // 40: goto 47
      // 43: invokestatic com/trolmastercard/velvet/ay.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 46: athrow
      // 47: aload 0
      // 48: invokevirtual com/trolmastercard/velvet/ay.func_71061_d_ ()V
      // 4b: goto 52
      // 4e: invokestatic com/trolmastercard/velvet/ay.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 51: athrow
      // 52: aload 0
      // 53: aload 1
      // 54: invokespecial net/minecraft/entity/EntityLiving.func_184206_a (Lnet/minecraft/network/datasync/DataParameter;)V
      // 57: return
      // try (7 -> 33): 34 java/lang/RuntimeException
      // try (28 -> 38): 39 java/lang/RuntimeException
   }

   public void func_70106_y() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 00: aload 0
      // 01: invokevirtual com/trolmastercard/velvet/ay.h ()I
      // 04: istore 1
      // 05: aload 0
      // 06: getfield com/trolmastercard/velvet/ay.field_70170_p Lnet/minecraft/world/World;
      // 09: getfield net/minecraft/world/World.field_72995_K Z
      // 0c: ifne d1
      // 0f: iload 1
      // 10: bipush 1
      // 11: if_icmple d1
      // 14: goto 1b
      // 17: invokestatic com/trolmastercard/velvet/ay.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 1a: athrow
      // 1b: aload 0
      // 1c: invokevirtual com/trolmastercard/velvet/ay.func_110143_aJ ()F
      // 1f: fconst_0
      // 20: fcmpg
      // 21: ifgt d1
      // 24: goto 2b
      // 27: invokestatic com/trolmastercard/velvet/ay.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 2a: athrow
      // 2b: bipush 2
      // 2c: aload 0
      // 2d: getfield com/trolmastercard/velvet/ay.field_70146_Z Ljava/util/Random;
      // 30: bipush 3
      // 31: invokevirtual java/util/Random.nextInt (I)I
      // 34: iadd
      // 35: istore 2
      // 36: bipush 0
      // 37: istore 3
      // 38: iload 3
      // 39: iload 2
      // 3a: if_icmpge d1
      // 3d: iload 3
      // 3e: bipush 2
      // 3f: irem
      // 40: i2f
      // 41: ldc_w 0.5
      // 44: fsub
      // 45: iload 1
      // 46: i2f
      // 47: fmul
      // 48: ldc_w 4.0
      // 4b: fdiv
      // 4c: fstore 4
      // 4e: iload 3
      // 4f: bipush 2
      // 50: idiv
      // 51: i2f
      // 52: ldc_w 0.5
      // 55: fsub
      // 56: iload 1
      // 57: i2f
      // 58: fmul
      // 59: ldc_w 4.0
      // 5c: fdiv
      // 5d: fstore 5
      // 5f: aload 0
      // 60: invokevirtual com/trolmastercard/velvet/ay.d ()Lcom/trolmastercard/velvet/ay;
      // 63: astore 6
      // 65: aload 0
      // 66: invokevirtual com/trolmastercard/velvet/ay.func_145818_k_ ()Z
      // 69: ifeq 7c
      // 6c: aload 6
      // 6e: aload 0
      // 6f: invokevirtual com/trolmastercard/velvet/ay.func_95999_t ()Ljava/lang/String;
      // 72: invokevirtual com/trolmastercard/velvet/ay.func_96094_a (Ljava/lang/String;)V
      // 75: goto 7c
      // 78: invokestatic com/trolmastercard/velvet/ay.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 7b: athrow
      // 7c: aload 0
      // 7d: invokevirtual com/trolmastercard/velvet/ay.func_104002_bU ()Z
      // 80: ifeq 8f
      // 83: aload 6
      // 85: invokevirtual com/trolmastercard/velvet/ay.func_110163_bv ()V
      // 88: goto 8f
      // 8b: invokestatic com/trolmastercard/velvet/ay.a (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 8e: athrow
      // 8f: aload 6
      // 91: iload 1
      // 92: bipush 2
      // 93: idiv
      // 94: bipush 1
      // 95: invokevirtual com/trolmastercard/velvet/ay.a (IZ)V
      // 98: aload 6
      // 9a: aload 0
      // 9b: getfield com/trolmastercard/velvet/ay.field_70165_t D
      // 9e: fload 4
      // a0: f2d
      // a1: dadd
      // a2: aload 0
      // a3: getfield com/trolmastercard/velvet/ay.field_70163_u D
      // a6: ldc2_w 0.5
      // a9: dadd
      // aa: aload 0
      // ab: getfield com/trolmastercard/velvet/ay.field_70161_v D
      // ae: fload 5
      // b0: f2d
      // b1: dadd
      // b2: aload 0
      // b3: getfield com/trolmastercard/velvet/ay.field_70146_Z Ljava/util/Random;
      // b6: invokevirtual java/util/Random.nextFloat ()F
      // b9: ldc_w 360.0
      // bc: fmul
      // bd: fconst_0
      // be: invokevirtual com/trolmastercard/velvet/ay.func_70012_b (DDDFF)V
      // c1: aload 0
      // c2: getfield com/trolmastercard/velvet/ay.field_70170_p Lnet/minecraft/world/World;
      // c5: aload 6
      // c7: invokevirtual net/minecraft/world/World.func_72838_d (Lnet/minecraft/entity/Entity;)Z
      // ca: pop
      // cb: iinc 3 1
      // ce: goto 38
      // d1: aload 0
      // d2: invokespecial net/minecraft/entity/EntityLiving.func_70106_y ()V
      // d5: return
      // try (3 -> 10): 11 java/lang/RuntimeException
      // try (7 -> 18): 19 java/lang/RuntimeException
      // try (60 -> 67): 68 java/lang/RuntimeException
      // try (70 -> 75): 76 java/lang/RuntimeException
   }

   public float func_70047_e() {
      return 0.625F * this.field_70131_O;
   }

   protected SoundEvent func_184601_bQ(DamageSource var1) {
      try {
         if (this.j()) {
            return SoundEvents.field_187898_fy;
         }
      } catch (RuntimeException var2) {
         throw a(var2);
      }

      return SoundEvents.field_187880_fp;
   }

   protected SoundEvent func_184615_bR() {
      try {
         if (this.j()) {
            return SoundEvents.field_187896_fx;
         }
      } catch (RuntimeException var1) {
         throw a(var1);
      }

      return SoundEvents.field_187874_fm;
   }

   protected SoundEvent f() {
      try {
         if (this.j()) {
            return SoundEvents.field_187900_fz;
         }
      } catch (RuntimeException var1) {
         throw a(var1);
      }

      return SoundEvents.field_187886_fs;
   }

   protected Item func_146068_u() {
      try {
         if (this.h() == 1) {
            return Items.field_151123_aH;
         }
      } catch (RuntimeException var1) {
         throw a(var1);
      }

      return null;
   }

   @Nullable
   protected ResourceLocation func_184647_J() {
      try {
         if (this.h() == 1) {
            return LootTableList.field_186378_ac;
         }
      } catch (RuntimeException var1) {
         throw a(var1);
      }

      return LootTableList.field_186419_a;
   }

   protected float func_70599_aP() {
      return 0.4F * this.h();
   }

   public int func_70646_bf() {
      return 0;
   }

   protected boolean i() {
      try {
         if (this.h() > 0) {
            return true;
         }
      } catch (RuntimeException var1) {
         throw a(var1);
      }

      return false;
   }

   protected void func_70664_aZ() {
      this.field_70181_x = 0.42F;
      this.field_70160_al = true;
   }

   @Nullable
   public IEntityLivingData func_180482_a(DifficultyInstance var1, @Nullable IEntityLivingData var2) {
      this.a(1, true);
      return super.func_180482_a(var1, var2);
   }

   protected SoundEvent c() {
      try {
         if (this.j()) {
            return SoundEvents.field_189110_fE;
         }
      } catch (RuntimeException var1) {
         throw a(var1);
      }

      return SoundEvents.field_187882_fq;
   }

   protected boolean k() {
      return false;
   }

   private static Exception a(Exception var0) {
      return var0;
   }

   static class a extends EntityAIBase {
      private final ay b;
      private float a;
      private int c;

      public a(ay var1) {
         this.b = var1;
         this.func_75248_a(2);
      }

      public boolean func_75250_a() {
         // $VF: Couldn't be decompiled
         // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
         // java.lang.RuntimeException: parsing failure!
         //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
         //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
         //
         // Bytecode:
         // 00: aload 0
         // 01: getfield com/trolmastercard/velvet/ay$a.b Lcom/trolmastercard/velvet/ay;
         // 04: invokevirtual com/trolmastercard/velvet/ay.func_70638_az ()Lnet/minecraft/entity/EntityLivingBase;
         // 07: ifnonnull 59
         // 0a: aload 0
         // 0b: getfield com/trolmastercard/velvet/ay$a.b Lcom/trolmastercard/velvet/ay;
         // 0e: getfield com/trolmastercard/velvet/ay.field_70122_E Z
         // 11: ifne 51
         // 14: goto 1b
         // 17: invokestatic com/trolmastercard/velvet/ay$a.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
         // 1a: athrow
         // 1b: aload 0
         // 1c: getfield com/trolmastercard/velvet/ay$a.b Lcom/trolmastercard/velvet/ay;
         // 1f: invokevirtual com/trolmastercard/velvet/ay.func_70090_H ()Z
         // 22: ifne 51
         // 25: goto 2c
         // 28: invokestatic com/trolmastercard/velvet/ay$a.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
         // 2b: athrow
         // 2c: aload 0
         // 2d: getfield com/trolmastercard/velvet/ay$a.b Lcom/trolmastercard/velvet/ay;
         // 30: invokevirtual com/trolmastercard/velvet/ay.func_180799_ab ()Z
         // 33: ifne 51
         // 36: goto 3d
         // 39: invokestatic com/trolmastercard/velvet/ay$a.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
         // 3c: athrow
         // 3d: aload 0
         // 3e: getfield com/trolmastercard/velvet/ay$a.b Lcom/trolmastercard/velvet/ay;
         // 41: getstatic net/minecraft/init/MobEffects.field_188424_y Lnet/minecraft/potion/Potion;
         // 44: invokevirtual com/trolmastercard/velvet/ay.func_70644_a (Lnet/minecraft/potion/Potion;)Z
         // 47: ifeq 59
         // 4a: goto 51
         // 4d: invokestatic com/trolmastercard/velvet/ay$a.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
         // 50: athrow
         // 51: bipush 1
         // 52: goto 5a
         // 55: invokestatic com/trolmastercard/velvet/ay$a.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
         // 58: athrow
         // 59: bipush 0
         // 5a: ireturn
         // try (0 -> 8): 9 java/lang/RuntimeException
         // try (4 -> 15): 16 java/lang/RuntimeException
         // try (11 -> 22): 23 java/lang/RuntimeException
         // try (18 -> 30): 31 java/lang/RuntimeException
         // try (25 -> 35): 35 java/lang/RuntimeException
      }

      public void func_75246_d() {
         try {
            if (--this.c <= 0) {
               this.c = 40 + this.b.func_70681_au().nextInt(60);
               this.a = this.b.func_70681_au().nextInt(360);
            }
         } catch (RuntimeException var1) {
            throw a(var1);
         }

         ((ay.b)this.b.func_70605_aq()).a(this.a, false);
      }

      private static RuntimeException a(RuntimeException var0) {
         return var0;
      }
   }

   static class b extends EntityMoveHelper {
      private float b;
      private int c;
      private final ay d;
      private boolean a;

      public b(ay var1) {
         super(var1);
         this.d = var1;
         this.b = 180.0F * var1.field_70177_z / (float) Math.PI;
      }

      public void a(float var1, boolean var2) {
         this.b = var1;
         this.a = var2;
      }

      public void a(double var1) {
         this.field_75645_e = var1;
         this.field_188491_h = Action.MOVE_TO;
      }

      public void func_75641_c() {
         // $VF: Couldn't be decompiled
         // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
         // java.lang.RuntimeException: parsing failure!
         //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
         //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
         //
         // Bytecode:
         // 000: aload 0
         // 001: getfield com/trolmastercard/velvet/ay$b.field_75648_a Lnet/minecraft/entity/EntityLiving;
         // 004: aload 0
         // 005: aload 0
         // 006: getfield com/trolmastercard/velvet/ay$b.field_75648_a Lnet/minecraft/entity/EntityLiving;
         // 009: getfield net/minecraft/entity/EntityLiving.field_70177_z F
         // 00c: aload 0
         // 00d: getfield com/trolmastercard/velvet/ay$b.b F
         // 010: ldc 90.0
         // 012: invokevirtual com/trolmastercard/velvet/ay$b.func_75639_a (FFF)F
         // 015: putfield net/minecraft/entity/EntityLiving.field_70177_z F
         // 018: aload 0
         // 019: getfield com/trolmastercard/velvet/ay$b.field_75648_a Lnet/minecraft/entity/EntityLiving;
         // 01c: aload 0
         // 01d: getfield com/trolmastercard/velvet/ay$b.field_75648_a Lnet/minecraft/entity/EntityLiving;
         // 020: getfield net/minecraft/entity/EntityLiving.field_70177_z F
         // 023: putfield net/minecraft/entity/EntityLiving.field_70759_as F
         // 026: aload 0
         // 027: getfield com/trolmastercard/velvet/ay$b.field_75648_a Lnet/minecraft/entity/EntityLiving;
         // 02a: aload 0
         // 02b: getfield com/trolmastercard/velvet/ay$b.field_75648_a Lnet/minecraft/entity/EntityLiving;
         // 02e: getfield net/minecraft/entity/EntityLiving.field_70177_z F
         // 031: putfield net/minecraft/entity/EntityLiving.field_70761_aq F
         // 034: aload 0
         // 035: getfield com/trolmastercard/velvet/ay$b.field_188491_h Lnet/minecraft/entity/ai/EntityMoveHelper$Action;
         // 038: getstatic net/minecraft/entity/ai/EntityMoveHelper$Action.MOVE_TO Lnet/minecraft/entity/ai/EntityMoveHelper$Action;
         // 03b: if_acmpeq 04d
         // 03e: aload 0
         // 03f: getfield com/trolmastercard/velvet/ay$b.field_75648_a Lnet/minecraft/entity/EntityLiving;
         // 042: fconst_0
         // 043: invokevirtual net/minecraft/entity/EntityLiving.func_191989_p (F)V
         // 046: goto 15a
         // 049: invokestatic com/trolmastercard/velvet/ay$b.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
         // 04c: athrow
         // 04d: aload 0
         // 04e: getstatic net/minecraft/entity/ai/EntityMoveHelper$Action.WAIT Lnet/minecraft/entity/ai/EntityMoveHelper$Action;
         // 051: putfield com/trolmastercard/velvet/ay$b.field_188491_h Lnet/minecraft/entity/ai/EntityMoveHelper$Action;
         // 054: aload 0
         // 055: getfield com/trolmastercard/velvet/ay$b.field_75648_a Lnet/minecraft/entity/EntityLiving;
         // 058: getfield net/minecraft/entity/EntityLiving.field_70122_E Z
         // 05b: ifeq 13e
         // 05e: aload 0
         // 05f: getfield com/trolmastercard/velvet/ay$b.field_75648_a Lnet/minecraft/entity/EntityLiving;
         // 062: aload 0
         // 063: getfield com/trolmastercard/velvet/ay$b.field_75645_e D
         // 066: aload 0
         // 067: getfield com/trolmastercard/velvet/ay$b.field_75648_a Lnet/minecraft/entity/EntityLiving;
         // 06a: getstatic net/minecraft/entity/SharedMonsterAttributes.field_111263_d Lnet/minecraft/entity/ai/attributes/IAttribute;
         // 06d: invokevirtual net/minecraft/entity/EntityLiving.func_110148_a (Lnet/minecraft/entity/ai/attributes/IAttribute;)Lnet/minecraft/entity/ai/attributes/IAttributeInstance;
         // 070: invokeinterface net/minecraft/entity/ai/attributes/IAttributeInstance.func_111126_e ()D 1
         // 075: dmul
         // 076: d2f
         // 077: invokevirtual net/minecraft/entity/EntityLiving.func_70659_e (F)V
         // 07a: aload 0
         // 07b: dup
         // 07c: getfield com/trolmastercard/velvet/ay$b.c I
         // 07f: dup_x1
         // 080: bipush 1
         // 081: isub
         // 082: putfield com/trolmastercard/velvet/ay$b.c I
         // 085: ifgt 123
         // 088: goto 08f
         // 08b: invokestatic com/trolmastercard/velvet/ay$b.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
         // 08e: athrow
         // 08f: aload 0
         // 090: aload 0
         // 091: getfield com/trolmastercard/velvet/ay$b.d Lcom/trolmastercard/velvet/ay;
         // 094: invokevirtual com/trolmastercard/velvet/ay.a ()I
         // 097: putfield com/trolmastercard/velvet/ay$b.c I
         // 09a: aload 0
         // 09b: getfield com/trolmastercard/velvet/ay$b.a Z
         // 09e: ifeq 0b9
         // 0a1: goto 0a8
         // 0a4: invokestatic com/trolmastercard/velvet/ay$b.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
         // 0a7: athrow
         // 0a8: aload 0
         // 0a9: dup
         // 0aa: getfield com/trolmastercard/velvet/ay$b.c I
         // 0ad: bipush 3
         // 0ae: idiv
         // 0af: putfield com/trolmastercard/velvet/ay$b.c I
         // 0b2: goto 0b9
         // 0b5: invokestatic com/trolmastercard/velvet/ay$b.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
         // 0b8: athrow
         // 0b9: getstatic com/trolmastercard/velvet/r.f Ljava/util/Random;
         // 0bc: sipush 360
         // 0bf: invokevirtual java/util/Random.nextInt (I)I
         // 0c2: i2f
         // 0c3: fstore 1
         // 0c4: aload 0
         // 0c5: getfield com/trolmastercard/velvet/ay$b.d Lcom/trolmastercard/velvet/ay;
         // 0c8: invokevirtual com/trolmastercard/velvet/ay.func_70605_aq ()Lnet/minecraft/entity/ai/EntityMoveHelper;
         // 0cb: checkcast com/trolmastercard/velvet/ay$b
         // 0ce: fload 1
         // 0cf: bipush 0
         // 0d0: invokevirtual com/trolmastercard/velvet/ay$b.a (FZ)V
         // 0d3: aload 0
         // 0d4: getfield com/trolmastercard/velvet/ay$b.d Lcom/trolmastercard/velvet/ay;
         // 0d7: invokevirtual com/trolmastercard/velvet/ay.func_70683_ar ()Lnet/minecraft/entity/ai/EntityJumpHelper;
         // 0da: invokevirtual net/minecraft/entity/ai/EntityJumpHelper.func_75660_a ()V
         // 0dd: aload 0
         // 0de: getfield com/trolmastercard/velvet/ay$b.d Lcom/trolmastercard/velvet/ay;
         // 0e1: invokevirtual com/trolmastercard/velvet/ay.i ()Z
         // 0e4: ifeq 120
         // 0e7: aload 0
         // 0e8: getfield com/trolmastercard/velvet/ay$b.d Lcom/trolmastercard/velvet/ay;
         // 0eb: aload 0
         // 0ec: getfield com/trolmastercard/velvet/ay$b.d Lcom/trolmastercard/velvet/ay;
         // 0ef: invokevirtual com/trolmastercard/velvet/ay.c ()Lnet/minecraft/util/SoundEvent;
         // 0f2: aload 0
         // 0f3: getfield com/trolmastercard/velvet/ay$b.d Lcom/trolmastercard/velvet/ay;
         // 0f6: invokevirtual com/trolmastercard/velvet/ay.func_70599_aP ()F
         // 0f9: aload 0
         // 0fa: getfield com/trolmastercard/velvet/ay$b.d Lcom/trolmastercard/velvet/ay;
         // 0fd: invokevirtual com/trolmastercard/velvet/ay.func_70681_au ()Ljava/util/Random;
         // 100: invokevirtual java/util/Random.nextFloat ()F
         // 103: aload 0
         // 104: getfield com/trolmastercard/velvet/ay$b.d Lcom/trolmastercard/velvet/ay;
         // 107: invokevirtual com/trolmastercard/velvet/ay.func_70681_au ()Ljava/util/Random;
         // 10a: invokevirtual java/util/Random.nextFloat ()F
         // 10d: fsub
         // 10e: ldc 0.2
         // 110: fmul
         // 111: fconst_1
         // 112: fadd
         // 113: ldc 0.8
         // 115: fmul
         // 116: invokevirtual com/trolmastercard/velvet/ay.func_184185_a (Lnet/minecraft/util/SoundEvent;FF)V
         // 119: goto 120
         // 11c: invokestatic com/trolmastercard/velvet/ay$b.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
         // 11f: athrow
         // 120: goto 15a
         // 123: aload 0
         // 124: getfield com/trolmastercard/velvet/ay$b.d Lcom/trolmastercard/velvet/ay;
         // 127: fconst_0
         // 128: putfield com/trolmastercard/velvet/ay.field_70702_br F
         // 12b: aload 0
         // 12c: getfield com/trolmastercard/velvet/ay$b.d Lcom/trolmastercard/velvet/ay;
         // 12f: fconst_0
         // 130: putfield com/trolmastercard/velvet/ay.field_191988_bg F
         // 133: aload 0
         // 134: getfield com/trolmastercard/velvet/ay$b.field_75648_a Lnet/minecraft/entity/EntityLiving;
         // 137: fconst_0
         // 138: invokevirtual net/minecraft/entity/EntityLiving.func_70659_e (F)V
         // 13b: goto 15a
         // 13e: aload 0
         // 13f: getfield com/trolmastercard/velvet/ay$b.field_75648_a Lnet/minecraft/entity/EntityLiving;
         // 142: aload 0
         // 143: getfield com/trolmastercard/velvet/ay$b.field_75645_e D
         // 146: aload 0
         // 147: getfield com/trolmastercard/velvet/ay$b.field_75648_a Lnet/minecraft/entity/EntityLiving;
         // 14a: getstatic net/minecraft/entity/SharedMonsterAttributes.field_111263_d Lnet/minecraft/entity/ai/attributes/IAttribute;
         // 14d: invokevirtual net/minecraft/entity/EntityLiving.func_110148_a (Lnet/minecraft/entity/ai/attributes/IAttribute;)Lnet/minecraft/entity/ai/attributes/IAttributeInstance;
         // 150: invokeinterface net/minecraft/entity/ai/attributes/IAttributeInstance.func_111126_e ()D 1
         // 155: dmul
         // 156: d2f
         // 157: invokevirtual net/minecraft/entity/EntityLiving.func_70659_e (F)V
         // 15a: return
         // try (0 -> 32): 32 java/lang/RuntimeException
         // try (34 -> 61): 62 java/lang/RuntimeException
         // try (41 -> 72): 73 java/lang/RuntimeException
         // try (64 -> 81): 82 java/lang/RuntimeException
         // try (89 -> 128): 129 java/lang/RuntimeException
      }

      private static RuntimeException a(RuntimeException var0) {
         return var0;
      }
   }

   static class c extends EntityAIBase {
      private final ay a;

      public c(ay var1) {
         this.a = var1;
         this.func_75248_a(5);
      }

      public boolean func_75250_a() {
         return true;
      }

      public void func_75246_d() {
         ((ay.b)this.a.func_70605_aq()).a(1.0);
      }
   }

   static class d extends EntityAIBase {
      private final ay a;

      public d(ay var1) {
         this.a = var1;
         this.func_75248_a(5);
         ((PathNavigateGround)var1.func_70661_as()).func_179693_d(true);
      }

      public boolean func_75250_a() {
         // $VF: Couldn't be decompiled
         // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
         // java.lang.RuntimeException: parsing failure!
         //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
         //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
         //
         // Bytecode:
         // 00: aload 0
         // 01: getfield com/trolmastercard/velvet/ay$d.a Lcom/trolmastercard/velvet/ay;
         // 04: invokevirtual com/trolmastercard/velvet/ay.func_70090_H ()Z
         // 07: ifne 1b
         // 0a: aload 0
         // 0b: getfield com/trolmastercard/velvet/ay$d.a Lcom/trolmastercard/velvet/ay;
         // 0e: invokevirtual com/trolmastercard/velvet/ay.func_180799_ab ()Z
         // 11: ifeq 23
         // 14: goto 1b
         // 17: invokestatic com/trolmastercard/velvet/ay$d.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
         // 1a: athrow
         // 1b: bipush 1
         // 1c: goto 24
         // 1f: invokestatic com/trolmastercard/velvet/ay$d.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
         // 22: athrow
         // 23: bipush 0
         // 24: ireturn
         // try (0 -> 8): 9 java/lang/RuntimeException
         // try (4 -> 13): 13 java/lang/RuntimeException
      }

      public void func_75246_d() {
         try {
            if (this.a.func_70681_au().nextFloat() < 0.8F) {
               this.a.func_70683_ar().func_75660_a();
            }
         } catch (RuntimeException var1) {
            throw a(var1);
         }

         ((ay.b)this.a.func_70605_aq()).a(1.2);
      }

      private static RuntimeException a(RuntimeException var0) {
         return var0;
      }
   }
}
