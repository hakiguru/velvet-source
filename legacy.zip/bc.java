package org.velvet;

import net.minecraft.util.ResourceLocation;
import software.bernie.geckolib3.model.AnimatedGeoModel;

public class bc extends AnimatedGeoModel<hy> {
   public ResourceLocation b(hy var1) {
      return new ResourceLocation("velvet", "geo/kobold/staff.geo.json");
   }

   public ResourceLocation a(hy var1) {
      return new ResourceLocation("velvet", "textures/entity/kobold/staff.png");
   }

   public ResourceLocation c(hy var1) {
      return new ResourceLocation("velvet", "animations/kobold/staff.animation.json");
   }
}
