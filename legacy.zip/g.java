package org.velvet;

import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.entity.projectile.EntityTippedArrow;
import net.minecraft.init.Enchantments;
import net.minecraft.init.Items;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingHealEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class g extends f {
   e2 q;
   EntityLivingBase r;
   Entity o;
   double l = Float.MAX_VALUE;
   Vec3d i = Vec3d.field_186680_a;
   int j = 0;
   int n = 0;
   int k = 0;
   int p = 0;
   int m = 0;

   public g(e2 var1) {
      super(var1);
      this.q = var1;
   }

   @Override
   public void func_75246_d() {
      try {
         super.func_75246_d();
         this.l = this.q.func_70032_d(this.a);
         this.i = this.a.func_174791_d();
         if (this.q.y() == fp.BOW) {
            this.q.b(fp.NULL);
         }
      } catch (RuntimeException var1) {
         throw a(var1);
      }
   }

   boolean a(EntityLivingBase param1) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 00: aload 0
      // 01: getfield com/trolmastercard/velvet/g.q Lcom/trolmastercard/velvet/e2;
      // 04: invokevirtual com/trolmastercard/velvet/e2.func_174791_d ()Lnet/minecraft/util/math/Vec3d;
      // 07: astore 2
      // 08: aload 1
      // 09: instanceof com/trolmastercard/velvet/em
      // 0c: ifne 9f
      // 0f: aload 0
      // 10: getfield com/trolmastercard/velvet/g.n I
      // 13: ifgt 9f
      // 16: goto 1d
      // 19: invokestatic com/trolmastercard/velvet/g.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 1c: athrow
      // 1d: aload 1
      // 1e: ifnull 9f
      // 21: goto 28
      // 24: invokestatic com/trolmastercard/velvet/g.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 27: athrow
      // 28: aload 1
      // 29: getfield net/minecraft/entity/EntityLivingBase.field_70170_p Lnet/minecraft/world/World;
      // 2c: ifnull 9f
      // 2f: goto 36
      // 32: invokestatic com/trolmastercard/velvet/g.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 35: athrow
      // 36: aload 0
      // 37: getfield com/trolmastercard/velvet/g.q Lcom/trolmastercard/velvet/e2;
      // 3a: aload 1
      // 3b: invokevirtual com/trolmastercard/velvet/e2.equals (Ljava/lang/Object;)Z
      // 3e: ifne 9f
      // 41: goto 48
      // 44: invokestatic com/trolmastercard/velvet/g.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 47: athrow
      // 48: aload 1
      // 49: invokevirtual net/minecraft/entity/EntityLivingBase.func_70089_S ()Z
      // 4c: ifeq 9f
      // 4f: goto 56
      // 52: invokestatic com/trolmastercard/velvet/g.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 55: athrow
      // 56: aload 2
      // 57: aload 0
      // 58: getfield com/trolmastercard/velvet/g.a Lnet/minecraft/entity/player/EntityPlayer;
      // 5b: invokevirtual net/minecraft/entity/player/EntityPlayer.func_174791_d ()Lnet/minecraft/util/math/Vec3d;
      // 5e: invokevirtual net/minecraft/util/math/Vec3d.func_72438_d (Lnet/minecraft/util/math/Vec3d;)D
      // 61: ldc2_w 15.0
      // 64: dcmpg
      // 65: ifge 9f
      // 68: goto 6f
      // 6b: invokestatic com/trolmastercard/velvet/g.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 6e: athrow
      // 6f: aload 2
      // 70: aload 1
      // 71: invokevirtual net/minecraft/entity/EntityLivingBase.func_174791_d ()Lnet/minecraft/util/math/Vec3d;
      // 74: invokevirtual net/minecraft/util/math/Vec3d.func_72438_d (Lnet/minecraft/util/math/Vec3d;)D
      // 77: ldc2_w 20.0
      // 7a: dcmpg
      // 7b: ifge 9f
      // 7e: goto 85
      // 81: invokestatic com/trolmastercard/velvet/g.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 84: athrow
      // 85: aload 1
      // 86: aload 0
      // 87: getfield com/trolmastercard/velvet/g.a Lnet/minecraft/entity/player/EntityPlayer;
      // 8a: invokevirtual net/minecraft/entity/EntityLivingBase.equals (Ljava/lang/Object;)Z
      // 8d: ifne 9f
      // 90: goto 97
      // 93: invokestatic com/trolmastercard/velvet/g.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 96: athrow
      // 97: bipush 1
      // 98: goto a0
      // 9b: invokestatic com/trolmastercard/velvet/g.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 9e: athrow
      // 9f: bipush 0
      // a0: ireturn
      // try (4 -> 10): 11 java/lang/RuntimeException
      // try (7 -> 15): 16 java/lang/RuntimeException
      // try (13 -> 21): 22 java/lang/RuntimeException
      // try (18 -> 29): 30 java/lang/RuntimeException
      // try (24 -> 35): 36 java/lang/RuntimeException
      // try (32 -> 46): 47 java/lang/RuntimeException
      // try (38 -> 56): 57 java/lang/RuntimeException
      // try (49 -> 64): 65 java/lang/RuntimeException
      // try (59 -> 69): 69 java/lang/RuntimeException
   }

   @Override
   protected void a(f.a param1) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 000: getstatic com/trolmastercard/velvet/g$b.a [I
      // 003: aload 1
      // 004: invokevirtual com/trolmastercard/velvet/f$a.ordinal ()I
      // 007: iaload
      // 008: tableswitch 846 1 5 36 392 501 694 839
      // 02c: aload 0
      // 02d: getfield com/trolmastercard/velvet/g.q Lcom/trolmastercard/velvet/e2;
      // 030: invokevirtual com/trolmastercard/velvet/e2.func_70671_ap ()Lnet/minecraft/entity/ai/EntityLookHelper;
      // 033: aload 0
      // 034: getfield com/trolmastercard/velvet/g.r Lnet/minecraft/entity/EntityLivingBase;
      // 037: ldc 30.0
      // 039: ldc 30.0
      // 03b: invokevirtual net/minecraft/entity/ai/EntityLookHelper.func_75651_a (Lnet/minecraft/entity/Entity;FF)V
      // 03e: aload 0
      // 03f: getfield com/trolmastercard/velvet/g.q Lcom/trolmastercard/velvet/e2;
      // 042: aload 0
      // 043: getfield com/trolmastercard/velvet/g.r Lnet/minecraft/entity/EntityLivingBase;
      // 046: invokevirtual com/trolmastercard/velvet/e2.func_70032_d (Lnet/minecraft/entity/Entity;)F
      // 049: f2d
      // 04a: dstore 2
      // 04b: aload 0
      // 04c: getfield com/trolmastercard/velvet/g.c Lnet/minecraft/pathfinding/PathNavigate;
      // 04f: invokevirtual net/minecraft/pathfinding/PathNavigate.func_75499_g ()V
      // 052: dload 2
      // 053: ldc2_w 1.9
      // 056: dcmpg
      // 057: ifge 07a
      // 05a: aload 0
      // 05b: dup
      // 05c: getfield com/trolmastercard/velvet/g.k I
      // 05f: bipush 1
      // 060: isub
      // 061: dup_x1
      // 062: putfield com/trolmastercard/velvet/g.k I
      // 065: ifgt 07a
      // 068: goto 06f
      // 06b: invokestatic com/trolmastercard/velvet/g.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 06e: athrow
      // 06f: aload 0
      // 070: invokevirtual com/trolmastercard/velvet/g.d ()V
      // 073: goto 356
      // 076: invokestatic com/trolmastercard/velvet/g.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 079: athrow
      // 07a: aload 0
      // 07b: getfield com/trolmastercard/velvet/g.q Lcom/trolmastercard/velvet/e2;
      // 07e: getfield com/trolmastercard/velvet/e2.Q Lnet/minecraftforge/items/ItemStackHandler;
      // 081: bipush 1
      // 082: invokevirtual net/minecraftforge/items/ItemStackHandler.getStackInSlot (I)Lnet/minecraft/item/ItemStack;
      // 085: invokevirtual net/minecraft/item/ItemStack.func_77973_b ()Lnet/minecraft/item/Item;
      // 088: instanceof net/minecraft/item/ItemBow
      // 08b: ifeq 130
      // 08e: aload 0
      // 08f: getfield com/trolmastercard/velvet/g.q Lcom/trolmastercard/velvet/e2;
      // 092: invokevirtual com/trolmastercard/velvet/e2.func_70635_at ()Lnet/minecraft/entity/ai/EntitySenses;
      // 095: aload 0
      // 096: getfield com/trolmastercard/velvet/g.r Lnet/minecraft/entity/EntityLivingBase;
      // 099: invokevirtual net/minecraft/entity/ai/EntitySenses.func_75522_a (Lnet/minecraft/entity/Entity;)Z
      // 09c: ifeq 130
      // 09f: goto 0a6
      // 0a2: invokestatic com/trolmastercard/velvet/g.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 0a5: athrow
      // 0a6: aload 0
      // 0a7: dup
      // 0a8: getfield com/trolmastercard/velvet/g.p I
      // 0ab: bipush 1
      // 0ac: iadd
      // 0ad: dup_x1
      // 0ae: putfield com/trolmastercard/velvet/g.p I
      // 0b1: ifle 130
      // 0b4: goto 0bb
      // 0b7: invokestatic com/trolmastercard/velvet/g.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 0ba: athrow
      // 0bb: dload 2
      // 0bc: ldc2_w 6.0
      // 0bf: dcmpl
      // 0c0: ifle 130
      // 0c3: goto 0ca
      // 0c6: invokestatic com/trolmastercard/velvet/g.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 0c9: athrow
      // 0ca: aload 0
      // 0cb: getfield com/trolmastercard/velvet/g.e Lnet/minecraft/network/datasync/EntityDataManager;
      // 0ce: getstatic com/trolmastercard/velvet/e2.M Lnet/minecraft/network/datasync/DataParameter;
      // 0d1: bipush 2
      // 0d2: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 0d5: invokevirtual net/minecraft/network/datasync/EntityDataManager.func_187227_b (Lnet/minecraft/network/datasync/DataParameter;Ljava/lang/Object;)V
      // 0d8: aload 0
      // 0d9: getfield com/trolmastercard/velvet/g.q Lcom/trolmastercard/velvet/e2;
      // 0dc: getstatic com/trolmastercard/velvet/fp.BOW Lcom/trolmastercard/velvet/fp;
      // 0df: invokevirtual com/trolmastercard/velvet/e2.b (Lcom/trolmastercard/velvet/fp;)V
      // 0e2: aload 0
      // 0e3: dup
      // 0e4: getfield com/trolmastercard/velvet/g.p I
      // 0e7: bipush 1
      // 0e8: iadd
      // 0e9: dup_x1
      // 0ea: putfield com/trolmastercard/velvet/g.p I
      // 0ed: bipush 32
      // 0ef: if_icmplt 114
      // 0f2: goto 0f9
      // 0f5: invokestatic com/trolmastercard/velvet/g.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 0f8: athrow
      // 0f9: aload 0
      // 0fa: bipush -20
      // 0fc: putfield com/trolmastercard/velvet/g.p I
      // 0ff: aload 0
      // 100: invokevirtual com/trolmastercard/velvet/g.e ()V
      // 103: aload 0
      // 104: getfield com/trolmastercard/velvet/g.q Lcom/trolmastercard/velvet/e2;
      // 107: getstatic com/trolmastercard/velvet/fp.NULL Lcom/trolmastercard/velvet/fp;
      // 10a: invokevirtual com/trolmastercard/velvet/e2.b (Lcom/trolmastercard/velvet/fp;)V
      // 10d: goto 114
      // 110: invokestatic com/trolmastercard/velvet/g.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 113: athrow
      // 114: aload 0
      // 115: aload 0
      // 116: getfield com/trolmastercard/velvet/g.q Lcom/trolmastercard/velvet/e2;
      // 119: aload 0
      // 11a: getfield com/trolmastercard/velvet/g.a Lnet/minecraft/entity/player/EntityPlayer;
      // 11d: invokevirtual com/trolmastercard/velvet/e2.func_70032_d (Lnet/minecraft/entity/Entity;)F
      // 120: f2d
      // 121: putfield com/trolmastercard/velvet/g.l D
      // 124: aload 0
      // 125: aload 0
      // 126: getfield com/trolmastercard/velvet/g.a Lnet/minecraft/entity/player/EntityPlayer;
      // 129: invokevirtual net/minecraft/entity/player/EntityPlayer.func_174791_d ()Lnet/minecraft/util/math/Vec3d;
      // 12c: putfield com/trolmastercard/velvet/g.i Lnet/minecraft/util/math/Vec3d;
      // 12f: return
      // 130: dload 2
      // 131: ldc2_w 2.0
      // 134: dcmpg
      // 135: ifge 166
      // 138: aload 0
      // 139: getfield com/trolmastercard/velvet/g.e Lnet/minecraft/network/datasync/EntityDataManager;
      // 13c: getstatic com/trolmastercard/velvet/e2.M Lnet/minecraft/network/datasync/DataParameter;
      // 13f: bipush 1
      // 140: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 143: invokevirtual net/minecraft/network/datasync/EntityDataManager.func_187227_b (Lnet/minecraft/network/datasync/DataParameter;Ljava/lang/Object;)V
      // 146: aload 0
      // 147: getfield com/trolmastercard/velvet/g.c Lnet/minecraft/pathfinding/PathNavigate;
      // 14a: aload 0
      // 14b: getfield com/trolmastercard/velvet/g.r Lnet/minecraft/entity/EntityLivingBase;
      // 14e: ldc2_w 0.5
      // 151: invokevirtual net/minecraft/pathfinding/PathNavigate.func_75497_a (Lnet/minecraft/entity/Entity;D)Z
      // 154: pop
      // 155: aload 0
      // 156: getfield com/trolmastercard/velvet/g.q Lcom/trolmastercard/velvet/e2;
      // 159: getstatic com/trolmastercard/velvet/em$a.WALK Lcom/trolmastercard/velvet/em$a;
      // 15c: invokevirtual com/trolmastercard/velvet/e2.a (Lcom/trolmastercard/velvet/em$a;)V
      // 15f: goto 356
      // 162: invokestatic com/trolmastercard/velvet/g.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 165: athrow
      // 166: aload 0
      // 167: getfield com/trolmastercard/velvet/g.e Lnet/minecraft/network/datasync/EntityDataManager;
      // 16a: getstatic com/trolmastercard/velvet/e2.M Lnet/minecraft/network/datasync/DataParameter;
      // 16d: bipush 1
      // 16e: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 171: invokevirtual net/minecraft/network/datasync/EntityDataManager.func_187227_b (Lnet/minecraft/network/datasync/DataParameter;Ljava/lang/Object;)V
      // 174: aload 0
      // 175: getfield com/trolmastercard/velvet/g.c Lnet/minecraft/pathfinding/PathNavigate;
      // 178: aload 0
      // 179: getfield com/trolmastercard/velvet/g.r Lnet/minecraft/entity/EntityLivingBase;
      // 17c: ldc2_w 0.7
      // 17f: invokevirtual net/minecraft/pathfinding/PathNavigate.func_75497_a (Lnet/minecraft/entity/Entity;D)Z
      // 182: pop
      // 183: aload 0
      // 184: getfield com/trolmastercard/velvet/g.q Lcom/trolmastercard/velvet/e2;
      // 187: getstatic com/trolmastercard/velvet/em$a.RUN Lcom/trolmastercard/velvet/em$a;
      // 18a: invokevirtual com/trolmastercard/velvet/e2.a (Lcom/trolmastercard/velvet/em$a;)V
      // 18d: goto 356
      // 190: aload 0
      // 191: getfield com/trolmastercard/velvet/g.e Lnet/minecraft/network/datasync/EntityDataManager;
      // 194: getstatic com/trolmastercard/velvet/e2.M Lnet/minecraft/network/datasync/DataParameter;
      // 197: bipush 0
      // 198: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 19b: invokevirtual net/minecraft/network/datasync/EntityDataManager.func_187227_b (Lnet/minecraft/network/datasync/DataParameter;Ljava/lang/Object;)V
      // 19e: aload 0
      // 19f: getfield com/trolmastercard/velvet/g.q Lcom/trolmastercard/velvet/e2;
      // 1a2: aload 0
      // 1a3: getfield com/trolmastercard/velvet/g.a Lnet/minecraft/entity/player/EntityPlayer;
      // 1a6: invokevirtual com/trolmastercard/velvet/e2.func_70032_d (Lnet/minecraft/entity/Entity;)F
      // 1a9: f2d
      // 1aa: dstore 2
      // 1ab: aload 0
      // 1ac: getfield com/trolmastercard/velvet/g.c Lnet/minecraft/pathfinding/PathNavigate;
      // 1af: invokevirtual net/minecraft/pathfinding/PathNavigate.func_111269_d ()F
      // 1b2: f2d
      // 1b3: dload 2
      // 1b4: dcmpl
      // 1b5: ifle 1ea
      // 1b8: aload 0
      // 1b9: getfield com/trolmastercard/velvet/g.c Lnet/minecraft/pathfinding/PathNavigate;
      // 1bc: invokevirtual net/minecraft/pathfinding/PathNavigate.func_75499_g ()V
      // 1bf: aload 0
      // 1c0: getfield com/trolmastercard/velvet/g.q Lcom/trolmastercard/velvet/e2;
      // 1c3: getfield com/trolmastercard/velvet/e2.N Z
      // 1c6: ifne 1ee
      // 1c9: goto 1d0
      // 1cc: invokestatic com/trolmastercard/velvet/g.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 1cf: athrow
      // 1d0: aload 0
      // 1d1: getfield com/trolmastercard/velvet/g.c Lnet/minecraft/pathfinding/PathNavigate;
      // 1d4: aload 0
      // 1d5: getfield com/trolmastercard/velvet/g.a Lnet/minecraft/entity/player/EntityPlayer;
      // 1d8: ldc2_w 0.5
      // 1db: invokevirtual net/minecraft/pathfinding/PathNavigate.func_75497_a (Lnet/minecraft/entity/Entity;D)Z
      // 1de: pop
      // 1df: aload 0
      // 1e0: invokevirtual com/trolmastercard/velvet/g.a ()V
      // 1e3: goto 1ee
      // 1e6: invokestatic com/trolmastercard/velvet/g.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 1e9: athrow
      // 1ea: aload 0
      // 1eb: invokevirtual com/trolmastercard/velvet/g.c ()V
      // 1ee: aload 0
      // 1ef: sipush 300
      // 1f2: putfield com/trolmastercard/velvet/g.j I
      // 1f5: aload 0
      // 1f6: invokevirtual com/trolmastercard/velvet/g.b ()D
      // 1f9: pop2
      // 1fa: goto 356
      // 1fd: aload 0
      // 1fe: getfield com/trolmastercard/velvet/g.e Lnet/minecraft/network/datasync/EntityDataManager;
      // 201: getstatic com/trolmastercard/velvet/e2.M Lnet/minecraft/network/datasync/DataParameter;
      // 204: bipush 0
      // 205: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 208: invokevirtual net/minecraft/network/datasync/EntityDataManager.func_187227_b (Lnet/minecraft/network/datasync/DataParameter;Ljava/lang/Object;)V
      // 20b: aload 0
      // 20c: getfield com/trolmastercard/velvet/g.q Lcom/trolmastercard/velvet/e2;
      // 20f: getfield com/trolmastercard/velvet/e2.N Z
      // 212: ifne 2a1
      // 215: aload 0
      // 216: dup
      // 217: getfield com/trolmastercard/velvet/g.j I
      // 21a: bipush 1
      // 21b: iadd
      // 21c: dup_x1
      // 21d: putfield com/trolmastercard/velvet/g.j I
      // 220: sipush 200
      // 223: getstatic com/trolmastercard/velvet/r.f Ljava/util/Random;
      // 226: bipush 100
      // 228: invokevirtual java/util/Random.nextInt (I)I
      // 22b: iadd
      // 22c: if_icmple 299
      // 22f: goto 236
      // 232: invokestatic com/trolmastercard/velvet/g.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 235: athrow
      // 236: aload 0
      // 237: bipush 0
      // 238: putfield com/trolmastercard/velvet/g.j I
      // 23b: aload 0
      // 23c: getfield com/trolmastercard/velvet/g.a Lnet/minecraft/entity/player/EntityPlayer;
      // 23f: invokevirtual net/minecraft/entity/player/EntityPlayer.func_174791_d ()Lnet/minecraft/util/math/Vec3d;
      // 242: astore 4
      // 244: new net/minecraft/util/math/Vec3d
      // 247: dup
      // 248: aload 4
      // 24a: getfield net/minecraft/util/math/Vec3d.field_72450_a D
      // 24d: dconst_1
      // 24e: dadd
      // 24f: getstatic com/trolmastercard/velvet/r.f Ljava/util/Random;
      // 252: invokevirtual java/util/Random.nextFloat ()F
      // 255: ldc_w 3.0
      // 258: fmul
      // 259: f2d
      // 25a: dadd
      // 25b: aload 4
      // 25d: getfield net/minecraft/util/math/Vec3d.field_72448_b D
      // 260: aload 4
      // 262: getfield net/minecraft/util/math/Vec3d.field_72449_c D
      // 265: dconst_1
      // 266: dadd
      // 267: getstatic com/trolmastercard/velvet/r.f Ljava/util/Random;
      // 26a: invokevirtual java/util/Random.nextFloat ()F
      // 26d: ldc_w 3.0
      // 270: fmul
      // 271: f2d
      // 272: dadd
      // 273: invokespecial net/minecraft/util/math/Vec3d.<init> (DDD)V
      // 276: astore 5
      // 278: aload 0
      // 279: getfield com/trolmastercard/velvet/g.c Lnet/minecraft/pathfinding/PathNavigate;
      // 27c: invokevirtual net/minecraft/pathfinding/PathNavigate.func_75499_g ()V
      // 27f: aload 0
      // 280: getfield com/trolmastercard/velvet/g.c Lnet/minecraft/pathfinding/PathNavigate;
      // 283: aload 5
      // 285: getfield net/minecraft/util/math/Vec3d.field_72450_a D
      // 288: aload 5
      // 28a: getfield net/minecraft/util/math/Vec3d.field_72448_b D
      // 28d: aload 5
      // 28f: getfield net/minecraft/util/math/Vec3d.field_72449_c D
      // 292: ldc2_w 0.5
      // 295: invokevirtual net/minecraft/pathfinding/PathNavigate.func_75492_a (DDDD)Z
      // 298: pop
      // 299: aload 0
      // 29a: invokevirtual com/trolmastercard/velvet/g.b ()D
      // 29d: pop2
      // 29e: goto 356
      // 2a1: aload 0
      // 2a2: getfield com/trolmastercard/velvet/g.q Lcom/trolmastercard/velvet/e2;
      // 2a5: aload 0
      // 2a6: getfield com/trolmastercard/velvet/g.a Lnet/minecraft/entity/player/EntityPlayer;
      // 2a9: invokevirtual com/trolmastercard/velvet/e2.func_70032_d (Lnet/minecraft/entity/Entity;)F
      // 2ac: ldc_w 10.0
      // 2af: fcmpl
      // 2b0: ifle 356
      // 2b3: aload 0
      // 2b4: invokevirtual com/trolmastercard/velvet/g.c ()V
      // 2b7: goto 356
      // 2ba: invokestatic com/trolmastercard/velvet/g.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 2bd: athrow
      // 2be: aload 0
      // 2bf: getfield com/trolmastercard/velvet/g.q Lcom/trolmastercard/velvet/e2;
      // 2c2: invokevirtual com/trolmastercard/velvet/e2.func_184218_aH ()Z
      // 2c5: ifeq 2d9
      // 2c8: aload 0
      // 2c9: getfield com/trolmastercard/velvet/g.q Lcom/trolmastercard/velvet/e2;
      // 2cc: getstatic com/trolmastercard/velvet/fp.SIT Lcom/trolmastercard/velvet/fp;
      // 2cf: invokevirtual com/trolmastercard/velvet/e2.b (Lcom/trolmastercard/velvet/fp;)V
      // 2d2: goto 356
      // 2d5: invokestatic com/trolmastercard/velvet/g.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 2d8: athrow
      // 2d9: aload 0
      // 2da: getfield com/trolmastercard/velvet/g.q Lcom/trolmastercard/velvet/e2;
      // 2dd: bipush 1
      // 2de: invokevirtual com/trolmastercard/velvet/e2.func_189654_d (Z)V
      // 2e1: aload 0
      // 2e2: getfield com/trolmastercard/velvet/g.q Lcom/trolmastercard/velvet/e2;
      // 2e5: bipush 1
      // 2e6: putfield com/trolmastercard/velvet/e2.field_70145_X Z
      // 2e9: aload 0
      // 2ea: getfield com/trolmastercard/velvet/g.a Lnet/minecraft/entity/player/EntityPlayer;
      // 2ed: invokevirtual net/minecraft/entity/player/EntityPlayer.func_174791_d ()Lnet/minecraft/util/math/Vec3d;
      // 2f0: aload 0
      // 2f1: getfield com/trolmastercard/velvet/g.o Lnet/minecraft/entity/Entity;
      // 2f4: invokevirtual net/minecraft/entity/Entity.func_70040_Z ()Lnet/minecraft/util/math/Vec3d;
      // 2f7: getfield net/minecraft/util/math/Vec3d.field_72450_a D
      // 2fa: ldc2_w 0.5
      // 2fd: dmul
      // 2fe: dconst_0
      // 2ff: aload 0
      // 300: getfield com/trolmastercard/velvet/g.o Lnet/minecraft/entity/Entity;
      // 303: invokevirtual net/minecraft/entity/Entity.func_70040_Z ()Lnet/minecraft/util/math/Vec3d;
      // 306: getfield net/minecraft/util/math/Vec3d.field_72449_c D
      // 309: ldc2_w 0.5
      // 30c: dmul
      // 30d: invokevirtual net/minecraft/util/math/Vec3d.func_178786_a (DDD)Lnet/minecraft/util/math/Vec3d;
      // 310: astore 4
      // 312: aload 0
      // 313: getfield com/trolmastercard/velvet/g.q Lcom/trolmastercard/velvet/e2;
      // 316: aload 4
      // 318: getfield net/minecraft/util/math/Vec3d.field_72450_a D
      // 31b: aload 4
      // 31d: getfield net/minecraft/util/math/Vec3d.field_72448_b D
      // 320: aload 4
      // 322: getfield net/minecraft/util/math/Vec3d.field_72449_c D
      // 325: fconst_0
      // 326: fconst_0
      // 327: invokevirtual com/trolmastercard/velvet/e2.func_70080_a (DDDFF)V
      // 32a: aload 0
      // 32b: getfield com/trolmastercard/velvet/g.q Lcom/trolmastercard/velvet/e2;
      // 32e: dconst_0
      // 32f: putfield com/trolmastercard/velvet/e2.field_70159_w D
      // 332: aload 0
      // 333: getfield com/trolmastercard/velvet/g.q Lcom/trolmastercard/velvet/e2;
      // 336: dconst_0
      // 337: putfield com/trolmastercard/velvet/e2.field_70181_x D
      // 33a: aload 0
      // 33b: getfield com/trolmastercard/velvet/g.q Lcom/trolmastercard/velvet/e2;
      // 33e: dconst_0
      // 33f: putfield com/trolmastercard/velvet/e2.field_70179_y D
      // 342: aload 0
      // 343: getfield com/trolmastercard/velvet/g.q Lcom/trolmastercard/velvet/e2;
      // 346: getstatic com/trolmastercard/velvet/fp.RIDE Lcom/trolmastercard/velvet/fp;
      // 349: invokevirtual com/trolmastercard/velvet/e2.b (Lcom/trolmastercard/velvet/fp;)V
      // 34c: goto 356
      // 34f: aload 0
      // 350: getfield com/trolmastercard/velvet/g.c Lnet/minecraft/pathfinding/PathNavigate;
      // 353: invokevirtual net/minecraft/pathfinding/PathNavigate.func_75499_g ()V
      // 356: return
      // try (20 -> 35): 36 java/lang/RuntimeException
      // try (27 -> 41): 41 java/lang/RuntimeException
      // try (43 -> 58): 59 java/lang/RuntimeException
      // try (51 -> 69): 70 java/lang/RuntimeException
      // try (61 -> 76): 77 java/lang/RuntimeException
      // try (72 -> 98): 99 java/lang/RuntimeException
      // try (79 -> 110): 111 java/lang/RuntimeException
      // try (127 -> 149): 149 java/lang/RuntimeException
      // try (182 -> 196): 197 java/lang/RuntimeException
      // try (189 -> 209): 209 java/lang/RuntimeException
      // try (220 -> 243): 244 java/lang/RuntimeException
      // try (297 -> 308): 308 java/lang/RuntimeException
      // try (310 -> 319): 319 java/lang/RuntimeException
   }

   @Override
   protected f.a a() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 000: aload 0
      // 001: dup
      // 002: getfield com/trolmastercard/velvet/g.n I
      // 005: bipush 1
      // 006: isub
      // 007: putfield com/trolmastercard/velvet/g.n I
      // 00a: aload 0
      // 00b: getfield com/trolmastercard/velvet/g.q Lcom/trolmastercard/velvet/e2;
      // 00e: getfield com/trolmastercard/velvet/e2.N Z
      // 011: ifne 025
      // 014: aload 0
      // 015: getfield com/trolmastercard/velvet/g.q Lcom/trolmastercard/velvet/e2;
      // 018: invokevirtual com/trolmastercard/velvet/e2.ae ()Ljava/util/UUID;
      // 01b: ifnull 02d
      // 01e: goto 025
      // 021: invokestatic com/trolmastercard/velvet/g.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 024: athrow
      // 025: getstatic com/trolmastercard/velvet/f$a.DOWNED Lcom/trolmastercard/velvet/f$a;
      // 028: areturn
      // 029: invokestatic com/trolmastercard/velvet/g.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 02c: athrow
      // 02d: aload 0
      // 02e: getfield com/trolmastercard/velvet/g.a Lnet/minecraft/entity/player/EntityPlayer;
      // 031: invokevirtual net/minecraft/entity/player/EntityPlayer.func_184218_aH ()Z
      // 034: ifeq 08a
      // 037: aload 0
      // 038: getfield com/trolmastercard/velvet/g.a Lnet/minecraft/entity/player/EntityPlayer;
      // 03b: invokevirtual net/minecraft/entity/player/EntityPlayer.func_184187_bx ()Lnet/minecraft/entity/Entity;
      // 03e: astore 1
      // 03f: aload 0
      // 040: getfield com/trolmastercard/velvet/g.q Lcom/trolmastercard/velvet/e2;
      // 043: invokevirtual com/trolmastercard/velvet/e2.func_184218_aH ()Z
      // 046: ifne 07a
      // 049: aload 0
      // 04a: getfield com/trolmastercard/velvet/g.q Lcom/trolmastercard/velvet/e2;
      // 04d: aload 1
      // 04e: invokevirtual com/trolmastercard/velvet/e2.func_184220_m (Lnet/minecraft/entity/Entity;)Z
      // 051: ifne 07a
      // 054: goto 05b
      // 057: invokestatic com/trolmastercard/velvet/g.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 05a: athrow
      // 05b: aload 1
      // 05c: instanceof net/minecraft/entity/passive/EntityHorse
      // 05f: ifeq 087
      // 062: goto 069
      // 065: invokestatic com/trolmastercard/velvet/g.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 068: athrow
      // 069: aload 1
      // 06a: checkcast net/minecraft/entity/passive/EntityHorse
      // 06d: invokevirtual net/minecraft/entity/passive/EntityHorse.func_110257_ck ()Z
      // 070: ifeq 087
      // 073: goto 07a
      // 076: invokestatic com/trolmastercard/velvet/g.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 079: athrow
      // 07a: aload 0
      // 07b: aload 1
      // 07c: putfield com/trolmastercard/velvet/g.o Lnet/minecraft/entity/Entity;
      // 07f: getstatic com/trolmastercard/velvet/f$a.RIDE Lcom/trolmastercard/velvet/f$a;
      // 082: areturn
      // 083: invokestatic com/trolmastercard/velvet/g.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 086: athrow
      // 087: goto 0ef
      // 08a: aload 0
      // 08b: getfield com/trolmastercard/velvet/g.a Lnet/minecraft/entity/player/EntityPlayer;
      // 08e: invokevirtual net/minecraft/entity/player/EntityPlayer.func_184218_aH ()Z
      // 091: ifne 0a5
      // 094: aload 0
      // 095: getfield com/trolmastercard/velvet/g.q Lcom/trolmastercard/velvet/e2;
      // 098: invokevirtual com/trolmastercard/velvet/e2.func_184218_aH ()Z
      // 09b: ifne 0c7
      // 09e: goto 0a5
      // 0a1: invokestatic com/trolmastercard/velvet/g.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 0a4: athrow
      // 0a5: aload 0
      // 0a6: getfield com/trolmastercard/velvet/g.f Lcom/trolmastercard/velvet/f$a;
      // 0a9: getstatic com/trolmastercard/velvet/f$a.RIDE Lcom/trolmastercard/velvet/f$a;
      // 0ac: if_acmpne 0ef
      // 0af: goto 0b6
      // 0b2: invokestatic com/trolmastercard/velvet/g.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 0b5: athrow
      // 0b6: aload 0
      // 0b7: getfield com/trolmastercard/velvet/g.a Lnet/minecraft/entity/player/EntityPlayer;
      // 0ba: invokevirtual net/minecraft/entity/player/EntityPlayer.func_184218_aH ()Z
      // 0bd: ifne 0ef
      // 0c0: goto 0c7
      // 0c3: invokestatic com/trolmastercard/velvet/g.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 0c6: athrow
      // 0c7: aload 0
      // 0c8: getfield com/trolmastercard/velvet/g.q Lcom/trolmastercard/velvet/e2;
      // 0cb: getstatic com/trolmastercard/velvet/fp.NULL Lcom/trolmastercard/velvet/fp;
      // 0ce: invokevirtual com/trolmastercard/velvet/e2.b (Lcom/trolmastercard/velvet/fp;)V
      // 0d1: aload 0
      // 0d2: getfield com/trolmastercard/velvet/g.q Lcom/trolmastercard/velvet/e2;
      // 0d5: invokevirtual com/trolmastercard/velvet/e2.func_184210_p ()V
      // 0d8: aload 0
      // 0d9: getfield com/trolmastercard/velvet/g.q Lcom/trolmastercard/velvet/e2;
      // 0dc: bipush 0
      // 0dd: putfield com/trolmastercard/velvet/e2.field_70145_X Z
      // 0e0: aload 0
      // 0e1: getfield com/trolmastercard/velvet/g.q Lcom/trolmastercard/velvet/e2;
      // 0e4: bipush 0
      // 0e5: invokevirtual com/trolmastercard/velvet/e2.func_189654_d (Z)V
      // 0e8: goto 0ef
      // 0eb: invokestatic com/trolmastercard/velvet/g.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 0ee: athrow
      // 0ef: aload 0
      // 0f0: aload 0
      // 0f1: getfield com/trolmastercard/velvet/g.r Lnet/minecraft/entity/EntityLivingBase;
      // 0f4: invokevirtual com/trolmastercard/velvet/g.a (Lnet/minecraft/entity/EntityLivingBase;)Z
      // 0f7: ifeq 102
      // 0fa: getstatic com/trolmastercard/velvet/f$a.ATTACK Lcom/trolmastercard/velvet/f$a;
      // 0fd: areturn
      // 0fe: invokestatic com/trolmastercard/velvet/g.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 101: athrow
      // 102: aload 0
      // 103: getfield com/trolmastercard/velvet/g.q Lcom/trolmastercard/velvet/e2;
      // 106: invokevirtual com/trolmastercard/velvet/e2.func_189748_bU ()Lnet/minecraft/util/DamageSource;
      // 109: astore 2
      // 10a: aload 2
      // 10b: ifnull 12b
      // 10e: aload 2
      // 10f: invokevirtual net/minecraft/util/DamageSource.func_76346_g ()Lnet/minecraft/entity/Entity;
      // 112: checkcast net/minecraft/entity/EntityLivingBase
      // 115: astore 1
      // 116: aload 0
      // 117: aload 1
      // 118: invokevirtual com/trolmastercard/velvet/g.a (Lnet/minecraft/entity/EntityLivingBase;)Z
      // 11b: ifeq 12b
      // 11e: aload 0
      // 11f: aload 1
      // 120: putfield com/trolmastercard/velvet/g.r Lnet/minecraft/entity/EntityLivingBase;
      // 123: getstatic com/trolmastercard/velvet/f$a.ATTACK Lcom/trolmastercard/velvet/f$a;
      // 126: areturn
      // 127: invokestatic com/trolmastercard/velvet/g.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 12a: athrow
      // 12b: aload 0
      // 12c: getfield com/trolmastercard/velvet/g.a Lnet/minecraft/entity/player/EntityPlayer;
      // 12f: invokevirtual net/minecraft/entity/player/EntityPlayer.func_110144_aD ()Lnet/minecraft/entity/EntityLivingBase;
      // 132: astore 1
      // 133: aload 0
      // 134: getfield com/trolmastercard/velvet/g.a Lnet/minecraft/entity/player/EntityPlayer;
      // 137: getfield net/minecraft/entity/player/EntityPlayer.field_70173_aa I
      // 13a: aload 0
      // 13b: getfield com/trolmastercard/velvet/g.a Lnet/minecraft/entity/player/EntityPlayer;
      // 13e: invokevirtual net/minecraft/entity/player/EntityPlayer.func_142013_aG ()I
      // 141: isub
      // 142: sipush 140
      // 145: if_icmpge 164
      // 148: aload 0
      // 149: aload 1
      // 14a: invokevirtual com/trolmastercard/velvet/g.a (Lnet/minecraft/entity/EntityLivingBase;)Z
      // 14d: ifeq 164
      // 150: goto 157
      // 153: invokestatic com/trolmastercard/velvet/g.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 156: athrow
      // 157: aload 0
      // 158: aload 1
      // 159: putfield com/trolmastercard/velvet/g.r Lnet/minecraft/entity/EntityLivingBase;
      // 15c: getstatic com/trolmastercard/velvet/f$a.ATTACK Lcom/trolmastercard/velvet/f$a;
      // 15f: areturn
      // 160: invokestatic com/trolmastercard/velvet/g.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 163: athrow
      // 164: aload 0
      // 165: getfield com/trolmastercard/velvet/g.f Lcom/trolmastercard/velvet/f$a;
      // 168: getstatic com/trolmastercard/velvet/f$a.FOLLOW Lcom/trolmastercard/velvet/f$a;
      // 16b: if_acmpeq 23e
      // 16e: aload 0
      // 16f: getfield com/trolmastercard/velvet/g.a Lnet/minecraft/entity/player/EntityPlayer;
      // 172: invokevirtual net/minecraft/entity/player/EntityPlayer.func_189748_bU ()Lnet/minecraft/util/DamageSource;
      // 175: astore 2
      // 176: aload 2
      // 177: ifnull 197
      // 17a: aload 2
      // 17b: invokevirtual net/minecraft/util/DamageSource.func_76346_g ()Lnet/minecraft/entity/Entity;
      // 17e: checkcast net/minecraft/entity/EntityLivingBase
      // 181: astore 1
      // 182: aload 0
      // 183: aload 1
      // 184: invokevirtual com/trolmastercard/velvet/g.a (Lnet/minecraft/entity/EntityLivingBase;)Z
      // 187: ifeq 197
      // 18a: aload 0
      // 18b: aload 1
      // 18c: putfield com/trolmastercard/velvet/g.r Lnet/minecraft/entity/EntityLivingBase;
      // 18f: getstatic com/trolmastercard/velvet/f$a.ATTACK Lcom/trolmastercard/velvet/f$a;
      // 192: areturn
      // 193: invokestatic com/trolmastercard/velvet/g.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 196: athrow
      // 197: aload 0
      // 198: getfield com/trolmastercard/velvet/g.q Lcom/trolmastercard/velvet/e2;
      // 19b: invokevirtual com/trolmastercard/velvet/e2.func_174791_d ()Lnet/minecraft/util/math/Vec3d;
      // 19e: astore 3
      // 19f: new net/minecraft/util/math/AxisAlignedBB
      // 1a2: dup
      // 1a3: aload 3
      // 1a4: getfield net/minecraft/util/math/Vec3d.field_72450_a D
      // 1a7: ldc2_w 5.0
      // 1aa: dsub
      // 1ab: aload 3
      // 1ac: getfield net/minecraft/util/math/Vec3d.field_72448_b D
      // 1af: ldc2_w 2.0
      // 1b2: dsub
      // 1b3: aload 3
      // 1b4: getfield net/minecraft/util/math/Vec3d.field_72449_c D
      // 1b7: ldc2_w 5.0
      // 1ba: dsub
      // 1bb: aload 3
      // 1bc: getfield net/minecraft/util/math/Vec3d.field_72450_a D
      // 1bf: ldc2_w 5.0
      // 1c2: dadd
      // 1c3: aload 3
      // 1c4: getfield net/minecraft/util/math/Vec3d.field_72448_b D
      // 1c7: ldc2_w 2.0
      // 1ca: dadd
      // 1cb: aload 3
      // 1cc: getfield net/minecraft/util/math/Vec3d.field_72449_c D
      // 1cf: ldc2_w 5.0
      // 1d2: dadd
      // 1d3: invokespecial net/minecraft/util/math/AxisAlignedBB.<init> (DDDDDD)V
      // 1d6: astore 4
      // 1d8: aload 0
      // 1d9: getfield com/trolmastercard/velvet/g.q Lcom/trolmastercard/velvet/e2;
      // 1dc: getfield com/trolmastercard/velvet/e2.field_70170_p Lnet/minecraft/world/World;
      // 1df: ldc_w net/minecraft/entity/monster/EntityMob
      // 1e2: aload 4
      // 1e4: invokevirtual net/minecraft/world/World.func_72872_a (Ljava/lang/Class;Lnet/minecraft/util/math/AxisAlignedBB;)Ljava/util/List;
      // 1e7: astore 5
      // 1e9: aload 5
      // 1eb: aload 0
      // 1ec: invokedynamic compare (Lcom/trolmastercard/velvet/g;)Ljava/util/Comparator; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ (Ljava/lang/Object;Ljava/lang/Object;)I, com/trolmastercard/velvet/g.lambda$updateMode$0 (Lnet/minecraft/entity/monster/EntityMob;Lnet/minecraft/entity/monster/EntityMob;)I, (Lnet/minecraft/entity/monster/EntityMob;Lnet/minecraft/entity/monster/EntityMob;)I ]
      // 1f1: invokeinterface java/util/List.sort (Ljava/util/Comparator;)V 2
      // 1f6: aload 5
      // 1f8: invokeinterface java/util/List.iterator ()Ljava/util/Iterator; 1
      // 1fd: astore 6
      // 1ff: aload 6
      // 201: invokeinterface java/util/Iterator.hasNext ()Z 1
      // 206: ifeq 23e
      // 209: aload 6
      // 20b: invokeinterface java/util/Iterator.next ()Ljava/lang/Object; 1
      // 210: checkcast net/minecraft/entity/monster/EntityMob
      // 213: astore 7
      // 215: aload 0
      // 216: aload 7
      // 218: invokevirtual com/trolmastercard/velvet/g.a (Lnet/minecraft/entity/EntityLivingBase;)Z
      // 21b: ifeq 23b
      // 21e: aload 7
      // 220: instanceof net/minecraft/entity/monster/EntityCreeper
      // 223: ifne 23b
      // 226: goto 22d
      // 229: invokestatic com/trolmastercard/velvet/g.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 22c: athrow
      // 22d: aload 0
      // 22e: aload 7
      // 230: putfield com/trolmastercard/velvet/g.r Lnet/minecraft/entity/EntityLivingBase;
      // 233: getstatic com/trolmastercard/velvet/f$a.ATTACK Lcom/trolmastercard/velvet/f$a;
      // 236: areturn
      // 237: invokestatic com/trolmastercard/velvet/g.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 23a: athrow
      // 23b: goto 1ff
      // 23e: aload 0
      // 23f: getfield com/trolmastercard/velvet/g.q Lcom/trolmastercard/velvet/e2;
      // 242: aload 0
      // 243: getfield com/trolmastercard/velvet/g.a Lnet/minecraft/entity/player/EntityPlayer;
      // 246: invokevirtual com/trolmastercard/velvet/e2.func_70032_d (Lnet/minecraft/entity/Entity;)F
      // 249: fstore 3
      // 24a: fload 3
      // 24b: ldc_w 5.0
      // 24e: fcmpl
      // 24f: ifle 25a
      // 252: bipush 1
      // 253: goto 25b
      // 256: invokestatic com/trolmastercard/velvet/g.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 259: athrow
      // 25a: bipush 0
      // 25b: istore 4
      // 25d: iload 4
      // 25f: ifne 298
      // 262: aload 0
      // 263: getfield com/trolmastercard/velvet/g.f Lcom/trolmastercard/velvet/f$a;
      // 266: getstatic com/trolmastercard/velvet/f$a.FOLLOW Lcom/trolmastercard/velvet/f$a;
      // 269: if_acmpne 298
      // 26c: goto 273
      // 26f: invokestatic com/trolmastercard/velvet/g.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 272: athrow
      // 273: aload 0
      // 274: dup
      // 275: getfield com/trolmastercard/velvet/g.m I
      // 278: bipush 1
      // 279: iadd
      // 27a: dup_x1
      // 27b: putfield com/trolmastercard/velvet/g.m I
      // 27e: bipush 60
      // 280: if_icmple 295
      // 283: goto 28a
      // 286: invokestatic com/trolmastercard/velvet/g.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 289: athrow
      // 28a: bipush 0
      // 28b: istore 4
      // 28d: aload 0
      // 28e: bipush 0
      // 28f: putfield com/trolmastercard/velvet/g.m I
      // 292: goto 298
      // 295: bipush 1
      // 296: istore 4
      // 298: iload 4
      // 29a: ifeq 2bb
      // 29d: aload 0
      // 29e: getfield com/trolmastercard/velvet/g.f Lcom/trolmastercard/velvet/f$a;
      // 2a1: getstatic com/trolmastercard/velvet/f$a.ATTACK Lcom/trolmastercard/velvet/f$a;
      // 2a4: if_acmpne 2bb
      // 2a7: goto 2ae
      // 2aa: invokestatic com/trolmastercard/velvet/g.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 2ad: athrow
      // 2ae: aload 0
      // 2af: bipush 60
      // 2b1: putfield com/trolmastercard/velvet/g.n I
      // 2b4: goto 2bb
      // 2b7: invokestatic com/trolmastercard/velvet/g.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 2ba: athrow
      // 2bb: iload 4
      // 2bd: ifeq 2c8
      // 2c0: getstatic com/trolmastercard/velvet/f$a.FOLLOW Lcom/trolmastercard/velvet/f$a;
      // 2c3: areturn
      // 2c4: invokestatic com/trolmastercard/velvet/g.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 2c7: athrow
      // 2c8: getstatic com/trolmastercard/velvet/f$a.IDLE Lcom/trolmastercard/velvet/f$a;
      // 2cb: areturn
      // try (0 -> 14): 15 java/lang/RuntimeException
      // try (10 -> 19): 19 java/lang/RuntimeException
      // try (29 -> 38): 39 java/lang/RuntimeException
      // try (33 -> 44): 45 java/lang/RuntimeException
      // try (41 -> 51): 52 java/lang/RuntimeException
      // try (47 -> 59): 59 java/lang/RuntimeException
      // try (62 -> 70): 71 java/lang/RuntimeException
      // try (66 -> 77): 78 java/lang/RuntimeException
      // try (73 -> 84): 85 java/lang/RuntimeException
      // try (80 -> 102): 103 java/lang/RuntimeException
      // try (105 -> 112): 112 java/lang/RuntimeException
      // try (124 -> 133): 133 java/lang/RuntimeException
      // try (139 -> 152): 153 java/lang/RuntimeException
      // try (148 -> 160): 160 java/lang/RuntimeException
      // try (176 -> 185): 185 java/lang/RuntimeException
      // try (240 -> 247): 248 java/lang/RuntimeException
      // try (244 -> 255): 255 java/lang/RuntimeException
      // try (264 -> 270): 270 java/lang/RuntimeException
      // try (274 -> 280): 281 java/lang/RuntimeException
      // try (276 -> 292): 293 java/lang/RuntimeException
      // try (303 -> 309): 310 java/lang/RuntimeException
      // try (305 -> 315): 316 java/lang/RuntimeException
      // try (318 -> 322): 322 java/lang/RuntimeException
   }

   public void e() {
      EntityArrow var1 = this.b();
      double var2 = this.r.field_70165_t - this.q.field_70165_t;
      double var4 = this.r.func_174813_aQ().field_72338_b + this.r.field_70131_O / 3.0F - var1.field_70163_u;
      double var6 = this.r.field_70161_v - this.q.field_70161_v;
      double var8 = MathHelper.func_76133_a(var2 * var2 + var6 * var6);
      var1.func_70186_c(var2, var4 + var8 * 0.2F, var6, 1.6F, 2.0F);
      this.q.func_184185_a(SoundEvents.field_187866_fi, 1.0F, 1.0F / (this.q.func_70681_au().nextFloat() * 0.4F + 0.8F));
      this.q.field_70170_p.func_72838_d(var1);
      var1.func_70239_b(4.5);
   }

   protected EntityArrow b() {
      EntityTippedArrow var1 = new EntityTippedArrow(this.q.field_70170_p, this.q);
      ItemStack var2 = this.q.Q.getStackInSlot(1);
      double var3 = EnchantmentHelper.func_77506_a(Enchantments.field_185309_u, var2);
      int var5 = EnchantmentHelper.func_77506_a(Enchantments.field_185310_v, var2);
      int var6 = EnchantmentHelper.func_77506_a(Enchantments.field_185311_w, var2);

      try {
         if (var3 != 0.0) {
            var1.func_70239_b(var1.func_70242_d() + var3 * 0.5 + 0.5);
         }
      } catch (RuntimeException var8) {
         throw a(var8);
      }

      try {
         if (var5 != 0) {
            var1.func_70240_a(var5);
         }
      } catch (RuntimeException var9) {
         throw a(var9);
      }

      try {
         if (var6 != 0) {
            var1.func_70015_d(100);
         }

         return var1;
      } catch (RuntimeException var7) {
         throw a(var7);
      }
   }

   void d() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 000: aload 0
      // 001: getfield com/trolmastercard/velvet/g.q Lcom/trolmastercard/velvet/e2;
      // 004: getstatic com/trolmastercard/velvet/fp.ATTACK Lcom/trolmastercard/velvet/fp;
      // 007: invokevirtual com/trolmastercard/velvet/e2.b (Lcom/trolmastercard/velvet/fp;)V
      // 00a: aload 0
      // 00b: getfield com/trolmastercard/velvet/g.e Lnet/minecraft/network/datasync/EntityDataManager;
      // 00e: getstatic com/trolmastercard/velvet/e2.M Lnet/minecraft/network/datasync/DataParameter;
      // 011: bipush 1
      // 012: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 015: invokevirtual net/minecraft/network/datasync/EntityDataManager.func_187227_b (Lnet/minecraft/network/datasync/DataParameter;Ljava/lang/Object;)V
      // 018: aload 0
      // 019: getfield com/trolmastercard/velvet/g.q Lcom/trolmastercard/velvet/e2;
      // 01c: getfield com/trolmastercard/velvet/e2.Q Lnet/minecraftforge/items/ItemStackHandler;
      // 01f: bipush 0
      // 020: invokevirtual net/minecraftforge/items/ItemStackHandler.getStackInSlot (I)Lnet/minecraft/item/ItemStack;
      // 023: astore 1
      // 024: aload 1
      // 025: getstatic net/minecraft/inventory/EntityEquipmentSlot.MAINHAND Lnet/minecraft/inventory/EntityEquipmentSlot;
      // 028: invokevirtual net/minecraft/item/ItemStack.func_111283_C (Lnet/minecraft/inventory/EntityEquipmentSlot;)Lcom/google/common/collect/Multimap;
      // 02b: astore 2
      // 02c: fconst_0
      // 02d: fstore 3
      // 02e: fconst_0
      // 02f: fstore 4
      // 031: aload 2
      // 032: getstatic net/minecraft/entity/SharedMonsterAttributes.field_111264_e Lnet/minecraft/entity/ai/attributes/IAttribute;
      // 035: invokeinterface net/minecraft/entity/ai/attributes/IAttribute.func_111108_a ()Ljava/lang/String; 1
      // 03a: invokeinterface com/google/common/collect/Multimap.get (Ljava/lang/Object;)Ljava/util/Collection; 2
      // 03f: invokeinterface java/util/Collection.iterator ()Ljava/util/Iterator; 1
      // 044: astore 5
      // 046: aload 5
      // 048: invokeinterface java/util/Iterator.hasNext ()Z 1
      // 04d: ifeq 066
      // 050: aload 5
      // 052: invokeinterface java/util/Iterator.next ()Ljava/lang/Object; 1
      // 057: checkcast net/minecraft/entity/ai/attributes/AttributeModifier
      // 05a: astore 6
      // 05c: aload 6
      // 05e: invokevirtual net/minecraft/entity/ai/attributes/AttributeModifier.func_111164_d ()D
      // 061: d2f
      // 062: fstore 3
      // 063: goto 046
      // 066: aload 2
      // 067: getstatic net/minecraft/entity/SharedMonsterAttributes.field_188790_f Lnet/minecraft/entity/ai/attributes/IAttribute;
      // 06a: invokeinterface net/minecraft/entity/ai/attributes/IAttribute.func_111108_a ()Ljava/lang/String; 1
      // 06f: invokeinterface com/google/common/collect/Multimap.get (Ljava/lang/Object;)Ljava/util/Collection; 2
      // 074: invokeinterface java/util/Collection.iterator ()Ljava/util/Iterator; 1
      // 079: astore 5
      // 07b: aload 5
      // 07d: invokeinterface java/util/Iterator.hasNext ()Z 1
      // 082: ifeq 09c
      // 085: aload 5
      // 087: invokeinterface java/util/Iterator.next ()Ljava/lang/Object; 1
      // 08c: checkcast net/minecraft/entity/ai/attributes/AttributeModifier
      // 08f: astore 6
      // 091: aload 6
      // 093: invokevirtual net/minecraft/entity/ai/attributes/AttributeModifier.func_111164_d ()D
      // 096: d2f
      // 097: fstore 4
      // 099: goto 07b
      // 09c: fload 4
      // 09e: ldc_w 0.5
      // 0a1: invokestatic java/lang/Math.max (FF)F
      // 0a4: fstore 4
      // 0a6: aload 1
      // 0a7: aload 0
      // 0a8: getfield com/trolmastercard/velvet/g.r Lnet/minecraft/entity/EntityLivingBase;
      // 0ab: invokevirtual net/minecraft/entity/EntityLivingBase.func_70668_bt ()Lnet/minecraft/entity/EnumCreatureAttribute;
      // 0ae: invokestatic net/minecraft/enchantment/EnchantmentHelper.func_152377_a (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/EnumCreatureAttribute;)F
      // 0b1: fstore 5
      // 0b3: getstatic net/minecraft/init/Enchantments.field_180313_o Lnet/minecraft/enchantment/Enchantment;
      // 0b6: aload 1
      // 0b7: invokestatic net/minecraft/enchantment/EnchantmentHelper.func_77506_a (Lnet/minecraft/enchantment/Enchantment;Lnet/minecraft/item/ItemStack;)I
      // 0ba: istore 6
      // 0bc: getstatic net/minecraft/init/Enchantments.field_77334_n Lnet/minecraft/enchantment/Enchantment;
      // 0bf: aload 1
      // 0c0: invokestatic net/minecraft/enchantment/EnchantmentHelper.func_77506_a (Lnet/minecraft/enchantment/Enchantment;Lnet/minecraft/item/ItemStack;)I
      // 0c3: istore 7
      // 0c5: getstatic net/minecraft/init/Enchantments.field_191530_r Lnet/minecraft/enchantment/Enchantment;
      // 0c8: aload 1
      // 0c9: invokestatic net/minecraft/enchantment/EnchantmentHelper.func_77506_a (Lnet/minecraft/enchantment/Enchantment;Lnet/minecraft/item/ItemStack;)I
      // 0cc: istore 8
      // 0ce: aload 0
      // 0cf: getfield com/trolmastercard/velvet/g.r Lnet/minecraft/entity/EntityLivingBase;
      // 0d2: aload 0
      // 0d3: getfield com/trolmastercard/velvet/g.q Lcom/trolmastercard/velvet/e2;
      // 0d6: iload 6
      // 0d8: i2f
      // 0d9: ldc_w 0.5
      // 0dc: fmul
      // 0dd: aload 0
      // 0de: getfield com/trolmastercard/velvet/g.q Lcom/trolmastercard/velvet/e2;
      // 0e1: getfield com/trolmastercard/velvet/e2.field_70177_z F
      // 0e4: ldc_w 0.017453292
      // 0e7: fmul
      // 0e8: invokestatic net/minecraft/util/math/MathHelper.func_76126_a (F)F
      // 0eb: f2d
      // 0ec: aload 0
      // 0ed: getfield com/trolmastercard/velvet/g.q Lcom/trolmastercard/velvet/e2;
      // 0f0: getfield com/trolmastercard/velvet/e2.field_70177_z F
      // 0f3: ldc_w 0.017453292
      // 0f6: fmul
      // 0f7: invokestatic net/minecraft/util/math/MathHelper.func_76134_b (F)F
      // 0fa: fneg
      // 0fb: f2d
      // 0fc: invokevirtual net/minecraft/entity/EntityLivingBase.func_70653_a (Lnet/minecraft/entity/Entity;FDD)V
      // 0ff: aload 0
      // 100: getfield com/trolmastercard/velvet/g.r Lnet/minecraft/entity/EntityLivingBase;
      // 103: iload 7
      // 105: bipush 4
      // 106: imul
      // 107: invokevirtual net/minecraft/entity/EntityLivingBase.func_70015_d (I)V
      // 10a: iload 8
      // 10c: ifeq 201
      // 10f: ldc_w 0.5
      // 112: fstore 9
      // 114: iload 8
      // 116: bipush 2
      // 117: if_icmpne 122
      // 11a: ldc_w 0.67
      // 11d: fstore 9
      // 11f: goto 12d
      // 122: iload 8
      // 124: bipush 3
      // 125: if_icmpne 12d
      // 128: ldc_w 0.75
      // 12b: fstore 9
      // 12d: aload 0
      // 12e: getfield com/trolmastercard/velvet/g.q Lcom/trolmastercard/velvet/e2;
      // 131: getfield com/trolmastercard/velvet/e2.field_70170_p Lnet/minecraft/world/World;
      // 134: ldc net/minecraft/entity/EntityLivingBase
      // 136: aload 0
      // 137: getfield com/trolmastercard/velvet/g.r Lnet/minecraft/entity/EntityLivingBase;
      // 13a: invokevirtual net/minecraft/entity/EntityLivingBase.func_174813_aQ ()Lnet/minecraft/util/math/AxisAlignedBB;
      // 13d: dconst_1
      // 13e: ldc2_w 0.25
      // 141: dconst_1
      // 142: invokevirtual net/minecraft/util/math/AxisAlignedBB.func_72314_b (DDD)Lnet/minecraft/util/math/AxisAlignedBB;
      // 145: invokevirtual net/minecraft/world/World.func_72872_a (Ljava/lang/Class;Lnet/minecraft/util/math/AxisAlignedBB;)Ljava/util/List;
      // 148: invokeinterface java/util/List.iterator ()Ljava/util/Iterator; 1
      // 14d: astore 10
      // 14f: aload 10
      // 151: invokeinterface java/util/Iterator.hasNext ()Z 1
      // 156: ifeq 201
      // 159: aload 10
      // 15b: invokeinterface java/util/Iterator.next ()Ljava/lang/Object; 1
      // 160: checkcast net/minecraft/entity/EntityLivingBase
      // 163: astore 11
      // 165: aload 11
      // 167: aload 0
      // 168: getfield com/trolmastercard/velvet/g.q Lcom/trolmastercard/velvet/e2;
      // 16b: if_acmpeq 1fe
      // 16e: aload 11
      // 170: aload 0
      // 171: getfield com/trolmastercard/velvet/g.a Lnet/minecraft/entity/player/EntityPlayer;
      // 174: if_acmpeq 1fe
      // 177: goto 17e
      // 17a: invokestatic com/trolmastercard/velvet/g.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 17d: athrow
      // 17e: aload 11
      // 180: aload 0
      // 181: getfield com/trolmastercard/velvet/g.r Lnet/minecraft/entity/EntityLivingBase;
      // 184: if_acmpeq 1fe
      // 187: goto 18e
      // 18a: invokestatic com/trolmastercard/velvet/g.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 18d: athrow
      // 18e: aload 0
      // 18f: getfield com/trolmastercard/velvet/g.q Lcom/trolmastercard/velvet/e2;
      // 192: aload 11
      // 194: invokevirtual com/trolmastercard/velvet/e2.func_184191_r (Lnet/minecraft/entity/Entity;)Z
      // 197: ifne 1fe
      // 19a: goto 1a1
      // 19d: invokestatic com/trolmastercard/velvet/g.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 1a0: athrow
      // 1a1: aload 0
      // 1a2: getfield com/trolmastercard/velvet/g.q Lcom/trolmastercard/velvet/e2;
      // 1a5: aload 11
      // 1a7: invokevirtual com/trolmastercard/velvet/e2.func_70068_e (Lnet/minecraft/entity/Entity;)D
      // 1aa: ldc2_w 9.0
      // 1ad: dcmpg
      // 1ae: ifge 1fe
      // 1b1: goto 1b8
      // 1b4: invokestatic com/trolmastercard/velvet/g.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 1b7: athrow
      // 1b8: aload 11
      // 1ba: aload 0
      // 1bb: getfield com/trolmastercard/velvet/g.q Lcom/trolmastercard/velvet/e2;
      // 1be: ldc_w 0.4
      // 1c1: aload 0
      // 1c2: getfield com/trolmastercard/velvet/g.q Lcom/trolmastercard/velvet/e2;
      // 1c5: getfield com/trolmastercard/velvet/e2.field_70177_z F
      // 1c8: ldc_w 0.017453292
      // 1cb: fmul
      // 1cc: invokestatic net/minecraft/util/math/MathHelper.func_76126_a (F)F
      // 1cf: f2d
      // 1d0: aload 0
      // 1d1: getfield com/trolmastercard/velvet/g.q Lcom/trolmastercard/velvet/e2;
      // 1d4: getfield com/trolmastercard/velvet/e2.field_70177_z F
      // 1d7: ldc_w 0.017453292
      // 1da: fmul
      // 1db: invokestatic net/minecraft/util/math/MathHelper.func_76134_b (F)F
      // 1de: fneg
      // 1df: f2d
      // 1e0: invokevirtual net/minecraft/entity/EntityLivingBase.func_70653_a (Lnet/minecraft/entity/Entity;FDD)V
      // 1e3: aload 11
      // 1e5: aload 0
      // 1e6: getfield com/trolmastercard/velvet/g.q Lcom/trolmastercard/velvet/e2;
      // 1e9: invokestatic net/minecraft/util/DamageSource.func_76358_a (Lnet/minecraft/entity/EntityLivingBase;)Lnet/minecraft/util/DamageSource;
      // 1ec: fload 3
      // 1ed: fload 5
      // 1ef: fadd
      // 1f0: fload 9
      // 1f2: fmul
      // 1f3: invokevirtual net/minecraft/entity/EntityLivingBase.func_70097_a (Lnet/minecraft/util/DamageSource;F)Z
      // 1f6: pop
      // 1f7: goto 1fe
      // 1fa: invokestatic com/trolmastercard/velvet/g.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 1fd: athrow
      // 1fe: goto 14f
      // 201: aload 0
      // 202: getfield com/trolmastercard/velvet/g.r Lnet/minecraft/entity/EntityLivingBase;
      // 205: aload 0
      // 206: getfield com/trolmastercard/velvet/g.q Lcom/trolmastercard/velvet/e2;
      // 209: invokestatic net/minecraft/util/DamageSource.func_76358_a (Lnet/minecraft/entity/EntityLivingBase;)Lnet/minecraft/util/DamageSource;
      // 20c: fload 3
      // 20d: fload 5
      // 20f: fadd
      // 210: invokevirtual net/minecraft/entity/EntityLivingBase.func_70097_a (Lnet/minecraft/util/DamageSource;F)Z
      // 213: pop
      // 214: aload 0
      // 215: fload 4
      // 217: invokestatic java/lang/Math.abs (F)F
      // 21a: ldc_w 3.373494
      // 21d: fdiv
      // 21e: ldc_w 20.0
      // 221: fmul
      // 222: invokestatic java/lang/Math.round (F)I
      // 225: putfield com/trolmastercard/velvet/g.k I
      // 228: return
      // try (148 -> 156): 157 java/lang/RuntimeException
      // try (152 -> 163): 164 java/lang/RuntimeException
      // try (159 -> 171): 172 java/lang/RuntimeException
      // try (166 -> 181): 182 java/lang/RuntimeException
      // try (174 -> 215): 216 java/lang/RuntimeException
   }

   @Override
   protected double b() {
      double var1 = super.b();
      if (this.q.N) {
         var1 = 0.0;
      }

      this.c.func_75489_a(var1);
      this.q.a(this.q.q());
      return var1;
   }

   @Override
   public void func_75251_c() {
      super.func_75251_c();
      this.q.func_184212_Q().func_187227_b(e2.M, 0);
   }

   void a() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 00: aload 0
      // 01: getfield com/trolmastercard/velvet/g.q Lcom/trolmastercard/velvet/e2;
      // 04: getfield com/trolmastercard/velvet/e2.field_70122_E Z
      // 07: ifne 49
      // 0a: aload 0
      // 0b: getfield com/trolmastercard/velvet/g.q Lcom/trolmastercard/velvet/e2;
      // 0e: invokevirtual com/trolmastercard/velvet/e2.func_70090_H ()Z
      // 11: ifne 49
      // 14: goto 1b
      // 17: invokestatic com/trolmastercard/velvet/g.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 1a: athrow
      // 1b: aload 0
      // 1c: getfield com/trolmastercard/velvet/g.q Lcom/trolmastercard/velvet/e2;
      // 1f: getfield com/trolmastercard/velvet/e2.field_70159_w D
      // 22: aload 0
      // 23: getfield com/trolmastercard/velvet/g.q Lcom/trolmastercard/velvet/e2;
      // 26: getfield com/trolmastercard/velvet/e2.field_70179_y D
      // 29: dadd
      // 2a: dconst_0
      // 2b: dcmpl
      // 2c: ifne 49
      // 2f: goto 36
      // 32: invokestatic com/trolmastercard/velvet/g.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 35: athrow
      // 36: aload 0
      // 37: getfield com/trolmastercard/velvet/g.q Lcom/trolmastercard/velvet/e2;
      // 3a: getfield com/trolmastercard/velvet/e2.field_70181_x D
      // 3d: dconst_0
      // 3e: dcmpg
      // 3f: ifgt 4e
      // 42: goto 49
      // 45: invokestatic com/trolmastercard/velvet/g.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 48: athrow
      // 49: return
      // 4a: invokestatic com/trolmastercard/velvet/g.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 4d: athrow
      // 4e: new net/minecraft/util/math/Vec3d
      // 51: dup
      // 52: dconst_0
      // 53: dconst_0
      // 54: ldc2_w 0.10000000149011612
      // 57: invokespecial net/minecraft/util/math/Vec3d.<init> (DDD)V
      // 5a: astore 1
      // 5b: aload 1
      // 5c: aload 0
      // 5d: getfield com/trolmastercard/velvet/g.q Lcom/trolmastercard/velvet/e2;
      // 60: getfield com/trolmastercard/velvet/e2.field_70177_z F
      // 63: invokestatic com/trolmastercard/velvet/ck.a (Lnet/minecraft/util/math/Vec3d;F)Lnet/minecraft/util/math/Vec3d;
      // 66: astore 1
      // 67: aload 0
      // 68: getfield com/trolmastercard/velvet/g.q Lcom/trolmastercard/velvet/e2;
      // 6b: aload 1
      // 6c: getfield net/minecraft/util/math/Vec3d.field_72450_a D
      // 6f: putfield com/trolmastercard/velvet/e2.field_70159_w D
      // 72: aload 0
      // 73: getfield com/trolmastercard/velvet/g.q Lcom/trolmastercard/velvet/e2;
      // 76: aload 1
      // 77: getfield net/minecraft/util/math/Vec3d.field_72449_c D
      // 7a: putfield com/trolmastercard/velvet/e2.field_70179_y D
      // 7d: return
      // try (0 -> 8): 9 java/lang/RuntimeException
      // try (4 -> 21): 22 java/lang/RuntimeException
      // try (11 -> 30): 31 java/lang/RuntimeException
      // try (24 -> 34): 34 java/lang/RuntimeException
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   public static class a {
      @SubscribeEvent
      public void a(LivingHurtEvent param1) {
         // $VF: Couldn't be decompiled
         // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
         // java.lang.RuntimeException: parsing failure!
         //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
         //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
         //
         // Bytecode:
         // 00: aload 1
         // 01: invokevirtual net/minecraftforge/event/entity/living/LivingHurtEvent.getEntityLiving ()Lnet/minecraft/entity/EntityLivingBase;
         // 04: instanceof com/trolmastercard/velvet/e2
         // 07: ifeq 73
         // 0a: aload 1
         // 0b: invokevirtual net/minecraftforge/event/entity/living/LivingHurtEvent.getEntityLiving ()Lnet/minecraft/entity/EntityLivingBase;
         // 0e: checkcast com/trolmastercard/velvet/e2
         // 11: astore 2
         // 12: aload 2
         // 13: getfield com/trolmastercard/velvet/e2.N Z
         // 16: ifeq 25
         // 19: aload 1
         // 1a: bipush 1
         // 1b: invokevirtual net/minecraftforge/event/entity/living/LivingHurtEvent.setCanceled (Z)V
         // 1e: goto 73
         // 21: invokestatic com/trolmastercard/velvet/g$a.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
         // 24: athrow
         // 25: aload 2
         // 26: invokevirtual com/trolmastercard/velvet/e2.func_110143_aJ ()F
         // 29: aload 1
         // 2a: invokevirtual net/minecraftforge/event/entity/living/LivingHurtEvent.getAmount ()F
         // 2d: fsub
         // 2e: fconst_0
         // 2f: fcmpg
         // 30: ifge 73
         // 33: aload 2
         // 34: invokevirtual com/trolmastercard/velvet/e2.func_184212_Q ()Lnet/minecraft/network/datasync/EntityDataManager;
         // 37: getstatic com/trolmastercard/velvet/e2.v Lnet/minecraft/network/datasync/DataParameter;
         // 3a: invokevirtual net/minecraft/network/datasync/EntityDataManager.func_187225_a (Lnet/minecraft/network/datasync/DataParameter;)Ljava/lang/Object;
         // 3d: checkcast java/lang/String
         // 40: ldc ""
         // 42: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
         // 45: ifne 73
         // 48: goto 4f
         // 4b: invokestatic com/trolmastercard/velvet/g$a.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
         // 4e: athrow
         // 4f: aload 2
         // 50: bipush 1
         // 51: putfield com/trolmastercard/velvet/e2.N Z
         // 54: aload 2
         // 55: getstatic com/trolmastercard/velvet/fp.DOWNED Lcom/trolmastercard/velvet/fp;
         // 58: invokevirtual com/trolmastercard/velvet/e2.b (Lcom/trolmastercard/velvet/fp;)V
         // 5b: aload 1
         // 5c: aload 2
         // 5d: invokevirtual com/trolmastercard/velvet/e2.func_110143_aJ ()F
         // 60: fconst_1
         // 61: fsub
         // 62: invokevirtual net/minecraftforge/event/entity/living/LivingHurtEvent.setAmount (F)V
         // 65: aload 2
         // 66: invokevirtual com/trolmastercard/velvet/e2.func_70661_as ()Lnet/minecraft/pathfinding/PathNavigate;
         // 69: invokevirtual net/minecraft/pathfinding/PathNavigate.func_75499_g ()V
         // 6c: goto 73
         // 6f: invokestatic com/trolmastercard/velvet/g$a.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
         // 72: athrow
         // 73: return
         // try (8 -> 15): 15 java/lang/RuntimeException
         // try (17 -> 33): 34 java/lang/RuntimeException
         // try (25 -> 51): 52 java/lang/RuntimeException
      }

      @SubscribeEvent
      public void a(LivingHealEvent param1) {
         // $VF: Couldn't be decompiled
         // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
         // java.lang.RuntimeException: parsing failure!
         //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
         //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
         //
         // Bytecode:
         // 00: aload 1
         // 01: invokevirtual net/minecraftforge/event/entity/living/LivingHealEvent.getEntityLiving ()Lnet/minecraft/entity/EntityLivingBase;
         // 04: instanceof com/trolmastercard/velvet/e2
         // 07: ifeq 44
         // 0a: aload 1
         // 0b: invokevirtual net/minecraftforge/event/entity/living/LivingHealEvent.getEntityLiving ()Lnet/minecraft/entity/EntityLivingBase;
         // 0e: checkcast com/trolmastercard/velvet/e2
         // 11: astore 2
         // 12: aload 2
         // 13: getfield com/trolmastercard/velvet/e2.N Z
         // 16: ifeq 44
         // 19: aload 2
         // 1a: invokevirtual com/trolmastercard/velvet/e2.func_110143_aJ ()F
         // 1d: aload 1
         // 1e: invokevirtual net/minecraftforge/event/entity/living/LivingHealEvent.getAmount ()F
         // 21: fadd
         // 22: aload 2
         // 23: invokevirtual com/trolmastercard/velvet/e2.func_110138_aP ()F
         // 26: fcmpl
         // 27: iflt 44
         // 2a: goto 31
         // 2d: invokestatic com/trolmastercard/velvet/g$a.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
         // 30: athrow
         // 31: aload 2
         // 32: bipush 0
         // 33: putfield com/trolmastercard/velvet/e2.N Z
         // 36: aload 2
         // 37: getstatic com/trolmastercard/velvet/fp.NULL Lcom/trolmastercard/velvet/fp;
         // 3a: invokevirtual com/trolmastercard/velvet/e2.b (Lcom/trolmastercard/velvet/fp;)V
         // 3d: goto 44
         // 40: invokestatic com/trolmastercard/velvet/g$a.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
         // 43: athrow
         // 44: return
         // try (8 -> 20): 21 java/lang/RuntimeException
         // try (11 -> 29): 30 java/lang/RuntimeException
      }

      @SubscribeEvent
      public void a(LivingDeathEvent var1) {
         if (var1.getEntityLiving() instanceof e2) {
            e2 var2 = (e2)var1.getEntityLiving();

            try {
               if (var2.field_70170_p.field_72995_K) {
                  return;
               }
            } catch (RuntimeException var6) {
               throw a(var6);
            }

            for (int var3 = 0; var3 < 6; var3++) {
               Item var4 = var2.Q.getStackInSlot(var3).func_77973_b();

               try {
                  if (var4 != Items.field_190931_a) {
                     var2.func_145779_a(var4, 1);
                  }
               } catch (RuntimeException var5) {
                  throw a(var5);
               }
            }
         }
      }

      private static RuntimeException a(RuntimeException var0) {
         return var0;
      }
   }
}
