package org.velvet;

import java.util.Random;
import net.minecraft.util.math.Vec3d;

public class r {
   public static final String l = "velvet";
   public static final String g = "Fapcraft";
   public static final String h = "1.1.5";
   public static final String d = "org.velvet.ClientProxy";
   public static final String c = "org.velvet.CommonProxy";
   public static final Random f = new Random();
   public static int b = 0;
   public static int i = 0;
   public static final int a = 4674237;
   public static final int e = 6281823;
   public static Vec3d j = Vec3d.field_186680_a;
   public static Vec3d k = Vec3d.field_186680_a;
}
