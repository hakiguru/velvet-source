package org.velvet;

import net.minecraft.util.ResourceLocation;

public class c5 extends cv {
   @Override
   protected ResourceLocation[] a() {
      return new ResourceLocation[]{
         new ResourceLocation("velvet", "geo/jenny/jennynude.geo.json"), new ResourceLocation("velvet", "geo/jenny/jennydressed.geo.json")
      };
   }

   @Override
   public ResourceLocation b() {
      return new ResourceLocation("velvet", "textures/entity/jenny/jenny.png");
   }

   @Override
   public ResourceLocation b(em var1) {
      return new ResourceLocation("velvet", "animations/jenny/jenny.animation.json");
   }

   @Override
   public String[] c() {
      return new String[]{"armorHelmet"};
   }

   @Override
   public String[] f() {
      return new String[]{"armorShoulderR", "armorShoulderL", "armorChest", "armorBoobs"};
   }

   @Override
   public String[] a() {
      return new String[]{"boobsFlesh", "upperBodyL", "upperBodyR"};
   }

   @Override
   public String[] h() {
      return new String[]{"armorBootyR", "armorBootyL", "armorPantsLowL", "armorPantsLowR", "armorPantsLowR", "armorPantsUpR", "armorPantsUpL", "armorHip"};
   }

   @Override
   public String[] e() {
      return new String[]{"fleshL", "fleshR", "vagina", "curvesL", "curvesR", "kneeL", "kneeR"};
   }

   @Override
   public String[] b() {
      return new String[]{"armorShoesL", "armorShoesR"};
   }
}
