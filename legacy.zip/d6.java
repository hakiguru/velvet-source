package org.velvet;

import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.block.model.ItemCameraTransforms.TransformType;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Vec3i;
import org.lwjgl.opengl.GL11;
import software.bernie.geckolib3.geo.render.built.GeoBone;
import software.bernie.geckolib3.geo.render.built.GeoCube;
import software.bernie.geckolib3.model.AnimatedGeoModel;
import software.bernie.geckolib3.renderers.geo.IGeoRenderer;

public abstract class d6<G extends e4> extends d_<G> {
   protected static final Vec3i r = new Vec3i(255, 255, 255);
   static HashMap<Integer, Vec3i> s = new HashMap<>();

   public d6(RenderManager var1, AnimatedGeoModel var2, double var3) {
      super(var1, var2, var3);
   }

   public static void c() {
      s.clear();
   }

   protected Vec3i a(GeoBone var1) {
      String var2 = var1.getName();
      int var3 = var2.hashCode() + this.j.getPersistentID().hashCode();
      Vec3i var4 = s.get(var3);

      try {
         if (var4 != null) {
            return var4;
         }
      } catch (RuntimeException var5) {
         throw c(var5);
      }

      var4 = this.a(var2);
      s.put(var3, var4);
      return var4;
   }

   protected abstract Vec3i a(String var1);

   protected static void b(GeoBone var0, int var1) {
      List var2 = var0.childBones;

      for (int var4 = 0; var4 < var2.size(); var4++) {
         GeoBone var5 = (GeoBone)var2.get(var4);
         if (var1 == var4) {
            GeoBone var3 = var5;
            var3.setHidden(false);
            return;
         }
      }
   }

   @Override
   protected void a(BufferBuilder var1, GeoBone var2) {
      ItemStack var3 = this.a((ItemStack)null);
      float var4 = this.a();
      Vec3d var5 = this.a(var3);

      try {
         if (var3 == null) {
            return;
         }
      } catch (RuntimeException var6) {
         throw c(var6);
      }

      GlStateManager.func_179094_E();
      Tessellator.func_178181_a().func_78381_a();
      org.velvet.p.a(IGeoRenderer.MATRIX_STACK, var2);
      GL11.glEnable(2896);
      GlStateManager.func_179152_a(var4, var4, var4);
      GlStateManager.func_179114_b((float)var5.field_72450_a, 1.0F, 0.0F, 0.0F);
      GlStateManager.func_179114_b((float)var5.field_72448_b, 0.0F, 1.0F, 0.0F);
      GlStateManager.func_179114_b((float)var5.field_72449_c, 0.0F, 0.0F, 1.0F);
      Minecraft.func_71410_x().func_175597_ag().func_178099_a(this.j, var3, TransformType.THIRD_PERSON_RIGHT_HAND);
      this.func_110776_a(Objects.requireNonNull(this.getEntityTexture(this.j)));
      var1.func_181668_a(7, DefaultVertexFormats.field_181712_l);
      GL11.glDisable(2896);
      GlStateManager.func_179121_F();
   }

   protected float a() {
      return 1.0F;
   }

   protected Vec3d a(ItemStack var1) {
      return new Vec3d(-90.0, 0.0, 0.0);
   }

   protected static GeoBone a(GeoBone var0, int var1) {
      List var2 = var0.childBones;
      GeoBone var3 = null;
      var2.sort(Comparator.comparingDouble(GeoBone::getPivotY));

      for (int var4 = 0; var4 < var2.size(); var4++) {
         GeoBone var5 = (GeoBone)var2.get(var4);
         if (var1 == var4) {
            var3 = var5;
            var3.setHidden(false);
         } else {
            var5.setHidden(true);
         }
      }

      return var3;
   }

   protected Vec3i a(Vec3i var1) {
      return var1;
   }

   @Override
   public void a(BufferBuilder param1, GeoBone param2, float param3, float param4, float param5, float param6, double param7) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 000: aload 0
      // 001: getfield com/trolmastercard/velvet/d6.j Lcom/trolmastercard/velvet/em;
      // 004: checkcast com/trolmastercard/velvet/e4
      // 007: getfield com/trolmastercard/velvet/e4.field_70170_p Lnet/minecraft/world/World;
      // 00a: instanceof com/trolmastercard/velvet/gj
      // 00d: ifeq 015
      // 010: return
      // 011: invokestatic com/trolmastercard/velvet/d6.c (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 014: athrow
      // 015: aload 2
      // 016: invokevirtual software/bernie/geckolib3/geo/render/built/GeoBone.getName ()Ljava/lang/String;
      // 019: astore 9
      // 01b: aload 9
      // 01d: ldc_w "weapon"
      // 020: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 023: ifeq 033
      // 026: aload 0
      // 027: aload 1
      // 028: aload 2
      // 029: invokevirtual com/trolmastercard/velvet/d6.a (Lnet/minecraft/client/renderer/BufferBuilder;Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;)V
      // 02c: goto 033
      // 02f: invokestatic com/trolmastercard/velvet/d6.c (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 032: athrow
      // 033: aload 9
      // 035: ldc_w "itemRenderer"
      // 038: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 03b: ifeq 062
      // 03e: aload 0
      // 03f: getfield com/trolmastercard/velvet/d6.j Lcom/trolmastercard/velvet/em;
      // 042: checkcast com/trolmastercard/velvet/e4
      // 045: invokevirtual com/trolmastercard/velvet/e4.y ()Lcom/trolmastercard/velvet/fp;
      // 048: getstatic com/trolmastercard/velvet/fp.PAYMENT Lcom/trolmastercard/velvet/fp;
      // 04b: if_acmpne 062
      // 04e: goto 055
      // 051: invokestatic com/trolmastercard/velvet/d6.c (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 054: athrow
      // 055: aload 0
      // 056: aload 1
      // 057: aload 2
      // 058: invokevirtual com/trolmastercard/velvet/d6.b (Lnet/minecraft/client/renderer/BufferBuilder;Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;)V
      // 05b: goto 062
      // 05e: invokestatic com/trolmastercard/velvet/d6.c (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 061: athrow
      // 062: aload 0
      // 063: aload 1
      // 064: aload 2
      // 065: invokevirtual software/bernie/geckolib3/geo/render/built/GeoBone.getName ()Ljava/lang/String;
      // 068: aload 2
      // 069: invokevirtual com/trolmastercard/velvet/d6.a (Lnet/minecraft/client/renderer/BufferBuilder;Ljava/lang/String;Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;)V
      // 06c: getstatic com/trolmastercard/velvet/d6.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 06f: invokevirtual software/bernie/geckolib3/util/MatrixStack.push ()V
      // 072: getstatic com/trolmastercard/velvet/d6.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 075: aload 2
      // 076: invokevirtual software/bernie/geckolib3/util/MatrixStack.translate (Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;)V
      // 079: getstatic com/trolmastercard/velvet/d6.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 07c: aload 2
      // 07d: invokevirtual software/bernie/geckolib3/util/MatrixStack.moveToPivot (Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;)V
      // 080: getstatic com/trolmastercard/velvet/d6.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 083: aload 2
      // 084: invokevirtual software/bernie/geckolib3/util/MatrixStack.rotate (Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;)V
      // 087: getstatic com/trolmastercard/velvet/d6.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 08a: aload 2
      // 08b: invokevirtual software/bernie/geckolib3/util/MatrixStack.scale (Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;)V
      // 08e: getstatic com/trolmastercard/velvet/d6.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 091: aload 2
      // 092: invokevirtual software/bernie/geckolib3/util/MatrixStack.moveBackFromPivot (Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;)V
      // 095: aload 2
      // 096: getfield software/bernie/geckolib3/geo/render/built/GeoBone.isHidden Z
      // 099: ifne 11c
      // 09c: aload 2
      // 09d: getfield software/bernie/geckolib3/geo/render/built/GeoBone.childCubes Ljava/util/List;
      // 0a0: invokeinterface java/util/List.iterator ()Ljava/util/Iterator; 1
      // 0a5: astore 10
      // 0a7: aload 10
      // 0a9: invokeinterface java/util/Iterator.hasNext ()Z 1
      // 0ae: ifeq 0e8
      // 0b1: aload 10
      // 0b3: invokeinterface java/util/Iterator.next ()Ljava/lang/Object; 1
      // 0b8: checkcast software/bernie/geckolib3/geo/render/built/GeoCube
      // 0bb: astore 11
      // 0bd: getstatic com/trolmastercard/velvet/d6.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 0c0: invokevirtual software/bernie/geckolib3/util/MatrixStack.push ()V
      // 0c3: invokestatic net/minecraft/client/renderer/GlStateManager.func_179094_E ()V
      // 0c6: aload 0
      // 0c7: aload 2
      // 0c8: putfield com/trolmastercard/velvet/d6.q Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;
      // 0cb: aload 0
      // 0cc: aload 1
      // 0cd: aload 11
      // 0cf: aload 2
      // 0d0: fload 3
      // 0d1: fload 4
      // 0d3: fload 5
      // 0d5: fload 6
      // 0d7: dload 7
      // 0d9: invokevirtual com/trolmastercard/velvet/d6.a (Lnet/minecraft/client/renderer/BufferBuilder;Lsoftware/bernie/geckolib3/geo/render/built/GeoCube;Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;FFFFD)V
      // 0dc: invokestatic net/minecraft/client/renderer/GlStateManager.func_179121_F ()V
      // 0df: getstatic com/trolmastercard/velvet/d6.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 0e2: invokevirtual software/bernie/geckolib3/util/MatrixStack.pop ()V
      // 0e5: goto 0a7
      // 0e8: aload 2
      // 0e9: getfield software/bernie/geckolib3/geo/render/built/GeoBone.childBones Ljava/util/List;
      // 0ec: invokeinterface java/util/List.iterator ()Ljava/util/Iterator; 1
      // 0f1: astore 10
      // 0f3: aload 10
      // 0f5: invokeinterface java/util/Iterator.hasNext ()Z 1
      // 0fa: ifeq 11c
      // 0fd: aload 10
      // 0ff: invokeinterface java/util/Iterator.next ()Ljava/lang/Object; 1
      // 104: checkcast software/bernie/geckolib3/geo/render/built/GeoBone
      // 107: astore 11
      // 109: aload 0
      // 10a: aload 1
      // 10b: aload 11
      // 10d: fload 3
      // 10e: fload 4
      // 110: fload 5
      // 112: fload 6
      // 114: dload 7
      // 116: invokevirtual com/trolmastercard/velvet/d6.a (Lnet/minecraft/client/renderer/BufferBuilder;Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;FFFFD)V
      // 119: goto 0f3
      // 11c: getstatic com/trolmastercard/velvet/d6.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 11f: invokevirtual software/bernie/geckolib3/util/MatrixStack.pop ()V
      // 122: return
      // try (0 -> 7): 7 java/lang/RuntimeException
      // try (12 -> 20): 21 java/lang/RuntimeException
      // try (23 -> 33): 34 java/lang/RuntimeException
      // try (27 -> 40): 41 java/lang/RuntimeException
   }

   @Override
   public void renderRecursively(BufferBuilder var1, GeoBone var2, float var3, float var4, float var5, float var6) {
      this.a(var1, var2, var3, var4, var5, var6, 0.0);
   }

   public void a(BufferBuilder param1, GeoCube param2, GeoBone param3, float param4, float param5, float param6, float param7, double param8) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 000: getstatic com/trolmastercard/velvet/d6.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 003: aload 2
      // 004: invokevirtual software/bernie/geckolib3/util/MatrixStack.moveToPivot (Lsoftware/bernie/geckolib3/geo/render/built/GeoCube;)V
      // 007: getstatic com/trolmastercard/velvet/d6.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 00a: aload 2
      // 00b: invokevirtual software/bernie/geckolib3/util/MatrixStack.rotate (Lsoftware/bernie/geckolib3/geo/render/built/GeoCube;)V
      // 00e: getstatic com/trolmastercard/velvet/d6.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 011: aload 2
      // 012: invokevirtual software/bernie/geckolib3/util/MatrixStack.moveBackFromPivot (Lsoftware/bernie/geckolib3/geo/render/built/GeoCube;)V
      // 015: aload 2
      // 016: getfield software/bernie/geckolib3/geo/render/built/GeoCube.quads [Lsoftware/bernie/geckolib3/geo/render/built/GeoQuad;
      // 019: astore 10
      // 01b: aload 10
      // 01d: arraylength
      // 01e: istore 11
      // 020: bipush 0
      // 021: istore 12
      // 023: iload 12
      // 025: iload 11
      // 027: if_icmpge 222
      // 02a: aload 10
      // 02c: iload 12
      // 02e: aaload
      // 02f: astore 13
      // 031: aload 13
      // 033: ifnonnull 03d
      // 036: goto 21c
      // 039: invokestatic com/trolmastercard/velvet/d6.c (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 03c: athrow
      // 03d: new javax/vecmath/Vector3f
      // 040: dup
      // 041: aload 13
      // 043: getfield software/bernie/geckolib3/geo/render/built/GeoQuad.normal Lnet/minecraft/util/math/Vec3i;
      // 046: invokevirtual net/minecraft/util/math/Vec3i.func_177958_n ()I
      // 049: i2f
      // 04a: aload 13
      // 04c: getfield software/bernie/geckolib3/geo/render/built/GeoQuad.normal Lnet/minecraft/util/math/Vec3i;
      // 04f: invokevirtual net/minecraft/util/math/Vec3i.func_177956_o ()I
      // 052: i2f
      // 053: aload 13
      // 055: getfield software/bernie/geckolib3/geo/render/built/GeoQuad.normal Lnet/minecraft/util/math/Vec3i;
      // 058: invokevirtual net/minecraft/util/math/Vec3i.func_177952_p ()I
      // 05b: i2f
      // 05c: invokespecial javax/vecmath/Vector3f.<init> (FFF)V
      // 05f: astore 14
      // 061: getstatic com/trolmastercard/velvet/d6.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 064: invokevirtual software/bernie/geckolib3/util/MatrixStack.getNormalMatrix ()Ljavax/vecmath/Matrix3f;
      // 067: aload 14
      // 069: invokevirtual javax/vecmath/Matrix3f.transform (Ljavax/vecmath/Tuple3f;)V
      // 06c: aload 2
      // 06d: getfield software/bernie/geckolib3/geo/render/built/GeoCube.size Ljavax/vecmath/Vector3f;
      // 070: getfield javax/vecmath/Vector3f.y F
      // 073: fconst_0
      // 074: fcmpl
      // 075: ifeq 08b
      // 078: aload 2
      // 079: getfield software/bernie/geckolib3/geo/render/built/GeoCube.size Ljavax/vecmath/Vector3f;
      // 07c: getfield javax/vecmath/Vector3f.z F
      // 07f: fconst_0
      // 080: fcmpl
      // 081: ifne 0b0
      // 084: goto 08b
      // 087: invokestatic com/trolmastercard/velvet/d6.c (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 08a: athrow
      // 08b: aload 14
      // 08d: invokevirtual javax/vecmath/Vector3f.getX ()F
      // 090: fconst_0
      // 091: fcmpg
      // 092: ifge 0b0
      // 095: goto 09c
      // 098: invokestatic com/trolmastercard/velvet/d6.c (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 09b: athrow
      // 09c: aload 14
      // 09e: dup
      // 09f: getfield javax/vecmath/Vector3f.x F
      // 0a2: ldc_w -1.0
      // 0a5: fmul
      // 0a6: putfield javax/vecmath/Vector3f.x F
      // 0a9: goto 0b0
      // 0ac: invokestatic com/trolmastercard/velvet/d6.c (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 0af: athrow
      // 0b0: aload 2
      // 0b1: getfield software/bernie/geckolib3/geo/render/built/GeoCube.size Ljavax/vecmath/Vector3f;
      // 0b4: getfield javax/vecmath/Vector3f.x F
      // 0b7: fconst_0
      // 0b8: fcmpl
      // 0b9: ifeq 0cf
      // 0bc: aload 2
      // 0bd: getfield software/bernie/geckolib3/geo/render/built/GeoCube.size Ljavax/vecmath/Vector3f;
      // 0c0: getfield javax/vecmath/Vector3f.z F
      // 0c3: fconst_0
      // 0c4: fcmpl
      // 0c5: ifne 0f4
      // 0c8: goto 0cf
      // 0cb: invokestatic com/trolmastercard/velvet/d6.c (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 0ce: athrow
      // 0cf: aload 14
      // 0d1: invokevirtual javax/vecmath/Vector3f.getY ()F
      // 0d4: fconst_0
      // 0d5: fcmpg
      // 0d6: ifge 0f4
      // 0d9: goto 0e0
      // 0dc: invokestatic com/trolmastercard/velvet/d6.c (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 0df: athrow
      // 0e0: aload 14
      // 0e2: dup
      // 0e3: getfield javax/vecmath/Vector3f.y F
      // 0e6: ldc_w -1.0
      // 0e9: fmul
      // 0ea: putfield javax/vecmath/Vector3f.y F
      // 0ed: goto 0f4
      // 0f0: invokestatic com/trolmastercard/velvet/d6.c (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 0f3: athrow
      // 0f4: aload 2
      // 0f5: getfield software/bernie/geckolib3/geo/render/built/GeoCube.size Ljavax/vecmath/Vector3f;
      // 0f8: getfield javax/vecmath/Vector3f.x F
      // 0fb: fconst_0
      // 0fc: fcmpl
      // 0fd: ifeq 113
      // 100: aload 2
      // 101: getfield software/bernie/geckolib3/geo/render/built/GeoCube.size Ljavax/vecmath/Vector3f;
      // 104: getfield javax/vecmath/Vector3f.y F
      // 107: fconst_0
      // 108: fcmpl
      // 109: ifne 138
      // 10c: goto 113
      // 10f: invokestatic com/trolmastercard/velvet/d6.c (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 112: athrow
      // 113: aload 14
      // 115: invokevirtual javax/vecmath/Vector3f.getZ ()F
      // 118: fconst_0
      // 119: fcmpg
      // 11a: ifge 138
      // 11d: goto 124
      // 120: invokestatic com/trolmastercard/velvet/d6.c (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 123: athrow
      // 124: aload 14
      // 126: dup
      // 127: getfield javax/vecmath/Vector3f.z F
      // 12a: ldc_w -1.0
      // 12d: fmul
      // 12e: putfield javax/vecmath/Vector3f.z F
      // 131: goto 138
      // 134: invokestatic com/trolmastercard/velvet/d6.c (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 137: athrow
      // 138: aload 0
      // 139: aload 3
      // 13a: invokevirtual com/trolmastercard/velvet/d6.a (Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;)Lnet/minecraft/util/math/Vec3i;
      // 13d: astore 15
      // 13f: aload 0
      // 140: aload 15
      // 142: invokevirtual com/trolmastercard/velvet/d6.a (Lnet/minecraft/util/math/Vec3i;)Lnet/minecraft/util/math/Vec3i;
      // 145: astore 15
      // 147: aload 0
      // 148: aload 3
      // 149: new net/minecraft/util/math/Vec3d
      // 14c: dup
      // 14d: aload 15
      // 14f: invokevirtual net/minecraft/util/math/Vec3i.func_177958_n ()I
      // 152: i2f
      // 153: ldc_w 255.0
      // 156: fdiv
      // 157: f2d
      // 158: aload 15
      // 15a: invokevirtual net/minecraft/util/math/Vec3i.func_177956_o ()I
      // 15d: i2f
      // 15e: ldc_w 255.0
      // 161: fdiv
      // 162: f2d
      // 163: aload 15
      // 165: invokevirtual net/minecraft/util/math/Vec3i.func_177952_p ()I
      // 168: i2f
      // 169: ldc_w 255.0
      // 16c: fdiv
      // 16d: f2d
      // 16e: invokespecial net/minecraft/util/math/Vec3d.<init> (DDD)V
      // 171: aload 14
      // 173: invokestatic com/trolmastercard/velvet/gx.a (Lcom/trolmastercard/velvet/c3;Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;Lnet/minecraft/util/math/Vec3d;Ljavax/vecmath/Vector3f;)Lnet/minecraft/util/math/Vec3d;
      // 176: astore 16
      // 178: aload 13
      // 17a: getfield software/bernie/geckolib3/geo/render/built/GeoQuad.vertices [Lsoftware/bernie/geckolib3/geo/render/built/GeoVertex;
      // 17d: astore 17
      // 17f: aload 17
      // 181: arraylength
      // 182: istore 18
      // 184: bipush 0
      // 185: istore 19
      // 187: iload 19
      // 189: iload 18
      // 18b: if_icmpge 21c
      // 18e: aload 17
      // 190: iload 19
      // 192: aaload
      // 193: astore 20
      // 195: new javax/vecmath/Vector4f
      // 198: dup
      // 199: aload 20
      // 19b: getfield software/bernie/geckolib3/geo/render/built/GeoVertex.position Ljavax/vecmath/Vector3f;
      // 19e: invokevirtual javax/vecmath/Vector3f.getX ()F
      // 1a1: aload 20
      // 1a3: getfield software/bernie/geckolib3/geo/render/built/GeoVertex.position Ljavax/vecmath/Vector3f;
      // 1a6: invokevirtual javax/vecmath/Vector3f.getY ()F
      // 1a9: aload 20
      // 1ab: getfield software/bernie/geckolib3/geo/render/built/GeoVertex.position Ljavax/vecmath/Vector3f;
      // 1ae: invokevirtual javax/vecmath/Vector3f.getZ ()F
      // 1b1: fconst_1
      // 1b2: invokespecial javax/vecmath/Vector4f.<init> (FFFF)V
      // 1b5: astore 21
      // 1b7: getstatic com/trolmastercard/velvet/d6.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 1ba: invokevirtual software/bernie/geckolib3/util/MatrixStack.getModelMatrix ()Ljavax/vecmath/Matrix4f;
      // 1bd: aload 21
      // 1bf: invokevirtual javax/vecmath/Matrix4f.transform (Ljavax/vecmath/Tuple4f;)V
      // 1c2: aload 1
      // 1c3: aload 21
      // 1c5: invokevirtual javax/vecmath/Vector4f.getX ()F
      // 1c8: f2d
      // 1c9: aload 21
      // 1cb: invokevirtual javax/vecmath/Vector4f.getY ()F
      // 1ce: f2d
      // 1cf: aload 21
      // 1d1: invokevirtual javax/vecmath/Vector4f.getZ ()F
      // 1d4: f2d
      // 1d5: invokevirtual net/minecraft/client/renderer/BufferBuilder.func_181662_b (DDD)Lnet/minecraft/client/renderer/BufferBuilder;
      // 1d8: aload 20
      // 1da: getfield software/bernie/geckolib3/geo/render/built/GeoVertex.textureU F
      // 1dd: f2d
      // 1de: dload 8
      // 1e0: dadd
      // 1e1: aload 20
      // 1e3: getfield software/bernie/geckolib3/geo/render/built/GeoVertex.textureV F
      // 1e6: f2d
      // 1e7: invokevirtual net/minecraft/client/renderer/BufferBuilder.func_187315_a (DD)Lnet/minecraft/client/renderer/BufferBuilder;
      // 1ea: aload 16
      // 1ec: getfield net/minecraft/util/math/Vec3d.field_72450_a D
      // 1ef: d2f
      // 1f0: aload 16
      // 1f2: getfield net/minecraft/util/math/Vec3d.field_72448_b D
      // 1f5: d2f
      // 1f6: aload 16
      // 1f8: getfield net/minecraft/util/math/Vec3d.field_72449_c D
      // 1fb: d2f
      // 1fc: fload 7
      // 1fe: invokevirtual net/minecraft/client/renderer/BufferBuilder.func_181666_a (FFFF)Lnet/minecraft/client/renderer/BufferBuilder;
      // 201: aload 14
      // 203: invokevirtual javax/vecmath/Vector3f.getX ()F
      // 206: aload 14
      // 208: invokevirtual javax/vecmath/Vector3f.getY ()F
      // 20b: aload 14
      // 20d: invokevirtual javax/vecmath/Vector3f.getZ ()F
      // 210: invokevirtual net/minecraft/client/renderer/BufferBuilder.func_181663_c (FFF)Lnet/minecraft/client/renderer/BufferBuilder;
      // 213: invokevirtual net/minecraft/client/renderer/BufferBuilder.func_181675_d ()V
      // 216: iinc 19 1
      // 219: goto 187
      // 21c: iinc 12 1
      // 21f: goto 023
      // 222: return
      // try (24 -> 27): 27 java/lang/RuntimeException
      // try (45 -> 61): 62 java/lang/RuntimeException
      // try (55 -> 69): 70 java/lang/RuntimeException
      // try (64 -> 78): 79 java/lang/RuntimeException
      // try (81 -> 93): 94 java/lang/RuntimeException
      // try (87 -> 101): 102 java/lang/RuntimeException
      // try (96 -> 110): 111 java/lang/RuntimeException
      // try (113 -> 125): 126 java/lang/RuntimeException
      // try (119 -> 133): 134 java/lang/RuntimeException
      // try (128 -> 142): 143 java/lang/RuntimeException
   }

   private static RuntimeException c(RuntimeException var0) {
      return var0;
   }
}
