package org.velvet;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.init.Blocks;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.fml.common.network.simpleimpl.SimpleNetworkWrapper;

public class j extends GuiScreen {
   static final float f = 100.0F;
   static final float g = 15.0F;
   static final float j = 0.5F;
   static final ResourceLocation h = new ResourceLocation("velvet", "textures/gui/command.png");
   static final HashSet<Material> l = new HashSet<>(
      Arrays.asList(Material.field_151571_B, Material.field_151576_e, Material.field_151595_p, Material.field_151578_c)
   );
   public static boolean d = false;
   float m = 0.0F;
   float a = 0.0F;
   float k = 0.0F;
   float n = 0.0F;
   float i = 0.0F;
   IBlockState e;
   BlockPos c;
   EnumFacing b;

   public j() {
      Minecraft var1 = Minecraft.func_71410_x();

      label27: {
         try {
            this.c = var1.field_71476_x.func_178782_a();
            if (var1.field_71476_x.field_178784_b == null) {
               this.b = EnumFacing.NORTH;
               break label27;
            }
         } catch (NullPointerException var3) {
            throw a(var3);
         }

         this.b = var1.field_71476_x.field_178784_b.func_176734_d();
      }

      try {
         if (this.c == null) {
            this.c = BlockPos.field_177992_a;
         }
      } catch (NullPointerException var2) {
         throw a(var2);
      }

      this.e = var1.field_71441_e.func_180495_p(this.c);
   }

   public void func_146281_b() {
      super.func_146281_b();
      List var1 = Arrays.asList(this.a, this.k, this.n, this.i);
      float var2 = Collections.max(var1);

      try {
         if (var2 == 0.0F) {
            return;
         }
      } catch (NullPointerException var5) {
         throw a(var5);
      }

      try {
         if (this.a == var2) {
            this.b();
         }
      } catch (NullPointerException var7) {
         throw a(var7);
      }

      try {
         if (this.k == var2) {
            this.d();
         }
      } catch (NullPointerException var4) {
         throw a(var4);
      }

      try {
         if (this.n == var2) {
            this.c();
         }
      } catch (NullPointerException var6) {
         throw a(var6);
      }

      try {
         if (this.i == var2) {
            this.a();
         }
      } catch (NullPointerException var3) {
         throw a(var3);
      }
   }

   void b() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 00: aload 0
      // 01: getfield com/trolmastercard/velvet/j.field_146297_k Lnet/minecraft/client/Minecraft;
      // 04: getfield net/minecraft/client/Minecraft.field_71441_e Lnet/minecraft/client/multiplayer/WorldClient;
      // 07: aload 0
      // 08: getfield com/trolmastercard/velvet/j.c Lnet/minecraft/util/math/BlockPos;
      // 0b: invokevirtual net/minecraft/client/multiplayer/WorldClient.func_180495_p (Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/state/IBlockState;
      // 0e: astore 1
      // 0f: aload 1
      // 10: invokeinterface net/minecraft/block/state/IBlockState.func_177230_c ()Lnet/minecraft/block/Block; 1
      // 15: instanceof net/minecraft/block/BlockBed
      // 18: ifne 2e
      // 1b: aload 1
      // 1c: invokeinterface net/minecraft/block/state/IBlockState.func_177230_c ()Lnet/minecraft/block/Block; 1
      // 21: instanceof net/minecraft/block/BlockChest
      // 24: ifeq 59
      // 27: goto 2e
      // 2a: invokestatic com/trolmastercard/velvet/j.a (Ljava/lang/NullPointerException;)Ljava/lang/NullPointerException;
      // 2d: athrow
      // 2e: getstatic com/trolmastercard/velvet/ge.b Lnet/minecraftforge/fml/common/network/simpleimpl/SimpleNetworkWrapper;
      // 31: new com/trolmastercard/velvet/h6
      // 34: dup
      // 35: aload 0
      // 36: getfield com/trolmastercard/velvet/j.c Lnet/minecraft/util/math/BlockPos;
      // 39: aload 0
      // 3a: getfield com/trolmastercard/velvet/j.c Lnet/minecraft/util/math/BlockPos;
      // 3d: invokestatic com/trolmastercard/velvet/gm.a (Lnet/minecraft/util/math/BlockPos;)Z
      // 40: ifne 52
      // 43: goto 4a
      // 46: invokestatic com/trolmastercard/velvet/j.a (Ljava/lang/NullPointerException;)Ljava/lang/NullPointerException;
      // 49: athrow
      // 4a: bipush 1
      // 4b: goto 53
      // 4e: invokestatic com/trolmastercard/velvet/j.a (Ljava/lang/NullPointerException;)Ljava/lang/NullPointerException;
      // 51: athrow
      // 52: bipush 0
      // 53: invokespecial com/trolmastercard/velvet/h6.<init> (Lnet/minecraft/util/math/BlockPos;Z)V
      // 56: invokevirtual net/minecraftforge/fml/common/network/simpleimpl/SimpleNetworkWrapper.sendToServer (Lnet/minecraftforge/fml/common/network/simpleimpl/IMessage;)V
      // 59: return
      // try (7 -> 15): 16 java/lang/NullPointerException
      // try (11 -> 27): 28 java/lang/NullPointerException
      // try (18 -> 32): 32 java/lang/NullPointerException
   }

   void d() {
      SimpleNetworkWrapper var10000;
      fj var10001;
      fj var10002;
      boolean var10003;
      label16: {
         try {
            var10000 = ge.b;
            var10001 = new fj;
            var10002 = var10001;
            if (!d) {
               var10003 = true;
               break label16;
            }
         } catch (NullPointerException var1) {
            throw a(var1);
         }

         var10003 = false;
      }

      var10002./* $VF: Unable to resugar constructor */<init>(var10003);
      var10000.sendToServer(var10001);
   }

   void c() {
      fa.a();
   }

   void a() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 00: aload 0
      // 01: getfield com/trolmastercard/velvet/j.e Lnet/minecraft/block/state/IBlockState;
      // 04: invokeinterface net/minecraft/block/state/IBlockState.func_177230_c ()Lnet/minecraft/block/Block; 1
      // 09: astore 1
      // 0a: aload 1
      // 0b: instanceof net/minecraft/block/BlockLog
      // 0e: ifeq 49
      // 11: aload 0
      // 12: getfield com/trolmastercard/velvet/j.c Lnet/minecraft/util/math/BlockPos;
      // 15: invokestatic com/trolmastercard/velvet/gm.a (Lnet/minecraft/util/math/BlockPos;)Z
      // 18: ifeq 38
      // 1b: goto 22
      // 1e: invokestatic com/trolmastercard/velvet/j.a (Ljava/lang/NullPointerException;)Ljava/lang/NullPointerException;
      // 21: athrow
      // 22: getstatic com/trolmastercard/velvet/ge.b Lnet/minecraftforge/fml/common/network/simpleimpl/SimpleNetworkWrapper;
      // 25: new com/trolmastercard/velvet/au
      // 28: dup
      // 29: aload 0
      // 2a: getfield com/trolmastercard/velvet/j.c Lnet/minecraft/util/math/BlockPos;
      // 2d: invokespecial com/trolmastercard/velvet/au.<init> (Lnet/minecraft/util/math/BlockPos;)V
      // 30: invokevirtual net/minecraftforge/fml/common/network/simpleimpl/SimpleNetworkWrapper.sendToServer (Lnet/minecraftforge/fml/common/network/simpleimpl/IMessage;)V
      // 33: return
      // 34: invokestatic com/trolmastercard/velvet/j.a (Ljava/lang/NullPointerException;)Ljava/lang/NullPointerException;
      // 37: athrow
      // 38: getstatic com/trolmastercard/velvet/ge.b Lnet/minecraftforge/fml/common/network/simpleimpl/SimpleNetworkWrapper;
      // 3b: new com/trolmastercard/velvet/fc
      // 3e: dup
      // 3f: aload 0
      // 40: getfield com/trolmastercard/velvet/j.c Lnet/minecraft/util/math/BlockPos;
      // 43: invokespecial com/trolmastercard/velvet/fc.<init> (Lnet/minecraft/util/math/BlockPos;)V
      // 46: invokevirtual net/minecraftforge/fml/common/network/simpleimpl/SimpleNetworkWrapper.sendToServer (Lnet/minecraftforge/fml/common/network/simpleimpl/IMessage;)V
      // 49: aload 0
      // 4a: invokevirtual com/trolmastercard/velvet/j.e ()[Ljava/lang/Object;
      // 4d: astore 2
      // 4e: aload 2
      // 4f: ifnull 92
      // 52: aload 0
      // 53: getfield com/trolmastercard/velvet/j.c Lnet/minecraft/util/math/BlockPos;
      // 56: invokestatic com/trolmastercard/velvet/gm.a (Lnet/minecraft/util/math/BlockPos;)Z
      // 59: ifeq 79
      // 5c: goto 63
      // 5f: invokestatic com/trolmastercard/velvet/j.a (Ljava/lang/NullPointerException;)Ljava/lang/NullPointerException;
      // 62: athrow
      // 63: getstatic com/trolmastercard/velvet/ge.b Lnet/minecraftforge/fml/common/network/simpleimpl/SimpleNetworkWrapper;
      // 66: new com/trolmastercard/velvet/au
      // 69: dup
      // 6a: aload 0
      // 6b: getfield com/trolmastercard/velvet/j.c Lnet/minecraft/util/math/BlockPos;
      // 6e: invokespecial com/trolmastercard/velvet/au.<init> (Lnet/minecraft/util/math/BlockPos;)V
      // 71: invokevirtual net/minecraftforge/fml/common/network/simpleimpl/SimpleNetworkWrapper.sendToServer (Lnet/minecraftforge/fml/common/network/simpleimpl/IMessage;)V
      // 74: return
      // 75: invokestatic com/trolmastercard/velvet/j.a (Ljava/lang/NullPointerException;)Ljava/lang/NullPointerException;
      // 78: athrow
      // 79: getstatic com/trolmastercard/velvet/ge.b Lnet/minecraftforge/fml/common/network/simpleimpl/SimpleNetworkWrapper;
      // 7c: new com/trolmastercard/velvet/e6
      // 7f: dup
      // 80: aload 2
      // 81: bipush 0
      // 82: aaload
      // 83: checkcast net/minecraft/util/math/BlockPos
      // 86: aload 2
      // 87: bipush 1
      // 88: aaload
      // 89: checkcast net/minecraft/util/EnumFacing
      // 8c: invokespecial com/trolmastercard/velvet/e6.<init> (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;)V
      // 8f: invokevirtual net/minecraftforge/fml/common/network/simpleimpl/SimpleNetworkWrapper.sendToServer (Lnet/minecraftforge/fml/common/network/simpleimpl/IMessage;)V
      // 92: return
      // try (4 -> 11): 12 java/lang/NullPointerException
      // try (7 -> 22): 22 java/lang/NullPointerException
      // try (34 -> 40): 41 java/lang/NullPointerException
      // try (36 -> 51): 51 java/lang/NullPointerException
   }

   @Nullable
   Object[] e() {
      Material var1 = this.field_146297_k.field_71441_e.func_180495_p(this.c).func_185904_a();
      EntityPlayerSP var2 = this.field_146297_k.field_71439_g;

      try {
         if (!l.contains(var1)) {
            return null;
         }
      } catch (NullPointerException var4) {
         throw a(var4);
      }

      try {
         if (var2.func_180425_c().func_177956_o() > this.c.func_177956_o()) {
            return null;
         }
      } catch (NullPointerException var6) {
         throw a(var6);
      }

      BlockPos var3 = this.c;

      while (
         this.field_146297_k.field_71441_e.func_180495_p(var3.func_177977_b().func_177971_a(this.b.func_176734_d().func_176730_m())).func_177230_c()
            == Blocks.field_150350_a
      ) {
         var3 = var3.func_177977_b();
      }

      try {
         if (this.c.func_177956_o() - var3.func_177956_o() > 3) {
            return null;
         }
      } catch (NullPointerException var5) {
         throw a(var5);
      }

      return new Object[]{var3, this.b};
   }

   public void func_73863_a(int param1, int param2, float param3) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 000: aload 0
      // 001: iload 1
      // 002: iload 2
      // 003: fload 3
      // 004: invokespecial net/minecraft/client/gui/GuiScreen.func_73863_a (IIF)V
      // 007: sipush 3042
      // 00a: invokestatic org/lwjgl/opengl/GL11.glEnable (I)V
      // 00d: sipush 770
      // 010: sipush 771
      // 013: bipush 1
      // 014: bipush 0
      // 015: invokestatic net/minecraft/client/renderer/OpenGlHelper.func_148821_a (IIII)V
      // 018: sipush 770
      // 01b: sipush 771
      // 01e: invokestatic org/lwjgl/opengl/GL11.glBlendFunc (II)V
      // 021: aload 0
      // 022: fconst_1
      // 023: aload 0
      // 024: getfield com/trolmastercard/velvet/j.m F
      // 027: aload 0
      // 028: getfield com/trolmastercard/velvet/j.field_146297_k Lnet/minecraft/client/Minecraft;
      // 02b: invokevirtual net/minecraft/client/Minecraft.func_193989_ak ()F
      // 02e: ldc_w 5.0
      // 031: fdiv
      // 032: fadd
      // 033: invokestatic java/lang/Math.min (FF)F
      // 036: putfield com/trolmastercard/velvet/j.m F
      // 039: goto 03e
      // 03c: astore 4
      // 03e: aload 0
      // 03f: aload 0
      // 040: getfield com/trolmastercard/velvet/j.m F
      // 043: f2d
      // 044: invokevirtual com/trolmastercard/velvet/j.a (D)D
      // 047: d2f
      // 048: fstore 4
      // 04a: fconst_1
      // 04b: fload 4
      // 04d: fsub
      // 04e: ldc 100.0
      // 050: fmul
      // 051: fstore 5
      // 053: aload 0
      // 054: dup
      // 055: getfield com/trolmastercard/velvet/j.a F
      // 058: iload 1
      // 059: aload 0
      // 05a: getfield com/trolmastercard/velvet/j.field_146294_l I
      // 05d: bipush 2
      // 05e: idiv
      // 05f: if_icmpge 07b
      // 062: iload 2
      // 063: aload 0
      // 064: getfield com/trolmastercard/velvet/j.field_146295_m I
      // 067: bipush 2
      // 068: idiv
      // 069: if_icmple 07b
      // 06c: goto 073
      // 06f: invokestatic com/trolmastercard/velvet/j.a (Ljava/lang/NullPointerException;)Ljava/lang/NullPointerException;
      // 072: athrow
      // 073: bipush 1
      // 074: goto 07c
      // 077: invokestatic com/trolmastercard/velvet/j.a (Ljava/lang/NullPointerException;)Ljava/lang/NullPointerException;
      // 07a: athrow
      // 07b: bipush -1
      // 07c: i2f
      // 07d: aload 0
      // 07e: getfield com/trolmastercard/velvet/j.field_146297_k Lnet/minecraft/client/Minecraft;
      // 081: invokevirtual net/minecraft/client/Minecraft.func_193989_ak ()F
      // 084: fmul
      // 085: fadd
      // 086: putfield com/trolmastercard/velvet/j.a F
      // 089: aload 0
      // 08a: dup
      // 08b: getfield com/trolmastercard/velvet/j.k F
      // 08e: iload 1
      // 08f: aload 0
      // 090: getfield com/trolmastercard/velvet/j.field_146294_l I
      // 093: bipush 2
      // 094: idiv
      // 095: if_icmpge 0b1
      // 098: iload 2
      // 099: aload 0
      // 09a: getfield com/trolmastercard/velvet/j.field_146295_m I
      // 09d: bipush 2
      // 09e: idiv
      // 09f: if_icmpge 0b1
      // 0a2: goto 0a9
      // 0a5: invokestatic com/trolmastercard/velvet/j.a (Ljava/lang/NullPointerException;)Ljava/lang/NullPointerException;
      // 0a8: athrow
      // 0a9: bipush 1
      // 0aa: goto 0b2
      // 0ad: invokestatic com/trolmastercard/velvet/j.a (Ljava/lang/NullPointerException;)Ljava/lang/NullPointerException;
      // 0b0: athrow
      // 0b1: bipush -1
      // 0b2: i2f
      // 0b3: aload 0
      // 0b4: getfield com/trolmastercard/velvet/j.field_146297_k Lnet/minecraft/client/Minecraft;
      // 0b7: invokevirtual net/minecraft/client/Minecraft.func_193989_ak ()F
      // 0ba: fmul
      // 0bb: fadd
      // 0bc: putfield com/trolmastercard/velvet/j.k F
      // 0bf: aload 0
      // 0c0: dup
      // 0c1: getfield com/trolmastercard/velvet/j.n F
      // 0c4: iload 1
      // 0c5: aload 0
      // 0c6: getfield com/trolmastercard/velvet/j.field_146294_l I
      // 0c9: bipush 2
      // 0ca: idiv
      // 0cb: if_icmple 0e7
      // 0ce: iload 2
      // 0cf: aload 0
      // 0d0: getfield com/trolmastercard/velvet/j.field_146295_m I
      // 0d3: bipush 2
      // 0d4: idiv
      // 0d5: if_icmple 0e7
      // 0d8: goto 0df
      // 0db: invokestatic com/trolmastercard/velvet/j.a (Ljava/lang/NullPointerException;)Ljava/lang/NullPointerException;
      // 0de: athrow
      // 0df: bipush 1
      // 0e0: goto 0e8
      // 0e3: invokestatic com/trolmastercard/velvet/j.a (Ljava/lang/NullPointerException;)Ljava/lang/NullPointerException;
      // 0e6: athrow
      // 0e7: bipush -1
      // 0e8: i2f
      // 0e9: aload 0
      // 0ea: getfield com/trolmastercard/velvet/j.field_146297_k Lnet/minecraft/client/Minecraft;
      // 0ed: invokevirtual net/minecraft/client/Minecraft.func_193989_ak ()F
      // 0f0: fmul
      // 0f1: fadd
      // 0f2: putfield com/trolmastercard/velvet/j.n F
      // 0f5: aload 0
      // 0f6: dup
      // 0f7: getfield com/trolmastercard/velvet/j.i F
      // 0fa: iload 1
      // 0fb: aload 0
      // 0fc: getfield com/trolmastercard/velvet/j.field_146294_l I
      // 0ff: bipush 2
      // 100: idiv
      // 101: if_icmple 11d
      // 104: iload 2
      // 105: aload 0
      // 106: getfield com/trolmastercard/velvet/j.field_146295_m I
      // 109: bipush 2
      // 10a: idiv
      // 10b: if_icmpge 11d
      // 10e: goto 115
      // 111: invokestatic com/trolmastercard/velvet/j.a (Ljava/lang/NullPointerException;)Ljava/lang/NullPointerException;
      // 114: athrow
      // 115: bipush 1
      // 116: goto 11e
      // 119: invokestatic com/trolmastercard/velvet/j.a (Ljava/lang/NullPointerException;)Ljava/lang/NullPointerException;
      // 11c: athrow
      // 11d: bipush -1
      // 11e: i2f
      // 11f: aload 0
      // 120: getfield com/trolmastercard/velvet/j.field_146297_k Lnet/minecraft/client/Minecraft;
      // 123: invokevirtual net/minecraft/client/Minecraft.func_193989_ak ()F
      // 126: fmul
      // 127: fadd
      // 128: putfield com/trolmastercard/velvet/j.i F
      // 12b: aload 0
      // 12c: aload 0
      // 12d: getfield com/trolmastercard/velvet/j.a F
      // 130: fconst_0
      // 131: fconst_1
      // 132: invokestatic com/trolmastercard/velvet/be.b (FFF)F
      // 135: putfield com/trolmastercard/velvet/j.a F
      // 138: aload 0
      // 139: aload 0
      // 13a: getfield com/trolmastercard/velvet/j.k F
      // 13d: fconst_0
      // 13e: fconst_1
      // 13f: invokestatic com/trolmastercard/velvet/be.b (FFF)F
      // 142: putfield com/trolmastercard/velvet/j.k F
      // 145: aload 0
      // 146: aload 0
      // 147: getfield com/trolmastercard/velvet/j.n F
      // 14a: fconst_0
      // 14b: fconst_1
      // 14c: invokestatic com/trolmastercard/velvet/be.b (FFF)F
      // 14f: putfield com/trolmastercard/velvet/j.n F
      // 152: aload 0
      // 153: aload 0
      // 154: getfield com/trolmastercard/velvet/j.i F
      // 157: fconst_0
      // 158: fconst_1
      // 159: invokestatic com/trolmastercard/velvet/be.b (FFF)F
      // 15c: putfield com/trolmastercard/velvet/j.i F
      // 15f: invokestatic net/minecraft/client/renderer/GlStateManager.func_179094_E ()V
      // 162: aload 0
      // 163: getfield com/trolmastercard/velvet/j.field_146294_l I
      // 166: i2f
      // 167: fconst_2
      // 168: fdiv
      // 169: aload 0
      // 16a: getfield com/trolmastercard/velvet/j.field_146295_m I
      // 16d: i2f
      // 16e: fconst_2
      // 16f: fdiv
      // 170: fconst_0
      // 171: invokestatic net/minecraft/client/renderer/GlStateManager.func_179109_b (FFF)V
      // 174: fload 4
      // 176: fload 4
      // 178: fload 4
      // 17a: invokestatic net/minecraft/client/renderer/GlStateManager.func_179152_a (FFF)V
      // 17d: aload 0
      // 17e: getfield com/trolmastercard/velvet/j.field_146297_k Lnet/minecraft/client/Minecraft;
      // 181: getfield net/minecraft/client/Minecraft.field_71446_o Lnet/minecraft/client/renderer/texture/TextureManager;
      // 184: getstatic com/trolmastercard/velvet/j.h Lnet/minecraft/util/ResourceLocation;
      // 187: invokevirtual net/minecraft/client/renderer/texture/TextureManager.func_110577_a (Lnet/minecraft/util/ResourceLocation;)V
      // 18a: invokestatic net/minecraft/client/renderer/GlStateManager.func_179094_E ()V
      // 18d: fconst_1
      // 18e: aload 0
      // 18f: getfield com/trolmastercard/velvet/j.k F
      // 192: ldc 0.5
      // 194: fmul
      // 195: fadd
      // 196: fconst_1
      // 197: aload 0
      // 198: getfield com/trolmastercard/velvet/j.k F
      // 19b: ldc 0.5
      // 19d: fmul
      // 19e: fadd
      // 19f: fconst_1
      // 1a0: invokestatic net/minecraft/client/renderer/GlStateManager.func_179152_a (FFF)V
      // 1a3: aload 0
      // 1a4: ldc_w -62.0
      // 1a7: fload 5
      // 1a9: fadd
      // 1aa: aload 0
      // 1ab: getfield com/trolmastercard/velvet/j.k F
      // 1ae: ldc 15.0
      // 1b0: fmul
      // 1b1: fsub
      // 1b2: ldc_w -62.0
      // 1b5: fload 5
      // 1b7: fadd
      // 1b8: aload 0
      // 1b9: getfield com/trolmastercard/velvet/j.k F
      // 1bc: ldc 15.0
      // 1be: fmul
      // 1bf: fsub
      // 1c0: bipush 0
      // 1c1: bipush 0
      // 1c2: bipush 64
      // 1c4: bipush 64
      // 1c6: invokevirtual com/trolmastercard/velvet/j.func_175174_a (FFIIII)V
      // 1c9: aload 0
      // 1ca: fload 5
      // 1cc: invokevirtual com/trolmastercard/velvet/j.c (F)V
      // 1cf: getstatic com/trolmastercard/velvet/j.d Z
      // 1d2: ifeq 205
      // 1d5: aload 0
      // 1d6: ldc_w -62.0
      // 1d9: fload 5
      // 1db: fadd
      // 1dc: aload 0
      // 1dd: getfield com/trolmastercard/velvet/j.k F
      // 1e0: ldc 15.0
      // 1e2: fmul
      // 1e3: fsub
      // 1e4: ldc_w -62.0
      // 1e7: fload 5
      // 1e9: fadd
      // 1ea: aload 0
      // 1eb: getfield com/trolmastercard/velvet/j.k F
      // 1ee: ldc 15.0
      // 1f0: fmul
      // 1f1: fsub
      // 1f2: sipush 128
      // 1f5: bipush 64
      // 1f7: bipush 64
      // 1f9: bipush 64
      // 1fb: invokevirtual com/trolmastercard/velvet/j.func_175174_a (FFIIII)V
      // 1fe: goto 205
      // 201: invokestatic com/trolmastercard/velvet/j.a (Ljava/lang/NullPointerException;)Ljava/lang/NullPointerException;
      // 204: athrow
      // 205: invokestatic net/minecraft/client/renderer/GlStateManager.func_179121_F ()V
      // 208: invokestatic net/minecraft/client/renderer/GlStateManager.func_179094_E ()V
      // 20b: fconst_1
      // 20c: aload 0
      // 20d: getfield com/trolmastercard/velvet/j.n F
      // 210: ldc 0.5
      // 212: fmul
      // 213: fadd
      // 214: fconst_1
      // 215: aload 0
      // 216: getfield com/trolmastercard/velvet/j.n F
      // 219: ldc 0.5
      // 21b: fmul
      // 21c: fadd
      // 21d: fconst_1
      // 21e: invokestatic net/minecraft/client/renderer/GlStateManager.func_179152_a (FFF)V
      // 221: aload 0
      // 222: ldc_w -2.0
      // 225: fload 5
      // 227: fsub
      // 228: aload 0
      // 229: getfield com/trolmastercard/velvet/j.n F
      // 22c: ldc 15.0
      // 22e: fmul
      // 22f: fadd
      // 230: ldc_w -2.0
      // 233: fload 5
      // 235: fsub
      // 236: aload 0
      // 237: getfield com/trolmastercard/velvet/j.n F
      // 23a: ldc 15.0
      // 23c: fmul
      // 23d: fadd
      // 23e: bipush 0
      // 23f: bipush 0
      // 240: bipush 64
      // 242: bipush 64
      // 244: invokevirtual com/trolmastercard/velvet/j.func_175174_a (FFIIII)V
      // 247: aload 0
      // 248: fload 5
      // 24a: invokevirtual com/trolmastercard/velvet/j.a (F)V
      // 24d: invokestatic com/trolmastercard/velvet/fa.b ()Z
      // 250: ifeq 283
      // 253: aload 0
      // 254: ldc_w -2.0
      // 257: fload 5
      // 259: fsub
      // 25a: aload 0
      // 25b: getfield com/trolmastercard/velvet/j.n F
      // 25e: ldc 15.0
      // 260: fmul
      // 261: fadd
      // 262: ldc_w -2.0
      // 265: fload 5
      // 267: fsub
      // 268: aload 0
      // 269: getfield com/trolmastercard/velvet/j.n F
      // 26c: ldc 15.0
      // 26e: fmul
      // 26f: fadd
      // 270: sipush 128
      // 273: bipush 64
      // 275: bipush 64
      // 277: bipush 64
      // 279: invokevirtual com/trolmastercard/velvet/j.func_175174_a (FFIIII)V
      // 27c: goto 283
      // 27f: invokestatic com/trolmastercard/velvet/j.a (Ljava/lang/NullPointerException;)Ljava/lang/NullPointerException;
      // 282: athrow
      // 283: invokestatic net/minecraft/client/renderer/GlStateManager.func_179121_F ()V
      // 286: aload 0
      // 287: getfield com/trolmastercard/velvet/j.e Lnet/minecraft/block/state/IBlockState;
      // 28a: invokeinterface net/minecraft/block/state/IBlockState.func_177230_c ()Lnet/minecraft/block/Block; 1
      // 28f: astore 6
      // 291: aload 6
      // 293: instanceof net/minecraft/block/BlockChest
      // 296: istore 7
      // 298: aload 6
      // 29a: instanceof net/minecraft/block/BlockBed
      // 29d: istore 8
      // 29f: iload 7
      // 2a1: ifne 2b0
      // 2a4: iload 8
      // 2a6: ifeq 357
      // 2a9: goto 2b0
      // 2ac: invokestatic com/trolmastercard/velvet/j.a (Ljava/lang/NullPointerException;)Ljava/lang/NullPointerException;
      // 2af: athrow
      // 2b0: invokestatic net/minecraft/client/renderer/GlStateManager.func_179094_E ()V
      // 2b3: fconst_1
      // 2b4: aload 0
      // 2b5: getfield com/trolmastercard/velvet/j.a F
      // 2b8: ldc 0.5
      // 2ba: fmul
      // 2bb: fadd
      // 2bc: fconst_1
      // 2bd: aload 0
      // 2be: getfield com/trolmastercard/velvet/j.a F
      // 2c1: ldc 0.5
      // 2c3: fmul
      // 2c4: fadd
      // 2c5: fconst_1
      // 2c6: invokestatic net/minecraft/client/renderer/GlStateManager.func_179152_a (FFF)V
      // 2c9: aload 0
      // 2ca: ldc_w -62.0
      // 2cd: fload 5
      // 2cf: fadd
      // 2d0: aload 0
      // 2d1: getfield com/trolmastercard/velvet/j.a F
      // 2d4: ldc 15.0
      // 2d6: fmul
      // 2d7: fsub
      // 2d8: ldc_w -2.0
      // 2db: fload 5
      // 2dd: fsub
      // 2de: aload 0
      // 2df: getfield com/trolmastercard/velvet/j.a F
      // 2e2: ldc 15.0
      // 2e4: fmul
      // 2e5: fadd
      // 2e6: bipush 0
      // 2e7: bipush 0
      // 2e8: bipush 64
      // 2ea: bipush 64
      // 2ec: invokevirtual com/trolmastercard/velvet/j.func_175174_a (FFIIII)V
      // 2ef: iload 7
      // 2f1: ifeq 308
      // 2f4: goto 2fb
      // 2f7: invokestatic com/trolmastercard/velvet/j.a (Ljava/lang/NullPointerException;)Ljava/lang/NullPointerException;
      // 2fa: athrow
      // 2fb: aload 0
      // 2fc: fload 5
      // 2fe: invokevirtual com/trolmastercard/velvet/j.d (F)V
      // 301: goto 308
      // 304: invokestatic com/trolmastercard/velvet/j.a (Ljava/lang/NullPointerException;)Ljava/lang/NullPointerException;
      // 307: athrow
      // 308: iload 8
      // 30a: ifeq 31a
      // 30d: aload 0
      // 30e: fload 5
      // 310: invokevirtual com/trolmastercard/velvet/j.f (F)V
      // 313: goto 31a
      // 316: invokestatic com/trolmastercard/velvet/j.a (Ljava/lang/NullPointerException;)Ljava/lang/NullPointerException;
      // 319: athrow
      // 31a: aload 0
      // 31b: getfield com/trolmastercard/velvet/j.c Lnet/minecraft/util/math/BlockPos;
      // 31e: invokestatic com/trolmastercard/velvet/gm.a (Lnet/minecraft/util/math/BlockPos;)Z
      // 321: ifeq 354
      // 324: aload 0
      // 325: ldc_w -62.0
      // 328: fload 5
      // 32a: fadd
      // 32b: aload 0
      // 32c: getfield com/trolmastercard/velvet/j.a F
      // 32f: ldc 15.0
      // 331: fmul
      // 332: fsub
      // 333: ldc_w -2.0
      // 336: fload 5
      // 338: fsub
      // 339: aload 0
      // 33a: getfield com/trolmastercard/velvet/j.a F
      // 33d: ldc 15.0
      // 33f: fmul
      // 340: fadd
      // 341: sipush 128
      // 344: bipush 64
      // 346: bipush 64
      // 348: bipush 64
      // 34a: invokevirtual com/trolmastercard/velvet/j.func_175174_a (FFIIII)V
      // 34d: goto 354
      // 350: invokestatic com/trolmastercard/velvet/j.a (Ljava/lang/NullPointerException;)Ljava/lang/NullPointerException;
      // 353: athrow
      // 354: invokestatic net/minecraft/client/renderer/GlStateManager.func_179121_F ()V
      // 357: aload 6
      // 359: instanceof net/minecraft/block/BlockLog
      // 35c: istore 9
      // 35e: aload 0
      // 35f: invokevirtual com/trolmastercard/velvet/j.e ()[Ljava/lang/Object;
      // 362: ifnull 36d
      // 365: bipush 1
      // 366: goto 36e
      // 369: invokestatic com/trolmastercard/velvet/j.a (Ljava/lang/NullPointerException;)Ljava/lang/NullPointerException;
      // 36c: athrow
      // 36d: bipush 0
      // 36e: istore 10
      // 370: iload 9
      // 372: ifne 381
      // 375: iload 10
      // 377: ifeq 428
      // 37a: goto 381
      // 37d: invokestatic com/trolmastercard/velvet/j.a (Ljava/lang/NullPointerException;)Ljava/lang/NullPointerException;
      // 380: athrow
      // 381: invokestatic net/minecraft/client/renderer/GlStateManager.func_179094_E ()V
      // 384: fconst_1
      // 385: aload 0
      // 386: getfield com/trolmastercard/velvet/j.i F
      // 389: ldc 0.5
      // 38b: fmul
      // 38c: fadd
      // 38d: fconst_1
      // 38e: aload 0
      // 38f: getfield com/trolmastercard/velvet/j.i F
      // 392: ldc 0.5
      // 394: fmul
      // 395: fadd
      // 396: fconst_1
      // 397: invokestatic net/minecraft/client/renderer/GlStateManager.func_179152_a (FFF)V
      // 39a: aload 0
      // 39b: ldc_w -2.0
      // 39e: fload 5
      // 3a0: fsub
      // 3a1: aload 0
      // 3a2: getfield com/trolmastercard/velvet/j.i F
      // 3a5: ldc 15.0
      // 3a7: fmul
      // 3a8: fadd
      // 3a9: ldc_w -62.0
      // 3ac: fload 5
      // 3ae: fadd
      // 3af: aload 0
      // 3b0: getfield com/trolmastercard/velvet/j.i F
      // 3b3: ldc 15.0
      // 3b5: fmul
      // 3b6: fsub
      // 3b7: bipush 0
      // 3b8: bipush 0
      // 3b9: bipush 64
      // 3bb: bipush 64
      // 3bd: invokevirtual com/trolmastercard/velvet/j.func_175174_a (FFIIII)V
      // 3c0: iload 9
      // 3c2: ifeq 3d9
      // 3c5: goto 3cc
      // 3c8: invokestatic com/trolmastercard/velvet/j.a (Ljava/lang/NullPointerException;)Ljava/lang/NullPointerException;
      // 3cb: athrow
      // 3cc: aload 0
      // 3cd: fload 5
      // 3cf: invokevirtual com/trolmastercard/velvet/j.e (F)V
      // 3d2: goto 3d9
      // 3d5: invokestatic com/trolmastercard/velvet/j.a (Ljava/lang/NullPointerException;)Ljava/lang/NullPointerException;
      // 3d8: athrow
      // 3d9: iload 10
      // 3db: ifeq 3eb
      // 3de: aload 0
      // 3df: fload 5
      // 3e1: invokevirtual com/trolmastercard/velvet/j.b (F)V
      // 3e4: goto 3eb
      // 3e7: invokestatic com/trolmastercard/velvet/j.a (Ljava/lang/NullPointerException;)Ljava/lang/NullPointerException;
      // 3ea: athrow
      // 3eb: aload 0
      // 3ec: getfield com/trolmastercard/velvet/j.c Lnet/minecraft/util/math/BlockPos;
      // 3ef: invokestatic com/trolmastercard/velvet/gm.a (Lnet/minecraft/util/math/BlockPos;)Z
      // 3f2: ifeq 425
      // 3f5: aload 0
      // 3f6: ldc_w -2.0
      // 3f9: fload 5
      // 3fb: fsub
      // 3fc: aload 0
      // 3fd: getfield com/trolmastercard/velvet/j.i F
      // 400: ldc 15.0
      // 402: fmul
      // 403: fadd
      // 404: ldc_w -62.0
      // 407: fload 5
      // 409: fadd
      // 40a: aload 0
      // 40b: getfield com/trolmastercard/velvet/j.i F
      // 40e: ldc 15.0
      // 410: fmul
      // 411: fsub
      // 412: sipush 128
      // 415: bipush 64
      // 417: bipush 64
      // 419: bipush 64
      // 41b: invokevirtual com/trolmastercard/velvet/j.func_175174_a (FFIIII)V
      // 41e: goto 425
      // 421: invokestatic com/trolmastercard/velvet/j.a (Ljava/lang/NullPointerException;)Ljava/lang/NullPointerException;
      // 424: athrow
      // 425: invokestatic net/minecraft/client/renderer/GlStateManager.func_179121_F ()V
      // 428: invokestatic net/minecraft/client/renderer/GlStateManager.func_179121_F ()V
      // 42b: sipush 3042
      // 42e: invokestatic org/lwjgl/opengl/GL11.glDisable (I)V
      // 431: return
      // try (15 -> 27): 28 java/lang/NullPointerException
      // try (42 -> 57): 58 java/lang/NullPointerException
      // try (51 -> 62): 62 java/lang/NullPointerException
      // try (65 -> 87): 88 java/lang/NullPointerException
      // try (81 -> 92): 92 java/lang/NullPointerException
      // try (95 -> 117): 118 java/lang/NullPointerException
      // try (111 -> 122): 122 java/lang/NullPointerException
      // try (125 -> 147): 148 java/lang/NullPointerException
      // try (141 -> 152): 152 java/lang/NullPointerException
      // try (155 -> 276): 277 java/lang/NullPointerException
      // try (279 -> 344): 345 java/lang/NullPointerException
      // try (358 -> 362): 363 java/lang/NullPointerException
      // try (360 -> 404): 405 java/lang/NullPointerException
      // try (365 -> 410): 411 java/lang/NullPointerException
      // try (413 -> 418): 419 java/lang/NullPointerException
      // try (421 -> 447): 448 java/lang/NullPointerException
      // try (454 -> 459): 459 java/lang/NullPointerException
      // try (463 -> 467): 468 java/lang/NullPointerException
      // try (465 -> 509): 510 java/lang/NullPointerException
      // try (470 -> 515): 516 java/lang/NullPointerException
      // try (518 -> 523): 524 java/lang/NullPointerException
      // try (526 -> 552): 553 java/lang/NullPointerException
   }

   void a(float var1) {
      this.func_175174_a(-2.0F - var1 + this.n * 15.0F, -2.0F - var1 + this.n * 15.0F, 192, 64, 64, 64);
   }

   void c(float var1) {
      this.func_175174_a(-62.0F + var1 - this.k * 15.0F, -62.0F + var1 - this.k * 15.0F, 64, 64, 64, 64);
   }

   void e(float var1) {
      this.func_175174_a(-2.0F - var1 + this.i * 15.0F, -62.0F + var1 - this.i * 15.0F, 64, 0, 64, 64);
   }

   void b(float var1) {
      this.func_175174_a(-2.0F - var1 + this.i * 15.0F, -62.0F + var1 - this.i * 15.0F, 128, 0, 64, 64);
   }

   void f(float var1) {
      this.func_175174_a(-62.0F + var1 - this.a * 15.0F, -2.0F - var1 + this.a * 15.0F, 0, 64, 64, 64);
   }

   void d(float var1) {
      this.func_175174_a(-62.0F + var1 - this.a * 15.0F, -2.0F - var1 + this.a * 15.0F, 192, 0, 64, 64);
   }

   double a(double var1) {
      double var3 = 1.70158;
      double var5 = var3 + 1.0;
      return 1.0 + var5 * Math.pow(var1 - 1.0, 3.0) + var3 * Math.pow(var1 - 1.0, 2.0);
   }

   protected void func_146286_b(int var1, int var2, int var3) {
      this.field_146297_k.field_71439_g.func_71053_j();
      super.func_146286_b(var1, var2, var3);
   }

   public boolean func_73868_f() {
      return false;
   }

   private static NullPointerException a(NullPointerException var0) {
      return var0;
   }
}
