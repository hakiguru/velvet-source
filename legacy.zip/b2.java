package org.velvet;

@FunctionalInterface
public interface b2 {
   void a(f_ var1);
}
