package org.velvet;

import java.util.ConcurrentModificationException;
import java.util.HashSet;
import net.minecraft.block.Block;
import net.minecraft.block.BlockBed;
import net.minecraft.block.BlockChest;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumHand;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Vec3i;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent.ClientTickEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent.Phase;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import org.lwjgl.opengl.GL11;

@SideOnly(Side.CLIENT)
public class gm {
   static final Vec3i e = new Vec3i(255, 0, 0);
   static final Vec3i g = new Vec3i(0, 255, 0);
   static final Vec3i d = new Vec3i(0, 0, 255);
   static final ResourceLocation b = new ResourceLocation("velvet", "textures/mark.png");
   static HashSet<BlockPos> f = new HashSet<>();
   static Minecraft a = Minecraft.func_71410_x();
   static TextureManager c = Minecraft.func_71410_x().func_110434_K();

   public static void a() {
      f.clear();
   }

   public static boolean a(BlockPos var0) {
      return f.contains(var0);
   }

   public static void b() {
      Tessellator var0 = Tessellator.func_178181_a();
      BufferBuilder var1 = var0.func_178180_c();
      Vec3d var2 = b6.a(r.k, r.j, a.func_184121_ak());
      GlStateManager.func_179094_E();
      GlStateManager.func_179129_p();
      GlStateManager.func_179097_i();
      c.func_110577_a(b);
      GlStateManager.func_179137_b(-var2.field_72450_a, -var2.field_72448_b, -var2.field_72449_c);
      var1.func_181668_a(7, DefaultVertexFormats.field_181709_i);

      try {
         for (BlockPos var4 : f) {
            Vec3i var5 = b(var4);
            a(var1, var4, var5.func_177958_n(), var5.func_177956_o(), var5.func_177952_p());
         }
      } catch (ConcurrentModificationException var6) {
      }

      var0.func_78381_a();
      GlStateManager.func_179126_j();
      GlStateManager.func_179089_o();
      GlStateManager.func_179121_F();
   }

   static Vec3i b(BlockPos var0) {
      Block var1 = Minecraft.func_71410_x().field_71441_e.func_180495_p(var0).func_177230_c();

      try {
         if (var1 instanceof BlockBed) {
            return d;
         }
      } catch (ConcurrentModificationException var2) {
         throw a(var2);
      }

      try {
         if (var1 instanceof BlockChest) {
            return g;
         }
      } catch (ConcurrentModificationException var3) {
         throw a(var3);
      }

      return e;
   }

   static void a(BufferBuilder var0, BlockPos var1, int var2, int var3, int var4) {
      var0.func_181662_b(var1.func_177958_n(), var1.func_177956_o() + 1, var1.func_177952_p())
         .func_187315_a(0.0, 1.0)
         .func_181669_b(var2, var3, var4, 255)
         .func_181675_d();
      var0.func_181662_b(1 + var1.func_177958_n(), var1.func_177956_o() + 1, var1.func_177952_p())
         .func_187315_a(1.0, 1.0)
         .func_181669_b(var2, var3, var4, 255)
         .func_181675_d();
      var0.func_181662_b(1 + var1.func_177958_n(), var1.func_177956_o(), var1.func_177952_p())
         .func_187315_a(1.0, 0.0)
         .func_181669_b(var2, var3, var4, 255)
         .func_181675_d();
      var0.func_181662_b(var1.func_177958_n(), var1.func_177956_o(), var1.func_177952_p())
         .func_187315_a(0.0, 0.0)
         .func_181669_b(var2, var3, var4, 255)
         .func_181675_d();
      var0.func_181662_b(var1.func_177958_n(), var1.func_177956_o() + 1, 1 + var1.func_177952_p())
         .func_187315_a(0.0, 1.0)
         .func_181669_b(var2, var3, var4, 255)
         .func_181675_d();
      var0.func_181662_b(1 + var1.func_177958_n(), var1.func_177956_o() + 1, 1 + var1.func_177952_p())
         .func_187315_a(1.0, 1.0)
         .func_181669_b(var2, var3, var4, 255)
         .func_181675_d();
      var0.func_181662_b(1 + var1.func_177958_n(), var1.func_177956_o(), 1 + var1.func_177952_p())
         .func_187315_a(1.0, 0.0)
         .func_181669_b(var2, var3, var4, 255)
         .func_181675_d();
      var0.func_181662_b(var1.func_177958_n(), var1.func_177956_o(), 1 + var1.func_177952_p())
         .func_187315_a(0.0, 0.0)
         .func_181669_b(var2, var3, var4, 255)
         .func_181675_d();
      var0.func_181662_b(1 + var1.func_177958_n(), var1.func_177956_o() + 1, var1.func_177952_p())
         .func_187315_a(0.0, 1.0)
         .func_181669_b(var2, var3, var4, 255)
         .func_181675_d();
      var0.func_181662_b(1 + var1.func_177958_n(), var1.func_177956_o() + 1, 1 + var1.func_177952_p())
         .func_187315_a(1.0, 1.0)
         .func_181669_b(var2, var3, var4, 255)
         .func_181675_d();
      var0.func_181662_b(1 + var1.func_177958_n(), var1.func_177956_o(), 1 + var1.func_177952_p())
         .func_187315_a(1.0, 0.0)
         .func_181669_b(var2, var3, var4, 255)
         .func_181675_d();
      var0.func_181662_b(1 + var1.func_177958_n(), var1.func_177956_o(), var1.func_177952_p())
         .func_187315_a(0.0, 0.0)
         .func_181669_b(var2, var3, var4, 255)
         .func_181675_d();
      var0.func_181662_b(var1.func_177958_n(), var1.func_177956_o() + 1, var1.func_177952_p())
         .func_187315_a(0.0, 1.0)
         .func_181669_b(var2, var3, var4, 255)
         .func_181675_d();
      var0.func_181662_b(var1.func_177958_n(), var1.func_177956_o() + 1, 1 + var1.func_177952_p())
         .func_187315_a(1.0, 1.0)
         .func_181669_b(var2, var3, var4, 255)
         .func_181675_d();
      var0.func_181662_b(var1.func_177958_n(), var1.func_177956_o(), 1 + var1.func_177952_p())
         .func_187315_a(1.0, 0.0)
         .func_181669_b(var2, var3, var4, 255)
         .func_181675_d();
      var0.func_181662_b(var1.func_177958_n(), var1.func_177956_o(), var1.func_177952_p())
         .func_187315_a(0.0, 0.0)
         .func_181669_b(var2, var3, var4, 255)
         .func_181675_d();
      var0.func_181662_b(var1.func_177958_n(), var1.func_177956_o(), 1 + var1.func_177952_p())
         .func_187315_a(0.0, 1.0)
         .func_181669_b(var2, var3, var4, 255)
         .func_181675_d();
      var0.func_181662_b(1 + var1.func_177958_n(), var1.func_177956_o(), 1 + var1.func_177952_p())
         .func_187315_a(1.0, 1.0)
         .func_181669_b(var2, var3, var4, 255)
         .func_181675_d();
      var0.func_181662_b(1 + var1.func_177958_n(), var1.func_177956_o(), var1.func_177952_p())
         .func_187315_a(1.0, 0.0)
         .func_181669_b(var2, var3, var4, 255)
         .func_181675_d();
      var0.func_181662_b(var1.func_177958_n(), var1.func_177956_o(), var1.func_177952_p())
         .func_187315_a(0.0, 0.0)
         .func_181669_b(var2, var3, var4, 255)
         .func_181675_d();
      var0.func_181662_b(var1.func_177958_n(), var1.func_177956_o() + 1, 1 + var1.func_177952_p())
         .func_187315_a(0.0, 1.0)
         .func_181669_b(var2, var3, var4, 255)
         .func_181675_d();
      var0.func_181662_b(1 + var1.func_177958_n(), var1.func_177956_o() + 1, 1 + var1.func_177952_p())
         .func_187315_a(1.0, 1.0)
         .func_181669_b(var2, var3, var4, 255)
         .func_181675_d();
      var0.func_181662_b(1 + var1.func_177958_n(), var1.func_177956_o() + 1, var1.func_177952_p())
         .func_187315_a(1.0, 0.0)
         .func_181669_b(var2, var3, var4, 255)
         .func_181675_d();
      var0.func_181662_b(var1.func_177958_n(), var1.func_177956_o() + 1, var1.func_177952_p())
         .func_187315_a(0.0, 0.0)
         .func_181669_b(var2, var3, var4, 255)
         .func_181675_d();
   }

   public static void a(HashSet<BlockPos> var0) {
      f.addAll(var0);
   }

   public static void b(HashSet<BlockPos> var0) {
      f.removeAll(var0);
   }

   @SubscribeEvent
   public void a(RenderWorldLastEvent var1) {
      GlStateManager.func_179142_g();
      GL11.glDisable(2896);
      ItemStack var2 = a.field_71439_g.func_184586_b(EnumHand.MAIN_HAND);
      if (var2.func_77973_b() != hy.b) {
         var2 = a.field_71439_g.func_184586_b(EnumHand.OFF_HAND);
      }

      try {
         if (var2.func_77973_b() == hy.b) {
            b();
         }
      } catch (ConcurrentModificationException var3) {
         throw a(var3);
      }

      GlStateManager.func_179145_e();
      GlStateManager.func_179126_j();
      GlStateManager.func_179141_d();
      GL11.glEnable(2896);
   }

   @SideOnly(Side.CLIENT)
   @SubscribeEvent
   public void a(ClientTickEvent var1) {
      try {
         if (var1.phase == Phase.START) {
            return;
         }
      } catch (ConcurrentModificationException var4) {
         throw a(var4);
      }

      EntityPlayerSP var2 = Minecraft.func_71410_x().field_71439_g;

      try {
         if (var2 == null) {
            return;
         }
      } catch (ConcurrentModificationException var3) {
         throw a(var3);
      }

      r.k = r.j;
      r.j = var2.func_174791_d();
   }

   private static ConcurrentModificationException a(ConcurrentModificationException var0) {
      return var0;
   }
}
