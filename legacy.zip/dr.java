package org.velvet;

public interface dr {
   boolean a();
}
