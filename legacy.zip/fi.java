package org.velvet;

import javax.annotation.Nullable;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.util.ResourceLocation;

public class fi extends Render<gi> {
   static final double b = 0.1896224320030116;
   static final double d = -0.5;
   static final double c = 0.08742380916962415;
   private static final ResourceLocation a = new ResourceLocation("textures/particle/particles.png");

   public fi(RenderManager var1) {
      super(var1);
   }

   public void a(gi param1, double param2, double param4, double param6, float param8, float param9) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 000: aload 1
      // 001: invokevirtual com/trolmastercard/velvet/gi.g ()Lcom/trolmastercard/velvet/eb;
      // 004: astore 10
      // 006: aload 10
      // 008: ifnull 02a
      // 00b: aload 0
      // 00c: getfield com/trolmastercard/velvet/fi.field_188301_f Z
      // 00f: ifne 02a
      // 012: goto 019
      // 015: invokestatic com/trolmastercard/velvet/fi.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 018: athrow
      // 019: aload 10
      // 01b: getfield com/trolmastercard/velvet/eb.Z F
      // 01e: fconst_1
      // 01f: fcmpl
      // 020: ifne 02f
      // 023: goto 02a
      // 026: invokestatic com/trolmastercard/velvet/fi.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 029: athrow
      // 02a: return
      // 02b: invokestatic com/trolmastercard/velvet/fi.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 02e: athrow
      // 02f: aload 10
      // 031: aload 1
      // 032: putfield com/trolmastercard/velvet/eb.av Lcom/trolmastercard/velvet/gi;
      // 035: aload 10
      // 037: invokevirtual com/trolmastercard/velvet/eb.func_184212_Q ()Lnet/minecraft/network/datasync/EntityDataManager;
      // 03a: getstatic com/trolmastercard/velvet/eb.ag Lnet/minecraft/network/datasync/DataParameter;
      // 03d: invokevirtual net/minecraft/network/datasync/EntityDataManager.func_187225_a (Lnet/minecraft/network/datasync/DataParameter;)Ljava/lang/Object;
      // 040: checkcast net/minecraft/item/ItemStack
      // 043: astore 11
      // 045: aload 11
      // 047: invokevirtual net/minecraft/item/ItemStack.func_77973_b ()Lnet/minecraft/item/Item;
      // 04a: getstatic net/minecraft/init/Items.field_190931_a Lnet/minecraft/item/Item;
      // 04d: invokevirtual java/lang/Object.equals (Ljava/lang/Object;)Z
      // 050: ifne 11d
      // 053: invokestatic net/minecraft/client/Minecraft.func_175610_ah ()I
      // 056: i2f
      // 057: fstore 12
      // 059: fload 12
      // 05b: fconst_0
      // 05c: fcmpl
      // 05d: ifne 064
      // 060: ldc 0.1
      // 062: fstore 12
      // 064: aload 10
      // 066: dup
      // 067: getfield com/trolmastercard/velvet/eb.Z F
      // 06a: ldc 60.0
      // 06c: fload 12
      // 06e: fdiv
      // 06f: ldc 0.01666
      // 071: fmul
      // 072: fconst_2
      // 073: fmul
      // 074: fadd
      // 075: putfield com/trolmastercard/velvet/eb.Z F
      // 078: aload 10
      // 07a: fconst_1
      // 07b: aload 10
      // 07d: getfield com/trolmastercard/velvet/eb.Z F
      // 080: invokestatic java/lang/Math.min (FF)F
      // 083: putfield com/trolmastercard/velvet/eb.Z F
      // 086: invokestatic net/minecraft/client/Minecraft.func_71410_x ()Lnet/minecraft/client/Minecraft;
      // 089: getfield net/minecraft/client/Minecraft.field_71439_g Lnet/minecraft/client/entity/EntityPlayerSP;
      // 08c: astore 13
      // 08e: new net/minecraft/util/math/Vec3d
      // 091: dup
      // 092: aload 13
      // 094: getfield net/minecraft/entity/player/EntityPlayer.field_70142_S D
      // 097: aload 13
      // 099: getfield net/minecraft/entity/player/EntityPlayer.field_70137_T D
      // 09c: aload 13
      // 09e: getfield net/minecraft/entity/player/EntityPlayer.field_70136_U D
      // 0a1: invokespecial net/minecraft/util/math/Vec3d.<init> (DDD)V
      // 0a4: aload 13
      // 0a6: invokevirtual net/minecraft/entity/player/EntityPlayer.func_174791_d ()Lnet/minecraft/util/math/Vec3d;
      // 0a9: fload 9
      // 0ab: f2d
      // 0ac: invokestatic com/trolmastercard/velvet/b6.a (Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/math/Vec3d;D)Lnet/minecraft/util/math/Vec3d;
      // 0af: astore 14
      // 0b1: new net/minecraft/util/math/Vec3d
      // 0b4: dup
      // 0b5: dload 2
      // 0b6: dload 4
      // 0b8: dload 6
      // 0ba: invokespecial net/minecraft/util/math/Vec3d.<init> (DDD)V
      // 0bd: astore 15
      // 0bf: new net/minecraft/util/math/Vec3d
      // 0c2: dup
      // 0c3: aload 10
      // 0c5: getfield com/trolmastercard/velvet/eb.field_70142_S D
      // 0c8: aload 10
      // 0ca: getfield com/trolmastercard/velvet/eb.field_70137_T D
      // 0cd: ldc2_w 0.875
      // 0d0: dadd
      // 0d1: aload 10
      // 0d3: getfield com/trolmastercard/velvet/eb.field_70136_U D
      // 0d6: invokespecial net/minecraft/util/math/Vec3d.<init> (DDD)V
      // 0d9: aload 10
      // 0db: invokevirtual com/trolmastercard/velvet/eb.func_174791_d ()Lnet/minecraft/util/math/Vec3d;
      // 0de: dconst_0
      // 0df: ldc2_w 0.875
      // 0e2: dconst_0
      // 0e3: invokevirtual net/minecraft/util/math/Vec3d.func_72441_c (DDD)Lnet/minecraft/util/math/Vec3d;
      // 0e6: fload 9
      // 0e8: f2d
      // 0e9: invokestatic com/trolmastercard/velvet/b6.a (Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/math/Vec3d;D)Lnet/minecraft/util/math/Vec3d;
      // 0ec: astore 16
      // 0ee: aload 16
      // 0f0: aload 14
      // 0f2: invokevirtual net/minecraft/util/math/Vec3d.func_178788_d (Lnet/minecraft/util/math/Vec3d;)Lnet/minecraft/util/math/Vec3d;
      // 0f5: astore 16
      // 0f7: aload 15
      // 0f9: aload 16
      // 0fb: aload 10
      // 0fd: getfield com/trolmastercard/velvet/eb.Z F
      // 100: f2d
      // 101: invokestatic com/trolmastercard/velvet/b6.a (Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/math/Vec3d;D)Lnet/minecraft/util/math/Vec3d;
      // 104: astore 15
      // 106: aload 15
      // 108: getfield net/minecraft/util/math/Vec3d.field_72450_a D
      // 10b: dstore 2
      // 10c: aload 15
      // 10e: getfield net/minecraft/util/math/Vec3d.field_72448_b D
      // 111: dstore 4
      // 113: aload 15
      // 115: getfield net/minecraft/util/math/Vec3d.field_72449_c D
      // 118: dstore 6
      // 11a: goto 123
      // 11d: aload 10
      // 11f: fconst_0
      // 120: putfield com/trolmastercard/velvet/eb.Z F
      // 123: invokestatic net/minecraft/client/renderer/GlStateManager.func_179094_E ()V
      // 126: dload 2
      // 127: d2f
      // 128: dload 4
      // 12a: d2f
      // 12b: dload 6
      // 12d: d2f
      // 12e: invokestatic net/minecraft/client/renderer/GlStateManager.func_179109_b (FFF)V
      // 131: invokestatic net/minecraft/client/renderer/GlStateManager.func_179091_B ()V
      // 134: ldc 0.5
      // 136: ldc 0.5
      // 138: ldc 0.5
      // 13a: invokestatic net/minecraft/client/renderer/GlStateManager.func_179152_a (FFF)V
      // 13d: aload 0
      // 13e: aload 1
      // 13f: invokevirtual com/trolmastercard/velvet/fi.func_180548_c (Lnet/minecraft/entity/Entity;)Z
      // 142: pop
      // 143: invokestatic net/minecraft/client/renderer/Tessellator.func_178181_a ()Lnet/minecraft/client/renderer/Tessellator;
      // 146: astore 12
      // 148: aload 12
      // 14a: invokevirtual net/minecraft/client/renderer/Tessellator.func_178180_c ()Lnet/minecraft/client/renderer/BufferBuilder;
      // 14d: astore 13
      // 14f: ldc 180.0
      // 151: aload 0
      // 152: getfield com/trolmastercard/velvet/fi.field_76990_c Lnet/minecraft/client/renderer/entity/RenderManager;
      // 155: getfield net/minecraft/client/renderer/entity/RenderManager.field_78735_i F
      // 158: fsub
      // 159: fconst_0
      // 15a: fconst_1
      // 15b: fconst_0
      // 15c: invokestatic net/minecraft/client/renderer/GlStateManager.func_179114_b (FFFF)V
      // 15f: aload 0
      // 160: getfield com/trolmastercard/velvet/fi.field_76990_c Lnet/minecraft/client/renderer/entity/RenderManager;
      // 163: getfield net/minecraft/client/renderer/entity/RenderManager.field_78733_k Lnet/minecraft/client/settings/GameSettings;
      // 166: getfield net/minecraft/client/settings/GameSettings.field_74320_O I
      // 169: bipush 2
      // 16a: if_icmpne 175
      // 16d: bipush -1
      // 16e: goto 176
      // 171: invokestatic com/trolmastercard/velvet/fi.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 174: athrow
      // 175: bipush 1
      // 176: i2f
      // 177: aload 0
      // 178: getfield com/trolmastercard/velvet/fi.field_76990_c Lnet/minecraft/client/renderer/entity/RenderManager;
      // 17b: getfield net/minecraft/client/renderer/entity/RenderManager.field_78732_j F
      // 17e: fneg
      // 17f: fmul
      // 180: fconst_1
      // 181: fconst_0
      // 182: fconst_0
      // 183: invokestatic net/minecraft/client/renderer/GlStateManager.func_179114_b (FFFF)V
      // 186: aload 0
      // 187: getfield com/trolmastercard/velvet/fi.field_188301_f Z
      // 18a: ifeq 19f
      // 18d: invokestatic net/minecraft/client/renderer/GlStateManager.func_179142_g ()V
      // 190: aload 0
      // 191: aload 1
      // 192: invokevirtual com/trolmastercard/velvet/fi.func_188298_c (Lnet/minecraft/entity/Entity;)I
      // 195: invokestatic net/minecraft/client/renderer/GlStateManager.func_187431_e (I)V
      // 198: goto 19f
      // 19b: invokestatic com/trolmastercard/velvet/fi.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 19e: athrow
      // 19f: aload 11
      // 1a1: invokevirtual net/minecraft/item/ItemStack.func_77973_b ()Lnet/minecraft/item/Item;
      // 1a4: getstatic net/minecraft/init/Items.field_190931_a Lnet/minecraft/item/Item;
      // 1a7: invokevirtual java/lang/Object.equals (Ljava/lang/Object;)Z
      // 1aa: ifne 1e1
      // 1ad: fconst_2
      // 1ae: fconst_2
      // 1af: fconst_2
      // 1b0: invokestatic net/minecraft/client/renderer/GlStateManager.func_179152_a (FFF)V
      // 1b3: fconst_0
      // 1b4: ldc -0.2
      // 1b6: fconst_0
      // 1b7: invokestatic net/minecraft/client/renderer/GlStateManager.func_179109_b (FFF)V
      // 1ba: invokestatic net/minecraft/client/Minecraft.func_71410_x ()Lnet/minecraft/client/Minecraft;
      // 1bd: invokevirtual net/minecraft/client/Minecraft.func_175597_ag ()Lnet/minecraft/client/renderer/ItemRenderer;
      // 1c0: aload 10
      // 1c2: aload 11
      // 1c4: getstatic net/minecraft/client/renderer/block/model/ItemCameraTransforms$TransformType.THIRD_PERSON_RIGHT_HAND Lnet/minecraft/client/renderer/block/model/ItemCameraTransforms$TransformType;
      // 1c7: invokevirtual net/minecraft/client/renderer/ItemRenderer.func_178099_a (Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/item/ItemStack;Lnet/minecraft/client/renderer/block/model/ItemCameraTransforms$TransformType;)V
      // 1ca: fconst_0
      // 1cb: ldc 0.2
      // 1cd: fconst_0
      // 1ce: invokestatic net/minecraft/client/renderer/GlStateManager.func_179109_b (FFF)V
      // 1d1: ldc 0.5
      // 1d3: ldc 0.5
      // 1d5: ldc 0.5
      // 1d7: invokestatic net/minecraft/client/renderer/GlStateManager.func_179152_a (FFF)V
      // 1da: goto 1e1
      // 1dd: invokestatic com/trolmastercard/velvet/fi.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 1e0: athrow
      // 1e1: aload 0
      // 1e2: aload 1
      // 1e3: invokevirtual com/trolmastercard/velvet/fi.func_180548_c (Lnet/minecraft/entity/Entity;)Z
      // 1e6: pop
      // 1e7: aload 13
      // 1e9: bipush 7
      // 1eb: getstatic net/minecraft/client/renderer/vertex/DefaultVertexFormats.field_181710_j Lnet/minecraft/client/renderer/vertex/VertexFormat;
      // 1ee: invokevirtual net/minecraft/client/renderer/BufferBuilder.func_181668_a (ILnet/minecraft/client/renderer/vertex/VertexFormat;)V
      // 1f1: aload 13
      // 1f3: ldc2_w -0.5
      // 1f6: ldc2_w -0.5
      // 1f9: dconst_0
      // 1fa: invokevirtual net/minecraft/client/renderer/BufferBuilder.func_181662_b (DDD)Lnet/minecraft/client/renderer/BufferBuilder;
      // 1fd: ldc2_w 0.0625
      // 200: ldc2_w 0.1875
      // 203: invokevirtual net/minecraft/client/renderer/BufferBuilder.func_187315_a (DD)Lnet/minecraft/client/renderer/BufferBuilder;
      // 206: fconst_0
      // 207: fconst_1
      // 208: fconst_0
      // 209: invokevirtual net/minecraft/client/renderer/BufferBuilder.func_181663_c (FFF)Lnet/minecraft/client/renderer/BufferBuilder;
      // 20c: invokevirtual net/minecraft/client/renderer/BufferBuilder.func_181675_d ()V
      // 20f: aload 13
      // 211: ldc2_w 0.5
      // 214: ldc2_w -0.5
      // 217: dconst_0
      // 218: invokevirtual net/minecraft/client/renderer/BufferBuilder.func_181662_b (DDD)Lnet/minecraft/client/renderer/BufferBuilder;
      // 21b: ldc2_w 0.125
      // 21e: ldc2_w 0.1875
      // 221: invokevirtual net/minecraft/client/renderer/BufferBuilder.func_187315_a (DD)Lnet/minecraft/client/renderer/BufferBuilder;
      // 224: fconst_0
      // 225: fconst_1
      // 226: fconst_0
      // 227: invokevirtual net/minecraft/client/renderer/BufferBuilder.func_181663_c (FFF)Lnet/minecraft/client/renderer/BufferBuilder;
      // 22a: invokevirtual net/minecraft/client/renderer/BufferBuilder.func_181675_d ()V
      // 22d: aload 13
      // 22f: ldc2_w 0.5
      // 232: ldc2_w 0.5
      // 235: dconst_0
      // 236: invokevirtual net/minecraft/client/renderer/BufferBuilder.func_181662_b (DDD)Lnet/minecraft/client/renderer/BufferBuilder;
      // 239: ldc2_w 0.125
      // 23c: ldc2_w 0.125
      // 23f: invokevirtual net/minecraft/client/renderer/BufferBuilder.func_187315_a (DD)Lnet/minecraft/client/renderer/BufferBuilder;
      // 242: fconst_0
      // 243: fconst_1
      // 244: fconst_0
      // 245: invokevirtual net/minecraft/client/renderer/BufferBuilder.func_181663_c (FFF)Lnet/minecraft/client/renderer/BufferBuilder;
      // 248: invokevirtual net/minecraft/client/renderer/BufferBuilder.func_181675_d ()V
      // 24b: aload 13
      // 24d: ldc2_w -0.5
      // 250: ldc2_w 0.5
      // 253: dconst_0
      // 254: invokevirtual net/minecraft/client/renderer/BufferBuilder.func_181662_b (DDD)Lnet/minecraft/client/renderer/BufferBuilder;
      // 257: ldc2_w 0.0625
      // 25a: ldc2_w 0.125
      // 25d: invokevirtual net/minecraft/client/renderer/BufferBuilder.func_187315_a (DD)Lnet/minecraft/client/renderer/BufferBuilder;
      // 260: fconst_0
      // 261: fconst_1
      // 262: fconst_0
      // 263: invokevirtual net/minecraft/client/renderer/BufferBuilder.func_181663_c (FFF)Lnet/minecraft/client/renderer/BufferBuilder;
      // 266: invokevirtual net/minecraft/client/renderer/BufferBuilder.func_181675_d ()V
      // 269: aload 12
      // 26b: invokevirtual net/minecraft/client/renderer/Tessellator.func_78381_a ()V
      // 26e: aload 0
      // 26f: getfield com/trolmastercard/velvet/fi.field_188301_f Z
      // 272: ifeq 282
      // 275: invokestatic net/minecraft/client/renderer/GlStateManager.func_187417_n ()V
      // 278: invokestatic net/minecraft/client/renderer/GlStateManager.func_179119_h ()V
      // 27b: goto 282
      // 27e: invokestatic com/trolmastercard/velvet/fi.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 281: athrow
      // 282: invokestatic net/minecraft/client/renderer/GlStateManager.func_179101_C ()V
      // 285: invokestatic net/minecraft/client/renderer/GlStateManager.func_179121_F ()V
      // 288: aload 10
      // 28a: invokevirtual com/trolmastercard/velvet/eb.func_184591_cq ()Lnet/minecraft/util/EnumHandSide;
      // 28d: getstatic net/minecraft/util/EnumHandSide.RIGHT Lnet/minecraft/util/EnumHandSide;
      // 290: if_acmpne 29b
      // 293: bipush 1
      // 294: goto 29c
      // 297: invokestatic com/trolmastercard/velvet/fi.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 29a: athrow
      // 29b: bipush -1
      // 29c: istore 14
      // 29e: aload 10
      // 2a0: invokevirtual com/trolmastercard/velvet/eb.func_184614_ca ()Lnet/minecraft/item/ItemStack;
      // 2a3: astore 15
      // 2a5: aload 15
      // 2a7: invokevirtual net/minecraft/item/ItemStack.func_77973_b ()Lnet/minecraft/item/Item;
      // 2aa: instanceof net/minecraft/item/ItemFishingRod
      // 2ad: ifne 2b5
      // 2b0: iload 14
      // 2b2: ineg
      // 2b3: istore 14
      // 2b5: aload 10
      // 2b7: aload 10
      // 2b9: invokevirtual com/trolmastercard/velvet/eb.I ()Ljava/lang/Float;
      // 2bc: invokevirtual java/lang/Float.floatValue ()F
      // 2bf: putfield com/trolmastercard/velvet/eb.field_70177_z F
      // 2c2: aload 10
      // 2c4: aload 10
      // 2c6: invokevirtual com/trolmastercard/velvet/eb.I ()Ljava/lang/Float;
      // 2c9: invokevirtual java/lang/Float.floatValue ()F
      // 2cc: putfield com/trolmastercard/velvet/eb.field_70761_aq F
      // 2cf: aload 10
      // 2d1: aload 10
      // 2d3: invokevirtual com/trolmastercard/velvet/eb.o ()Lnet/minecraft/util/math/Vec3d;
      // 2d6: getfield net/minecraft/util/math/Vec3d.field_72450_a D
      // 2d9: putfield com/trolmastercard/velvet/eb.field_70165_t D
      // 2dc: aload 10
      // 2de: aload 10
      // 2e0: invokevirtual com/trolmastercard/velvet/eb.o ()Lnet/minecraft/util/math/Vec3d;
      // 2e3: getfield net/minecraft/util/math/Vec3d.field_72448_b D
      // 2e6: putfield com/trolmastercard/velvet/eb.field_70163_u D
      // 2e9: aload 10
      // 2eb: aload 10
      // 2ed: invokevirtual com/trolmastercard/velvet/eb.o ()Lnet/minecraft/util/math/Vec3d;
      // 2f0: getfield net/minecraft/util/math/Vec3d.field_72449_c D
      // 2f3: putfield com/trolmastercard/velvet/eb.field_70161_v D
      // 2f6: aload 10
      // 2f8: aload 10
      // 2fa: invokevirtual com/trolmastercard/velvet/eb.o ()Lnet/minecraft/util/math/Vec3d;
      // 2fd: getfield net/minecraft/util/math/Vec3d.field_72450_a D
      // 300: putfield com/trolmastercard/velvet/eb.field_70169_q D
      // 303: aload 10
      // 305: aload 10
      // 307: invokevirtual com/trolmastercard/velvet/eb.o ()Lnet/minecraft/util/math/Vec3d;
      // 30a: getfield net/minecraft/util/math/Vec3d.field_72448_b D
      // 30d: putfield com/trolmastercard/velvet/eb.field_70167_r D
      // 310: aload 10
      // 312: aload 10
      // 314: invokevirtual com/trolmastercard/velvet/eb.o ()Lnet/minecraft/util/math/Vec3d;
      // 317: getfield net/minecraft/util/math/Vec3d.field_72449_c D
      // 31a: putfield com/trolmastercard/velvet/eb.field_70166_s D
      // 31d: aload 10
      // 31f: getfield com/trolmastercard/velvet/eb.field_70760_ar F
      // 322: aload 10
      // 324: getfield com/trolmastercard/velvet/eb.field_70761_aq F
      // 327: aload 10
      // 329: getfield com/trolmastercard/velvet/eb.field_70760_ar F
      // 32c: fsub
      // 32d: fload 9
      // 32f: fmul
      // 330: fadd
      // 331: ldc_w 0.017453292
      // 334: fmul
      // 335: fstore 16
      // 337: fload 16
      // 339: invokestatic net/minecraft/util/math/MathHelper.func_76126_a (F)F
      // 33c: f2d
      // 33d: dstore 17
      // 33f: fload 16
      // 341: invokestatic net/minecraft/util/math/MathHelper.func_76134_b (F)F
      // 344: f2d
      // 345: dstore 19
      // 347: iload 14
      // 349: i2d
      // 34a: ldc2_w 0.35
      // 34d: dmul
      // 34e: dstore 21
      // 350: aload 10
      // 352: getfield com/trolmastercard/velvet/eb.field_70169_q D
      // 355: aload 10
      // 357: getfield com/trolmastercard/velvet/eb.field_70165_t D
      // 35a: aload 10
      // 35c: getfield com/trolmastercard/velvet/eb.field_70169_q D
      // 35f: dsub
      // 360: fload 9
      // 362: f2d
      // 363: dmul
      // 364: dadd
      // 365: dload 19
      // 367: dload 21
      // 369: dmul
      // 36a: dsub
      // 36b: dload 17
      // 36d: ldc2_w 0.8
      // 370: dmul
      // 371: dsub
      // 372: dstore 23
      // 374: aload 10
      // 376: getfield com/trolmastercard/velvet/eb.field_70167_r D
      // 379: aload 10
      // 37b: invokevirtual com/trolmastercard/velvet/eb.func_70047_e ()F
      // 37e: f2d
      // 37f: dadd
      // 380: aload 10
      // 382: getfield com/trolmastercard/velvet/eb.field_70163_u D
      // 385: aload 10
      // 387: getfield com/trolmastercard/velvet/eb.field_70167_r D
      // 38a: dsub
      // 38b: fload 9
      // 38d: f2d
      // 38e: dmul
      // 38f: dadd
      // 390: ldc2_w 0.45
      // 393: dsub
      // 394: dstore 25
      // 396: aload 10
      // 398: getfield com/trolmastercard/velvet/eb.field_70166_s D
      // 39b: aload 10
      // 39d: getfield com/trolmastercard/velvet/eb.field_70161_v D
      // 3a0: aload 10
      // 3a2: getfield com/trolmastercard/velvet/eb.field_70166_s D
      // 3a5: dsub
      // 3a6: fload 9
      // 3a8: f2d
      // 3a9: dmul
      // 3aa: dadd
      // 3ab: dload 17
      // 3ad: dload 21
      // 3af: dmul
      // 3b0: dsub
      // 3b1: dload 19
      // 3b3: ldc2_w 0.8
      // 3b6: dmul
      // 3b7: dadd
      // 3b8: dstore 27
      // 3ba: aload 10
      // 3bc: invokevirtual com/trolmastercard/velvet/eb.func_70093_af ()Z
      // 3bf: ifeq 3cc
      // 3c2: ldc2_w -0.1875
      // 3c5: goto 3cd
      // 3c8: invokestatic com/trolmastercard/velvet/fi.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 3cb: athrow
      // 3cc: dconst_0
      // 3cd: dstore 29
      // 3cf: aload 1
      // 3d0: getfield com/trolmastercard/velvet/gi.field_70169_q D
      // 3d3: aload 1
      // 3d4: getfield com/trolmastercard/velvet/gi.field_70165_t D
      // 3d7: aload 1
      // 3d8: getfield com/trolmastercard/velvet/gi.field_70169_q D
      // 3db: dsub
      // 3dc: fload 9
      // 3de: f2d
      // 3df: dmul
      // 3e0: dadd
      // 3e1: aload 10
      // 3e3: invokevirtual com/trolmastercard/velvet/eb.I ()Ljava/lang/Float;
      // 3e6: invokevirtual java/lang/Float.floatValue ()F
      // 3e9: ldc_w 90.0
      // 3ec: fadd
      // 3ed: f2d
      // 3ee: ldc2_w 0.017453292519943295
      // 3f1: dmul
      // 3f2: invokestatic java/lang/Math.sin (D)D
      // 3f5: ldc2_w 0.1896224320030116
      // 3f8: dmul
      // 3f9: dsub
      // 3fa: aload 10
      // 3fc: invokevirtual com/trolmastercard/velvet/eb.I ()Ljava/lang/Float;
      // 3ff: invokevirtual java/lang/Float.floatValue ()F
      // 402: f2d
      // 403: ldc2_w 0.017453292519943295
      // 406: dmul
      // 407: invokestatic java/lang/Math.sin (D)D
      // 40a: ldc2_w 0.08742380916962415
      // 40d: dmul
      // 40e: dsub
      // 40f: dstore 31
      // 411: aload 1
      // 412: getfield com/trolmastercard/velvet/gi.field_70167_r D
      // 415: aload 1
      // 416: getfield com/trolmastercard/velvet/gi.field_70163_u D
      // 419: aload 1
      // 41a: getfield com/trolmastercard/velvet/gi.field_70167_r D
      // 41d: dsub
      // 41e: fload 9
      // 420: f2d
      // 421: dmul
      // 422: dadd
      // 423: ldc2_w 0.25
      // 426: dadd
      // 427: ldc2_w -0.5
      // 42a: dadd
      // 42b: dstore 33
      // 42d: aload 1
      // 42e: getfield com/trolmastercard/velvet/gi.field_70166_s D
      // 431: aload 1
      // 432: getfield com/trolmastercard/velvet/gi.field_70161_v D
      // 435: aload 1
      // 436: getfield com/trolmastercard/velvet/gi.field_70166_s D
      // 439: dsub
      // 43a: fload 9
      // 43c: f2d
      // 43d: dmul
      // 43e: dadd
      // 43f: aload 10
      // 441: invokevirtual com/trolmastercard/velvet/eb.I ()Ljava/lang/Float;
      // 444: invokevirtual java/lang/Float.floatValue ()F
      // 447: ldc_w 90.0
      // 44a: fadd
      // 44b: f2d
      // 44c: ldc2_w 0.017453292519943295
      // 44f: dmul
      // 450: invokestatic java/lang/Math.cos (D)D
      // 453: ldc2_w 0.1896224320030116
      // 456: dmul
      // 457: dadd
      // 458: aload 10
      // 45a: invokevirtual com/trolmastercard/velvet/eb.I ()Ljava/lang/Float;
      // 45d: invokevirtual java/lang/Float.floatValue ()F
      // 460: f2d
      // 461: ldc2_w 0.017453292519943295
      // 464: dmul
      // 465: invokestatic java/lang/Math.cos (D)D
      // 468: ldc2_w 0.08742380916962415
      // 46b: dmul
      // 46c: dadd
      // 46d: dstore 35
      // 46f: dload 23
      // 471: dload 31
      // 473: dsub
      // 474: d2f
      // 475: f2d
      // 476: dstore 37
      // 478: dload 25
      // 47a: dload 33
      // 47c: dsub
      // 47d: d2f
      // 47e: f2d
      // 47f: dload 29
      // 481: dadd
      // 482: dstore 39
      // 484: dload 27
      // 486: dload 35
      // 488: dsub
      // 489: d2f
      // 48a: f2d
      // 48b: dstore 41
      // 48d: invokestatic net/minecraft/client/renderer/GlStateManager.func_179090_x ()V
      // 490: invokestatic net/minecraft/client/renderer/GlStateManager.func_179140_f ()V
      // 493: aload 11
      // 495: invokevirtual net/minecraft/item/ItemStack.func_77973_b ()Lnet/minecraft/item/Item;
      // 498: getstatic net/minecraft/init/Items.field_190931_a Lnet/minecraft/item/Item;
      // 49b: invokevirtual java/lang/Object.equals (Ljava/lang/Object;)Z
      // 49e: ifeq 501
      // 4a1: aload 13
      // 4a3: bipush 3
      // 4a4: getstatic net/minecraft/client/renderer/vertex/DefaultVertexFormats.field_181706_f Lnet/minecraft/client/renderer/vertex/VertexFormat;
      // 4a7: invokevirtual net/minecraft/client/renderer/BufferBuilder.func_181668_a (ILnet/minecraft/client/renderer/vertex/VertexFormat;)V
      // 4aa: bipush 0
      // 4ab: istore 43
      // 4ad: iload 43
      // 4af: bipush 16
      // 4b1: if_icmpgt 4fc
      // 4b4: iload 43
      // 4b6: i2f
      // 4b7: ldc_w 16.0
      // 4ba: fdiv
      // 4bb: fstore 44
      // 4bd: aload 13
      // 4bf: dload 2
      // 4c0: dload 37
      // 4c2: fload 44
      // 4c4: f2d
      // 4c5: dmul
      // 4c6: dadd
      // 4c7: dload 4
      // 4c9: dload 39
      // 4cb: fload 44
      // 4cd: fload 44
      // 4cf: fmul
      // 4d0: fload 44
      // 4d2: fadd
      // 4d3: f2d
      // 4d4: dmul
      // 4d5: ldc2_w 0.5
      // 4d8: dmul
      // 4d9: dadd
      // 4da: ldc2_w 0.25
      // 4dd: dadd
      // 4de: dload 6
      // 4e0: dload 41
      // 4e2: fload 44
      // 4e4: f2d
      // 4e5: dmul
      // 4e6: dadd
      // 4e7: invokevirtual net/minecraft/client/renderer/BufferBuilder.func_181662_b (DDD)Lnet/minecraft/client/renderer/BufferBuilder;
      // 4ea: bipush 0
      // 4eb: bipush 0
      // 4ec: bipush 0
      // 4ed: sipush 255
      // 4f0: invokevirtual net/minecraft/client/renderer/BufferBuilder.func_181669_b (IIII)Lnet/minecraft/client/renderer/BufferBuilder;
      // 4f3: invokevirtual net/minecraft/client/renderer/BufferBuilder.func_181675_d ()V
      // 4f6: iinc 43 1
      // 4f9: goto 4ad
      // 4fc: aload 12
      // 4fe: invokevirtual net/minecraft/client/renderer/Tessellator.func_78381_a ()V
      // 501: invokestatic net/minecraft/client/renderer/GlStateManager.func_179145_e ()V
      // 504: invokestatic net/minecraft/client/renderer/GlStateManager.func_179098_w ()V
      // 507: aload 0
      // 508: aload 1
      // 509: dload 2
      // 50a: dload 4
      // 50c: dload 6
      // 50e: fload 8
      // 510: fload 9
      // 512: invokespecial net/minecraft/client/renderer/entity/Render.func_76986_a (Lnet/minecraft/entity/Entity;DDDFF)V
      // 515: return
      // try (3 -> 8): 9 java/lang/RuntimeException
      // try (5 -> 16): 17 java/lang/RuntimeException
      // try (11 -> 20): 20 java/lang/RuntimeException
      // try (155 -> 172): 172 java/lang/RuntimeException
      // try (175 -> 193): 194 java/lang/RuntimeException
      // try (196 -> 223): 224 java/lang/RuntimeException
      // try (226 -> 293): 294 java/lang/RuntimeException
      // try (296 -> 304): 304 java/lang/RuntimeException
      // try (442 -> 447): 447 java/lang/RuntimeException
   }

   @Nullable
   protected ResourceLocation a(gi var1) {
      return a;
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }
}
