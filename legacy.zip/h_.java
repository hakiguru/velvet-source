package org.velvet;

@FunctionalInterface
public interface h_ {
   boolean a(f_ var1);
}
