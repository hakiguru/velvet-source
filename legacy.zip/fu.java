package org.velvet;

import java.util.ArrayList;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayer.SleepResult;
import net.minecraft.init.Blocks;
import net.minecraft.util.DamageSource;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;
import net.minecraftforge.client.event.GuiScreenEvent.ActionPerformedEvent;
import net.minecraftforge.client.event.GuiScreenEvent.InitGuiEvent;
import net.minecraftforge.event.entity.living.LivingDamageEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.PlayerSleepInBedEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent.EntityInteract;
import net.minecraftforge.event.entity.player.PlayerInteractEvent.RightClickBlock;
import net.minecraftforge.event.world.GetCollisionBoxesEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.eventhandler.Event.Result;
import net.minecraftforge.fml.common.gameevent.PlayerEvent.PlayerRespawnEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class fu {
   static final int a = 284453;

   @SubscribeEvent
   public void a(PlayerSleepInBedEvent var1) {
      EntityPlayer var2 = var1.getEntityPlayer();
      ei var3 = ei.g(var2);

      try {
         if (var3 == null) {
            return;
         }
      } catch (RuntimeException var4) {
         throw a(var4);
      }

      try {
         if (!var2.func_70093_af()) {
            return;
         }
      } catch (RuntimeException var5) {
         throw a(var5);
      }

      var1.setResult(SleepResult.OTHER_PROBLEM);
   }

   @SubscribeEvent
   public void a(GetCollisionBoxesEvent var1) {
   }

   @SubscribeEvent
   public void a(RightClickBlock var1) {
      ei var2 = ei.d(var1.getEntityPlayer().getPersistentID());
      BlockPos var3 = var1.getPos();
      World var4 = var1.getEntityPlayer().field_70170_p;
      EntityPlayer var5 = var1.getEntityPlayer();

      try {
         if (var2 == null) {
            return;
         }
      } catch (RuntimeException var29) {
         throw a(var29);
      }

      try {
         if (!var2.v()) {
            return;
         }
      } catch (RuntimeException var21) {
         throw a(var21);
      }

      try {
         if (!cj.a(var4, var3, var1.getHitVec(), var1.getFace(), var5)) {
            return;
         }
      } catch (RuntimeException var28) {
         throw a(var28);
      }

      try {
         if ((Boolean)var2.func_184212_Q().func_187225_a(em.G)) {
            var1.setCanceled(true);
            return;
         }
      } catch (RuntimeException var20) {
         throw a(var20);
      }

      try {
         if (!var5.func_70093_af()) {
            return;
         }
      } catch (RuntimeException var27) {
         throw a(var27);
      }

      ArrayList var6 = new ArrayList();

      try {
         if (var4.func_180495_p(var3.func_177978_c()).func_177230_c() == Blocks.field_150350_a) {
            var6.add(var3.func_177978_c());
         }
      } catch (RuntimeException var19) {
         throw a(var19);
      }

      try {
         if (var4.func_180495_p(var3.func_177974_f()).func_177230_c() == Blocks.field_150350_a) {
            var6.add(var3.func_177974_f());
         }
      } catch (RuntimeException var26) {
         throw a(var26);
      }

      try {
         if (var4.func_180495_p(var3.func_177968_d()).func_177230_c() == Blocks.field_150350_a) {
            var6.add(var3.func_177968_d());
         }
      } catch (RuntimeException var18) {
         throw a(var18);
      }

      try {
         if (var4.func_180495_p(var3.func_177976_e()).func_177230_c() == Blocks.field_150350_a) {
            var6.add(var3.func_177976_e());
         }
      } catch (RuntimeException var25) {
         throw a(var25);
      }

      BlockPos var7 = null;

      for (BlockPos var9 : var6) {
         if (var7 == null) {
            var7 = var9;
         } else {
            Vec3d var10 = var5.func_174791_d();
            double var11 = this.a(
               var9.func_177958_n(), var9.func_177956_o(), var9.func_177952_p(), var10.field_72450_a, var10.field_72448_b, var10.field_72449_c
            );
            double var13 = this.a(
               var7.func_177958_n(), var7.func_177956_o(), var7.func_177952_p(), var10.field_72450_a, var10.field_72448_b, var10.field_72449_c
            );
            if (var11 < var13) {
               var7 = var9;
            }
         }
      }

      try {
         if (var7 == null) {
            var5.func_145747_a(new TextComponentString("Bed is obscured"));
            return;
         }
      } catch (RuntimeException var17) {
         throw a(var17);
      }

      try {
         var5.func_70107_b(var7.func_177958_n() + 0.5, var7.func_177956_o(), var7.func_177952_p() + 0.5);
         if (var3.func_177978_c().equals(var7)) {
            var5.field_70177_z = 0.0F;
         }
      } catch (RuntimeException var24) {
         throw a(var24);
      }

      try {
         if (var3.func_177974_f().equals(var7)) {
            var5.field_70177_z = 90.0F;
         }
      } catch (RuntimeException var16) {
         throw a(var16);
      }

      try {
         if (var3.func_177968_d().equals(var7)) {
            var5.field_70177_z = 180.0F;
         }
      } catch (RuntimeException var23) {
         throw a(var23);
      }

      try {
         if (var3.func_177976_e().equals(var7)) {
            var5.field_70177_z = -90.0F;
         }
      } catch (RuntimeException var15) {
         throw a(var15);
      }

      try {
         if (var1.getWorld().field_72995_K) {
            d3.a(false);
            var2.H();
            return;
         }
      } catch (RuntimeException var22) {
         throw a(var22);
      }

      var2.c(new Vec3d(var7.func_177958_n() + 0.5, var7.func_177956_o() + 0.0F, var7.func_177952_p() + 0.5));
      var2.b(var5.field_70177_z);
      var2.func_184212_Q().func_187227_b(em.G, true);
      var2.u();
   }

   double a(double var1, double var3, double var5, double var7, double var9, double var11) {
      double var13 = var1 - var7;
      double var15 = var3 - var9;
      double var17 = var5 - var11;
      return Math.sqrt(var13 * var13 + var15 * var15 + var17 * var17);
   }

   @SubscribeEvent
   public void a(PlayerRespawnEvent var1) {
      EntityPlayer var2 = var1.player;

      try {
         if (var2 == null) {
            return;
         }
      } catch (RuntimeException var6) {
         throw a(var6);
      }

      ei var3 = ei.a(var2.getPersistentID());

      try {
         if (var3 == null) {
            return;
         }
      } catch (RuntimeException var5) {
         throw a(var5);
      }

      Vec3d var4 = var2.func_174791_d();
      var3.field_71093_bK = var2.field_71093_bK;
      var3.func_70634_a(var4.field_72450_a, var4.field_72448_b, var4.field_72449_c);
      var3.func_70619_bc();
      System.out.println(var2.field_70170_p.func_175697_a(var3.func_180425_c(), 2));
   }

   @SideOnly(Side.CLIENT)
   @SubscribeEvent
   public void b(EntityInteract var1) {
      try {
         if (!(var1.getTarget() instanceof EntityPlayer)) {
            return;
         }
      } catch (RuntimeException var12) {
         throw a(var12);
      }

      try {
         if (var1.getEntityPlayer().func_70093_af()) {
            return;
         }
      } catch (RuntimeException var8) {
         throw a(var8);
      }

      try {
         if (!var1.getEntityPlayer().getPersistentID().equals(Minecraft.func_71410_x().field_71439_g.getPersistentID())) {
            return;
         }
      } catch (RuntimeException var11) {
         throw a(var11);
      }

      EntityPlayerSP var2 = Minecraft.func_71410_x().field_71439_g;
      ei var3 = ei.d(var2.getPersistentID());
      EntityPlayer var4 = (EntityPlayer)var1.getTarget();
      ei var5 = ei.g(var4);

      try {
         if (var5 == null) {
            return;
         }
      } catch (RuntimeException var10) {
         throw a(var10);
      }

      try {
         if (var3 != null) {
            var2.func_146105_b(new TextComponentString("no lesbo yet owo"), true);
            return;
         }
      } catch (RuntimeException var7) {
         throw a(var7);
      }

      try {
         if (!var5.l()) {
            return;
         }
      } catch (RuntimeException var9) {
         throw a(var9);
      }

      try {
         if (var5.p()) {
            var5.b(Minecraft.func_71410_x().field_71439_g);
         }
      } catch (RuntimeException var6) {
         throw a(var6);
      }
   }

   @SideOnly(Side.CLIENT)
   @SubscribeEvent
   public void a(EntityInteract var1) {
      try {
         if (!(var1.getTarget() instanceof EntityPlayer)) {
            return;
         }
      } catch (RuntimeException var7) {
         throw a(var7);
      }

      try {
         if (!var1.getEntityPlayer().getPersistentID().equals(Minecraft.func_71410_x().field_71439_g.getPersistentID())) {
            return;
         }
      } catch (RuntimeException var10) {
         throw a(var10);
      }

      EntityPlayerSP var2 = Minecraft.func_71410_x().field_71439_g;
      ei var3 = ei.d(var2.getPersistentID());

      try {
         if (var3 == null) {
            return;
         }
      } catch (RuntimeException var9) {
         throw a(var9);
      }

      EntityPlayer var4 = (EntityPlayer)var1.getTarget();
      ei var5 = ei.d(var4.getPersistentID());

      try {
         if (var5 != null) {
            var4.func_146105_b(new TextComponentString("no lesbo yet owo"), true);
            return;
         }
      } catch (RuntimeException var8) {
         throw a(var8);
      }

      try {
         if (var3.p()) {
            var3.ab = false;
            var3.b(var4);
         }
      } catch (RuntimeException var6) {
         throw a(var6);
      }
   }

   @SubscribeEvent
   public void b(RightClickBlock param1) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 000: aload 1
      // 001: invokevirtual net/minecraftforge/event/entity/player/PlayerInteractEvent$RightClickBlock.getEntityPlayer ()Lnet/minecraft/entity/player/EntityPlayer;
      // 004: astore 2
      // 005: aload 2
      // 006: invokestatic com/trolmastercard/velvet/ei.g (Lnet/minecraft/entity/player/EntityPlayer;)Lcom/trolmastercard/velvet/ei;
      // 009: astore 3
      // 00a: aload 3
      // 00b: ifnonnull 013
      // 00e: return
      // 00f: invokestatic com/trolmastercard/velvet/fu.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 012: athrow
      // 013: aload 3
      // 014: instanceof com/trolmastercard/velvet/ec
      // 017: ifne 01f
      // 01a: return
      // 01b: invokestatic com/trolmastercard/velvet/fu.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 01e: athrow
      // 01f: aload 2
      // 020: invokevirtual net/minecraft/entity/player/EntityPlayer.func_70093_af ()Z
      // 023: ifne 02b
      // 026: return
      // 027: invokestatic com/trolmastercard/velvet/fu.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 02a: athrow
      // 02b: aload 2
      // 02c: invokevirtual net/minecraft/entity/player/EntityPlayer.func_184614_ca ()Lnet/minecraft/item/ItemStack;
      // 02f: getstatic net/minecraft/item/ItemStack.field_190927_a Lnet/minecraft/item/ItemStack;
      // 032: invokevirtual java/lang/Object.equals (Ljava/lang/Object;)Z
      // 035: ifne 03d
      // 038: return
      // 039: invokestatic com/trolmastercard/velvet/fu.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 03c: athrow
      // 03d: aload 3
      // 03e: invokevirtual com/trolmastercard/velvet/ei.func_184212_Q ()Lnet/minecraft/network/datasync/EntityDataManager;
      // 041: getstatic com/trolmastercard/velvet/em.G Lnet/minecraft/network/datasync/DataParameter;
      // 044: invokevirtual net/minecraft/network/datasync/EntityDataManager.func_187225_a (Lnet/minecraft/network/datasync/DataParameter;)Ljava/lang/Object;
      // 047: checkcast java/lang/Boolean
      // 04a: invokevirtual java/lang/Boolean.booleanValue ()Z
      // 04d: ifeq 055
      // 050: return
      // 051: invokestatic com/trolmastercard/velvet/fu.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 054: athrow
      // 055: aload 2
      // 056: getfield net/minecraft/entity/player/EntityPlayer.field_70125_A F
      // 059: ldc_w 20.0
      // 05c: fcmpg
      // 05d: ifge 065
      // 060: return
      // 061: invokestatic com/trolmastercard/velvet/fu.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 064: athrow
      // 065: aload 1
      // 066: invokevirtual net/minecraftforge/event/entity/player/PlayerInteractEvent$RightClickBlock.getHitVec ()Lnet/minecraft/util/math/Vec3d;
      // 069: astore 4
      // 06b: aload 4
      // 06d: ifnonnull 075
      // 070: return
      // 071: invokestatic com/trolmastercard/velvet/fu.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 074: athrow
      // 075: new net/minecraft/util/math/Vec3d
      // 078: dup
      // 079: aload 4
      // 07b: getfield net/minecraft/util/math/Vec3d.field_72450_a D
      // 07e: aload 4
      // 080: getfield net/minecraft/util/math/Vec3d.field_72448_b D
      // 083: invokestatic java/lang/Math.floor (D)D
      // 086: dconst_0
      // 087: dadd
      // 088: aload 4
      // 08a: getfield net/minecraft/util/math/Vec3d.field_72449_c D
      // 08d: invokespecial net/minecraft/util/math/Vec3d.<init> (DDD)V
      // 090: astore 5
      // 092: aload 4
      // 094: aload 2
      // 095: invokevirtual net/minecraft/entity/player/EntityPlayer.func_174791_d ()Lnet/minecraft/util/math/Vec3d;
      // 098: invokevirtual net/minecraft/util/math/Vec3d.func_72438_d (Lnet/minecraft/util/math/Vec3d;)D
      // 09b: ldc2_w 3.0
      // 09e: dcmpl
      // 09f: ifle 0a7
      // 0a2: return
      // 0a3: invokestatic com/trolmastercard/velvet/fu.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 0a6: athrow
      // 0a7: aload 2
      // 0a8: aload 5
      // 0aa: getfield net/minecraft/util/math/Vec3d.field_72450_a D
      // 0ad: aload 4
      // 0af: getfield net/minecraft/util/math/Vec3d.field_72448_b D
      // 0b2: invokestatic java/lang/Math.floor (D)D
      // 0b5: aload 5
      // 0b7: getfield net/minecraft/util/math/Vec3d.field_72449_c D
      // 0ba: invokevirtual net/minecraft/entity/player/EntityPlayer.func_70107_b (DDD)V
      // 0bd: aload 3
      // 0be: aload 5
      // 0c0: invokevirtual com/trolmastercard/velvet/ei.c (Lnet/minecraft/util/math/Vec3d;)V
      // 0c3: aload 3
      // 0c4: aload 2
      // 0c5: getfield net/minecraft/entity/player/EntityPlayer.field_70177_z F
      // 0c8: invokevirtual com/trolmastercard/velvet/ei.b (F)V
      // 0cb: aload 3
      // 0cc: invokevirtual com/trolmastercard/velvet/ei.func_184212_Q ()Lnet/minecraft/network/datasync/EntityDataManager;
      // 0cf: getstatic com/trolmastercard/velvet/em.G Lnet/minecraft/network/datasync/DataParameter;
      // 0d2: bipush 1
      // 0d3: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 0d6: invokevirtual net/minecraft/network/datasync/EntityDataManager.func_187227_b (Lnet/minecraft/network/datasync/DataParameter;Ljava/lang/Object;)V
      // 0d9: aload 3
      // 0da: invokevirtual com/trolmastercard/velvet/ei.func_184212_Q ()Lnet/minecraft/network/datasync/EntityDataManager;
      // 0dd: getstatic com/trolmastercard/velvet/em.D Lnet/minecraft/network/datasync/DataParameter;
      // 0e0: bipush 0
      // 0e1: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 0e4: invokevirtual net/minecraft/network/datasync/EntityDataManager.func_187227_b (Lnet/minecraft/network/datasync/DataParameter;Ljava/lang/Object;)V
      // 0e7: aload 3
      // 0e8: getstatic com/trolmastercard/velvet/fp.STARTDOGGY Lcom/trolmastercard/velvet/fp;
      // 0eb: invokevirtual com/trolmastercard/velvet/ei.b (Lcom/trolmastercard/velvet/fp;)V
      // 0ee: aload 1
      // 0ef: invokevirtual net/minecraftforge/event/entity/player/PlayerInteractEvent$RightClickBlock.getWorld ()Lnet/minecraft/world/World;
      // 0f2: getfield net/minecraft/world/World.field_72995_K Z
      // 0f5: ifeq 11d
      // 0f8: invokestatic net/minecraft/client/Minecraft.func_71410_x ()Lnet/minecraft/client/Minecraft;
      // 0fb: getfield net/minecraft/client/Minecraft.field_71439_g Lnet/minecraft/client/entity/EntityPlayerSP;
      // 0fe: invokevirtual net/minecraft/client/entity/EntityPlayerSP.getPersistentID ()Ljava/util/UUID;
      // 101: aload 2
      // 102: invokevirtual net/minecraft/entity/player/EntityPlayer.getPersistentID ()Ljava/util/UUID;
      // 105: invokevirtual java/util/UUID.equals (Ljava/lang/Object;)Z
      // 108: ifeq 11d
      // 10b: goto 112
      // 10e: invokestatic com/trolmastercard/velvet/fu.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 111: athrow
      // 112: bipush 0
      // 113: invokestatic com/trolmastercard/velvet/d3.a (Z)V
      // 116: goto 11d
      // 119: invokestatic com/trolmastercard/velvet/fu.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 11c: athrow
      // 11d: return
      // try (6 -> 9): 9 java/lang/RuntimeException
      // try (11 -> 15): 15 java/lang/RuntimeException
      // try (17 -> 21): 21 java/lang/RuntimeException
      // try (23 -> 29): 29 java/lang/RuntimeException
      // try (31 -> 39): 39 java/lang/RuntimeException
      // try (41 -> 47): 47 java/lang/RuntimeException
      // try (52 -> 55): 55 java/lang/RuntimeException
      // try (70 -> 78): 78 java/lang/RuntimeException
      // try (80 -> 122): 123 java/lang/RuntimeException
      // try (115 -> 127): 128 java/lang/RuntimeException
   }

   @SubscribeEvent
   public void a(LivingHurtEvent param1) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 00: aload 1
      // 01: invokevirtual net/minecraftforge/event/entity/living/LivingHurtEvent.getEntityLiving ()Lnet/minecraft/entity/EntityLivingBase;
      // 04: instanceof net/minecraft/entity/player/EntityPlayer
      // 07: ifne 0f
      // 0a: return
      // 0b: invokestatic com/trolmastercard/velvet/fu.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 0e: athrow
      // 0f: aload 1
      // 10: invokevirtual net/minecraftforge/event/entity/living/LivingHurtEvent.getSource ()Lnet/minecraft/util/DamageSource;
      // 13: getstatic net/minecraft/util/DamageSource.field_76379_h Lnet/minecraft/util/DamageSource;
      // 16: if_acmpeq 1e
      // 19: return
      // 1a: invokestatic com/trolmastercard/velvet/fu.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 1d: athrow
      // 1e: aload 1
      // 1f: invokevirtual net/minecraftforge/event/entity/living/LivingHurtEvent.getEntityLiving ()Lnet/minecraft/entity/EntityLivingBase;
      // 22: checkcast net/minecraft/entity/player/EntityPlayer
      // 25: astore 2
      // 26: aload 2
      // 27: invokestatic com/trolmastercard/velvet/ei.g (Lnet/minecraft/entity/player/EntityPlayer;)Lcom/trolmastercard/velvet/ei;
      // 2a: astore 3
      // 2b: aload 3
      // 2c: ifnonnull 34
      // 2f: return
      // 30: invokestatic com/trolmastercard/velvet/fu.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 33: athrow
      // 34: aload 3
      // 35: instanceof com/trolmastercard/velvet/e5
      // 38: ifne 49
      // 3b: aload 3
      // 3c: instanceof com/trolmastercard/velvet/e9
      // 3f: ifeq 55
      // 42: goto 49
      // 45: invokestatic com/trolmastercard/velvet/fu.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 48: athrow
      // 49: aload 1
      // 4a: bipush 1
      // 4b: invokevirtual net/minecraftforge/event/entity/living/LivingHurtEvent.setCanceled (Z)V
      // 4e: goto 55
      // 51: invokestatic com/trolmastercard/velvet/fu.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 54: athrow
      // 55: return
      // try (0 -> 5): 5 java/lang/RuntimeException
      // try (7 -> 12): 12 java/lang/RuntimeException
      // try (21 -> 24): 24 java/lang/RuntimeException
      // try (26 -> 32): 33 java/lang/RuntimeException
      // try (29 -> 38): 39 java/lang/RuntimeException
   }

   @SideOnly(Side.CLIENT)
   @SubscribeEvent
   public void a(InitGuiEvent param1) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 00: aload 1
      // 01: invokevirtual net/minecraftforge/client/event/GuiScreenEvent$InitGuiEvent.getGui ()Lnet/minecraft/client/gui/GuiScreen;
      // 04: astore 2
      // 05: aload 2
      // 06: instanceof net/minecraft/client/gui/inventory/GuiInventory
      // 09: ifne 1f
      // 0c: aload 2
      // 0d: instanceof net/minecraft/client/gui/inventory/GuiContainerCreative
      // 10: ifne 1f
      // 13: goto 1a
      // 16: invokestatic com/trolmastercard/velvet/fu.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 19: athrow
      // 1a: return
      // 1b: invokestatic com/trolmastercard/velvet/fu.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 1e: athrow
      // 1f: invokestatic net/minecraft/client/Minecraft.func_71410_x ()Lnet/minecraft/client/Minecraft;
      // 22: getfield net/minecraft/client/Minecraft.field_71439_g Lnet/minecraft/client/entity/EntityPlayerSP;
      // 25: astore 3
      // 26: aload 3
      // 27: ifnonnull 2f
      // 2a: return
      // 2b: invokestatic com/trolmastercard/velvet/fu.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 2e: athrow
      // 2f: aload 3
      // 30: invokestatic com/trolmastercard/velvet/ei.g (Lnet/minecraft/entity/player/EntityPlayer;)Lcom/trolmastercard/velvet/ei;
      // 33: astore 4
      // 35: aload 4
      // 37: ifnonnull 3f
      // 3a: return
      // 3b: invokestatic com/trolmastercard/velvet/fu.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 3e: athrow
      // 3f: aload 4
      // 41: invokevirtual com/trolmastercard/velvet/ei.A ()Z
      // 44: ifeq 4c
      // 47: return
      // 48: invokestatic com/trolmastercard/velvet/fu.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 4b: athrow
      // 4c: aload 1
      // 4d: invokevirtual net/minecraftforge/client/event/GuiScreenEvent$InitGuiEvent.getButtonList ()Ljava/util/List;
      // 50: astore 5
      // 52: aload 4
      // 54: invokevirtual com/trolmastercard/velvet/ei.ah ()I
      // 57: ifne 64
      // 5a: ldc_w "action.names.dressup"
      // 5d: goto 67
      // 60: invokestatic com/trolmastercard/velvet/fu.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 63: athrow
      // 64: ldc_w "action.names.strip"
      // 67: bipush 0
      // 68: anewarray 4
      // 6b: invokestatic net/minecraft/client/resources/I18n.func_135052_a (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
      // 6e: astore 6
      // 70: aload 5
      // 72: new net/minecraft/client/gui/GuiButton
      // 75: dup
      // 76: ldc 284453
      // 78: aload 2
      // 79: getfield net/minecraft/client/gui/GuiScreen.field_146294_l I
      // 7c: i2d
      // 7d: ldc2_w 0.5
      // 80: dmul
      // 81: ldc2_w 35.0
      // 84: dsub
      // 85: d2i
      // 86: aload 2
      // 87: getfield net/minecraft/client/gui/GuiScreen.field_146295_m I
      // 8a: i2d
      // 8b: ldc2_w 0.87
      // 8e: dmul
      // 8f: d2i
      // 90: bipush 70
      // 92: bipush 20
      // 94: aload 6
      // 96: invokespecial net/minecraft/client/gui/GuiButton.<init> (IIIIILjava/lang/String;)V
      // 99: invokeinterface java/util/List.add (Ljava/lang/Object;)Z 2
      // 9e: pop
      // 9f: aload 1
      // a0: aload 5
      // a2: invokevirtual net/minecraftforge/client/event/GuiScreenEvent$InitGuiEvent.setButtonList (Ljava/util/List;)V
      // a5: return
      // try (3 -> 9): 10 java/lang/RuntimeException
      // try (6 -> 13): 13 java/lang/RuntimeException
      // try (18 -> 21): 21 java/lang/RuntimeException
      // try (26 -> 29): 29 java/lang/RuntimeException
      // try (31 -> 35): 35 java/lang/RuntimeException
      // try (40 -> 45): 45 java/lang/RuntimeException
   }

   @SideOnly(Side.CLIENT)
   @SubscribeEvent
   public void a(ActionPerformedEvent param1) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 00: aload 1
      // 01: invokevirtual net/minecraftforge/client/event/GuiScreenEvent$ActionPerformedEvent.getGui ()Lnet/minecraft/client/gui/GuiScreen;
      // 04: astore 2
      // 05: aload 2
      // 06: instanceof net/minecraft/client/gui/inventory/GuiInventory
      // 09: ifne 1f
      // 0c: aload 2
      // 0d: instanceof net/minecraft/client/gui/inventory/GuiContainerCreative
      // 10: ifne 1f
      // 13: goto 1a
      // 16: invokestatic com/trolmastercard/velvet/fu.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 19: athrow
      // 1a: return
      // 1b: invokestatic com/trolmastercard/velvet/fu.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 1e: athrow
      // 1f: aload 1
      // 20: invokevirtual net/minecraftforge/client/event/GuiScreenEvent$ActionPerformedEvent.getButton ()Lnet/minecraft/client/gui/GuiButton;
      // 23: getfield net/minecraft/client/gui/GuiButton.field_146127_k I
      // 26: ldc 284453
      // 28: if_icmpeq 30
      // 2b: return
      // 2c: invokestatic com/trolmastercard/velvet/fu.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 2f: athrow
      // 30: invokestatic net/minecraft/client/Minecraft.func_71410_x ()Lnet/minecraft/client/Minecraft;
      // 33: astore 3
      // 34: aload 3
      // 35: getfield net/minecraft/client/Minecraft.field_71439_g Lnet/minecraft/client/entity/EntityPlayerSP;
      // 38: invokevirtual net/minecraft/client/entity/EntityPlayerSP.getPersistentID ()Ljava/util/UUID;
      // 3b: invokestatic com/trolmastercard/velvet/ei.d (Ljava/util/UUID;)Lcom/trolmastercard/velvet/ei;
      // 3e: astore 4
      // 40: aload 4
      // 42: ifnonnull 4a
      // 45: return
      // 46: invokestatic com/trolmastercard/velvet/fu.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 49: athrow
      // 4a: aload 4
      // 4c: invokevirtual com/trolmastercard/velvet/ei.A ()Z
      // 4f: ifeq 57
      // 52: return
      // 53: invokestatic com/trolmastercard/velvet/fu.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 56: athrow
      // 57: aload 4
      // 59: invokevirtual com/trolmastercard/velvet/ei.ae ()Ljava/util/UUID;
      // 5c: ifnull 64
      // 5f: return
      // 60: invokestatic com/trolmastercard/velvet/fu.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 63: athrow
      // 64: aload 4
      // 66: invokevirtual com/trolmastercard/velvet/ei.y ()Lcom/trolmastercard/velvet/fp;
      // 69: getstatic com/trolmastercard/velvet/fp.NULL Lcom/trolmastercard/velvet/fp;
      // 6c: if_acmpeq 74
      // 6f: return
      // 70: invokestatic com/trolmastercard/velvet/fu.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 73: athrow
      // 74: aload 3
      // 75: getfield net/minecraft/client/Minecraft.field_71474_y Lnet/minecraft/client/settings/GameSettings;
      // 78: bipush 2
      // 79: putfield net/minecraft/client/settings/GameSettings.field_74320_O I
      // 7c: aload 3
      // 7d: getfield net/minecraft/client/Minecraft.field_71460_t Lnet/minecraft/client/renderer/EntityRenderer;
      // 80: aconst_null
      // 81: invokevirtual net/minecraft/client/renderer/EntityRenderer.func_175066_a (Lnet/minecraft/entity/Entity;)V
      // 84: aload 4
      // 86: getstatic com/trolmastercard/velvet/fp.STRIP Lcom/trolmastercard/velvet/fp;
      // 89: invokevirtual com/trolmastercard/velvet/ei.b (Lcom/trolmastercard/velvet/fp;)V
      // 8c: bipush 0
      // 8d: invokestatic com/trolmastercard/velvet/d3.a (Z)V
      // 90: aload 3
      // 91: getfield net/minecraft/client/Minecraft.field_71439_g Lnet/minecraft/client/entity/EntityPlayerSP;
      // 94: invokevirtual net/minecraft/client/entity/EntityPlayerSP.func_71053_j ()V
      // 97: return
      // try (3 -> 9): 10 java/lang/RuntimeException
      // try (6 -> 13): 13 java/lang/RuntimeException
      // try (15 -> 21): 21 java/lang/RuntimeException
      // try (30 -> 33): 33 java/lang/RuntimeException
      // try (35 -> 39): 39 java/lang/RuntimeException
      // try (41 -> 45): 45 java/lang/RuntimeException
      // try (47 -> 52): 52 java/lang/RuntimeException
   }

   @SubscribeEvent
   public void a(LivingDamageEvent var1) {
      try {
         if (var1.getSource() != DamageSource.field_76379_h) {
            return;
         }
      } catch (RuntimeException var7) {
         throw a(var7);
      }

      EntityLivingBase var2 = var1.getEntityLiving();

      try {
         if (!(var2 instanceof EntityPlayer)) {
            return;
         }
      } catch (RuntimeException var6) {
         throw a(var6);
      }

      ei var3 = ei.d(var2.getPersistentID());

      try {
         if (var3 == null) {
            return;
         }
      } catch (RuntimeException var5) {
         throw a(var5);
      }

      try {
         if (var3 instanceof ec) {
            var1.setResult(Result.DENY);
            var1.setAmount(0.0F);
            var1.setCanceled(true);
         }
      } catch (RuntimeException var4) {
         throw a(var4);
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }
}
