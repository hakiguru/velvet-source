package org.velvet;

@FunctionalInterface
public interface ao {
   void a(f_ var1);
}
