package org.velvet;

import net.minecraft.util.math.Vec3d;

@FunctionalInterface
public interface b8 {
   Vec3d a(em var1);
}
