package org.velvet;

public interface bh {
   void b();
}
