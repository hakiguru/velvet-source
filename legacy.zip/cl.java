package org.velvet;

import net.minecraft.util.ResourceLocation;

public class cl extends cv {
   public cl() {
      this.c = this.a();
   }

   @Override
   protected ResourceLocation[] a() {
      return new ResourceLocation[]{new ResourceLocation("velvet", "geo/bia/bianude.geo.json"), new ResourceLocation("velvet", "geo/bia/biadressed.geo.json")};
   }

   @Override
   public ResourceLocation b() {
      return new ResourceLocation("velvet", "textures/entity/bia/bia.png");
   }

   @Override
   public ResourceLocation b(em var1) {
      return new ResourceLocation("velvet", "animations/bia/bia.animation.json");
   }

   @Override
   public String[] c() {
      return new String[]{"armorHelmet"};
   }

   @Override
   public String[] g() {
      return new String[]{"leaf7", "leaf8"};
   }

   @Override
   public String[] f() {
      return new String[]{"armorChest", "armorBoobs", "armorShoulderR", "armorShoulderL"};
   }

   @Override
   public String[] a() {
      return new String[]{"bra", "upperBodyR", "upperBodyL"};
   }

   @Override
   public String[] h() {
      return new String[]{"armorBootyR", "armorBootyL", "armorPantsLowL", "armorPantsLowR", "armorPantsLowR", "armorPantsUpR", "armorPantsUpL", "armorHip"};
   }

   @Override
   public String[] e() {
      return new String[]{"slip", "fleshL", "fleshR", "vagina", "curvesL", "curvesR", "kneeL", "kneeR"};
   }

   @Override
   public String[] b() {
      return new String[]{"armorShoesL", "armorShoesR"};
   }
}
