package org.velvet;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.UUID;
import javax.annotation.Nullable;
import javax.imageio.ImageIO;
import javax.vecmath.Matrix4f;
import javax.vecmath.Vector4f;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.renderer.ActiveRenderInfo;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityHanging;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemArmor.ArmorMaterial;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import software.bernie.geckolib3.core.IAnimatable;
import software.bernie.geckolib3.geo.render.built.GeoBone;
import software.bernie.geckolib3.geo.render.built.GeoCube;
import software.bernie.geckolib3.geo.render.built.GeoModel;
import software.bernie.geckolib3.model.AnimatedGeoModel;
import software.bernie.geckolib3.model.provider.GeoModelProvider;
import software.bernie.geckolib3.renderers.geo.GeoEntityRenderer;
import software.bernie.geckolib3.util.MatrixStack;

public abstract class d_<T extends em & IAnimatable> extends GeoEntityRenderer<T> implements c3 {
   protected static final ResourceLocation e = new ResourceLocation("velvet", "textures/line.png");
   static final float m = 1.5F;
   protected double c;
   protected T j;
   protected static Minecraft i;
   protected static HashMap<UUID, ResourceLocation> l = new HashMap<>();
   Color f = new Color(245, 199, 165);
   Color o = new Color(245, 157, 169);
   boolean h = false;
   protected HashSet<String> p = new HashSet<>();
   Integer k = null;
   Integer b = null;
   Integer d = null;
   float a = 0.0F;
   public static BufferBuilder n;
   Matrix4f g = null;
   protected GeoBone q = null;

   public d_(RenderManager var1, AnimatedGeoModel<T> var2, double var3) {
      super(var1, var2);
      this.c = var3;
      i = Minecraft.func_71410_x();
      this.field_76989_e = 0.2F;
   }

   protected ResourceLocation d(T var1) throws IOException {
      label38: {
         try {
            if (!(var1.field_70170_p instanceof gj) && var1.ae() != null) {
               break label38;
            }
         } catch (IOException var5) {
            throw b(var5);
         }

         ResourceLocation var2 = l.get(i.func_110432_I().func_148256_e().getId());

         try {
            if (var2 == null) {
               return this.a(i.func_110432_I().func_148256_e().getId(), var1.field_70170_p);
            }

            return var2;
         } catch (IOException var4) {
            throw b(var4);
         }
      }

      ResourceLocation var6 = l.get(var1.ae());

      try {
         if (var6 == null) {
            return this.a(var1.ae(), var1.field_70170_p);
         }
      } catch (IOException var3) {
         throw b(var3);
      }

      return var6;
   }

   protected ResourceLocation a(UUID var1, World var2) throws IOException {
      BufferedImage var3;
      try {
         var3 = y.a(var1);
         Graphics var4 = var3.getGraphics();
         var4.setColor(this.f);
         var4.fillRect(0, 0, 4, 3);
         var4.setColor(this.o);
         var4.fillRect(4, 0, 3, 3);
      } catch (Exception var6) {
         try {
            if (!this.h) {
               this.h = true;
            }
         } catch (Exception var5) {
            throw b(var5);
         }

         var3 = ImageIO.read(i.func_110442_L().func_110536_a(new ResourceLocation("velvet", "textures/player/steve.png")).func_110527_b());
      }

      l.put(var1, this.field_76990_c.field_78724_e.func_110578_a("player" + var1, new DynamicTexture(var3)));
      return l.get(var1);
   }

   protected static float a(em var0, float var1) {
      try {
         if (var0.Q()) {
            return var0.I();
         }
      } catch (IllegalStateException var2) {
         throw b(var2);
      }

      return b6.a(var0.field_70760_ar, var0.field_70761_aq, var1);
   }

   protected void d() {
   }

   protected void b() {
   }

   float a(World var1, Vec3d var2, float var3, float var4) {
      RayTraceResult var5 = this.a(var2, var2.func_178787_e(ck.a(new Vec3d(0.0, 0.0, -4.0), var3, var4)), var1);

      try {
         if (var5 == null) {
            return 4.0F;
         }
      } catch (IllegalStateException var8) {
         throw b(var8);
      }

      Vec3d var6 = var5.field_72307_f;

      try {
         if (var6 == null) {
            return 4.0F;
         }
      } catch (IllegalStateException var7) {
         throw b(var7);
      }

      return (float)var2.func_72438_d(var6);
   }

   boolean a(T var1, EntityPlayer var2) {
      try {
         if (var1 instanceof ei) {
            return true;
         }
      } catch (IllegalStateException var20) {
         throw b(var20);
      }

      World var3 = var1.field_70170_p;
      Vec3d var4 = var1.func_174791_d();
      float var5 = var1.field_70130_N * 1.5F;
      float var6 = var1.field_70131_O * 1.5F;
      Vec3d var7 = var2.func_174791_d().func_72441_c(0.0, var2.func_70047_e(), 0.0);
      int var8 = i.field_71474_y.field_74320_O;

      try {
         if (var8 != 0) {
            return true;
         }
      } catch (IllegalStateException var19) {
         throw b(var19);
      }

      if (var8 > 0) {
         float var9 = var2.field_70177_z;
         float var10 = var2.field_70125_A;
         if (var8 == 2) {
            var10 += 180.0F;
         }

         float var11 = 4.0F;
         Vec3d var12 = var7.func_72441_c(
            MathHelper.func_76126_a(var9 * (float) (Math.PI / 180.0)) * MathHelper.func_76134_b(var10 * (float) (Math.PI / 180.0)) * var11,
            MathHelper.func_76126_a(var10 * (float) (Math.PI / 180.0)) * var11,
            -MathHelper.func_76134_b(var9 * (float) (Math.PI / 180.0)) * MathHelper.func_76134_b(var10 * (float) (Math.PI / 180.0)) * var11
         );
         BlockPos var13 = new BlockPos(var12);
         boolean var14 = var3.func_175623_d(var13);
         if (!var14) {
            var7 = var12;
         } else if (var3.func_175623_d(var13.func_177982_a(0, 1, 0))) {
            var7 = new Vec3d(var12.field_72450_a, var13.func_177956_o() + 1, var12.field_72449_c);
         }
      }

      Vec3d[] var21 = new Vec3d[]{
         var4.func_72441_c(-var5 / 2.0F, 0.0, -var5 / 2.0F),
         var4.func_72441_c(-var5 / 2.0F, 0.0, var5 / 2.0F),
         var4.func_72441_c(var5 / 2.0F, 0.0, -var5 / 2.0F),
         var4.func_72441_c(var5 / 2.0F, 0.0, var5 / 2.0F),
         var4.func_72441_c(-var5 / 2.0F, var6, -var5 / 2.0F),
         var4.func_72441_c(-var5 / 2.0F, var6, var5 / 2.0F),
         var4.func_72441_c(var5 / 2.0F, var6, -var5 / 2.0F),
         var4.func_72441_c(var5 / 2.0F, var6, var5 / 2.0F)
      };

      for (Vec3d var25 : var21) {
         RayTraceResult var26 = this.a(var7, var25, var3);

         try {
            if (var26 == null) {
               return true;
            }
         } catch (IllegalStateException var18) {
            throw b(var18);
         }

         IBlockState var15 = var3.func_180495_p(var26.func_178782_a());

         try {
            if (var15.func_185895_e()) {
               return true;
            }
         } catch (IllegalStateException var16) {
            throw b(var16);
         }

         try {
            if (var15.func_177230_c().func_180664_k() != BlockRenderLayer.SOLID) {
               return true;
            }
         } catch (IllegalStateException var17) {
            throw b(var17);
         }
      }

      return false;
   }

   HashSet<String> a(Boolean param1, boolean param2) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 00: getstatic com/trolmastercard/velvet/ClientProxy.IS_PRELOADING Z
      // 03: ifeq 12
      // 06: new java/util/HashSet
      // 09: dup
      // 0a: invokespecial java/util/HashSet.<init> ()V
      // 0d: areturn
      // 0e: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 11: athrow
      // 12: aload 1
      // 13: invokevirtual java/lang/Boolean.booleanValue ()Z
      // 16: ifeq 20
      // 19: invokestatic com/trolmastercard/velvet/a.b ()Ljava/util/HashSet;
      // 1c: astore 3
      // 1d: goto 28
      // 20: aload 0
      // 21: getfield com/trolmastercard/velvet/d_.j Lcom/trolmastercard/velvet/em;
      // 24: invokevirtual com/trolmastercard/velvet/em.Y ()Ljava/util/HashSet;
      // 27: astore 3
      // 28: new java/util/HashSet
      // 2b: dup
      // 2c: invokespecial java/util/HashSet.<init> ()V
      // 2f: astore 4
      // 31: aload 3
      // 32: invokevirtual java/util/HashSet.iterator ()Ljava/util/Iterator;
      // 35: astore 5
      // 37: aload 5
      // 39: invokeinterface java/util/Iterator.hasNext ()Z 1
      // 3e: ifeq 88
      // 41: aload 5
      // 43: invokeinterface java/util/Iterator.next ()Ljava/lang/Object; 1
      // 48: checkcast java/lang/String
      // 4b: astore 6
      // 4d: aload 6
      // 4f: invokestatic com/trolmastercard/velvet/br.b (Ljava/lang/String;)Lcom/trolmastercard/velvet/br$b;
      // 52: astore 7
      // 54: aload 7
      // 56: ifnonnull 60
      // 59: goto 37
      // 5c: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 5f: athrow
      // 60: aload 7
      // 62: invokevirtual com/trolmastercard/velvet/br$b.a ()Z
      // 65: ifne 7a
      // 68: iload 2
      // 69: ifeq 7a
      // 6c: goto 73
      // 6f: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 72: athrow
      // 73: goto 37
      // 76: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 79: athrow
      // 7a: aload 4
      // 7c: aload 7
      // 7e: invokevirtual com/trolmastercard/velvet/br$b.h ()Ljava/util/HashSet;
      // 81: invokevirtual java/util/HashSet.addAll (Ljava/util/Collection;)Z
      // 84: pop
      // 85: goto 37
      // 88: aload 4
      // 8a: areturn
      // try (0 -> 6): 6 java/lang/IllegalStateException
      // try (35 -> 38): 38 java/lang/IllegalStateException
      // try (40 -> 45): 46 java/lang/IllegalStateException
      // try (43 -> 49): 49 java/lang/IllegalStateException
   }

   public void a(GeoModel param1, T param2, float param3, float param4, float param5, float param6, float param7) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 00: getstatic com/trolmastercard/velvet/d_.i Lnet/minecraft/client/Minecraft;
      // 03: getfield net/minecraft/client/Minecraft.field_71439_g Lnet/minecraft/client/entity/EntityPlayerSP;
      // 06: ifnull 3f
      // 09: aload 2
      // 0a: invokevirtual com/trolmastercard/velvet/em.h ()Z
      // 0d: ifne 3f
      // 10: goto 17
      // 13: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 16: athrow
      // 17: aload 2
      // 18: invokevirtual com/trolmastercard/velvet/em.d ()Z
      // 1b: ifeq 3f
      // 1e: goto 25
      // 21: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 24: athrow
      // 25: aload 0
      // 26: aload 2
      // 27: getstatic com/trolmastercard/velvet/d_.i Lnet/minecraft/client/Minecraft;
      // 2a: getfield net/minecraft/client/Minecraft.field_71439_g Lnet/minecraft/client/entity/EntityPlayerSP;
      // 2d: invokevirtual com/trolmastercard/velvet/d_.a (Lcom/trolmastercard/velvet/em;Lnet/minecraft/entity/player/EntityPlayer;)Z
      // 30: ifne 3f
      // 33: goto 3a
      // 36: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 39: athrow
      // 3a: return
      // 3b: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 3e: athrow
      // 3f: invokestatic net/minecraft/client/renderer/GlStateManager.func_179091_B ()V
      // 42: aload 0
      // 43: aload 2
      // 44: fload 3
      // 45: fload 4
      // 47: fload 5
      // 49: fload 6
      // 4b: fload 7
      // 4d: invokevirtual com/trolmastercard/velvet/d_.a (Lcom/trolmastercard/velvet/em;FFFFF)V
      // 50: aload 0
      // 51: aload 2
      // 52: fload 3
      // 53: fload 4
      // 55: fload 5
      // 57: fload 6
      // 59: fload 7
      // 5b: invokevirtual com/trolmastercard/velvet/d_.renderLate (Ljava/lang/Object;FFFFF)V
      // 5e: invokestatic net/minecraft/client/renderer/Tessellator.func_178181_a ()Lnet/minecraft/client/renderer/Tessellator;
      // 61: invokevirtual net/minecraft/client/renderer/Tessellator.func_178180_c ()Lnet/minecraft/client/renderer/BufferBuilder;
      // 64: astore 8
      // 66: aload 8
      // 68: bipush 7
      // 6a: getstatic net/minecraft/client/renderer/vertex/DefaultVertexFormats.field_181712_l Lnet/minecraft/client/renderer/vertex/VertexFormat;
      // 6d: invokevirtual net/minecraft/client/renderer/BufferBuilder.func_181668_a (ILnet/minecraft/client/renderer/vertex/VertexFormat;)V
      // 70: aload 0
      // 71: aload 0
      // 72: aload 0
      // 73: getfield com/trolmastercard/velvet/d_.j Lcom/trolmastercard/velvet/em;
      // 76: invokevirtual com/trolmastercard/velvet/d_.getEntityTexture (Lnet/minecraft/entity/EntityLivingBase;)Lnet/minecraft/util/ResourceLocation;
      // 79: invokestatic java/util/Objects.requireNonNull (Ljava/lang/Object;)Ljava/lang/Object;
      // 7c: checkcast net/minecraft/util/ResourceLocation
      // 7f: invokevirtual com/trolmastercard/velvet/d_.func_110776_a (Lnet/minecraft/util/ResourceLocation;)V
      // 82: aload 0
      // 83: getfield com/trolmastercard/velvet/d_.p Ljava/util/HashSet;
      // 86: invokevirtual java/util/HashSet.clear ()V
      // 89: aload 0
      // 8a: aload 0
      // 8b: aload 2
      // 8c: invokevirtual com/trolmastercard/velvet/em.h ()Z
      // 8f: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 92: aload 2
      // 93: invokevirtual com/trolmastercard/velvet/em.ah ()I
      // 96: ifne a1
      // 99: bipush 1
      // 9a: goto a2
      // 9d: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // a0: athrow
      // a1: bipush 0
      // a2: invokevirtual com/trolmastercard/velvet/d_.a (Ljava/lang/Boolean;Z)Ljava/util/HashSet;
      // a5: putfield com/trolmastercard/velvet/d_.p Ljava/util/HashSet;
      // a8: aload 0
      // a9: invokevirtual com/trolmastercard/velvet/d_.d ()V
      // ac: aload 2
      // ad: invokevirtual com/trolmastercard/velvet/em.b ()Lsoftware/bernie/geckolib3/core/processor/AnimationProcessor;
      // b0: invokevirtual software/bernie/geckolib3/core/processor/AnimationProcessor.getModelRendererList ()Ljava/util/List;
      // b3: aload 0
      // b4: invokevirtual com/trolmastercard/velvet/d_.a ()Ljava/util/HashSet;
      // b7: aload 0
      // b8: invokestatic com/trolmastercard/velvet/gx.a (Ljava/util/List;Ljava/util/HashSet;Lcom/trolmastercard/velvet/c3;)V
      // bb: aload 2
      // bc: fload 3
      // bd: invokestatic com/trolmastercard/velvet/gx.a (Lnet/minecraft/entity/EntityLivingBase;F)V
      // c0: aload 0
      // c1: aload 1
      // c2: aload 8
      // c4: aload 2
      // c5: fload 4
      // c7: fload 5
      // c9: fload 6
      // cb: fload 7
      // cd: fload 3
      // ce: invokevirtual com/trolmastercard/velvet/d_.a (Lsoftware/bernie/geckolib3/geo/render/built/GeoModel;Lnet/minecraft/client/renderer/BufferBuilder;Lcom/trolmastercard/velvet/em;FFFFF)V
      // d1: aload 0
      // d2: aload 2
      // d3: fload 3
      // d4: fload 4
      // d6: fload 5
      // d8: fload 6
      // da: fload 7
      // dc: invokevirtual com/trolmastercard/velvet/d_.renderAfter (Ljava/lang/Object;FFFFF)V
      // df: invokestatic net/minecraft/client/renderer/GlStateManager.func_179101_C ()V
      // e2: invokestatic net/minecraft/client/renderer/GlStateManager.func_179089_o ()V
      // e5: bipush 0
      // e6: invokestatic org/lwjgl/opengl/GL20.glUseProgram (I)V
      // e9: return
      // try (0 -> 6): 7 java/lang/IllegalStateException
      // try (3 -> 12): 13 java/lang/IllegalStateException
      // try (9 -> 21): 22 java/lang/IllegalStateException
      // try (15 -> 25): 25 java/lang/IllegalStateException
      // try (47 -> 72): 72 java/lang/IllegalStateException
   }

   protected void a(GeoModel var1, BufferBuilder var2, T var3, float var4, float var5, float var6, float var7, float var8) {
      GeoBone var9 = null;

      for (GeoBone var11 : var1.topLevelBones) {
         if (var11.getName().equals("steve")) {
            var9 = var11;
         } else {
            this.renderRecursively(var2, var11, var4, var5, var6, var7);
         }
      }

      label30: {
         IOException var14;
         try {
            Tessellator.func_178181_a().func_78381_a();
            this.b();
            if (var9 == null) {
               return;
            }

            var2.func_181668_a(7, DefaultVertexFormats.field_181712_l);

            try {
               Minecraft.func_71410_x().field_71446_o.func_110577_a(this.d(this.j));
               break label30;
            } catch (IOException var12) {
               var14 = var12;
            }
         } catch (IllegalStateException var13) {
            throw b(var13);
         }

         var14.printStackTrace();
      }

      this.renderRecursively(var2, var9, var4, var5, var6, this.j.v());
      Tessellator.func_178181_a().func_78381_a();
   }

   String a(String var1) {
      StringBuilder var2 = new StringBuilder();

      try {
         BufferedReader var3 = new BufferedReader(new FileReader(var1));

         while (true) {
            String var4;
            String var10000 = var4 = var3.readLine();

            try {
               if (var10000 == null) {
                  break;
               }

               var2.append(var4).append("//\n");
            } catch (IOException var5) {
               throw b(var5);
            }
         }

         var3.close();
      } catch (IOException var6) {
         var6.printStackTrace();
      }

      return var2.toString();
   }

   protected void a(double var1, double var3, double var5) {
      try {
         if (this.j.h()) {
            return;
         }
      } catch (IllegalStateException var9) {
         throw b(var9);
      }

      try {
         if (this.j.y().hideNameTag) {
            return;
         }
      } catch (IllegalStateException var7) {
         throw b(var7);
      }

      try {
         if (i.func_175598_ae().field_78734_h == null) {
            return;
         }
      } catch (IllegalStateException var8) {
         throw b(var8);
      }

      this.func_147906_a(this.j, this.j.ab(), var1, var3 + this.j.i(), var5, 300);
   }

   Vec3d a(EntityPlayer var1, float var2) {
      EntityLiving var3 = (EntityLiving)var1.func_184187_bx();
      EntityPlayerSP var4 = i.field_71439_g;
      Vec3d var5 = var3.func_70040_Z();
      Vec3d var6 = b6.a(new Vec3d(var1.field_70142_S, var1.field_70137_T, var1.field_70136_U), var1.func_174791_d(), var2);
      Vec3d var7 = b6.a(new Vec3d(var4.field_70142_S, var4.field_70137_T, var4.field_70136_U), var4.func_174791_d(), var2);
      var7 = var6.func_178788_d(var7);
      this.j.field_70761_aq = var3.field_70761_aq;
      return new Vec3d(var7.field_72450_a + var5.field_72450_a * -0.5, var7.field_72448_b + 0.15F, var7.field_72449_c + var5.field_72449_c * -0.5);
   }

   protected Vec3d a(T var1, float var2, Vec3d var3) {
      return var3;
   }

   Vec3d a(T param1, float param2, double param3, double param5, double param7) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 000: new net/minecraft/util/math/Vec3d
      // 003: dup
      // 004: dload 3
      // 005: dload 5
      // 007: dload 7
      // 009: invokespecial net/minecraft/util/math/Vec3d.<init> (DDD)V
      // 00c: astore 9
      // 00e: aload 1
      // 00f: getfield com/trolmastercard/velvet/em.field_70170_p Lnet/minecraft/world/World;
      // 012: instanceof com/trolmastercard/velvet/gj
      // 015: ifeq 01f
      // 018: aload 9
      // 01a: areturn
      // 01b: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 01e: athrow
      // 01f: aload 1
      // 020: invokevirtual com/trolmastercard/velvet/em.t ()Z
      // 023: ifeq 057
      // 026: aload 1
      // 027: instanceof com/trolmastercard/velvet/ei
      // 02a: ifeq 047
      // 02d: goto 034
      // 030: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 033: athrow
      // 034: getstatic com/trolmastercard/velvet/d_.i Lnet/minecraft/client/Minecraft;
      // 037: getfield net/minecraft/client/Minecraft.field_71474_y Lnet/minecraft/client/settings/GameSettings;
      // 03a: getfield net/minecraft/client/settings/GameSettings.field_74320_O I
      // 03d: ifeq 057
      // 040: goto 047
      // 043: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 046: athrow
      // 047: aload 0
      // 048: dload 3
      // 049: dload 5
      // 04b: dload 7
      // 04d: invokevirtual com/trolmastercard/velvet/d_.a (DDD)V
      // 050: goto 057
      // 053: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 056: athrow
      // 057: aload 1
      // 058: invokevirtual com/trolmastercard/velvet/em.z ()Lnet/minecraft/entity/player/EntityPlayer;
      // 05b: astore 10
      // 05d: aload 10
      // 05f: ifnull 0a4
      // 062: aload 10
      // 064: invokevirtual net/minecraft/entity/player/EntityPlayer.func_184218_aH ()Z
      // 067: ifeq 0a4
      // 06a: goto 071
      // 06d: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 070: athrow
      // 071: aload 10
      // 073: invokevirtual net/minecraft/entity/player/EntityPlayer.func_184187_bx ()Lnet/minecraft/entity/Entity;
      // 076: instanceof net/minecraft/entity/passive/EntityHorse
      // 079: ifeq 0a4
      // 07c: goto 083
      // 07f: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 082: athrow
      // 083: aload 10
      // 085: invokevirtual net/minecraft/entity/player/EntityPlayer.func_184187_bx ()Lnet/minecraft/entity/Entity;
      // 088: checkcast net/minecraft/entity/passive/EntityHorse
      // 08b: invokevirtual net/minecraft/entity/passive/EntityHorse.func_110257_ck ()Z
      // 08e: ifeq 0a4
      // 091: goto 098
      // 094: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 097: athrow
      // 098: aload 0
      // 099: aload 10
      // 09b: fload 2
      // 09c: invokevirtual com/trolmastercard/velvet/d_.a (Lnet/minecraft/entity/player/EntityPlayer;F)Lnet/minecraft/util/math/Vec3d;
      // 09f: areturn
      // 0a0: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 0a3: athrow
      // 0a4: aload 1
      // 0a5: invokevirtual com/trolmastercard/velvet/em.Q ()Z
      // 0a8: ifne 0b2
      // 0ab: aload 9
      // 0ad: areturn
      // 0ae: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 0b1: athrow
      // 0b2: aload 1
      // 0b3: instanceof com/trolmastercard/velvet/ei
      // 0b6: ifeq 0dd
      // 0b9: aload 1
      // 0ba: checkcast com/trolmastercard/velvet/ei
      // 0bd: invokevirtual com/trolmastercard/velvet/ei.f ()Z
      // 0c0: ifeq 0dd
      // 0c3: goto 0ca
      // 0c6: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 0c9: athrow
      // 0ca: getstatic com/trolmastercard/velvet/d_.i Lnet/minecraft/client/Minecraft;
      // 0cd: getfield net/minecraft/client/Minecraft.field_71474_y Lnet/minecraft/client/settings/GameSettings;
      // 0d0: getfield net/minecraft/client/settings/GameSettings.field_74320_O I
      // 0d3: ifne 11a
      // 0d6: goto 0dd
      // 0d9: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 0dc: athrow
      // 0dd: new net/minecraft/util/math/Vec3d
      // 0e0: dup
      // 0e1: getstatic com/trolmastercard/velvet/d_.i Lnet/minecraft/client/Minecraft;
      // 0e4: getfield net/minecraft/client/Minecraft.field_71439_g Lnet/minecraft/client/entity/EntityPlayerSP;
      // 0e7: getfield net/minecraft/client/entity/EntityPlayerSP.field_70142_S D
      // 0ea: getstatic com/trolmastercard/velvet/d_.i Lnet/minecraft/client/Minecraft;
      // 0ed: getfield net/minecraft/client/Minecraft.field_71439_g Lnet/minecraft/client/entity/EntityPlayerSP;
      // 0f0: getfield net/minecraft/client/entity/EntityPlayerSP.field_70137_T D
      // 0f3: getstatic com/trolmastercard/velvet/d_.i Lnet/minecraft/client/Minecraft;
      // 0f6: getfield net/minecraft/client/Minecraft.field_71439_g Lnet/minecraft/client/entity/EntityPlayerSP;
      // 0f9: getfield net/minecraft/client/entity/EntityPlayerSP.field_70136_U D
      // 0fc: invokespecial net/minecraft/util/math/Vec3d.<init> (DDD)V
      // 0ff: getstatic com/trolmastercard/velvet/d_.i Lnet/minecraft/client/Minecraft;
      // 102: getfield net/minecraft/client/Minecraft.field_71439_g Lnet/minecraft/client/entity/EntityPlayerSP;
      // 105: invokevirtual net/minecraft/client/entity/EntityPlayerSP.func_174791_d ()Lnet/minecraft/util/math/Vec3d;
      // 108: fload 2
      // 109: f2d
      // 10a: invokestatic com/trolmastercard/velvet/b6.a (Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/math/Vec3d;D)Lnet/minecraft/util/math/Vec3d;
      // 10d: astore 11
      // 10f: aload 1
      // 110: invokevirtual com/trolmastercard/velvet/em.o ()Lnet/minecraft/util/math/Vec3d;
      // 113: aload 11
      // 115: invokevirtual net/minecraft/util/math/Vec3d.func_178788_d (Lnet/minecraft/util/math/Vec3d;)Lnet/minecraft/util/math/Vec3d;
      // 118: astore 9
      // 11a: aload 1
      // 11b: invokevirtual com/trolmastercard/velvet/em.I ()Ljava/lang/Float;
      // 11e: invokevirtual java/lang/Float.floatValue ()F
      // 121: fstore 11
      // 123: aload 1
      // 124: fload 11
      // 126: putfield com/trolmastercard/velvet/em.field_70177_z F
      // 129: aload 1
      // 12a: fload 11
      // 12c: putfield com/trolmastercard/velvet/em.field_70760_ar F
      // 12f: aload 1
      // 130: fload 11
      // 132: putfield com/trolmastercard/velvet/em.field_70761_aq F
      // 135: aload 1
      // 136: fload 11
      // 138: putfield com/trolmastercard/velvet/em.field_70758_at F
      // 13b: aload 1
      // 13c: fload 11
      // 13e: putfield com/trolmastercard/velvet/em.field_70759_as F
      // 141: aload 9
      // 143: areturn
      // try (7 -> 13): 13 java/lang/IllegalStateException
      // try (15 -> 21): 22 java/lang/IllegalStateException
      // try (18 -> 28): 29 java/lang/IllegalStateException
      // try (24 -> 36): 37 java/lang/IllegalStateException
      // try (42 -> 47): 48 java/lang/IllegalStateException
      // try (44 -> 54): 55 java/lang/IllegalStateException
      // try (50 -> 62): 63 java/lang/IllegalStateException
      // try (57 -> 70): 70 java/lang/IllegalStateException
      // try (72 -> 77): 77 java/lang/IllegalStateException
      // try (79 -> 86): 87 java/lang/IllegalStateException
      // try (82 -> 93): 94 java/lang/IllegalStateException
   }

   protected void b(T var1) {
   }

   public void a(T param1, double param2, double param4, double param6, float param8, float param9) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 000: aload 0
      // 001: aload 1
      // 002: putfield com/trolmastercard/velvet/d_.j Lcom/trolmastercard/velvet/em;
      // 005: aload 0
      // 006: aload 1
      // 007: fload 9
      // 009: dload 2
      // 00a: dload 4
      // 00c: dload 6
      // 00e: invokevirtual com/trolmastercard/velvet/d_.a (Lcom/trolmastercard/velvet/em;FDDD)Lnet/minecraft/util/math/Vec3d;
      // 011: astore 10
      // 013: aload 0
      // 014: aload 1
      // 015: fload 9
      // 017: aload 10
      // 019: invokevirtual com/trolmastercard/velvet/d_.a (Lcom/trolmastercard/velvet/em;FLnet/minecraft/util/math/Vec3d;)Lnet/minecraft/util/math/Vec3d;
      // 01c: astore 10
      // 01e: aload 10
      // 020: getfield net/minecraft/util/math/Vec3d.field_72450_a D
      // 023: dstore 2
      // 024: aload 10
      // 026: getfield net/minecraft/util/math/Vec3d.field_72448_b D
      // 029: dstore 4
      // 02b: aload 10
      // 02d: getfield net/minecraft/util/math/Vec3d.field_72449_c D
      // 030: dstore 6
      // 032: aload 0
      // 033: aload 1
      // 034: invokevirtual com/trolmastercard/velvet/d_.b (Lcom/trolmastercard/velvet/em;)V
      // 037: aload 1
      // 038: invokevirtual com/trolmastercard/velvet/em.func_110167_bD ()Z
      // 03b: ifeq 056
      // 03e: aload 0
      // 03f: aload 1
      // 040: dload 2
      // 041: dload 4
      // 043: aload 0
      // 044: getfield com/trolmastercard/velvet/d_.c D
      // 047: dadd
      // 048: dload 6
      // 04a: fload 9
      // 04c: invokevirtual com/trolmastercard/velvet/d_.a (Lcom/trolmastercard/velvet/em;DDDF)V
      // 04f: goto 056
      // 052: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 055: athrow
      // 056: invokestatic net/minecraft/client/renderer/GlStateManager.func_179094_E ()V
      // 059: dload 2
      // 05a: dload 4
      // 05c: dload 6
      // 05e: invokestatic net/minecraft/client/renderer/GlStateManager.func_179137_b (DDD)V
      // 061: sipush 2896
      // 064: invokestatic org/lwjgl/opengl/GL11.glDisable (I)V
      // 067: fconst_1
      // 068: fconst_1
      // 069: fconst_1
      // 06a: ldc_w 0.5
      // 06d: invokestatic net/minecraft/client/renderer/GlStateManager.func_179131_c (FFFF)V
      // 070: invokestatic net/minecraft/client/renderer/GlStateManager.func_179108_z ()V
      // 073: invokestatic net/minecraft/client/renderer/GlStateManager.func_179147_l ()V
      // 076: getstatic net/minecraft/client/renderer/GlStateManager$SourceFactor.SRC_ALPHA Lnet/minecraft/client/renderer/GlStateManager$SourceFactor;
      // 079: getstatic net/minecraft/client/renderer/GlStateManager$DestFactor.ONE_MINUS_SRC_ALPHA Lnet/minecraft/client/renderer/GlStateManager$DestFactor;
      // 07c: invokestatic net/minecraft/client/renderer/GlStateManager.func_187401_a (Lnet/minecraft/client/renderer/GlStateManager$SourceFactor;Lnet/minecraft/client/renderer/GlStateManager$DestFactor;)V
      // 07f: aload 1
      // 080: invokevirtual com/trolmastercard/velvet/em.func_184187_bx ()Lnet/minecraft/entity/Entity;
      // 083: ifnull 09f
      // 086: aload 1
      // 087: invokevirtual com/trolmastercard/velvet/em.func_184187_bx ()Lnet/minecraft/entity/Entity;
      // 08a: invokevirtual net/minecraft/entity/Entity.shouldRiderSit ()Z
      // 08d: ifeq 09f
      // 090: goto 097
      // 093: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 096: athrow
      // 097: bipush 1
      // 098: goto 0a0
      // 09b: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 09e: athrow
      // 09f: bipush 0
      // 0a0: istore 11
      // 0a2: new software/bernie/geckolib3/model/provider/data/EntityModelData
      // 0a5: dup
      // 0a6: invokespecial software/bernie/geckolib3/model/provider/data/EntityModelData.<init> ()V
      // 0a9: astore 12
      // 0ab: aload 12
      // 0ad: iload 11
      // 0af: putfield software/bernie/geckolib3/model/provider/data/EntityModelData.isSitting Z
      // 0b2: aload 12
      // 0b4: aload 1
      // 0b5: invokevirtual com/trolmastercard/velvet/em.func_70631_g_ ()Z
      // 0b8: putfield software/bernie/geckolib3/model/provider/data/EntityModelData.isChild Z
      // 0bb: aload 1
      // 0bc: getfield com/trolmastercard/velvet/em.field_70760_ar F
      // 0bf: aload 1
      // 0c0: getfield com/trolmastercard/velvet/em.field_70761_aq F
      // 0c3: fload 9
      // 0c5: invokestatic software/bernie/shadowed/eliotlash/mclib/utils/Interpolations.lerpYaw (FFF)F
      // 0c8: fstore 13
      // 0ca: aload 1
      // 0cb: getfield com/trolmastercard/velvet/em.field_70758_at F
      // 0ce: aload 1
      // 0cf: getfield com/trolmastercard/velvet/em.field_70759_as F
      // 0d2: fload 9
      // 0d4: invokestatic software/bernie/shadowed/eliotlash/mclib/utils/Interpolations.lerpYaw (FFF)F
      // 0d7: fstore 14
      // 0d9: fload 14
      // 0db: fload 13
      // 0dd: fsub
      // 0de: fstore 15
      // 0e0: iload 11
      // 0e2: ifeq 15e
      // 0e5: aload 1
      // 0e6: invokevirtual com/trolmastercard/velvet/em.func_184187_bx ()Lnet/minecraft/entity/Entity;
      // 0e9: instanceof net/minecraft/entity/EntityLivingBase
      // 0ec: ifeq 15e
      // 0ef: goto 0f6
      // 0f2: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 0f5: athrow
      // 0f6: aload 1
      // 0f7: invokevirtual com/trolmastercard/velvet/em.func_184187_bx ()Lnet/minecraft/entity/Entity;
      // 0fa: checkcast net/minecraft/entity/EntityLivingBase
      // 0fd: astore 16
      // 0ff: aload 16
      // 101: getfield net/minecraft/entity/EntityLivingBase.field_70760_ar F
      // 104: aload 16
      // 106: getfield net/minecraft/entity/EntityLivingBase.field_70761_aq F
      // 109: fload 9
      // 10b: invokestatic software/bernie/shadowed/eliotlash/mclib/utils/Interpolations.lerpYaw (FFF)F
      // 10e: fstore 13
      // 110: fload 14
      // 112: fload 13
      // 114: fsub
      // 115: fstore 15
      // 117: fload 15
      // 119: invokestatic net/minecraft/util/math/MathHelper.func_76142_g (F)F
      // 11c: fstore 17
      // 11e: fload 17
      // 120: ldc_w -85.0
      // 123: fcmpg
      // 124: ifge 12c
      // 127: ldc_w -85.0
      // 12a: fstore 17
      // 12c: fload 17
      // 12e: ldc_w 85.0
      // 131: fcmpl
      // 132: iflt 13a
      // 135: ldc_w 85.0
      // 138: fstore 17
      // 13a: fload 14
      // 13c: fload 17
      // 13e: fsub
      // 13f: fstore 13
      // 141: fload 17
      // 143: fload 17
      // 145: fmul
      // 146: ldc_w 2500.0
      // 149: fcmpl
      // 14a: ifle 157
      // 14d: fload 13
      // 14f: fload 17
      // 151: ldc 0.2
      // 153: fmul
      // 154: fadd
      // 155: fstore 13
      // 157: fload 14
      // 159: fload 13
      // 15b: fsub
      // 15c: fstore 15
      // 15e: aload 1
      // 15f: getfield com/trolmastercard/velvet/em.field_70127_C F
      // 162: aload 1
      // 163: getfield com/trolmastercard/velvet/em.field_70125_A F
      // 166: fload 9
      // 168: invokestatic software/bernie/shadowed/eliotlash/mclib/utils/Interpolations.lerp (FFF)F
      // 16b: fstore 16
      // 16d: aload 0
      // 16e: aload 1
      // 16f: fload 9
      // 171: invokevirtual com/trolmastercard/velvet/d_.handleRotationFloat (Lnet/minecraft/entity/EntityLivingBase;F)F
      // 174: fstore 17
      // 176: aload 0
      // 177: aload 1
      // 178: fload 17
      // 17a: fload 13
      // 17c: fload 9
      // 17e: invokevirtual com/trolmastercard/velvet/d_.b (Lcom/trolmastercard/velvet/em;FFF)V
      // 181: fconst_0
      // 182: fstore 18
      // 184: fconst_0
      // 185: fstore 19
      // 187: iload 11
      // 189: ifne 1d2
      // 18c: aload 1
      // 18d: invokevirtual com/trolmastercard/velvet/em.func_70089_S ()Z
      // 190: ifeq 1d2
      // 193: goto 19a
      // 196: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 199: athrow
      // 19a: aload 1
      // 19b: getfield com/trolmastercard/velvet/em.field_184618_aE F
      // 19e: aload 1
      // 19f: getfield com/trolmastercard/velvet/em.field_70721_aZ F
      // 1a2: fload 9
      // 1a4: invokestatic software/bernie/shadowed/eliotlash/mclib/utils/Interpolations.lerp (FFF)F
      // 1a7: fstore 18
      // 1a9: aload 1
      // 1aa: getfield com/trolmastercard/velvet/em.field_184619_aG F
      // 1ad: aload 1
      // 1ae: getfield com/trolmastercard/velvet/em.field_70721_aZ F
      // 1b1: fconst_1
      // 1b2: fload 9
      // 1b4: fsub
      // 1b5: fmul
      // 1b6: fsub
      // 1b7: fstore 19
      // 1b9: aload 1
      // 1ba: invokevirtual com/trolmastercard/velvet/em.func_70631_g_ ()Z
      // 1bd: ifeq 1c8
      // 1c0: fload 19
      // 1c2: ldc_w 3.0
      // 1c5: fmul
      // 1c6: fstore 19
      // 1c8: fload 18
      // 1ca: fconst_1
      // 1cb: fcmpl
      // 1cc: ifle 1d2
      // 1cf: fconst_1
      // 1d0: fstore 18
      // 1d2: aload 12
      // 1d4: fload 16
      // 1d6: fneg
      // 1d7: putfield software/bernie/geckolib3/model/provider/data/EntityModelData.headPitch F
      // 1da: aload 12
      // 1dc: fload 15
      // 1de: fneg
      // 1df: putfield software/bernie/geckolib3/model/provider/data/EntityModelData.netHeadYaw F
      // 1e2: new software/bernie/geckolib3/core/event/predicate/AnimationEvent
      // 1e5: dup
      // 1e6: aload 1
      // 1e7: fload 19
      // 1e9: fload 18
      // 1eb: fload 9
      // 1ed: fload 18
      // 1ef: ldc_w -0.15
      // 1f2: fcmpl
      // 1f3: ifle 206
      // 1f6: fload 18
      // 1f8: ldc_w 0.15
      // 1fb: fcmpg
      // 1fc: iflt 20a
      // 1ff: goto 206
      // 202: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 205: athrow
      // 206: bipush 1
      // 207: goto 20b
      // 20a: bipush 0
      // 20b: aload 12
      // 20d: invokestatic java/util/Collections.singletonList (Ljava/lang/Object;)Ljava/util/List;
      // 210: invokespecial software/bernie/geckolib3/core/event/predicate/AnimationEvent.<init> (Lsoftware/bernie/geckolib3/core/IAnimatable;FFFZLjava/util/List;)V
      // 213: astore 20
      // 215: aload 0
      // 216: invokespecial software/bernie/geckolib3/renderers/geo/GeoEntityRenderer.getGeoModelProvider ()Lsoftware/bernie/geckolib3/model/provider/GeoModelProvider;
      // 219: astore 21
      // 21b: aload 21
      // 21d: aload 1
      // 21e: invokevirtual software/bernie/geckolib3/model/provider/GeoModelProvider.getModelLocation (Ljava/lang/Object;)Lnet/minecraft/util/ResourceLocation;
      // 221: astore 22
      // 223: aload 21
      // 225: aload 22
      // 227: invokevirtual software/bernie/geckolib3/model/provider/GeoModelProvider.getModel (Lnet/minecraft/util/ResourceLocation;)Lsoftware/bernie/geckolib3/geo/render/built/GeoModel;
      // 22a: astore 23
      // 22c: aload 21
      // 22e: instanceof software/bernie/geckolib3/core/IAnimatableModel
      // 231: ifeq 252
      // 234: aload 21
      // 236: checkcast software/bernie/geckolib3/core/IAnimatableModel
      // 239: aload 1
      // 23a: aload 1
      // 23b: invokevirtual com/trolmastercard/velvet/em.func_110124_au ()Ljava/util/UUID;
      // 23e: invokevirtual java/util/UUID.hashCode ()I
      // 241: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 244: aload 20
      // 246: invokeinterface software/bernie/geckolib3/core/IAnimatableModel.setLivingAnimations (Ljava/lang/Object;Ljava/lang/Integer;Lsoftware/bernie/geckolib3/core/event/predicate/AnimationEvent;)V 4
      // 24b: goto 252
      // 24e: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 251: athrow
      // 252: invokestatic net/minecraft/client/renderer/GlStateManager.func_179094_E ()V
      // 255: fconst_0
      // 256: ldc_w 0.01
      // 259: fconst_0
      // 25a: invokestatic net/minecraft/client/renderer/GlStateManager.func_179109_b (FFF)V
      // 25d: invokestatic net/minecraft/client/Minecraft.func_71410_x ()Lnet/minecraft/client/Minecraft;
      // 260: getfield net/minecraft/client/Minecraft.field_71446_o Lnet/minecraft/client/renderer/texture/TextureManager;
      // 263: aload 0
      // 264: aload 1
      // 265: invokevirtual com/trolmastercard/velvet/d_.getEntityTexture (Lnet/minecraft/entity/EntityLivingBase;)Lnet/minecraft/util/ResourceLocation;
      // 268: invokevirtual net/minecraft/client/renderer/texture/TextureManager.func_110577_a (Lnet/minecraft/util/ResourceLocation;)V
      // 26b: aload 0
      // 26c: aload 1
      // 26d: fload 9
      // 26f: invokevirtual com/trolmastercard/velvet/d_.getRenderColor (Ljava/lang/Object;F)Lsoftware/bernie/geckolib3/core/util/Color;
      // 272: astore 24
      // 274: aload 0
      // 275: aload 1
      // 276: fload 9
      // 278: invokevirtual com/trolmastercard/velvet/d_.setDoRenderBrightness (Lnet/minecraft/entity/EntityLivingBase;F)Z
      // 27b: istore 25
      // 27d: aload 0
      // 27e: aload 23
      // 280: aload 1
      // 281: fload 9
      // 283: aload 24
      // 285: invokevirtual software/bernie/geckolib3/core/util/Color.getRed ()I
      // 288: i2f
      // 289: ldc_w 255.0
      // 28c: fdiv
      // 28d: aload 24
      // 28f: invokevirtual software/bernie/geckolib3/core/util/Color.getBlue ()I
      // 292: i2f
      // 293: ldc_w 255.0
      // 296: fdiv
      // 297: aload 24
      // 299: invokevirtual software/bernie/geckolib3/core/util/Color.getGreen ()I
      // 29c: i2f
      // 29d: ldc_w 255.0
      // 2a0: fdiv
      // 2a1: aload 24
      // 2a3: invokevirtual software/bernie/geckolib3/core/util/Color.getAlpha ()I
      // 2a6: i2f
      // 2a7: ldc_w 255.0
      // 2aa: fdiv
      // 2ab: invokevirtual com/trolmastercard/velvet/d_.a (Lsoftware/bernie/geckolib3/geo/render/built/GeoModel;Lcom/trolmastercard/velvet/em;FFFFF)V
      // 2ae: iload 25
      // 2b0: ifeq 2bd
      // 2b3: invokestatic software/bernie/geckolib3/renderers/geo/RenderHurtColor.unset ()V
      // 2b6: goto 2bd
      // 2b9: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 2bc: athrow
      // 2bd: aload 0
      // 2be: getfield com/trolmastercard/velvet/d_.layerRenderers Ljava/util/List;
      // 2c1: invokeinterface java/util/List.iterator ()Ljava/util/Iterator; 1
      // 2c6: astore 26
      // 2c8: aload 26
      // 2ca: invokeinterface java/util/Iterator.hasNext ()Z 1
      // 2cf: ifeq 2f5
      // 2d2: aload 26
      // 2d4: invokeinterface java/util/Iterator.next ()Ljava/lang/Object; 1
      // 2d9: checkcast software/bernie/geckolib3/renderers/geo/GeoLayerRenderer
      // 2dc: astore 27
      // 2de: aload 27
      // 2e0: aload 1
      // 2e1: fload 19
      // 2e3: fload 18
      // 2e5: fload 9
      // 2e7: fload 19
      // 2e9: fload 15
      // 2eb: fload 16
      // 2ed: aload 24
      // 2ef: invokevirtual software/bernie/geckolib3/renderers/geo/GeoLayerRenderer.render (Lnet/minecraft/entity/EntityLivingBase;FFFFFFLsoftware/bernie/geckolib3/core/util/Color;)V
      // 2f2: goto 2c8
      // 2f5: sipush 2896
      // 2f8: invokestatic org/lwjgl/opengl/GL11.glEnable (I)V
      // 2fb: invokestatic net/minecraft/client/renderer/GlStateManager.func_179084_k ()V
      // 2fe: invokestatic net/minecraft/client/renderer/GlStateManager.func_179133_A ()V
      // 301: invokestatic net/minecraft/client/renderer/GlStateManager.func_179121_F ()V
      // 304: invokestatic net/minecraft/client/renderer/GlStateManager.func_179121_F ()V
      // 307: aload 0
      // 308: aload 1
      // 309: invokevirtual com/trolmastercard/velvet/d_.a (Lcom/trolmastercard/velvet/em;)V
      // 30c: aload 1
      // 30d: fload 9
      // 30f: invokestatic com/trolmastercard/velvet/b.a (Lcom/trolmastercard/velvet/em;F)V
      // 312: aload 0
      // 313: aload 1
      // 314: invokevirtual com/trolmastercard/velvet/d_.e (Lcom/trolmastercard/velvet/em;)Lcom/trolmastercard/velvet/f7;
      // 317: astore 26
      // 319: aload 26
      // 31b: ifnull 32e
      // 31e: aload 0
      // 31f: aload 1
      // 320: fload 9
      // 322: aload 26
      // 324: invokevirtual com/trolmastercard/velvet/d_.a (Lcom/trolmastercard/velvet/em;FLcom/trolmastercard/velvet/f7;)V
      // 327: goto 32e
      // 32a: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 32d: athrow
      // 32e: return
      // try (26 -> 42): 43 java/lang/IllegalStateException
      // try (45 -> 69): 70 java/lang/IllegalStateException
      // try (65 -> 74): 74 java/lang/IllegalStateException
      // try (107 -> 113): 114 java/lang/IllegalStateException
      // try (188 -> 193): 194 java/lang/IllegalStateException
      // try (226 -> 248): 249 java/lang/IllegalStateException
      // try (269 -> 281): 282 java/lang/IllegalStateException
      // try (305 -> 333): 334 java/lang/IllegalStateException
      // try (374 -> 381): 382 java/lang/IllegalStateException
   }

   void a(T var1) {
      ArrayList var2 = new ArrayList<>(cv.e);
      var2.addAll(var1.p);

      for (String var4 : var2) {
         em var10000;
         String var10001;
         boolean var10002;
         label23: {
            try {
               var10000 = var1;
               var10001 = var4;
               if (!var1.h()) {
                  var10002 = true;
                  break label23;
               }
            } catch (IllegalStateException var8) {
               throw b(var8);
            }

            var10002 = false;
         }

         MatrixStack var5 = var10000.a(var10001, var10002);
         Matrix4f var6 = var5.getModelMatrix();
         Vec3d var7 = new Vec3d(-var6.m03, var6.m13, -var6.m23);
         var1.a(var4, var7);
      }
   }

   @Nullable
   protected f7 e(T var1) {
      return null;
   }

   public Entity c(em var1) {
      return var1;
   }

   void a(em var1, float var2, f7 var3) {
      EntityPlayerSP var4 = i.field_71439_g;
      var3 = new f7(var3.a / 255.0F, var3.c / 255.0F, var3.b / 255.0F);
      Tessellator var5 = Tessellator.func_178181_a();
      BufferBuilder var6 = var5.func_178180_c();
      GlStateManager.func_179094_E();
      GlStateManager.func_179137_b(0.0, 0.01, 0.0);
      Entity var7 = this.c(var1);

      Vec3d var10000;
      label17: {
         try {
            if (var1.Q()) {
               var10000 = var1.o();
               break label17;
            }
         } catch (IllegalStateException var12) {
            throw b(var12);
         }

         var10000 = b6.a(new Vec3d(var7.field_70142_S, var7.field_70137_T, var7.field_70136_U), var7.func_174791_d(), var2);
      }

      Vec3d var8 = var10000;
      Vec3d var9 = b6.a(new Vec3d(var4.field_70142_S, var4.field_70137_T, var4.field_70136_U), var4.func_174791_d(), var2);
      Vec3d var10 = var8.func_178788_d(var9);
      GlStateManager.func_179137_b(var10.field_72450_a, var10.field_72448_b, var10.field_72449_c);
      i.func_110434_K().func_110577_a(e);
      float var11 = a(var1, var2, 1.0F, 5.0F);
      this.b(var5, var6, var1, var3, var11);
      GlStateManager.func_179121_F();
   }

   protected static float a(em var0, float var1, float var2, float var3) {
      EntityPlayerSP var4 = i.field_71439_g;
      Entity var5 = ((d_)i.func_175598_ae().func_78713_a(var0)).c(var0);

      Vec3d var10000;
      label17: {
         try {
            if (var0.Q()) {
               var10000 = var0.o();
               break label17;
            }
         } catch (IllegalStateException var11) {
            throw b(var11);
         }

         var10000 = b6.a(new Vec3d(var5.field_70142_S, var5.field_70137_T, var5.field_70136_U), var5.func_174791_d(), var1);
      }

      Vec3d var6 = var10000;
      Vec3d var7 = b6.a(new Vec3d(var4.field_70142_S, var4.field_70137_T, var4.field_70136_U), var4.func_174791_d(), var1);
      Vec3d var8 = ActiveRenderInfo.getCameraPosition().func_178787_e(var7);
      float var9 = (float)var8.func_72438_d(var6);
      float var10 = Math.abs(var9) / 5.0F;
      return b6.a(var3, var2, be.b(var10, 0.0F, 1.0F));
   }

   protected void b(Tessellator var1, BufferBuilder var2, em var3, f7 var4, float var5) {
   }

   protected static void a(BufferBuilder var0, Tessellator var1, em var2, String var3, String var4, float var5, float var6, float var7, float var8) {
      var0.func_181668_a(1, DefaultVertexFormats.field_181709_i);
      GlStateManager.func_187441_d(var8);
      Vec3d var9 = var2.b(var3);
      Vec3d var10 = var2.b(var4);
      var0.func_181662_b(var9.field_72450_a, var9.field_72448_b, var9.field_72449_c)
         .func_187315_a(0.0, 0.0)
         .func_181666_a(var5, var6, var7, 1.0F)
         .func_181675_d();
      var0.func_181662_b(var10.field_72450_a, var10.field_72448_b, var10.field_72449_c)
         .func_187315_a(0.0, 0.0)
         .func_181666_a(var5, var6, var7, 1.0F)
         .func_181675_d();
      var1.func_78381_a();
   }

   protected static void a(Tessellator var0, BufferBuilder var1, em var2, f7 var3, float var4) {
      a(var1, var0, var2, "braStringMidStartR", "braStringMidMid1R", var3.a, var3.c, var3.b, var4);
      a(var1, var0, var2, "braStringMidMid1R", "braStringMidMid2R", var3.a, var3.c, var3.b, var4);
      a(var1, var0, var2, "braStringMidMid2R", "braStringMidMid3R", var3.a, var3.c, var3.b, var4);
      a(var1, var0, var2, "braStringMidMid3R", "braStringMidEndR", var3.a, var3.c, var3.b, var4);
      a(var1, var0, var2, "braStringMidEndR", "braStringBackR", var3.a, var3.c, var3.b, var4);
      a(var1, var0, var2, "braStringBackR", "braStringRightEndR", var3.a, var3.c, var3.b, var4);
      a(var1, var0, var2, "braStringRightEndR", "braStringRightStartR", var3.a, var3.c, var3.b, var4);
      a(var1, var0, var2, "braStringRightR", "braStringRightL", var3.a, var3.c, var3.b, var4);
      a(var1, var0, var2, "braStringMidStartL", "braStringMidMid1L", var3.a, var3.c, var3.b, var4);
      a(var1, var0, var2, "braStringMidMid1L", "braStringMidMid2L", var3.a, var3.c, var3.b, var4);
      a(var1, var0, var2, "braStringMidMid2L", "braStringMidMid3L", var3.a, var3.c, var3.b, var4);
      a(var1, var0, var2, "braStringMidMid3L", "braStringMidEndL", var3.a, var3.c, var3.b, var4);
      a(var1, var0, var2, "braStringMidEndL", "braStringBackL", var3.a, var3.c, var3.b, var4);
      a(var1, var0, var2, "braStringBackL", "braStringLeftEndL", var3.a, var3.c, var3.b, var4);
      a(var1, var0, var2, "braStringLeftEndL", "braStringLeftStartL", var3.a, var3.c, var3.b, var4);
   }

   protected void b(T var1, float var2, float var3, float var4) {
      try {
         super.applyRotations((T)var1, var2, var3, var4);
         if (!(var1 instanceof ei)) {
            return;
         }
      } catch (IllegalStateException var22) {
         throw b(var22);
      }

      UUID var5 = ((ei)var1).m();

      try {
         if (var5 == null) {
            return;
         }
      } catch (IllegalStateException var21) {
         throw b(var21);
      }

      EntityPlayer var6 = var1.field_70170_p.func_152378_a(var5);

      try {
         if (var6 == null) {
            return;
         }
      } catch (IllegalStateException var18) {
         throw b(var18);
      }

      try {
         if (!var6.func_184613_cA()) {
            return;
         }
      } catch (IllegalStateException var20) {
         throw b(var20);
      }

      float var7 = var6.func_184599_cB() + var4;
      float var8 = MathHelper.func_76131_a(var7 * var7 / 100.0F, 0.0F, 1.0F);
      GlStateManager.func_179114_b(var8 * (-90.0F - var6.field_70125_A), 1.0F, 0.0F, 0.0F);
      Vec3d var9 = var6.func_70676_i(var4);
      double var10 = var6.field_70159_w * var6.field_70159_w + var6.field_70179_y * var6.field_70179_y;
      double var12 = var9.field_72450_a * var9.field_72450_a + var9.field_72449_c * var9.field_72449_c;

      try {
         if (!(var10 > 0.0) || !(var12 > 0.0)) {
            return;
         }
      } catch (IllegalStateException var19) {
         throw b(var19);
      }

      double var14 = (var6.field_70159_w * var9.field_72450_a + var6.field_70179_y * var9.field_72449_c) / (Math.sqrt(var10) * Math.sqrt(var12));
      double var16 = var6.field_70159_w * var9.field_72449_c - var6.field_70179_y * var9.field_72450_a;
      GlStateManager.func_179114_b((float)(Math.signum(var16) * Math.acos(var14)) * 180.0F / (float) Math.PI, 0.0F, 1.0F, 0.0F);
   }

   protected void a(BufferBuilder var1, String var2, GeoBone var3) {
   }

   protected void a(em var1, double var2, double var4, double var6, float var8) {
      Entity var9 = var1.func_110166_bE();
      var4 -= (1.6 - var1.field_70131_O) * 0.5;
      Tessellator var10 = Tessellator.func_178181_a();
      BufferBuilder var11 = var10.func_178180_c();
      double var12 = b6.a(var9.field_70126_B, var9.field_70177_z, var8 * 0.5F) * (float) (Math.PI / 180.0);
      double var14 = b6.a(var9.field_70127_C, var9.field_70125_A, var8 * 0.5F) * (float) (Math.PI / 180.0);
      double var16 = Math.cos(var12);
      double var18 = Math.sin(var12);
      double var20 = Math.sin(var14);
      if (var9 instanceof EntityHanging) {
         var16 = 0.0;
         var18 = 0.0;
         var20 = -1.0;
      }

      double var22 = Math.cos(var14);
      double var24 = b6.b(var9.field_70169_q, var9.field_70165_t, var8) - var16 * 0.7 - var18 * 0.5 * var22;
      double var26 = b6.b(var9.field_70167_r + var9.func_70047_e() * 0.7, var9.field_70163_u + var9.func_70047_e() * 0.7, var8) - var20 * 0.5 - 0.25;
      double var28 = b6.b(var9.field_70166_s, var9.field_70161_v, var8) - var18 * 0.7 + var16 * 0.5 * var22;
      double var30 = b6.a(var1.field_70760_ar, var1.field_70761_aq, var8) * (float) (Math.PI / 180.0) + (Math.PI / 2);
      var16 = Math.cos(var30) * var1.field_70130_N * 0.4;
      var18 = Math.sin(var30) * var1.field_70130_N * 0.4;
      double var32 = b6.b(var1.field_70169_q, var1.field_70165_t, var8) + var16;
      double var34 = b6.b(var1.field_70167_r, var1.field_70163_u, var8);
      double var36 = b6.b(var1.field_70166_s, var1.field_70161_v, var8) + var18;
      var2 += var16;
      var6 += var18;
      double var38 = (float)(var24 - var32);
      double var40 = (float)(var26 - var34);
      double var42 = (float)(var28 - var36);
      GlStateManager.func_179090_x();
      GlStateManager.func_179140_f();
      GlStateManager.func_179129_p();
      var11.func_181668_a(5, DefaultVertexFormats.field_181706_f);

      for (int var44 = 0; var44 <= 24; var44++) {
         float var45 = 0.5F;
         float var46 = 0.4F;
         float var47 = 0.3F;
         if (var44 % 2 == 0) {
            var45 *= 0.7F;
            var46 *= 0.7F;
            var47 *= 0.7F;
         }

         float var48 = var44 / 24.0F;
         var11.func_181662_b(
               var2 + var38 * var48 + 0.0, var4 + var40 * (var48 * var48 + var48) * 0.5 + ((24.0F - var44) / 18.0F + 0.125F), var6 + var42 * var48
            )
            .func_181666_a(var45, var46, var47, 1.0F)
            .func_181675_d();
         var11.func_181662_b(
               var2 + var38 * var48 + 0.025, var4 + var40 * (var48 * var48 + var48) * 0.5 + ((24.0F - var44) / 18.0F + 0.125F) + 0.025, var6 + var42 * var48
            )
            .func_181666_a(var45, var46, var47, 1.0F)
            .func_181675_d();
      }

      var10.func_78381_a();
      var11.func_181668_a(5, DefaultVertexFormats.field_181706_f);

      for (int var54 = 0; var54 <= 24; var54++) {
         float var55 = 0.5F;
         float var56 = 0.4F;
         float var57 = 0.3F;
         if (var54 % 2 == 0) {
            var55 *= 0.7F;
            var56 *= 0.7F;
            var57 *= 0.7F;
         }

         float var58 = var54 / 24.0F;
         var11.func_181662_b(
               var2 + var38 * var58 + 0.0, var4 + var40 * (var58 * var58 + var58) * 0.5 + ((24.0F - var54) / 18.0F + 0.125F) + 0.025, var6 + var42 * var58
            )
            .func_181666_a(var55, var56, var57, 1.0F)
            .func_181675_d();
         var11.func_181662_b(
               var2 + var38 * var58 + 0.025, var4 + var40 * (var58 * var58 + var58) * 0.5 + ((24.0F - var54) / 18.0F + 0.125F), var6 + var42 * var58 + 0.025
            )
            .func_181666_a(var55, var56, var57, 1.0F)
            .func_181675_d();
      }

      var10.func_78381_a();
      GlStateManager.func_179145_e();
      GlStateManager.func_179098_w();
      GlStateManager.func_179089_o();
   }

   @Override
   public void renderRecursively(BufferBuilder param1, GeoBone param2, float param3, float param4, float param5, float param6) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 000: aload 0
      // 001: getfield com/trolmastercard/velvet/d_.j Lcom/trolmastercard/velvet/em;
      // 004: getfield com/trolmastercard/velvet/em.field_70170_p Lnet/minecraft/world/World;
      // 007: instanceof com/trolmastercard/velvet/gj
      // 00a: ifeq 012
      // 00d: return
      // 00e: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 011: athrow
      // 012: aload 2
      // 013: invokevirtual software/bernie/geckolib3/geo/render/built/GeoBone.getName ()Ljava/lang/String;
      // 016: astore 7
      // 018: aload 7
      // 01a: ldc_w "weapon"
      // 01d: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 020: ifeq 041
      // 023: aload 0
      // 024: getfield com/trolmastercard/velvet/d_.j Lcom/trolmastercard/velvet/em;
      // 027: instanceof com/trolmastercard/velvet/e2
      // 02a: ifeq 041
      // 02d: goto 034
      // 030: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 033: athrow
      // 034: aload 0
      // 035: aload 1
      // 036: aload 2
      // 037: invokevirtual com/trolmastercard/velvet/d_.a (Lnet/minecraft/client/renderer/BufferBuilder;Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;)V
      // 03a: goto 041
      // 03d: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 040: athrow
      // 041: aload 7
      // 043: ldc_w "itemRenderer"
      // 046: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 049: ifeq 06d
      // 04c: aload 0
      // 04d: getfield com/trolmastercard/velvet/d_.j Lcom/trolmastercard/velvet/em;
      // 050: invokevirtual com/trolmastercard/velvet/em.y ()Lcom/trolmastercard/velvet/fp;
      // 053: getstatic com/trolmastercard/velvet/fp.PAYMENT Lcom/trolmastercard/velvet/fp;
      // 056: if_acmpne 06d
      // 059: goto 060
      // 05c: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 05f: athrow
      // 060: aload 0
      // 061: aload 1
      // 062: aload 2
      // 063: invokevirtual com/trolmastercard/velvet/d_.b (Lnet/minecraft/client/renderer/BufferBuilder;Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;)V
      // 066: goto 06d
      // 069: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 06c: athrow
      // 06d: aload 7
      // 06f: ldc_w "ballL"
      // 072: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 075: ifne 09c
      // 078: aload 7
      // 07a: ldc_w "ballR"
      // 07d: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 080: ifne 09c
      // 083: goto 08a
      // 086: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 089: athrow
      // 08a: aload 7
      // 08c: ldc_w "cock"
      // 08f: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 092: ifeq 09f
      // 095: goto 09c
      // 098: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 09b: athrow
      // 09c: fconst_1
      // 09d: fstore 6
      // 09f: aload 1
      // 0a0: putstatic com/trolmastercard/velvet/d_.n Lnet/minecraft/client/renderer/BufferBuilder;
      // 0a3: aload 0
      // 0a4: aload 1
      // 0a5: aload 7
      // 0a7: aload 2
      // 0a8: invokevirtual com/trolmastercard/velvet/d_.a (Lnet/minecraft/client/renderer/BufferBuilder;Ljava/lang/String;Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;)V
      // 0ab: getstatic com/trolmastercard/velvet/d_.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 0ae: invokevirtual software/bernie/geckolib3/util/MatrixStack.push ()V
      // 0b1: getstatic com/trolmastercard/velvet/d_.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 0b4: aload 2
      // 0b5: invokevirtual software/bernie/geckolib3/util/MatrixStack.translate (Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;)V
      // 0b8: getstatic com/trolmastercard/velvet/d_.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 0bb: aload 2
      // 0bc: invokevirtual software/bernie/geckolib3/util/MatrixStack.moveToPivot (Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;)V
      // 0bf: getstatic com/trolmastercard/velvet/d_.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 0c2: aload 2
      // 0c3: invokevirtual software/bernie/geckolib3/util/MatrixStack.rotate (Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;)V
      // 0c6: getstatic com/trolmastercard/velvet/d_.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 0c9: aload 2
      // 0ca: invokevirtual software/bernie/geckolib3/util/MatrixStack.scale (Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;)V
      // 0cd: getstatic com/trolmastercard/velvet/d_.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 0d0: aload 2
      // 0d1: invokevirtual software/bernie/geckolib3/util/MatrixStack.moveBackFromPivot (Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;)V
      // 0d4: ldc_w "Head2"
      // 0d7: aload 7
      // 0d9: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 0dc: ifeq 0f8
      // 0df: aload 0
      // 0e0: invokevirtual com/trolmastercard/velvet/d_.c ()Z
      // 0e3: ifne 0f8
      // 0e6: goto 0ed
      // 0e9: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 0ec: athrow
      // 0ed: getstatic com/trolmastercard/velvet/d_.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 0f0: invokevirtual software/bernie/geckolib3/util/MatrixStack.pop ()V
      // 0f3: return
      // 0f4: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 0f7: athrow
      // 0f8: aload 0
      // 0f9: aload 7
      // 0fb: invokevirtual com/trolmastercard/velvet/d_.b (Ljava/lang/String;)Z
      // 0fe: ifne 10c
      // 101: getstatic com/trolmastercard/velvet/d_.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 104: invokevirtual software/bernie/geckolib3/util/MatrixStack.pop ()V
      // 107: return
      // 108: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 10b: athrow
      // 10c: aload 2
      // 10d: getfield software/bernie/geckolib3/geo/render/built/GeoBone.isHidden Z
      // 110: ifne 1dd
      // 113: aload 0
      // 114: aload 7
      // 116: fload 3
      // 117: fload 4
      // 119: fload 5
      // 11b: invokevirtual com/trolmastercard/velvet/d_.a (Ljava/lang/String;FFF)Ljavax/vecmath/Vector4f;
      // 11e: astore 8
      // 120: aload 8
      // 122: getfield javax/vecmath/Vector4f.x F
      // 125: fstore 3
      // 126: aload 8
      // 128: getfield javax/vecmath/Vector4f.y F
      // 12b: fstore 4
      // 12d: aload 8
      // 12f: getfield javax/vecmath/Vector4f.z F
      // 132: fstore 5
      // 134: aload 8
      // 136: getfield javax/vecmath/Vector4f.w F
      // 139: f2d
      // 13a: dstore 9
      // 13c: aload 0
      // 13d: getfield com/trolmastercard/velvet/d_.p Ljava/util/HashSet;
      // 140: aload 7
      // 142: invokevirtual java/util/HashSet.contains (Ljava/lang/Object;)Z
      // 145: ifne 18d
      // 148: aload 2
      // 149: getfield software/bernie/geckolib3/geo/render/built/GeoBone.childCubes Ljava/util/List;
      // 14c: invokeinterface java/util/List.iterator ()Ljava/util/Iterator; 1
      // 151: astore 11
      // 153: aload 11
      // 155: invokeinterface java/util/Iterator.hasNext ()Z 1
      // 15a: ifeq 18d
      // 15d: aload 11
      // 15f: invokeinterface java/util/Iterator.next ()Ljava/lang/Object; 1
      // 164: checkcast software/bernie/geckolib3/geo/render/built/GeoCube
      // 167: astore 12
      // 169: getstatic com/trolmastercard/velvet/d_.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 16c: invokevirtual software/bernie/geckolib3/util/MatrixStack.push ()V
      // 16f: aload 0
      // 170: aload 2
      // 171: putfield com/trolmastercard/velvet/d_.q Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;
      // 174: aload 0
      // 175: aload 1
      // 176: aload 12
      // 178: fload 3
      // 179: fload 4
      // 17b: fload 5
      // 17d: fload 6
      // 17f: dload 9
      // 181: invokevirtual com/trolmastercard/velvet/d_.a (Lnet/minecraft/client/renderer/BufferBuilder;Lsoftware/bernie/geckolib3/geo/render/built/GeoCube;FFFFD)V
      // 184: getstatic com/trolmastercard/velvet/d_.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 187: invokevirtual software/bernie/geckolib3/util/MatrixStack.pop ()V
      // 18a: goto 153
      // 18d: aload 2
      // 18e: getfield software/bernie/geckolib3/geo/render/built/GeoBone.childBones Ljava/util/List;
      // 191: invokeinterface java/util/List.iterator ()Ljava/util/Iterator; 1
      // 196: astore 11
      // 198: aload 11
      // 19a: invokeinterface java/util/Iterator.hasNext ()Z 1
      // 19f: ifeq 1dd
      // 1a2: aload 11
      // 1a4: invokeinterface java/util/Iterator.next ()Ljava/lang/Object; 1
      // 1a9: checkcast software/bernie/geckolib3/geo/render/built/GeoBone
      // 1ac: astore 12
      // 1ae: dload 9
      // 1b0: dconst_0
      // 1b1: dcmpl
      // 1b2: ifne 1ca
      // 1b5: aload 0
      // 1b6: aload 1
      // 1b7: aload 12
      // 1b9: fload 3
      // 1ba: fload 4
      // 1bc: fload 5
      // 1be: fload 6
      // 1c0: invokevirtual com/trolmastercard/velvet/d_.renderRecursively (Lnet/minecraft/client/renderer/BufferBuilder;Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;FFFF)V
      // 1c3: goto 1da
      // 1c6: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 1c9: athrow
      // 1ca: aload 0
      // 1cb: aload 1
      // 1cc: aload 12
      // 1ce: fload 3
      // 1cf: fload 4
      // 1d1: fload 5
      // 1d3: fload 6
      // 1d5: dload 9
      // 1d7: invokevirtual com/trolmastercard/velvet/d_.a (Lnet/minecraft/client/renderer/BufferBuilder;Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;FFFFD)V
      // 1da: goto 198
      // 1dd: getstatic com/trolmastercard/velvet/d_.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 1e0: invokevirtual software/bernie/geckolib3/util/MatrixStack.pop ()V
      // 1e3: goto 1e8
      // 1e6: astore 8
      // 1e8: return
      // try (183 -> 196): 196 java/lang/IllegalStateException
      // try (107 -> 114): 114 java/lang/IllegalStateException
      // try (96 -> 105): 105 java/lang/IllegalStateException
      // try (68 -> 99): 100 java/lang/IllegalStateException
      // try (52 -> 63): 64 java/lang/IllegalStateException
      // try (48 -> 56): 57 java/lang/IllegalStateException
      // try (33 -> 45): 46 java/lang/IllegalStateException
      // try (29 -> 38): 39 java/lang/IllegalStateException
      // try (15 -> 26): 27 java/lang/IllegalStateException
      // try (11 -> 19): 20 java/lang/IllegalStateException
      // try (0 -> 6): 6 java/lang/IllegalStateException
      // try (208 -> 210): 211 java/lang/IllegalStateException
   }

   protected Vector4f a(float var1, float var2, float var3) {
      return new Vector4f(var1, var2, var3, 0.0F);
   }

   boolean b(String var1) {
      try {
         if (!var1.startsWith("armor")) {
            return true;
         }
      } catch (IllegalStateException var2) {
         throw b(var2);
      }

      return this.j instanceof e2;
   }

   protected Vector4f a(String var1, float var2, float var3, float var4) {
      try {
         if (!var1.startsWith("armor")) {
            return this.a(var2, var3, var4);
         }
      } catch (IllegalStateException var19) {
         throw b(var19);
      }

      try {
         if (!(this.j instanceof e2)) {
            return this.a(var2, var3, var4);
         }
      } catch (IllegalStateException var15) {
         throw b(var15);
      }

      try {
         if ((Integer)this.j.m.func_187225_a(em.D) == 0) {
            return this.a(var2, var3, var4);
         }
      } catch (IllegalStateException var18) {
         throw b(var18);
      }

      GeoModelProvider var5 = this.getGeoModelProvider();

      try {
         if (!(var5 instanceof cv)) {
            return this.a(var2, var3, var4);
         }
      } catch (IllegalStateException var17) {
         throw b(var17);
      }

      cv var6 = (cv)var5;
      ItemStack var7 = var6.a(this.j, var1);

      try {
         if (!(var7.func_77973_b() instanceof ItemArmor)) {
            return this.a(var2, var3, var4);
         }
      } catch (IllegalStateException var16) {
         throw b(var16);
      }

      ItemArmor var8 = (ItemArmor)var7.func_77973_b();
      ArmorMaterial var9 = var8.func_82812_d();
      float var10 = 0.0F;
      switch (var9) {
         case GOLD:
            var10 = 1.0F;
            break;
         case CHAIN:
         case IRON:
            var10 = 2.0F;
            break;
         case LEATHER:
            var10 = 4.0F;
            int var11 = var8.func_82814_b(var7);
            float var12 = (var11 >> 16 & 0xFF) / 255.0F;
            float var13 = (var11 >> 8 & 0xFF) / 255.0F;
            float var14 = (var11 & 0xFF) / 255.0F;
            var2 *= var12;
            var3 *= var13;
            var4 *= var14;
      }

      return new Vector4f(var2, var3, var4, 72.0F * var10 / 4096.0F);
   }

   public void a(T var1, float var2, float var3, float var4, float var5, float var6) {
      this.g = (Matrix4f)MATRIX_STACK.getModelMatrix().clone();
   }

   public void a(BufferBuilder param1, GeoBone param2, float param3, float param4, float param5, float param6, double param7) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 000: aload 0
      // 001: getfield com/trolmastercard/velvet/d_.j Lcom/trolmastercard/velvet/em;
      // 004: getfield com/trolmastercard/velvet/em.field_70170_p Lnet/minecraft/world/World;
      // 007: instanceof com/trolmastercard/velvet/gj
      // 00a: ifeq 012
      // 00d: return
      // 00e: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 011: athrow
      // 012: aload 2
      // 013: invokevirtual software/bernie/geckolib3/geo/render/built/GeoBone.getName ()Ljava/lang/String;
      // 016: astore 9
      // 018: aload 9
      // 01a: ldc_w "weapon"
      // 01d: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 020: ifeq 030
      // 023: aload 0
      // 024: aload 1
      // 025: aload 2
      // 026: invokevirtual com/trolmastercard/velvet/d_.a (Lnet/minecraft/client/renderer/BufferBuilder;Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;)V
      // 029: goto 030
      // 02c: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 02f: athrow
      // 030: aload 9
      // 032: ldc_w "ballL"
      // 035: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 038: ifne 05f
      // 03b: aload 9
      // 03d: ldc_w "ballR"
      // 040: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 043: ifne 05f
      // 046: goto 04d
      // 049: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 04c: athrow
      // 04d: aload 9
      // 04f: ldc_w "cock"
      // 052: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 055: ifeq 062
      // 058: goto 05f
      // 05b: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 05e: athrow
      // 05f: fconst_1
      // 060: fstore 6
      // 062: aload 0
      // 063: aload 1
      // 064: aload 2
      // 065: invokevirtual software/bernie/geckolib3/geo/render/built/GeoBone.getName ()Ljava/lang/String;
      // 068: aload 2
      // 069: invokevirtual com/trolmastercard/velvet/d_.a (Lnet/minecraft/client/renderer/BufferBuilder;Ljava/lang/String;Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;)V
      // 06c: getstatic com/trolmastercard/velvet/d_.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 06f: invokevirtual software/bernie/geckolib3/util/MatrixStack.push ()V
      // 072: getstatic com/trolmastercard/velvet/d_.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 075: aload 2
      // 076: invokevirtual software/bernie/geckolib3/util/MatrixStack.translate (Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;)V
      // 079: getstatic com/trolmastercard/velvet/d_.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 07c: aload 2
      // 07d: invokevirtual software/bernie/geckolib3/util/MatrixStack.moveToPivot (Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;)V
      // 080: getstatic com/trolmastercard/velvet/d_.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 083: aload 2
      // 084: invokevirtual software/bernie/geckolib3/util/MatrixStack.rotate (Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;)V
      // 087: getstatic com/trolmastercard/velvet/d_.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 08a: aload 2
      // 08b: invokevirtual software/bernie/geckolib3/util/MatrixStack.scale (Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;)V
      // 08e: getstatic com/trolmastercard/velvet/d_.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 091: aload 2
      // 092: invokevirtual software/bernie/geckolib3/util/MatrixStack.moveBackFromPivot (Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;)V
      // 095: aload 2
      // 096: getfield software/bernie/geckolib3/geo/render/built/GeoBone.isHidden Z
      // 099: ifne 12e
      // 09c: aload 0
      // 09d: getfield com/trolmastercard/velvet/d_.p Ljava/util/HashSet;
      // 0a0: aload 9
      // 0a2: invokevirtual java/util/HashSet.contains (Ljava/lang/Object;)Z
      // 0a5: ifne 0fa
      // 0a8: goto 0af
      // 0ab: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 0ae: athrow
      // 0af: aload 2
      // 0b0: getfield software/bernie/geckolib3/geo/render/built/GeoBone.childCubes Ljava/util/List;
      // 0b3: invokeinterface java/util/List.iterator ()Ljava/util/Iterator; 1
      // 0b8: astore 10
      // 0ba: aload 10
      // 0bc: invokeinterface java/util/Iterator.hasNext ()Z 1
      // 0c1: ifeq 0fa
      // 0c4: aload 10
      // 0c6: invokeinterface java/util/Iterator.next ()Ljava/lang/Object; 1
      // 0cb: checkcast software/bernie/geckolib3/geo/render/built/GeoCube
      // 0ce: astore 11
      // 0d0: getstatic com/trolmastercard/velvet/d_.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 0d3: invokevirtual software/bernie/geckolib3/util/MatrixStack.push ()V
      // 0d6: invokestatic net/minecraft/client/renderer/GlStateManager.func_179094_E ()V
      // 0d9: aload 0
      // 0da: aload 2
      // 0db: putfield com/trolmastercard/velvet/d_.q Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;
      // 0de: aload 0
      // 0df: aload 1
      // 0e0: aload 11
      // 0e2: fload 3
      // 0e3: fload 4
      // 0e5: fload 5
      // 0e7: fload 6
      // 0e9: dload 7
      // 0eb: invokevirtual com/trolmastercard/velvet/d_.a (Lnet/minecraft/client/renderer/BufferBuilder;Lsoftware/bernie/geckolib3/geo/render/built/GeoCube;FFFFD)V
      // 0ee: invokestatic net/minecraft/client/renderer/GlStateManager.func_179121_F ()V
      // 0f1: getstatic com/trolmastercard/velvet/d_.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 0f4: invokevirtual software/bernie/geckolib3/util/MatrixStack.pop ()V
      // 0f7: goto 0ba
      // 0fa: aload 2
      // 0fb: getfield software/bernie/geckolib3/geo/render/built/GeoBone.childBones Ljava/util/List;
      // 0fe: invokeinterface java/util/List.iterator ()Ljava/util/Iterator; 1
      // 103: astore 10
      // 105: aload 10
      // 107: invokeinterface java/util/Iterator.hasNext ()Z 1
      // 10c: ifeq 12e
      // 10f: aload 10
      // 111: invokeinterface java/util/Iterator.next ()Ljava/lang/Object; 1
      // 116: checkcast software/bernie/geckolib3/geo/render/built/GeoBone
      // 119: astore 11
      // 11b: aload 0
      // 11c: aload 1
      // 11d: aload 11
      // 11f: fload 3
      // 120: fload 4
      // 122: fload 5
      // 124: fload 6
      // 126: dload 7
      // 128: invokevirtual com/trolmastercard/velvet/d_.a (Lnet/minecraft/client/renderer/BufferBuilder;Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;FFFFD)V
      // 12b: goto 105
      // 12e: getstatic com/trolmastercard/velvet/d_.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 131: invokevirtual software/bernie/geckolib3/util/MatrixStack.pop ()V
      // 134: return
      // try (0 -> 6): 6 java/lang/IllegalStateException
      // try (11 -> 19): 20 java/lang/IllegalStateException
      // try (22 -> 30): 31 java/lang/IllegalStateException
      // try (26 -> 37): 38 java/lang/IllegalStateException
      // try (42 -> 73): 74 java/lang/IllegalStateException
   }

   protected boolean c() {
      try {
         if (!this.j.n()) {
            return true;
         }
      } catch (IllegalStateException var1) {
         throw b(var1);
      }

      try {
         if (i.field_71474_y.field_74320_O != 0) {
            return true;
         }
      } catch (IllegalStateException var2) {
         throw b(var2);
      }

      return false;
   }

   public void a(BufferBuilder param1, GeoCube param2, float param3, float param4, float param5, float param6, double param7) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 000: getstatic com/trolmastercard/velvet/d_.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 003: aload 2
      // 004: invokevirtual software/bernie/geckolib3/util/MatrixStack.moveToPivot (Lsoftware/bernie/geckolib3/geo/render/built/GeoCube;)V
      // 007: getstatic com/trolmastercard/velvet/d_.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 00a: aload 2
      // 00b: invokevirtual software/bernie/geckolib3/util/MatrixStack.rotate (Lsoftware/bernie/geckolib3/geo/render/built/GeoCube;)V
      // 00e: getstatic com/trolmastercard/velvet/d_.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 011: aload 2
      // 012: invokevirtual software/bernie/geckolib3/util/MatrixStack.moveBackFromPivot (Lsoftware/bernie/geckolib3/geo/render/built/GeoCube;)V
      // 015: aload 2
      // 016: getfield software/bernie/geckolib3/geo/render/built/GeoCube.quads [Lsoftware/bernie/geckolib3/geo/render/built/GeoQuad;
      // 019: astore 9
      // 01b: aload 9
      // 01d: arraylength
      // 01e: istore 10
      // 020: bipush 0
      // 021: istore 11
      // 023: iload 11
      // 025: iload 10
      // 027: if_icmpge 1fd
      // 02a: aload 9
      // 02c: iload 11
      // 02e: aaload
      // 02f: astore 12
      // 031: aload 12
      // 033: ifnonnull 03d
      // 036: goto 1f7
      // 039: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 03c: athrow
      // 03d: new javax/vecmath/Vector3f
      // 040: dup
      // 041: aload 12
      // 043: getfield software/bernie/geckolib3/geo/render/built/GeoQuad.normal Lnet/minecraft/util/math/Vec3i;
      // 046: invokevirtual net/minecraft/util/math/Vec3i.func_177958_n ()I
      // 049: i2f
      // 04a: aload 12
      // 04c: getfield software/bernie/geckolib3/geo/render/built/GeoQuad.normal Lnet/minecraft/util/math/Vec3i;
      // 04f: invokevirtual net/minecraft/util/math/Vec3i.func_177956_o ()I
      // 052: i2f
      // 053: aload 12
      // 055: getfield software/bernie/geckolib3/geo/render/built/GeoQuad.normal Lnet/minecraft/util/math/Vec3i;
      // 058: invokevirtual net/minecraft/util/math/Vec3i.func_177952_p ()I
      // 05b: i2f
      // 05c: invokespecial javax/vecmath/Vector3f.<init> (FFF)V
      // 05f: astore 13
      // 061: getstatic com/trolmastercard/velvet/d_.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 064: invokevirtual software/bernie/geckolib3/util/MatrixStack.getNormalMatrix ()Ljavax/vecmath/Matrix3f;
      // 067: aload 13
      // 069: invokevirtual javax/vecmath/Matrix3f.transform (Ljavax/vecmath/Tuple3f;)V
      // 06c: aload 2
      // 06d: getfield software/bernie/geckolib3/geo/render/built/GeoCube.size Ljavax/vecmath/Vector3f;
      // 070: getfield javax/vecmath/Vector3f.y F
      // 073: fconst_0
      // 074: fcmpl
      // 075: ifeq 08b
      // 078: aload 2
      // 079: getfield software/bernie/geckolib3/geo/render/built/GeoCube.size Ljavax/vecmath/Vector3f;
      // 07c: getfield javax/vecmath/Vector3f.z F
      // 07f: fconst_0
      // 080: fcmpl
      // 081: ifne 0b0
      // 084: goto 08b
      // 087: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 08a: athrow
      // 08b: aload 13
      // 08d: invokevirtual javax/vecmath/Vector3f.getX ()F
      // 090: fconst_0
      // 091: fcmpg
      // 092: ifge 0b0
      // 095: goto 09c
      // 098: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 09b: athrow
      // 09c: aload 13
      // 09e: dup
      // 09f: getfield javax/vecmath/Vector3f.x F
      // 0a2: ldc_w -1.0
      // 0a5: fmul
      // 0a6: putfield javax/vecmath/Vector3f.x F
      // 0a9: goto 0b0
      // 0ac: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 0af: athrow
      // 0b0: aload 2
      // 0b1: getfield software/bernie/geckolib3/geo/render/built/GeoCube.size Ljavax/vecmath/Vector3f;
      // 0b4: getfield javax/vecmath/Vector3f.x F
      // 0b7: fconst_0
      // 0b8: fcmpl
      // 0b9: ifeq 0cf
      // 0bc: aload 2
      // 0bd: getfield software/bernie/geckolib3/geo/render/built/GeoCube.size Ljavax/vecmath/Vector3f;
      // 0c0: getfield javax/vecmath/Vector3f.z F
      // 0c3: fconst_0
      // 0c4: fcmpl
      // 0c5: ifne 0f4
      // 0c8: goto 0cf
      // 0cb: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 0ce: athrow
      // 0cf: aload 13
      // 0d1: invokevirtual javax/vecmath/Vector3f.getY ()F
      // 0d4: fconst_0
      // 0d5: fcmpg
      // 0d6: ifge 0f4
      // 0d9: goto 0e0
      // 0dc: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 0df: athrow
      // 0e0: aload 13
      // 0e2: dup
      // 0e3: getfield javax/vecmath/Vector3f.y F
      // 0e6: ldc_w -1.0
      // 0e9: fmul
      // 0ea: putfield javax/vecmath/Vector3f.y F
      // 0ed: goto 0f4
      // 0f0: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 0f3: athrow
      // 0f4: aload 2
      // 0f5: getfield software/bernie/geckolib3/geo/render/built/GeoCube.size Ljavax/vecmath/Vector3f;
      // 0f8: getfield javax/vecmath/Vector3f.x F
      // 0fb: fconst_0
      // 0fc: fcmpl
      // 0fd: ifeq 113
      // 100: aload 2
      // 101: getfield software/bernie/geckolib3/geo/render/built/GeoCube.size Ljavax/vecmath/Vector3f;
      // 104: getfield javax/vecmath/Vector3f.y F
      // 107: fconst_0
      // 108: fcmpl
      // 109: ifne 138
      // 10c: goto 113
      // 10f: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 112: athrow
      // 113: aload 13
      // 115: invokevirtual javax/vecmath/Vector3f.getZ ()F
      // 118: fconst_0
      // 119: fcmpg
      // 11a: ifge 138
      // 11d: goto 124
      // 120: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 123: athrow
      // 124: aload 13
      // 126: dup
      // 127: getfield javax/vecmath/Vector3f.z F
      // 12a: ldc_w -1.0
      // 12d: fmul
      // 12e: putfield javax/vecmath/Vector3f.z F
      // 131: goto 138
      // 134: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 137: athrow
      // 138: aload 0
      // 139: aload 0
      // 13a: getfield com/trolmastercard/velvet/d_.q Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;
      // 13d: new net/minecraft/util/math/Vec3d
      // 140: dup
      // 141: fload 3
      // 142: f2d
      // 143: fload 4
      // 145: f2d
      // 146: fload 5
      // 148: f2d
      // 149: invokespecial net/minecraft/util/math/Vec3d.<init> (DDD)V
      // 14c: aload 13
      // 14e: invokestatic com/trolmastercard/velvet/gx.a (Lcom/trolmastercard/velvet/c3;Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;Lnet/minecraft/util/math/Vec3d;Ljavax/vecmath/Vector3f;)Lnet/minecraft/util/math/Vec3d;
      // 151: astore 14
      // 153: aload 12
      // 155: getfield software/bernie/geckolib3/geo/render/built/GeoQuad.vertices [Lsoftware/bernie/geckolib3/geo/render/built/GeoVertex;
      // 158: astore 15
      // 15a: aload 15
      // 15c: arraylength
      // 15d: istore 16
      // 15f: bipush 0
      // 160: istore 17
      // 162: iload 17
      // 164: iload 16
      // 166: if_icmpge 1f7
      // 169: aload 15
      // 16b: iload 17
      // 16d: aaload
      // 16e: astore 18
      // 170: new javax/vecmath/Vector4f
      // 173: dup
      // 174: aload 18
      // 176: getfield software/bernie/geckolib3/geo/render/built/GeoVertex.position Ljavax/vecmath/Vector3f;
      // 179: invokevirtual javax/vecmath/Vector3f.getX ()F
      // 17c: aload 18
      // 17e: getfield software/bernie/geckolib3/geo/render/built/GeoVertex.position Ljavax/vecmath/Vector3f;
      // 181: invokevirtual javax/vecmath/Vector3f.getY ()F
      // 184: aload 18
      // 186: getfield software/bernie/geckolib3/geo/render/built/GeoVertex.position Ljavax/vecmath/Vector3f;
      // 189: invokevirtual javax/vecmath/Vector3f.getZ ()F
      // 18c: fconst_1
      // 18d: invokespecial javax/vecmath/Vector4f.<init> (FFFF)V
      // 190: astore 19
      // 192: getstatic com/trolmastercard/velvet/d_.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 195: invokevirtual software/bernie/geckolib3/util/MatrixStack.getModelMatrix ()Ljavax/vecmath/Matrix4f;
      // 198: aload 19
      // 19a: invokevirtual javax/vecmath/Matrix4f.transform (Ljavax/vecmath/Tuple4f;)V
      // 19d: aload 1
      // 19e: aload 19
      // 1a0: invokevirtual javax/vecmath/Vector4f.getX ()F
      // 1a3: f2d
      // 1a4: aload 19
      // 1a6: invokevirtual javax/vecmath/Vector4f.getY ()F
      // 1a9: f2d
      // 1aa: aload 19
      // 1ac: invokevirtual javax/vecmath/Vector4f.getZ ()F
      // 1af: f2d
      // 1b0: invokevirtual net/minecraft/client/renderer/BufferBuilder.func_181662_b (DDD)Lnet/minecraft/client/renderer/BufferBuilder;
      // 1b3: aload 18
      // 1b5: getfield software/bernie/geckolib3/geo/render/built/GeoVertex.textureU F
      // 1b8: f2d
      // 1b9: dload 7
      // 1bb: dadd
      // 1bc: aload 18
      // 1be: getfield software/bernie/geckolib3/geo/render/built/GeoVertex.textureV F
      // 1c1: f2d
      // 1c2: invokevirtual net/minecraft/client/renderer/BufferBuilder.func_187315_a (DD)Lnet/minecraft/client/renderer/BufferBuilder;
      // 1c5: aload 14
      // 1c7: getfield net/minecraft/util/math/Vec3d.field_72450_a D
      // 1ca: d2f
      // 1cb: aload 14
      // 1cd: getfield net/minecraft/util/math/Vec3d.field_72448_b D
      // 1d0: d2f
      // 1d1: aload 14
      // 1d3: getfield net/minecraft/util/math/Vec3d.field_72449_c D
      // 1d6: d2f
      // 1d7: fload 6
      // 1d9: invokevirtual net/minecraft/client/renderer/BufferBuilder.func_181666_a (FFFF)Lnet/minecraft/client/renderer/BufferBuilder;
      // 1dc: aload 13
      // 1de: invokevirtual javax/vecmath/Vector3f.getX ()F
      // 1e1: aload 13
      // 1e3: invokevirtual javax/vecmath/Vector3f.getY ()F
      // 1e6: aload 13
      // 1e8: invokevirtual javax/vecmath/Vector3f.getZ ()F
      // 1eb: invokevirtual net/minecraft/client/renderer/BufferBuilder.func_181663_c (FFF)Lnet/minecraft/client/renderer/BufferBuilder;
      // 1ee: invokevirtual net/minecraft/client/renderer/BufferBuilder.func_181675_d ()V
      // 1f1: iinc 17 1
      // 1f4: goto 162
      // 1f7: iinc 11 1
      // 1fa: goto 023
      // 1fd: return
      // try (24 -> 27): 27 java/lang/IllegalStateException
      // try (45 -> 61): 62 java/lang/IllegalStateException
      // try (55 -> 69): 70 java/lang/IllegalStateException
      // try (64 -> 78): 79 java/lang/IllegalStateException
      // try (81 -> 93): 94 java/lang/IllegalStateException
      // try (87 -> 101): 102 java/lang/IllegalStateException
      // try (96 -> 110): 111 java/lang/IllegalStateException
      // try (113 -> 125): 126 java/lang/IllegalStateException
      // try (119 -> 133): 134 java/lang/IllegalStateException
      // try (128 -> 142): 143 java/lang/IllegalStateException
   }

   protected ItemStack a() {
      String var1 = (String)this.j.m.func_187225_a(em.h);
      byte var2 = -1;

      label76: {
         label75: {
            label74: {
               label73: {
                  label72: {
                     label71: {
                        try {
                           switch (var1.hashCode()) {
                              case -20842805:
                                 break;
                              case 113766:
                                 break label74;
                              case 64419037:
                                 break label72;
                              case 95761198:
                                 if (!var1.equals("doggy")) {
                                    break label76;
                                 }
                                 break label75;
                              case 109773592:
                                 break label71;
                              case 2014427283:
                                 break label73;
                              default:
                                 break label76;
                           }
                        } catch (IllegalStateException var4) {
                           throw b(var4);
                        }

                        if (var1.equals("blowjob")) {
                           var2 = 1;
                        }
                        break label76;
                     }

                     if (var1.equals("strip")) {
                        var2 = 2;
                     }
                     break label76;
                  }

                  if (var1.equals("boobjob")) {
                     var2 = 3;
                  }
                  break label76;
               }

               if (var1.equals("touch_boobs")) {
                  var2 = 4;
               }
               break label76;
            }

            if (var1.equals("sex")) {
               var2 = 5;
            }
            break label76;
         }

         var2 = 0;
      }

      try {
         switch (var2) {
            case 0:
               return new ItemStack(Items.field_151045_i, 2);
            case 1:
               return new ItemStack(Items.field_151166_bC, 3);
            case 2:
               return new ItemStack(Items.field_151043_k, 1);
            case 3:
               return new ItemStack(Items.field_151079_bi, 2);
            case 4:
               return new ItemStack(Items.field_151115_aP, 2, 1);
            case 5:
               return new ItemStack(Items.field_151115_aP, 3, 0);
            default:
               return null;
         }
      } catch (IllegalStateException var3) {
         throw b(var3);
      }
   }

   protected void b(BufferBuilder param1, GeoBone param2) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 00: aload 0
      // 01: invokevirtual com/trolmastercard/velvet/d_.a ()Lnet/minecraft/item/ItemStack;
      // 04: astore 3
      // 05: aload 3
      // 06: ifnonnull 0e
      // 09: return
      // 0a: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 0d: athrow
      // 0e: invokestatic net/minecraft/client/Minecraft.func_71410_x ()Lnet/minecraft/client/Minecraft;
      // 11: invokevirtual net/minecraft/client/Minecraft.func_175597_ag ()Lnet/minecraft/client/renderer/ItemRenderer;
      // 14: astore 4
      // 16: bipush 0
      // 17: istore 5
      // 19: iload 5
      // 1b: aload 3
      // 1c: invokevirtual net/minecraft/item/ItemStack.func_190916_E ()I
      // 1f: if_icmpge ff
      // 22: invokestatic net/minecraft/client/renderer/GlStateManager.func_179094_E ()V
      // 25: invokestatic net/minecraft/client/renderer/Tessellator.func_178181_a ()Lnet/minecraft/client/renderer/Tessellator;
      // 28: invokevirtual net/minecraft/client/renderer/Tessellator.func_78381_a ()V
      // 2b: getstatic software/bernie/geckolib3/renderers/geo/IGeoRenderer.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 2e: aload 2
      // 2f: invokestatic com/trolmastercard/velvet/p.a (Lsoftware/bernie/geckolib3/util/MatrixStack;Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;)V
      // 32: sipush 2896
      // 35: invokestatic org/lwjgl/opengl/GL11.glEnable (I)V
      // 38: aload 2
      // 39: invokevirtual software/bernie/geckolib3/geo/render/built/GeoBone.getRotationX ()F
      // 3c: f2d
      // 3d: ldc2_w 2.5
      // 40: dadd
      // 41: dconst_0
      // 42: dconst_0
      // 43: dconst_1
      // 44: invokestatic org/lwjgl/opengl/GL11.glRotated (DDDD)V
      // 47: aload 2
      // 48: invokevirtual software/bernie/geckolib3/geo/render/built/GeoBone.getRotationY ()F
      // 4b: f2d
      // 4c: dconst_0
      // 4d: dconst_1
      // 4e: dconst_0
      // 4f: invokestatic org/lwjgl/opengl/GL11.glRotated (DDDD)V
      // 52: aload 2
      // 53: invokevirtual software/bernie/geckolib3/geo/render/built/GeoBone.getRotationZ ()F
      // 56: f2d
      // 57: dconst_1
      // 58: dconst_0
      // 59: dconst_0
      // 5a: invokestatic org/lwjgl/opengl/GL11.glRotated (DDDD)V
      // 5d: iload 5
      // 5f: lookupswitch 70 2 1 29 2 53
      // 78: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 7b: athrow
      // 7c: ldc2_w -15.0
      // 7f: dconst_0
      // 80: dconst_0
      // 81: dconst_1
      // 82: invokestatic org/lwjgl/opengl/GL11.glRotated (DDDD)V
      // 85: dconst_0
      // 86: dconst_0
      // 87: ldc2_w -0.025
      // 8a: invokestatic net/minecraft/client/renderer/GlStateManager.func_179137_b (DDD)V
      // 8d: goto a5
      // 90: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 93: athrow
      // 94: ldc2_w 15.0
      // 97: dconst_0
      // 98: dconst_0
      // 99: dconst_1
      // 9a: invokestatic org/lwjgl/opengl/GL11.glRotated (DDDD)V
      // 9d: dconst_0
      // 9e: dconst_0
      // 9f: ldc2_w 0.025
      // a2: invokestatic net/minecraft/client/renderer/GlStateManager.func_179137_b (DDD)V
      // a5: aload 0
      // a6: getfield com/trolmastercard/velvet/d_.j Lcom/trolmastercard/velvet/em;
      // a9: getfield com/trolmastercard/velvet/em.n F
      // ac: aload 0
      // ad: getfield com/trolmastercard/velvet/d_.j Lcom/trolmastercard/velvet/em;
      // b0: getfield com/trolmastercard/velvet/em.n F
      // b3: aload 0
      // b4: getfield com/trolmastercard/velvet/d_.j Lcom/trolmastercard/velvet/em;
      // b7: getfield com/trolmastercard/velvet/em.n F
      // ba: invokestatic net/minecraft/client/renderer/GlStateManager.func_179152_a (FFF)V
      // bd: aload 4
      // bf: aload 0
      // c0: getfield com/trolmastercard/velvet/d_.j Lcom/trolmastercard/velvet/em;
      // c3: new net/minecraft/item/ItemStack
      // c6: dup
      // c7: aload 3
      // c8: invokevirtual net/minecraft/item/ItemStack.func_77973_b ()Lnet/minecraft/item/Item;
      // cb: bipush 1
      // cc: invokespecial net/minecraft/item/ItemStack.<init> (Lnet/minecraft/item/Item;I)V
      // cf: getstatic net/minecraft/client/renderer/block/model/ItemCameraTransforms$TransformType.THIRD_PERSON_RIGHT_HAND Lnet/minecraft/client/renderer/block/model/ItemCameraTransforms$TransformType;
      // d2: invokevirtual net/minecraft/client/renderer/ItemRenderer.func_178099_a (Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/item/ItemStack;Lnet/minecraft/client/renderer/block/model/ItemCameraTransforms$TransformType;)V
      // d5: aload 0
      // d6: aload 0
      // d7: aload 0
      // d8: getfield com/trolmastercard/velvet/d_.j Lcom/trolmastercard/velvet/em;
      // db: invokevirtual com/trolmastercard/velvet/d_.getEntityTexture (Lnet/minecraft/entity/EntityLivingBase;)Lnet/minecraft/util/ResourceLocation;
      // de: invokestatic java/util/Objects.requireNonNull (Ljava/lang/Object;)Ljava/lang/Object;
      // e1: checkcast net/minecraft/util/ResourceLocation
      // e4: invokevirtual com/trolmastercard/velvet/d_.func_110776_a (Lnet/minecraft/util/ResourceLocation;)V
      // e7: aload 1
      // e8: bipush 7
      // ea: getstatic net/minecraft/client/renderer/vertex/DefaultVertexFormats.field_181712_l Lnet/minecraft/client/renderer/vertex/VertexFormat;
      // ed: invokevirtual net/minecraft/client/renderer/BufferBuilder.func_181668_a (ILnet/minecraft/client/renderer/vertex/VertexFormat;)V
      // f0: sipush 2896
      // f3: invokestatic org/lwjgl/opengl/GL11.glDisable (I)V
      // f6: invokestatic net/minecraft/client/renderer/GlStateManager.func_179121_F ()V
      // f9: iinc 5 1
      // fc: goto 19
      // ff: return
      // try (3 -> 6): 6 java/lang/IllegalStateException
      // try (13 -> 50): 50 java/lang/IllegalStateException
      // try (17 -> 62): 62 java/lang/IllegalStateException
   }

   protected ItemStack a(@Nullable ItemStack var1) {
      return var1;
   }

   protected void a(BufferBuilder param1, GeoBone param2) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 000: aload 0
      // 001: getfield com/trolmastercard/velvet/d_.j Lcom/trolmastercard/velvet/em;
      // 004: ifnonnull 00c
      // 007: return
      // 008: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 00b: athrow
      // 00c: aload 0
      // 00d: getfield com/trolmastercard/velvet/d_.j Lcom/trolmastercard/velvet/em;
      // 010: instanceof com/trolmastercard/velvet/e2
      // 013: ifne 01b
      // 016: return
      // 017: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 01a: athrow
      // 01b: aload 0
      // 01c: getfield com/trolmastercard/velvet/d_.j Lcom/trolmastercard/velvet/em;
      // 01f: invokevirtual com/trolmastercard/velvet/em.func_184212_Q ()Lnet/minecraft/network/datasync/EntityDataManager;
      // 022: astore 3
      // 023: aload 0
      // 024: getfield com/trolmastercard/velvet/d_.j Lcom/trolmastercard/velvet/em;
      // 027: checkcast com/trolmastercard/velvet/e2
      // 02a: astore 4
      // 02c: aload 3
      // 02d: getstatic com/trolmastercard/velvet/e2.M Lnet/minecraft/network/datasync/DataParameter;
      // 030: invokevirtual net/minecraft/network/datasync/EntityDataManager.func_187225_a (Lnet/minecraft/network/datasync/DataParameter;)Ljava/lang/Object;
      // 033: checkcast java/lang/Integer
      // 036: invokevirtual java/lang/Integer.intValue ()I
      // 039: istore 5
      // 03b: aload 4
      // 03d: invokevirtual com/trolmastercard/velvet/e2.y ()Lcom/trolmastercard/velvet/fp;
      // 040: getstatic com/trolmastercard/velvet/fp.BOW Lcom/trolmastercard/velvet/fp;
      // 043: if_acmpeq 052
      // 046: aload 0
      // 047: fconst_0
      // 048: putfield com/trolmastercard/velvet/d_.a F
      // 04b: goto 052
      // 04e: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 051: athrow
      // 052: aconst_null
      // 053: astore 6
      // 055: iload 5
      // 057: bipush 1
      // 058: if_icmpne 06a
      // 05b: aload 3
      // 05c: getstatic com/trolmastercard/velvet/e2.L Lnet/minecraft/network/datasync/DataParameter;
      // 05f: invokevirtual net/minecraft/network/datasync/EntityDataManager.func_187225_a (Lnet/minecraft/network/datasync/DataParameter;)Ljava/lang/Object;
      // 062: checkcast net/minecraft/item/ItemStack
      // 065: astore 6
      // 067: goto 07c
      // 06a: iload 5
      // 06c: bipush 2
      // 06d: if_icmpne 07c
      // 070: aload 3
      // 071: getstatic com/trolmastercard/velvet/e2.R Lnet/minecraft/network/datasync/DataParameter;
      // 074: invokevirtual net/minecraft/network/datasync/EntityDataManager.func_187225_a (Lnet/minecraft/network/datasync/DataParameter;)Ljava/lang/Object;
      // 077: checkcast net/minecraft/item/ItemStack
      // 07a: astore 6
      // 07c: aload 0
      // 07d: aload 6
      // 07f: invokevirtual com/trolmastercard/velvet/d_.a (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/ItemStack;
      // 082: astore 6
      // 084: aload 6
      // 086: ifnonnull 08e
      // 089: return
      // 08a: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 08d: athrow
      // 08e: aload 6
      // 090: invokevirtual net/minecraft/item/ItemStack.func_77973_b ()Lnet/minecraft/item/Item;
      // 093: getstatic net/minecraft/init/Items.field_151031_f Lnet/minecraft/item/ItemBow;
      // 096: invokevirtual java/lang/Object.equals (Ljava/lang/Object;)Z
      // 099: ifeq 0e0
      // 09c: aload 4
      // 09e: invokevirtual com/trolmastercard/velvet/e2.y ()Lcom/trolmastercard/velvet/fp;
      // 0a1: getstatic com/trolmastercard/velvet/fp.BOW Lcom/trolmastercard/velvet/fp;
      // 0a4: if_acmpne 0e0
      // 0a7: goto 0ae
      // 0aa: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 0ad: athrow
      // 0ae: aload 0
      // 0af: dup
      // 0b0: getfield com/trolmastercard/velvet/d_.a F
      // 0b3: ldc_w 0.015
      // 0b6: fadd
      // 0b7: putfield com/trolmastercard/velvet/d_.a F
      // 0ba: aload 4
      // 0bc: aload 0
      // 0bd: getfield com/trolmastercard/velvet/d_.a F
      // 0c0: fneg
      // 0c1: ldc_w 20.0
      // 0c4: fmul
      // 0c5: aload 6
      // 0c7: invokevirtual net/minecraft/item/ItemStack.func_77988_m ()I
      // 0ca: i2f
      // 0cb: fadd
      // 0cc: invokestatic java/lang/Math.round (F)I
      // 0cf: invokevirtual com/trolmastercard/velvet/e2.d (I)V
      // 0d2: aload 4
      // 0d4: aload 6
      // 0d6: invokevirtual com/trolmastercard/velvet/e2.a (Lnet/minecraft/item/ItemStack;)V
      // 0d9: goto 0e0
      // 0dc: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 0df: athrow
      // 0e0: invokestatic net/minecraft/client/renderer/GlStateManager.func_179094_E ()V
      // 0e3: invokestatic net/minecraft/client/renderer/Tessellator.func_178181_a ()Lnet/minecraft/client/renderer/Tessellator;
      // 0e6: invokevirtual net/minecraft/client/renderer/Tessellator.func_78381_a ()V
      // 0e9: getstatic com/trolmastercard/velvet/d_.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 0ec: aload 2
      // 0ed: invokestatic com/trolmastercard/velvet/p.a (Lsoftware/bernie/geckolib3/util/MatrixStack;Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;)V
      // 0f0: sipush 2896
      // 0f3: invokestatic org/lwjgl/opengl/GL11.glEnable (I)V
      // 0f6: aload 6
      // 0f8: invokevirtual net/minecraft/item/ItemStack.func_77973_b ()Lnet/minecraft/item/Item;
      // 0fb: instanceof net/minecraft/item/ItemBow
      // 0fe: ifeq 114
      // 101: aload 4
      // 103: getfield com/trolmastercard/velvet/e2.K I
      // 106: i2f
      // 107: fconst_1
      // 108: fconst_0
      // 109: fconst_0
      // 10a: invokestatic org/lwjgl/opengl/GL11.glRotatef (FFFF)V
      // 10d: goto 168
      // 110: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 113: athrow
      // 114: aload 4
      // 116: invokevirtual com/trolmastercard/velvet/e2.y ()Lcom/trolmastercard/velvet/fp;
      // 119: getstatic com/trolmastercard/velvet/fp.ATTACK Lcom/trolmastercard/velvet/fp;
      // 11c: if_acmpne 15c
      // 11f: aload 4
      // 121: getfield com/trolmastercard/velvet/e2.S I
      // 124: ifne 15c
      // 127: goto 12e
      // 12a: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 12d: athrow
      // 12e: aload 4
      // 130: getfield com/trolmastercard/velvet/e2.V Lnet/minecraft/util/math/Vec3d;
      // 133: getfield net/minecraft/util/math/Vec3d.field_72450_a D
      // 136: aload 4
      // 138: getfield com/trolmastercard/velvet/e2.V Lnet/minecraft/util/math/Vec3d;
      // 13b: getfield net/minecraft/util/math/Vec3d.field_72448_b D
      // 13e: aload 4
      // 140: getfield com/trolmastercard/velvet/e2.V Lnet/minecraft/util/math/Vec3d;
      // 143: getfield net/minecraft/util/math/Vec3d.field_72449_c D
      // 146: invokestatic net/minecraft/client/renderer/GlStateManager.func_179137_b (DDD)V
      // 149: aload 4
      // 14b: getfield com/trolmastercard/velvet/e2.O I
      // 14e: i2f
      // 14f: fconst_1
      // 150: fconst_0
      // 151: fconst_0
      // 152: invokestatic org/lwjgl/opengl/GL11.glRotatef (FFFF)V
      // 155: goto 168
      // 158: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 15b: athrow
      // 15c: aload 4
      // 15e: getfield com/trolmastercard/velvet/e2.P I
      // 161: i2f
      // 162: fconst_1
      // 163: fconst_0
      // 164: fconst_0
      // 165: invokestatic org/lwjgl/opengl/GL11.glRotatef (FFFF)V
      // 168: invokestatic net/minecraft/client/Minecraft.func_71410_x ()Lnet/minecraft/client/Minecraft;
      // 16b: invokevirtual net/minecraft/client/Minecraft.func_175597_ag ()Lnet/minecraft/client/renderer/ItemRenderer;
      // 16e: aload 0
      // 16f: getfield com/trolmastercard/velvet/d_.j Lcom/trolmastercard/velvet/em;
      // 172: aload 6
      // 174: getstatic net/minecraft/client/renderer/block/model/ItemCameraTransforms$TransformType.THIRD_PERSON_RIGHT_HAND Lnet/minecraft/client/renderer/block/model/ItemCameraTransforms$TransformType;
      // 177: invokevirtual net/minecraft/client/renderer/ItemRenderer.func_178099_a (Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/item/ItemStack;Lnet/minecraft/client/renderer/block/model/ItemCameraTransforms$TransformType;)V
      // 17a: aload 0
      // 17b: aload 0
      // 17c: aload 0
      // 17d: getfield com/trolmastercard/velvet/d_.j Lcom/trolmastercard/velvet/em;
      // 180: invokevirtual com/trolmastercard/velvet/d_.getEntityTexture (Lnet/minecraft/entity/EntityLivingBase;)Lnet/minecraft/util/ResourceLocation;
      // 183: invokestatic java/util/Objects.requireNonNull (Ljava/lang/Object;)Ljava/lang/Object;
      // 186: checkcast net/minecraft/util/ResourceLocation
      // 189: invokevirtual com/trolmastercard/velvet/d_.func_110776_a (Lnet/minecraft/util/ResourceLocation;)V
      // 18c: aload 1
      // 18d: bipush 7
      // 18f: getstatic net/minecraft/client/renderer/vertex/DefaultVertexFormats.field_181712_l Lnet/minecraft/client/renderer/vertex/VertexFormat;
      // 192: invokevirtual net/minecraft/client/renderer/BufferBuilder.func_181668_a (ILnet/minecraft/client/renderer/vertex/VertexFormat;)V
      // 195: sipush 2896
      // 198: invokestatic org/lwjgl/opengl/GL11.glDisable (I)V
      // 19b: invokestatic net/minecraft/client/renderer/GlStateManager.func_179121_F ()V
      // 19e: return
      // try (0 -> 4): 4 java/lang/IllegalStateException
      // try (6 -> 11): 11 java/lang/IllegalStateException
      // try (27 -> 34): 35 java/lang/IllegalStateException
      // try (60 -> 63): 63 java/lang/IllegalStateException
      // try (65 -> 74): 75 java/lang/IllegalStateException
      // try (70 -> 98): 99 java/lang/IllegalStateException
      // try (101 -> 121): 121 java/lang/IllegalStateException
      // try (123 -> 130): 131 java/lang/IllegalStateException
      // try (127 -> 151): 151 java/lang/IllegalStateException
   }

   RayTraceResult a(Vec3d param1, Vec3d param2, World param3) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 000: aload 1
      // 001: getfield net/minecraft/util/math/Vec3d.field_72450_a D
      // 004: invokestatic java/lang/Double.isNaN (D)Z
      // 007: ifne 02c
      // 00a: aload 1
      // 00b: getfield net/minecraft/util/math/Vec3d.field_72448_b D
      // 00e: invokestatic java/lang/Double.isNaN (D)Z
      // 011: ifne 02c
      // 014: goto 01b
      // 017: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 01a: athrow
      // 01b: aload 1
      // 01c: getfield net/minecraft/util/math/Vec3d.field_72449_c D
      // 01f: invokestatic java/lang/Double.isNaN (D)Z
      // 022: ifeq 032
      // 025: goto 02c
      // 028: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 02b: athrow
      // 02c: aconst_null
      // 02d: areturn
      // 02e: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 031: athrow
      // 032: aload 2
      // 033: getfield net/minecraft/util/math/Vec3d.field_72450_a D
      // 036: invokestatic java/lang/Double.isNaN (D)Z
      // 039: ifne 05e
      // 03c: aload 2
      // 03d: getfield net/minecraft/util/math/Vec3d.field_72448_b D
      // 040: invokestatic java/lang/Double.isNaN (D)Z
      // 043: ifne 05e
      // 046: goto 04d
      // 049: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 04c: athrow
      // 04d: aload 2
      // 04e: getfield net/minecraft/util/math/Vec3d.field_72449_c D
      // 051: invokestatic java/lang/Double.isNaN (D)Z
      // 054: ifeq 064
      // 057: goto 05e
      // 05a: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 05d: athrow
      // 05e: aconst_null
      // 05f: areturn
      // 060: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 063: athrow
      // 064: aload 2
      // 065: getfield net/minecraft/util/math/Vec3d.field_72450_a D
      // 068: invokestatic net/minecraft/util/math/MathHelper.func_76128_c (D)I
      // 06b: istore 4
      // 06d: aload 2
      // 06e: getfield net/minecraft/util/math/Vec3d.field_72448_b D
      // 071: invokestatic net/minecraft/util/math/MathHelper.func_76128_c (D)I
      // 074: istore 5
      // 076: aload 2
      // 077: getfield net/minecraft/util/math/Vec3d.field_72449_c D
      // 07a: invokestatic net/minecraft/util/math/MathHelper.func_76128_c (D)I
      // 07d: istore 6
      // 07f: aload 1
      // 080: getfield net/minecraft/util/math/Vec3d.field_72450_a D
      // 083: invokestatic net/minecraft/util/math/MathHelper.func_76128_c (D)I
      // 086: istore 7
      // 088: aload 1
      // 089: getfield net/minecraft/util/math/Vec3d.field_72448_b D
      // 08c: invokestatic net/minecraft/util/math/MathHelper.func_76128_c (D)I
      // 08f: istore 8
      // 091: aload 1
      // 092: getfield net/minecraft/util/math/Vec3d.field_72449_c D
      // 095: invokestatic net/minecraft/util/math/MathHelper.func_76128_c (D)I
      // 098: istore 9
      // 09a: new net/minecraft/util/math/BlockPos
      // 09d: dup
      // 09e: iload 7
      // 0a0: iload 8
      // 0a2: iload 9
      // 0a4: invokespecial net/minecraft/util/math/BlockPos.<init> (III)V
      // 0a7: astore 10
      // 0a9: aload 3
      // 0aa: aload 10
      // 0ac: invokevirtual net/minecraft/world/World.func_180495_p (Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/state/IBlockState;
      // 0af: astore 11
      // 0b1: aload 11
      // 0b3: aload 3
      // 0b4: aload 10
      // 0b6: invokeinterface net/minecraft/block/state/IBlockState.func_185890_d (Lnet/minecraft/world/IBlockAccess;Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/util/math/AxisAlignedBB; 3
      // 0bb: getstatic net/minecraft/block/Block.field_185506_k Lnet/minecraft/util/math/AxisAlignedBB;
      // 0be: if_acmpeq 0e9
      // 0c1: aload 11
      // 0c3: invokeinterface net/minecraft/block/state/IBlockState.func_177230_c ()Lnet/minecraft/block/Block; 1
      // 0c8: invokevirtual net/minecraft/block/Block.func_180664_k ()Lnet/minecraft/util/BlockRenderLayer;
      // 0cb: getstatic net/minecraft/util/BlockRenderLayer.SOLID Lnet/minecraft/util/BlockRenderLayer;
      // 0ce: if_acmpne 0e9
      // 0d1: goto 0d8
      // 0d4: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 0d7: athrow
      // 0d8: aload 11
      // 0da: aload 3
      // 0db: aload 10
      // 0dd: aload 1
      // 0de: aload 2
      // 0df: invokeinterface net/minecraft/block/state/IBlockState.func_185910_a (Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/math/Vec3d;)Lnet/minecraft/util/math/RayTraceResult; 5
      // 0e4: areturn
      // 0e5: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 0e8: athrow
      // 0e9: sipush 200
      // 0ec: istore 12
      // 0ee: iload 12
      // 0f0: iinc 12 -1
      // 0f3: iflt 3f2
      // 0f6: aload 1
      // 0f7: getfield net/minecraft/util/math/Vec3d.field_72450_a D
      // 0fa: invokestatic java/lang/Double.isNaN (D)Z
      // 0fd: ifne 129
      // 100: goto 107
      // 103: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 106: athrow
      // 107: aload 1
      // 108: getfield net/minecraft/util/math/Vec3d.field_72448_b D
      // 10b: invokestatic java/lang/Double.isNaN (D)Z
      // 10e: ifne 129
      // 111: goto 118
      // 114: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 117: athrow
      // 118: aload 1
      // 119: getfield net/minecraft/util/math/Vec3d.field_72449_c D
      // 11c: invokestatic java/lang/Double.isNaN (D)Z
      // 11f: ifeq 12f
      // 122: goto 129
      // 125: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 128: athrow
      // 129: aconst_null
      // 12a: areturn
      // 12b: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 12e: athrow
      // 12f: iload 7
      // 131: iload 4
      // 133: if_icmpne 158
      // 136: iload 8
      // 138: iload 5
      // 13a: if_icmpne 158
      // 13d: goto 144
      // 140: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 143: athrow
      // 144: iload 9
      // 146: iload 6
      // 148: if_icmpne 158
      // 14b: goto 152
      // 14e: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 151: athrow
      // 152: aconst_null
      // 153: areturn
      // 154: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 157: athrow
      // 158: bipush 1
      // 159: istore 13
      // 15b: bipush 1
      // 15c: istore 14
      // 15e: bipush 1
      // 15f: istore 15
      // 161: ldc2_w 999.0
      // 164: dstore 16
      // 166: ldc2_w 999.0
      // 169: dstore 18
      // 16b: ldc2_w 999.0
      // 16e: dstore 20
      // 170: iload 4
      // 172: iload 7
      // 174: if_icmple 181
      // 177: iload 7
      // 179: i2d
      // 17a: dconst_1
      // 17b: dadd
      // 17c: dstore 16
      // 17e: goto 195
      // 181: iload 4
      // 183: iload 7
      // 185: if_icmpge 192
      // 188: iload 7
      // 18a: i2d
      // 18b: dconst_0
      // 18c: dadd
      // 18d: dstore 16
      // 18f: goto 195
      // 192: bipush 0
      // 193: istore 13
      // 195: iload 5
      // 197: iload 8
      // 199: if_icmple 1a6
      // 19c: iload 8
      // 19e: i2d
      // 19f: dconst_1
      // 1a0: dadd
      // 1a1: dstore 18
      // 1a3: goto 1ba
      // 1a6: iload 5
      // 1a8: iload 8
      // 1aa: if_icmpge 1b7
      // 1ad: iload 8
      // 1af: i2d
      // 1b0: dconst_0
      // 1b1: dadd
      // 1b2: dstore 18
      // 1b4: goto 1ba
      // 1b7: bipush 0
      // 1b8: istore 14
      // 1ba: iload 6
      // 1bc: iload 9
      // 1be: if_icmple 1cb
      // 1c1: iload 9
      // 1c3: i2d
      // 1c4: dconst_1
      // 1c5: dadd
      // 1c6: dstore 20
      // 1c8: goto 1df
      // 1cb: iload 6
      // 1cd: iload 9
      // 1cf: if_icmpge 1dc
      // 1d2: iload 9
      // 1d4: i2d
      // 1d5: dconst_0
      // 1d6: dadd
      // 1d7: dstore 20
      // 1d9: goto 1df
      // 1dc: bipush 0
      // 1dd: istore 15
      // 1df: ldc2_w 999.0
      // 1e2: dstore 22
      // 1e4: ldc2_w 999.0
      // 1e7: dstore 24
      // 1e9: ldc2_w 999.0
      // 1ec: dstore 26
      // 1ee: aload 2
      // 1ef: getfield net/minecraft/util/math/Vec3d.field_72450_a D
      // 1f2: aload 1
      // 1f3: getfield net/minecraft/util/math/Vec3d.field_72450_a D
      // 1f6: dsub
      // 1f7: dstore 28
      // 1f9: aload 2
      // 1fa: getfield net/minecraft/util/math/Vec3d.field_72448_b D
      // 1fd: aload 1
      // 1fe: getfield net/minecraft/util/math/Vec3d.field_72448_b D
      // 201: dsub
      // 202: dstore 30
      // 204: aload 2
      // 205: getfield net/minecraft/util/math/Vec3d.field_72449_c D
      // 208: aload 1
      // 209: getfield net/minecraft/util/math/Vec3d.field_72449_c D
      // 20c: dsub
      // 20d: dstore 32
      // 20f: iload 13
      // 211: ifeq 220
      // 214: dload 16
      // 216: aload 1
      // 217: getfield net/minecraft/util/math/Vec3d.field_72450_a D
      // 21a: dsub
      // 21b: dload 28
      // 21d: ddiv
      // 21e: dstore 22
      // 220: iload 14
      // 222: ifeq 231
      // 225: dload 18
      // 227: aload 1
      // 228: getfield net/minecraft/util/math/Vec3d.field_72448_b D
      // 22b: dsub
      // 22c: dload 30
      // 22e: ddiv
      // 22f: dstore 24
      // 231: iload 15
      // 233: ifeq 242
      // 236: dload 20
      // 238: aload 1
      // 239: getfield net/minecraft/util/math/Vec3d.field_72449_c D
      // 23c: dsub
      // 23d: dload 32
      // 23f: ddiv
      // 240: dstore 26
      // 242: dload 22
      // 244: ldc2_w -0.0
      // 247: dcmpl
      // 248: ifne 250
      // 24b: ldc2_w -1.0E-4
      // 24e: dstore 22
      // 250: dload 24
      // 252: ldc2_w -0.0
      // 255: dcmpl
      // 256: ifne 25e
      // 259: ldc2_w -1.0E-4
      // 25c: dstore 24
      // 25e: dload 26
      // 260: ldc2_w -0.0
      // 263: dcmpl
      // 264: ifne 26c
      // 267: ldc2_w -1.0E-4
      // 26a: dstore 26
      // 26c: dload 22
      // 26e: dload 24
      // 270: dcmpg
      // 271: ifge 2c1
      // 274: dload 22
      // 276: dload 26
      // 278: dcmpg
      // 279: ifge 2c1
      // 27c: goto 283
      // 27f: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 282: athrow
      // 283: iload 4
      // 285: iload 7
      // 287: if_icmple 29b
      // 28a: goto 291
      // 28d: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 290: athrow
      // 291: getstatic net/minecraft/util/EnumFacing.WEST Lnet/minecraft/util/EnumFacing;
      // 294: goto 29e
      // 297: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 29a: athrow
      // 29b: getstatic net/minecraft/util/EnumFacing.EAST Lnet/minecraft/util/EnumFacing;
      // 29e: astore 34
      // 2a0: new net/minecraft/util/math/Vec3d
      // 2a3: dup
      // 2a4: dload 16
      // 2a6: aload 1
      // 2a7: getfield net/minecraft/util/math/Vec3d.field_72448_b D
      // 2aa: dload 30
      // 2ac: dload 22
      // 2ae: dmul
      // 2af: dadd
      // 2b0: aload 1
      // 2b1: getfield net/minecraft/util/math/Vec3d.field_72449_c D
      // 2b4: dload 32
      // 2b6: dload 22
      // 2b8: dmul
      // 2b9: dadd
      // 2ba: invokespecial net/minecraft/util/math/Vec3d.<init> (DDD)V
      // 2bd: astore 1
      // 2be: goto 33b
      // 2c1: dload 24
      // 2c3: dload 26
      // 2c5: dcmpg
      // 2c6: ifge 307
      // 2c9: iload 5
      // 2cb: iload 8
      // 2cd: if_icmple 2e1
      // 2d0: goto 2d7
      // 2d3: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 2d6: athrow
      // 2d7: getstatic net/minecraft/util/EnumFacing.DOWN Lnet/minecraft/util/EnumFacing;
      // 2da: goto 2e4
      // 2dd: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 2e0: athrow
      // 2e1: getstatic net/minecraft/util/EnumFacing.UP Lnet/minecraft/util/EnumFacing;
      // 2e4: astore 34
      // 2e6: new net/minecraft/util/math/Vec3d
      // 2e9: dup
      // 2ea: aload 1
      // 2eb: getfield net/minecraft/util/math/Vec3d.field_72450_a D
      // 2ee: dload 28
      // 2f0: dload 24
      // 2f2: dmul
      // 2f3: dadd
      // 2f4: dload 18
      // 2f6: aload 1
      // 2f7: getfield net/minecraft/util/math/Vec3d.field_72449_c D
      // 2fa: dload 32
      // 2fc: dload 24
      // 2fe: dmul
      // 2ff: dadd
      // 300: invokespecial net/minecraft/util/math/Vec3d.<init> (DDD)V
      // 303: astore 1
      // 304: goto 33b
      // 307: iload 6
      // 309: iload 9
      // 30b: if_icmple 318
      // 30e: getstatic net/minecraft/util/EnumFacing.NORTH Lnet/minecraft/util/EnumFacing;
      // 311: goto 31b
      // 314: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 317: athrow
      // 318: getstatic net/minecraft/util/EnumFacing.SOUTH Lnet/minecraft/util/EnumFacing;
      // 31b: astore 34
      // 31d: new net/minecraft/util/math/Vec3d
      // 320: dup
      // 321: aload 1
      // 322: getfield net/minecraft/util/math/Vec3d.field_72450_a D
      // 325: dload 28
      // 327: dload 26
      // 329: dmul
      // 32a: dadd
      // 32b: aload 1
      // 32c: getfield net/minecraft/util/math/Vec3d.field_72448_b D
      // 32f: dload 30
      // 331: dload 26
      // 333: dmul
      // 334: dadd
      // 335: dload 20
      // 337: invokespecial net/minecraft/util/math/Vec3d.<init> (DDD)V
      // 33a: astore 1
      // 33b: aload 1
      // 33c: getfield net/minecraft/util/math/Vec3d.field_72450_a D
      // 33f: invokestatic net/minecraft/util/math/MathHelper.func_76128_c (D)I
      // 342: aload 34
      // 344: getstatic net/minecraft/util/EnumFacing.EAST Lnet/minecraft/util/EnumFacing;
      // 347: if_acmpne 352
      // 34a: bipush 1
      // 34b: goto 353
      // 34e: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 351: athrow
      // 352: bipush 0
      // 353: isub
      // 354: istore 7
      // 356: aload 1
      // 357: getfield net/minecraft/util/math/Vec3d.field_72448_b D
      // 35a: invokestatic net/minecraft/util/math/MathHelper.func_76128_c (D)I
      // 35d: aload 34
      // 35f: getstatic net/minecraft/util/EnumFacing.UP Lnet/minecraft/util/EnumFacing;
      // 362: if_acmpne 36d
      // 365: bipush 1
      // 366: goto 36e
      // 369: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 36c: athrow
      // 36d: bipush 0
      // 36e: isub
      // 36f: istore 8
      // 371: aload 1
      // 372: getfield net/minecraft/util/math/Vec3d.field_72449_c D
      // 375: invokestatic net/minecraft/util/math/MathHelper.func_76128_c (D)I
      // 378: aload 34
      // 37a: getstatic net/minecraft/util/EnumFacing.SOUTH Lnet/minecraft/util/EnumFacing;
      // 37d: if_acmpne 388
      // 380: bipush 1
      // 381: goto 389
      // 384: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 387: athrow
      // 388: bipush 0
      // 389: isub
      // 38a: istore 9
      // 38c: new net/minecraft/util/math/BlockPos
      // 38f: dup
      // 390: iload 7
      // 392: iload 8
      // 394: iload 9
      // 396: invokespecial net/minecraft/util/math/BlockPos.<init> (III)V
      // 399: astore 10
      // 39b: aload 3
      // 39c: aload 10
      // 39e: invokevirtual net/minecraft/world/World.func_180495_p (Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/state/IBlockState;
      // 3a1: astore 35
      // 3a3: aload 35
      // 3a5: invokeinterface net/minecraft/block/state/IBlockState.func_185904_a ()Lnet/minecraft/block/material/Material; 1
      // 3aa: getstatic net/minecraft/block/material/Material.field_151567_E Lnet/minecraft/block/material/Material;
      // 3ad: if_acmpeq 3c7
      // 3b0: aload 35
      // 3b2: aload 3
      // 3b3: aload 10
      // 3b5: invokeinterface net/minecraft/block/state/IBlockState.func_185890_d (Lnet/minecraft/world/IBlockAccess;Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/util/math/AxisAlignedBB; 3
      // 3ba: getstatic net/minecraft/block/Block.field_185506_k Lnet/minecraft/util/math/AxisAlignedBB;
      // 3bd: if_acmpeq 3ef
      // 3c0: goto 3c7
      // 3c3: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 3c6: athrow
      // 3c7: aload 35
      // 3c9: invokeinterface net/minecraft/block/state/IBlockState.func_177230_c ()Lnet/minecraft/block/Block; 1
      // 3ce: invokevirtual net/minecraft/block/Block.func_180664_k ()Lnet/minecraft/util/BlockRenderLayer;
      // 3d1: getstatic net/minecraft/util/BlockRenderLayer.SOLID Lnet/minecraft/util/BlockRenderLayer;
      // 3d4: if_acmpne 3ef
      // 3d7: goto 3de
      // 3da: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 3dd: athrow
      // 3de: aload 35
      // 3e0: aload 3
      // 3e1: aload 10
      // 3e3: aload 1
      // 3e4: aload 2
      // 3e5: invokeinterface net/minecraft/block/state/IBlockState.func_185910_a (Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/math/Vec3d;)Lnet/minecraft/util/math/RayTraceResult; 5
      // 3ea: areturn
      // 3eb: invokestatic com/trolmastercard/velvet/d_.b (Ljava/lang/Exception;)Ljava/lang/Exception;
      // 3ee: athrow
      // 3ef: goto 0ee
      // 3f2: aconst_null
      // 3f3: areturn
      // try (0 -> 8): 9 java/lang/IllegalStateException
      // try (4 -> 15): 16 java/lang/IllegalStateException
      // try (11 -> 20): 20 java/lang/IllegalStateException
      // try (22 -> 30): 31 java/lang/IllegalStateException
      // try (26 -> 37): 38 java/lang/IllegalStateException
      // try (33 -> 42): 42 java/lang/IllegalStateException
      // try (79 -> 90): 91 java/lang/IllegalStateException
      // try (85 -> 100): 100 java/lang/IllegalStateException
      // try (104 -> 111): 112 java/lang/IllegalStateException
      // try (107 -> 118): 119 java/lang/IllegalStateException
      // try (114 -> 125): 126 java/lang/IllegalStateException
      // try (121 -> 130): 130 java/lang/IllegalStateException
      // try (132 -> 138): 139 java/lang/IllegalStateException
      // try (135 -> 144): 145 java/lang/IllegalStateException
      // try (141 -> 149): 149 java/lang/IllegalStateException
      // try (292 -> 300): 301 java/lang/IllegalStateException
      // try (296 -> 306): 307 java/lang/IllegalStateException
      // try (303 -> 311): 311 java/lang/IllegalStateException
      // try (333 -> 340): 341 java/lang/IllegalStateException
      // try (337 -> 345): 345 java/lang/IllegalStateException
      // try (367 -> 372): 372 java/lang/IllegalStateException
      // try (393 -> 401): 401 java/lang/IllegalStateException
      // try (406 -> 414): 414 java/lang/IllegalStateException
      // try (419 -> 427): 427 java/lang/IllegalStateException
      // try (443 -> 453): 454 java/lang/IllegalStateException
      // try (447 -> 461): 462 java/lang/IllegalStateException
      // try (456 -> 471): 471 java/lang/IllegalStateException
   }

   private static Exception b(Exception var0) {
      return var0;
   }
}
