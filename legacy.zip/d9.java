package org.velvet;

import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Vec3i;
import software.bernie.geckolib3.geo.render.built.GeoBone;
import software.bernie.geckolib3.geo.render.built.GeoCube;
import software.bernie.geckolib3.model.AnimatedGeoModel;

public abstract class d9 extends dm {
   protected static final Vec3i z = new Vec3i(255, 255, 255);
   static HashMap<Integer, Vec3i> A = new HashMap<>();

   public d9(RenderManager var1, AnimatedGeoModel var2) {
      super(var1, var2);
   }

   public static void e() {
      A.clear();
   }

   protected Vec3i a(GeoBone var1) {
      String var2 = var1.getName();
      int var3 = var2.hashCode() + this.j.getPersistentID().hashCode();
      Vec3i var4 = A.get(var3);

      try {
         if (var4 != null) {
            return var4;
         }
      } catch (IllegalStateException var5) {
         throw a(var5);
      }

      var4 = this.a(var2);
      A.put(var3, var4);
      return var4;
   }

   protected abstract Vec3i a(String var1);

   protected void b(GeoBone var1, int var2) {
      List var3 = var1.childBones;

      for (int var5 = 0; var5 < var3.size(); var5++) {
         GeoBone var6 = (GeoBone)var3.get(var5);
         if (var2 == var5) {
            GeoBone var4 = var6;
            var4.setHidden(false);
            return;
         }
      }
   }

   protected float a() {
      return 1.0F;
   }

   protected Vec3d a(ItemStack var1) {
      return new Vec3d(-90.0, 0.0, 0.0);
   }

   protected GeoBone a(GeoBone var1, int var2) {
      List var3 = var1.childBones;
      GeoBone var4 = null;
      var3.sort(Comparator.comparingDouble(GeoBone::getPivotY));

      for (int var5 = 0; var5 < var3.size(); var5++) {
         GeoBone var6 = (GeoBone)var3.get(var5);
         if (var2 == var5) {
            var4 = var6;
            var4.setHidden(false);
         } else {
            var6.setHidden(true);
         }
      }

      return var4;
   }

   protected Vec3i a(Vec3i var1) {
      return var1;
   }

   @Override
   public void renderRecursively(BufferBuilder param1, GeoBone param2, float param3, float param4, float param5, float param6) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 000: aload 2
      // 001: invokevirtual software/bernie/geckolib3/geo/render/built/GeoBone.getName ()Ljava/lang/String;
      // 004: astore 7
      // 006: aload 0
      // 007: getfield com/trolmastercard/velvet/d9.r Z
      // 00a: ifeq 078
      // 00d: aload 7
      // 00f: ldc "upperBody"
      // 011: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 014: ifeq 030
      // 017: goto 01e
      // 01a: invokestatic com/trolmastercard/velvet/d9.a (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 01d: athrow
      // 01e: aload 2
      // 01f: aload 2
      // 020: invokevirtual software/bernie/geckolib3/geo/render/built/GeoBone.getRotationX ()F
      // 023: ldc 0.5
      // 025: fsub
      // 026: invokevirtual software/bernie/geckolib3/geo/render/built/GeoBone.setRotationX (F)V
      // 029: goto 030
      // 02c: invokestatic com/trolmastercard/velvet/d9.a (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 02f: athrow
      // 030: aload 7
      // 032: ldc "head"
      // 034: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 037: ifeq 04c
      // 03a: aload 2
      // 03b: aload 2
      // 03c: invokevirtual software/bernie/geckolib3/geo/render/built/GeoBone.getRotationX ()F
      // 03f: ldc 0.5
      // 041: fadd
      // 042: invokevirtual software/bernie/geckolib3/geo/render/built/GeoBone.setRotationX (F)V
      // 045: goto 04c
      // 048: invokestatic com/trolmastercard/velvet/d9.a (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 04b: athrow
      // 04c: aload 7
      // 04e: ldc "legL"
      // 050: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 053: ifne 067
      // 056: aload 7
      // 058: ldc "legR"
      // 05a: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 05d: ifeq 078
      // 060: goto 067
      // 063: invokestatic com/trolmastercard/velvet/d9.a (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 066: athrow
      // 067: aload 2
      // 068: aload 2
      // 069: invokevirtual software/bernie/geckolib3/geo/render/built/GeoBone.getPositionZ ()F
      // 06c: fconst_1
      // 06d: fadd
      // 06e: invokevirtual software/bernie/geckolib3/geo/render/built/GeoBone.setPositionZ (F)V
      // 071: goto 078
      // 074: invokestatic com/trolmastercard/velvet/d9.a (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 077: athrow
      // 078: aload 7
      // 07a: ldc "head"
      // 07c: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 07f: ifeq 097
      // 082: aload 0
      // 083: aload 1
      // 084: aload 2
      // 085: fload 3
      // 086: fload 4
      // 088: fload 5
      // 08a: invokestatic software/bernie/geckolib3/core/util/Color.ofRGB (FFF)Lsoftware/bernie/geckolib3/core/util/Color;
      // 08d: invokevirtual com/trolmastercard/velvet/d9.a (Lnet/minecraft/client/renderer/BufferBuilder;Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;Lsoftware/bernie/geckolib3/core/util/Color;)V
      // 090: goto 097
      // 093: invokestatic com/trolmastercard/velvet/d9.a (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 096: athrow
      // 097: aload 0
      // 098: aload 7
      // 09a: aload 2
      // 09b: invokevirtual com/trolmastercard/velvet/d9.a (Ljava/lang/String;Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;)V
      // 09e: aload 0
      // 09f: aload 7
      // 0a1: aload 2
      // 0a2: aload 0
      // 0a3: getfield com/trolmastercard/velvet/d9.w Lcom/trolmastercard/velvet/ei;
      // 0a6: aload 1
      // 0a7: invokevirtual com/trolmastercard/velvet/d9.a (Ljava/lang/String;Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;Lcom/trolmastercard/velvet/ei;Lnet/minecraft/client/renderer/BufferBuilder;)V
      // 0aa: aload 0
      // 0ab: getfield com/trolmastercard/velvet/d9.u Z
      // 0ae: ifeq 149
      // 0b1: aload 0
      // 0b2: getfield com/trolmastercard/velvet/d9.s Lnet/minecraft/item/ItemStack;
      // 0b5: invokevirtual net/minecraft/item/ItemStack.func_77973_b ()Lnet/minecraft/item/Item;
      // 0b8: instanceof net/minecraft/item/ItemBow
      // 0bb: ifne 0d9
      // 0be: goto 0c5
      // 0c1: invokestatic com/trolmastercard/velvet/d9.a (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 0c4: athrow
      // 0c5: aload 0
      // 0c6: getfield com/trolmastercard/velvet/d9.x Lnet/minecraft/item/ItemStack;
      // 0c9: invokevirtual net/minecraft/item/ItemStack.func_77973_b ()Lnet/minecraft/item/Item;
      // 0cc: instanceof net/minecraft/item/ItemBow
      // 0cf: ifeq 149
      // 0d2: goto 0d9
      // 0d5: invokestatic com/trolmastercard/velvet/d9.a (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 0d8: athrow
      // 0d9: aload 7
      // 0db: ldc "armR"
      // 0dd: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 0e0: ifeq 104
      // 0e3: goto 0ea
      // 0e6: invokestatic com/trolmastercard/velvet/d9.a (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 0e9: athrow
      // 0ea: aload 2
      // 0eb: aload 2
      // 0ec: invokevirtual software/bernie/geckolib3/geo/render/built/GeoBone.getRotationX ()F
      // 0ef: aload 0
      // 0f0: getfield com/trolmastercard/velvet/d9.j Lcom/trolmastercard/velvet/em;
      // 0f3: getfield com/trolmastercard/velvet/em.field_70125_A F
      // 0f6: ldc 50.0
      // 0f8: fdiv
      // 0f9: fsub
      // 0fa: invokevirtual software/bernie/geckolib3/geo/render/built/GeoBone.setRotationX (F)V
      // 0fd: goto 104
      // 100: invokestatic com/trolmastercard/velvet/d9.a (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 103: athrow
      // 104: aload 7
      // 106: ldc "armL"
      // 108: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 10b: ifeq 128
      // 10e: aload 2
      // 10f: aload 2
      // 110: invokevirtual software/bernie/geckolib3/geo/render/built/GeoBone.getRotationY ()F
      // 113: aload 0
      // 114: getfield com/trolmastercard/velvet/d9.j Lcom/trolmastercard/velvet/em;
      // 117: getfield com/trolmastercard/velvet/em.field_70125_A F
      // 11a: ldc 50.0
      // 11c: fdiv
      // 11d: fsub
      // 11e: invokevirtual software/bernie/geckolib3/geo/render/built/GeoBone.setRotationY (F)V
      // 121: goto 128
      // 124: invokestatic com/trolmastercard/velvet/d9.a (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 127: athrow
      // 128: aload 0
      // 129: getfield com/trolmastercard/velvet/d9.x Lnet/minecraft/item/ItemStack;
      // 12c: invokevirtual net/minecraft/item/ItemStack.func_77973_b ()Lnet/minecraft/item/Item;
      // 12f: instanceof net/minecraft/item/ItemBow
      // 132: ifeq 149
      // 135: aload 0
      // 136: getfield com/trolmastercard/velvet/d9.x Lnet/minecraft/item/ItemStack;
      // 139: astore 8
      // 13b: aload 0
      // 13c: aload 0
      // 13d: getfield com/trolmastercard/velvet/d9.s Lnet/minecraft/item/ItemStack;
      // 140: putfield com/trolmastercard/velvet/d9.x Lnet/minecraft/item/ItemStack;
      // 143: aload 0
      // 144: aload 8
      // 146: putfield com/trolmastercard/velvet/d9.s Lnet/minecraft/item/ItemStack;
      // 149: aload 0
      // 14a: getfield com/trolmastercard/velvet/d9.u Z
      // 14d: ifeq 1b7
      // 150: aload 0
      // 151: getfield com/trolmastercard/velvet/d9.s Lnet/minecraft/item/ItemStack;
      // 154: invokevirtual net/minecraft/item/ItemStack.func_77973_b ()Lnet/minecraft/item/Item;
      // 157: instanceof net/minecraft/item/ItemShield
      // 15a: ifeq 1b7
      // 15d: goto 164
      // 160: invokestatic com/trolmastercard/velvet/d9.a (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 163: athrow
      // 164: aload 7
      // 166: ldc "armR"
      // 168: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 16b: ifeq 187
      // 16e: goto 175
      // 171: invokestatic com/trolmastercard/velvet/d9.a (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 174: athrow
      // 175: aload 2
      // 176: fconst_0
      // 177: invokevirtual software/bernie/geckolib3/geo/render/built/GeoBone.setRotationZ (F)V
      // 17a: aload 2
      // 17b: ldc 0.5
      // 17d: invokevirtual software/bernie/geckolib3/geo/render/built/GeoBone.setRotationX (F)V
      // 180: goto 1b7
      // 183: invokestatic com/trolmastercard/velvet/d9.a (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 186: athrow
      // 187: aload 0
      // 188: getfield com/trolmastercard/velvet/d9.x Lnet/minecraft/item/ItemStack;
      // 18b: invokevirtual net/minecraft/item/ItemStack.func_77973_b ()Lnet/minecraft/item/Item;
      // 18e: instanceof net/minecraft/item/ItemShield
      // 191: ifeq 1b7
      // 194: aload 7
      // 196: ldc "armL"
      // 198: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 19b: ifeq 1b7
      // 19e: goto 1a5
      // 1a1: invokestatic com/trolmastercard/velvet/d9.a (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 1a4: athrow
      // 1a5: aload 2
      // 1a6: fconst_0
      // 1a7: invokevirtual software/bernie/geckolib3/geo/render/built/GeoBone.setRotationZ (F)V
      // 1aa: aload 2
      // 1ab: ldc 0.5
      // 1ad: invokevirtual software/bernie/geckolib3/geo/render/built/GeoBone.setRotationX (F)V
      // 1b0: goto 1b7
      // 1b3: invokestatic com/trolmastercard/velvet/d9.a (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 1b6: athrow
      // 1b7: aload 7
      // 1b9: ldc "weapon"
      // 1bb: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 1be: ifeq 1e0
      // 1c1: aload 0
      // 1c2: getfield com/trolmastercard/velvet/d9.s Lnet/minecraft/item/ItemStack;
      // 1c5: invokevirtual net/minecraft/item/ItemStack.func_190926_b ()Z
      // 1c8: ifne 1e0
      // 1cb: goto 1d2
      // 1ce: invokestatic com/trolmastercard/velvet/d9.a (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 1d1: athrow
      // 1d2: aload 0
      // 1d3: aload 1
      // 1d4: aload 2
      // 1d5: bipush 0
      // 1d6: invokevirtual com/trolmastercard/velvet/d9.a (Lnet/minecraft/client/renderer/BufferBuilder;Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;Z)V
      // 1d9: goto 1e0
      // 1dc: invokestatic com/trolmastercard/velvet/d9.a (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 1df: athrow
      // 1e0: aload 7
      // 1e2: ldc "offhand"
      // 1e4: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 1e7: ifeq 209
      // 1ea: aload 0
      // 1eb: getfield com/trolmastercard/velvet/d9.x Lnet/minecraft/item/ItemStack;
      // 1ee: invokevirtual net/minecraft/item/ItemStack.func_190926_b ()Z
      // 1f1: ifne 209
      // 1f4: goto 1fb
      // 1f7: invokestatic com/trolmastercard/velvet/d9.a (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 1fa: athrow
      // 1fb: aload 0
      // 1fc: aload 1
      // 1fd: aload 2
      // 1fe: bipush 1
      // 1ff: invokevirtual com/trolmastercard/velvet/d9.a (Lnet/minecraft/client/renderer/BufferBuilder;Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;Z)V
      // 202: goto 209
      // 205: invokestatic com/trolmastercard/velvet/d9.a (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 208: athrow
      // 209: getstatic com/trolmastercard/velvet/d9.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 20c: invokevirtual software/bernie/geckolib3/util/MatrixStack.push ()V
      // 20f: getstatic com/trolmastercard/velvet/d9.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 212: aload 2
      // 213: invokevirtual software/bernie/geckolib3/util/MatrixStack.translate (Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;)V
      // 216: getstatic com/trolmastercard/velvet/d9.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 219: aload 2
      // 21a: invokevirtual software/bernie/geckolib3/util/MatrixStack.moveToPivot (Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;)V
      // 21d: getstatic com/trolmastercard/velvet/d9.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 220: aload 2
      // 221: invokevirtual software/bernie/geckolib3/util/MatrixStack.rotate (Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;)V
      // 224: getstatic com/trolmastercard/velvet/d9.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 227: aload 2
      // 228: invokevirtual software/bernie/geckolib3/util/MatrixStack.scale (Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;)V
      // 22b: getstatic com/trolmastercard/velvet/d9.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 22e: aload 2
      // 22f: invokevirtual software/bernie/geckolib3/util/MatrixStack.moveBackFromPivot (Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;)V
      // 232: ldc_w "Head2"
      // 235: aload 7
      // 237: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 23a: ifeq 256
      // 23d: aload 0
      // 23e: invokevirtual com/trolmastercard/velvet/d9.c ()Z
      // 241: ifne 256
      // 244: goto 24b
      // 247: invokestatic com/trolmastercard/velvet/d9.a (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 24a: athrow
      // 24b: getstatic com/trolmastercard/velvet/d9.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 24e: invokevirtual software/bernie/geckolib3/util/MatrixStack.pop ()V
      // 251: return
      // 252: invokestatic com/trolmastercard/velvet/d9.a (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 255: athrow
      // 256: ldc_w "neck"
      // 259: aload 7
      // 25b: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 25e: ifne 272
      // 261: ldc "head"
      // 263: aload 7
      // 265: invokevirtual java/lang/String.equals (Ljava/lang/Object;)Z
      // 268: ifeq 28b
      // 26b: goto 272
      // 26e: invokestatic com/trolmastercard/velvet/d9.a (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 271: athrow
      // 272: aload 0
      // 273: invokevirtual com/trolmastercard/velvet/d9.a ()Z
      // 276: ifne 28b
      // 279: goto 280
      // 27c: invokestatic com/trolmastercard/velvet/d9.a (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 27f: athrow
      // 280: getstatic com/trolmastercard/velvet/d9.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 283: invokevirtual software/bernie/geckolib3/util/MatrixStack.pop ()V
      // 286: return
      // 287: invokestatic com/trolmastercard/velvet/d9.a (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 28a: athrow
      // 28b: aload 2
      // 28c: getfield software/bernie/geckolib3/geo/render/built/GeoBone.isHidden Z
      // 28f: ifne 363
      // 292: aload 0
      // 293: aload 7
      // 295: fload 3
      // 296: fload 4
      // 298: fload 5
      // 29a: invokevirtual com/trolmastercard/velvet/d9.a (Ljava/lang/String;FFF)Ljavax/vecmath/Vector4f;
      // 29d: astore 8
      // 29f: aload 8
      // 2a1: getfield javax/vecmath/Vector4f.x F
      // 2a4: fstore 3
      // 2a5: aload 8
      // 2a7: getfield javax/vecmath/Vector4f.y F
      // 2aa: fstore 4
      // 2ac: aload 8
      // 2ae: getfield javax/vecmath/Vector4f.z F
      // 2b1: fstore 5
      // 2b3: aload 8
      // 2b5: getfield javax/vecmath/Vector4f.w F
      // 2b8: f2d
      // 2b9: dstore 9
      // 2bb: aload 0
      // 2bc: getfield com/trolmastercard/velvet/d9.p Ljava/util/HashSet;
      // 2bf: aload 7
      // 2c1: invokevirtual java/util/HashSet.contains (Ljava/lang/Object;)Z
      // 2c4: ifne 313
      // 2c7: aload 2
      // 2c8: getfield software/bernie/geckolib3/geo/render/built/GeoBone.childCubes Ljava/util/List;
      // 2cb: invokeinterface java/util/List.iterator ()Ljava/util/Iterator; 1
      // 2d0: astore 11
      // 2d2: aload 11
      // 2d4: invokeinterface java/util/Iterator.hasNext ()Z 1
      // 2d9: ifeq 313
      // 2dc: aload 11
      // 2de: invokeinterface java/util/Iterator.next ()Ljava/lang/Object; 1
      // 2e3: checkcast software/bernie/geckolib3/geo/render/built/GeoCube
      // 2e6: astore 12
      // 2e8: getstatic com/trolmastercard/velvet/d9.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 2eb: invokevirtual software/bernie/geckolib3/util/MatrixStack.push ()V
      // 2ee: invokestatic net/minecraft/client/renderer/GlStateManager.func_179094_E ()V
      // 2f1: aload 0
      // 2f2: aload 2
      // 2f3: putfield com/trolmastercard/velvet/d9.q Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;
      // 2f6: aload 0
      // 2f7: aload 1
      // 2f8: aload 12
      // 2fa: aload 2
      // 2fb: fload 3
      // 2fc: fload 4
      // 2fe: fload 5
      // 300: fload 6
      // 302: dload 9
      // 304: invokevirtual com/trolmastercard/velvet/d9.a (Lnet/minecraft/client/renderer/BufferBuilder;Lsoftware/bernie/geckolib3/geo/render/built/GeoCube;Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;FFFFD)V
      // 307: invokestatic net/minecraft/client/renderer/GlStateManager.func_179121_F ()V
      // 30a: getstatic com/trolmastercard/velvet/d9.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 30d: invokevirtual software/bernie/geckolib3/util/MatrixStack.pop ()V
      // 310: goto 2d2
      // 313: aload 2
      // 314: getfield software/bernie/geckolib3/geo/render/built/GeoBone.childBones Ljava/util/List;
      // 317: invokeinterface java/util/List.iterator ()Ljava/util/Iterator; 1
      // 31c: astore 11
      // 31e: aload 11
      // 320: invokeinterface java/util/Iterator.hasNext ()Z 1
      // 325: ifeq 363
      // 328: aload 11
      // 32a: invokeinterface java/util/Iterator.next ()Ljava/lang/Object; 1
      // 32f: checkcast software/bernie/geckolib3/geo/render/built/GeoBone
      // 332: astore 12
      // 334: dload 9
      // 336: dconst_0
      // 337: dcmpl
      // 338: ifne 350
      // 33b: aload 0
      // 33c: aload 1
      // 33d: aload 12
      // 33f: fload 3
      // 340: fload 4
      // 342: fload 5
      // 344: fload 6
      // 346: invokevirtual com/trolmastercard/velvet/d9.renderRecursively (Lnet/minecraft/client/renderer/BufferBuilder;Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;FFFF)V
      // 349: goto 360
      // 34c: invokestatic com/trolmastercard/velvet/d9.a (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 34f: athrow
      // 350: aload 0
      // 351: aload 1
      // 352: aload 12
      // 354: fload 3
      // 355: fload 4
      // 357: fload 5
      // 359: fload 6
      // 35b: dload 9
      // 35d: invokevirtual com/trolmastercard/velvet/d9.a (Lnet/minecraft/client/renderer/BufferBuilder;Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;FFFFD)V
      // 360: goto 31e
      // 363: getstatic com/trolmastercard/velvet/d9.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 366: invokevirtual software/bernie/geckolib3/util/MatrixStack.pop ()V
      // 369: goto 36e
      // 36c: astore 8
      // 36e: return
      // try (362 -> 375): 375 java/lang/IllegalStateException
      // try (281 -> 290): 290 java/lang/IllegalStateException
      // try (274 -> 284): 285 java/lang/IllegalStateException
      // try (270 -> 278): 279 java/lang/IllegalStateException
      // try (259 -> 268): 268 java/lang/IllegalStateException
      // try (238 -> 262): 263 java/lang/IllegalStateException
      // try (223 -> 235): 236 java/lang/IllegalStateException
      // try (219 -> 227): 228 java/lang/IllegalStateException
      // try (204 -> 216): 217 java/lang/IllegalStateException
      // try (200 -> 208): 209 java/lang/IllegalStateException
      // try (184 -> 197): 198 java/lang/IllegalStateException
      // try (179 -> 188): 189 java/lang/IllegalStateException
      // try (163 -> 177): 177 java/lang/IllegalStateException
      // try (155 -> 167): 168 java/lang/IllegalStateException
      // try (152 -> 160): 161 java/lang/IllegalStateException
      // try (120 -> 134): 135 java/lang/IllegalStateException
      // try (100 -> 117): 118 java/lang/IllegalStateException
      // try (92 -> 104): 105 java/lang/IllegalStateException
      // try (84 -> 97): 98 java/lang/IllegalStateException
      // try (70 -> 89): 90 java/lang/IllegalStateException
      // try (55 -> 67): 68 java/lang/IllegalStateException
      // try (39 -> 52): 53 java/lang/IllegalStateException
      // try (35 -> 43): 44 java/lang/IllegalStateException
      // try (22 -> 32): 33 java/lang/IllegalStateException
      // try (6 -> 19): 20 java/lang/IllegalStateException
      // try (3 -> 10): 11 java/lang/IllegalStateException
      // try (387 -> 389): 390 java/lang/IllegalStateException
   }

   public void a(BufferBuilder param1, GeoCube param2, GeoBone param3, float param4, float param5, float param6, float param7, double param8) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 000: getstatic com/trolmastercard/velvet/d9.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 003: aload 2
      // 004: invokevirtual software/bernie/geckolib3/util/MatrixStack.moveToPivot (Lsoftware/bernie/geckolib3/geo/render/built/GeoCube;)V
      // 007: getstatic com/trolmastercard/velvet/d9.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 00a: aload 2
      // 00b: invokevirtual software/bernie/geckolib3/util/MatrixStack.rotate (Lsoftware/bernie/geckolib3/geo/render/built/GeoCube;)V
      // 00e: getstatic com/trolmastercard/velvet/d9.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 011: aload 2
      // 012: invokevirtual software/bernie/geckolib3/util/MatrixStack.moveBackFromPivot (Lsoftware/bernie/geckolib3/geo/render/built/GeoCube;)V
      // 015: aload 2
      // 016: getfield software/bernie/geckolib3/geo/render/built/GeoCube.quads [Lsoftware/bernie/geckolib3/geo/render/built/GeoQuad;
      // 019: astore 10
      // 01b: aload 10
      // 01d: arraylength
      // 01e: istore 11
      // 020: bipush 0
      // 021: istore 12
      // 023: iload 12
      // 025: iload 11
      // 027: if_icmpge 242
      // 02a: aload 10
      // 02c: iload 12
      // 02e: aaload
      // 02f: astore 13
      // 031: aload 13
      // 033: ifnonnull 03d
      // 036: goto 23c
      // 039: invokestatic com/trolmastercard/velvet/d9.a (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 03c: athrow
      // 03d: new javax/vecmath/Vector3f
      // 040: dup
      // 041: aload 13
      // 043: getfield software/bernie/geckolib3/geo/render/built/GeoQuad.normal Lnet/minecraft/util/math/Vec3i;
      // 046: invokevirtual net/minecraft/util/math/Vec3i.func_177958_n ()I
      // 049: i2f
      // 04a: aload 13
      // 04c: getfield software/bernie/geckolib3/geo/render/built/GeoQuad.normal Lnet/minecraft/util/math/Vec3i;
      // 04f: invokevirtual net/minecraft/util/math/Vec3i.func_177956_o ()I
      // 052: i2f
      // 053: aload 13
      // 055: getfield software/bernie/geckolib3/geo/render/built/GeoQuad.normal Lnet/minecraft/util/math/Vec3i;
      // 058: invokevirtual net/minecraft/util/math/Vec3i.func_177952_p ()I
      // 05b: i2f
      // 05c: invokespecial javax/vecmath/Vector3f.<init> (FFF)V
      // 05f: astore 14
      // 061: getstatic com/trolmastercard/velvet/d9.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 064: invokevirtual software/bernie/geckolib3/util/MatrixStack.getNormalMatrix ()Ljavax/vecmath/Matrix3f;
      // 067: aload 14
      // 069: invokevirtual javax/vecmath/Matrix3f.transform (Ljavax/vecmath/Tuple3f;)V
      // 06c: aload 2
      // 06d: getfield software/bernie/geckolib3/geo/render/built/GeoCube.size Ljavax/vecmath/Vector3f;
      // 070: getfield javax/vecmath/Vector3f.y F
      // 073: fconst_0
      // 074: fcmpl
      // 075: ifeq 08b
      // 078: aload 2
      // 079: getfield software/bernie/geckolib3/geo/render/built/GeoCube.size Ljavax/vecmath/Vector3f;
      // 07c: getfield javax/vecmath/Vector3f.z F
      // 07f: fconst_0
      // 080: fcmpl
      // 081: ifne 0b0
      // 084: goto 08b
      // 087: invokestatic com/trolmastercard/velvet/d9.a (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 08a: athrow
      // 08b: aload 14
      // 08d: invokevirtual javax/vecmath/Vector3f.getX ()F
      // 090: fconst_0
      // 091: fcmpg
      // 092: ifge 0b0
      // 095: goto 09c
      // 098: invokestatic com/trolmastercard/velvet/d9.a (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 09b: athrow
      // 09c: aload 14
      // 09e: dup
      // 09f: getfield javax/vecmath/Vector3f.x F
      // 0a2: ldc_w -1.0
      // 0a5: fmul
      // 0a6: putfield javax/vecmath/Vector3f.x F
      // 0a9: goto 0b0
      // 0ac: invokestatic com/trolmastercard/velvet/d9.a (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 0af: athrow
      // 0b0: aload 2
      // 0b1: getfield software/bernie/geckolib3/geo/render/built/GeoCube.size Ljavax/vecmath/Vector3f;
      // 0b4: getfield javax/vecmath/Vector3f.x F
      // 0b7: fconst_0
      // 0b8: fcmpl
      // 0b9: ifeq 0cf
      // 0bc: aload 2
      // 0bd: getfield software/bernie/geckolib3/geo/render/built/GeoCube.size Ljavax/vecmath/Vector3f;
      // 0c0: getfield javax/vecmath/Vector3f.z F
      // 0c3: fconst_0
      // 0c4: fcmpl
      // 0c5: ifne 0f4
      // 0c8: goto 0cf
      // 0cb: invokestatic com/trolmastercard/velvet/d9.a (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 0ce: athrow
      // 0cf: aload 14
      // 0d1: invokevirtual javax/vecmath/Vector3f.getY ()F
      // 0d4: fconst_0
      // 0d5: fcmpg
      // 0d6: ifge 0f4
      // 0d9: goto 0e0
      // 0dc: invokestatic com/trolmastercard/velvet/d9.a (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 0df: athrow
      // 0e0: aload 14
      // 0e2: dup
      // 0e3: getfield javax/vecmath/Vector3f.y F
      // 0e6: ldc_w -1.0
      // 0e9: fmul
      // 0ea: putfield javax/vecmath/Vector3f.y F
      // 0ed: goto 0f4
      // 0f0: invokestatic com/trolmastercard/velvet/d9.a (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 0f3: athrow
      // 0f4: aload 2
      // 0f5: getfield software/bernie/geckolib3/geo/render/built/GeoCube.size Ljavax/vecmath/Vector3f;
      // 0f8: getfield javax/vecmath/Vector3f.x F
      // 0fb: fconst_0
      // 0fc: fcmpl
      // 0fd: ifeq 113
      // 100: aload 2
      // 101: getfield software/bernie/geckolib3/geo/render/built/GeoCube.size Ljavax/vecmath/Vector3f;
      // 104: getfield javax/vecmath/Vector3f.y F
      // 107: fconst_0
      // 108: fcmpl
      // 109: ifne 138
      // 10c: goto 113
      // 10f: invokestatic com/trolmastercard/velvet/d9.a (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 112: athrow
      // 113: aload 14
      // 115: invokevirtual javax/vecmath/Vector3f.getZ ()F
      // 118: fconst_0
      // 119: fcmpg
      // 11a: ifge 138
      // 11d: goto 124
      // 120: invokestatic com/trolmastercard/velvet/d9.a (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 123: athrow
      // 124: aload 14
      // 126: dup
      // 127: getfield javax/vecmath/Vector3f.z F
      // 12a: ldc_w -1.0
      // 12d: fmul
      // 12e: putfield javax/vecmath/Vector3f.z F
      // 131: goto 138
      // 134: invokestatic com/trolmastercard/velvet/d9.a (Ljava/lang/IllegalStateException;)Ljava/lang/IllegalStateException;
      // 137: athrow
      // 138: aload 0
      // 139: aload 3
      // 13a: invokevirtual software/bernie/geckolib3/geo/render/built/GeoBone.getName ()Ljava/lang/String;
      // 13d: invokevirtual com/trolmastercard/velvet/d9.c (Ljava/lang/String;)Z
      // 140: ifeq 158
      // 143: new net/minecraft/util/math/Vec3d
      // 146: dup
      // 147: fload 4
      // 149: f2d
      // 14a: fload 5
      // 14c: f2d
      // 14d: fload 6
      // 14f: f2d
      // 150: invokespecial net/minecraft/util/math/Vec3d.<init> (DDD)V
      // 153: astore 15
      // 155: goto 198
      // 158: aload 0
      // 159: aload 3
      // 15a: invokevirtual com/trolmastercard/velvet/d9.a (Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;)Lnet/minecraft/util/math/Vec3i;
      // 15d: astore 16
      // 15f: aload 0
      // 160: aload 16
      // 162: invokevirtual com/trolmastercard/velvet/d9.a (Lnet/minecraft/util/math/Vec3i;)Lnet/minecraft/util/math/Vec3i;
      // 165: astore 16
      // 167: aload 0
      // 168: aload 3
      // 169: new net/minecraft/util/math/Vec3d
      // 16c: dup
      // 16d: aload 16
      // 16f: invokevirtual net/minecraft/util/math/Vec3i.func_177958_n ()I
      // 172: i2f
      // 173: ldc_w 255.0
      // 176: fdiv
      // 177: f2d
      // 178: aload 16
      // 17a: invokevirtual net/minecraft/util/math/Vec3i.func_177956_o ()I
      // 17d: i2f
      // 17e: ldc_w 255.0
      // 181: fdiv
      // 182: f2d
      // 183: aload 16
      // 185: invokevirtual net/minecraft/util/math/Vec3i.func_177952_p ()I
      // 188: i2f
      // 189: ldc_w 255.0
      // 18c: fdiv
      // 18d: f2d
      // 18e: invokespecial net/minecraft/util/math/Vec3d.<init> (DDD)V
      // 191: aload 14
      // 193: invokestatic com/trolmastercard/velvet/gx.a (Lcom/trolmastercard/velvet/c3;Lsoftware/bernie/geckolib3/geo/render/built/GeoBone;Lnet/minecraft/util/math/Vec3d;Ljavax/vecmath/Vector3f;)Lnet/minecraft/util/math/Vec3d;
      // 196: astore 15
      // 198: aload 13
      // 19a: getfield software/bernie/geckolib3/geo/render/built/GeoQuad.vertices [Lsoftware/bernie/geckolib3/geo/render/built/GeoVertex;
      // 19d: astore 16
      // 19f: aload 16
      // 1a1: arraylength
      // 1a2: istore 17
      // 1a4: bipush 0
      // 1a5: istore 18
      // 1a7: iload 18
      // 1a9: iload 17
      // 1ab: if_icmpge 23c
      // 1ae: aload 16
      // 1b0: iload 18
      // 1b2: aaload
      // 1b3: astore 19
      // 1b5: new javax/vecmath/Vector4f
      // 1b8: dup
      // 1b9: aload 19
      // 1bb: getfield software/bernie/geckolib3/geo/render/built/GeoVertex.position Ljavax/vecmath/Vector3f;
      // 1be: invokevirtual javax/vecmath/Vector3f.getX ()F
      // 1c1: aload 19
      // 1c3: getfield software/bernie/geckolib3/geo/render/built/GeoVertex.position Ljavax/vecmath/Vector3f;
      // 1c6: invokevirtual javax/vecmath/Vector3f.getY ()F
      // 1c9: aload 19
      // 1cb: getfield software/bernie/geckolib3/geo/render/built/GeoVertex.position Ljavax/vecmath/Vector3f;
      // 1ce: invokevirtual javax/vecmath/Vector3f.getZ ()F
      // 1d1: fconst_1
      // 1d2: invokespecial javax/vecmath/Vector4f.<init> (FFFF)V
      // 1d5: astore 20
      // 1d7: getstatic com/trolmastercard/velvet/d9.MATRIX_STACK Lsoftware/bernie/geckolib3/util/MatrixStack;
      // 1da: invokevirtual software/bernie/geckolib3/util/MatrixStack.getModelMatrix ()Ljavax/vecmath/Matrix4f;
      // 1dd: aload 20
      // 1df: invokevirtual javax/vecmath/Matrix4f.transform (Ljavax/vecmath/Tuple4f;)V
      // 1e2: aload 1
      // 1e3: aload 20
      // 1e5: invokevirtual javax/vecmath/Vector4f.getX ()F
      // 1e8: f2d
      // 1e9: aload 20
      // 1eb: invokevirtual javax/vecmath/Vector4f.getY ()F
      // 1ee: f2d
      // 1ef: aload 20
      // 1f1: invokevirtual javax/vecmath/Vector4f.getZ ()F
      // 1f4: f2d
      // 1f5: invokevirtual net/minecraft/client/renderer/BufferBuilder.func_181662_b (DDD)Lnet/minecraft/client/renderer/BufferBuilder;
      // 1f8: aload 19
      // 1fa: getfield software/bernie/geckolib3/geo/render/built/GeoVertex.textureU F
      // 1fd: f2d
      // 1fe: dload 8
      // 200: dadd
      // 201: aload 19
      // 203: getfield software/bernie/geckolib3/geo/render/built/GeoVertex.textureV F
      // 206: f2d
      // 207: invokevirtual net/minecraft/client/renderer/BufferBuilder.func_187315_a (DD)Lnet/minecraft/client/renderer/BufferBuilder;
      // 20a: aload 15
      // 20c: getfield net/minecraft/util/math/Vec3d.field_72450_a D
      // 20f: d2f
      // 210: aload 15
      // 212: getfield net/minecraft/util/math/Vec3d.field_72448_b D
      // 215: d2f
      // 216: aload 15
      // 218: getfield net/minecraft/util/math/Vec3d.field_72449_c D
      // 21b: d2f
      // 21c: fload 7
      // 21e: invokevirtual net/minecraft/client/renderer/BufferBuilder.func_181666_a (FFFF)Lnet/minecraft/client/renderer/BufferBuilder;
      // 221: aload 14
      // 223: invokevirtual javax/vecmath/Vector3f.getX ()F
      // 226: aload 14
      // 228: invokevirtual javax/vecmath/Vector3f.getY ()F
      // 22b: aload 14
      // 22d: invokevirtual javax/vecmath/Vector3f.getZ ()F
      // 230: invokevirtual net/minecraft/client/renderer/BufferBuilder.func_181663_c (FFF)Lnet/minecraft/client/renderer/BufferBuilder;
      // 233: invokevirtual net/minecraft/client/renderer/BufferBuilder.func_181675_d ()V
      // 236: iinc 18 1
      // 239: goto 1a7
      // 23c: iinc 12 1
      // 23f: goto 023
      // 242: return
      // try (24 -> 27): 27 java/lang/IllegalStateException
      // try (45 -> 61): 62 java/lang/IllegalStateException
      // try (55 -> 69): 70 java/lang/IllegalStateException
      // try (64 -> 78): 79 java/lang/IllegalStateException
      // try (81 -> 93): 94 java/lang/IllegalStateException
      // try (87 -> 101): 102 java/lang/IllegalStateException
      // try (96 -> 110): 111 java/lang/IllegalStateException
      // try (113 -> 125): 126 java/lang/IllegalStateException
      // try (119 -> 133): 134 java/lang/IllegalStateException
      // try (128 -> 142): 143 java/lang/IllegalStateException
   }

   protected boolean c(String var1) {
      return var1.startsWith("armor");
   }

   private static IllegalStateException a(IllegalStateException var0) {
      return var0;
   }
}
