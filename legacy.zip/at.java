package org.velvet;

import net.minecraft.client.model.ModelRenderer;

public interface at {
   ModelRenderer a();
}
