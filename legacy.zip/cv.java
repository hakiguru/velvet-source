package org.velvet;

import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import software.bernie.geckolib3.core.IAnimatable;
import software.bernie.geckolib3.core.event.predicate.AnimationEvent;
import software.bernie.geckolib3.core.processor.AnimationProcessor;
import software.bernie.geckolib3.core.processor.IBone;

public abstract class cv<T extends em> extends cm<T> implements gs {
   public static final List<String> b = Arrays.asList(
      "braStringMidStartR",
      "braStringMidMid1R",
      "braStringMidMid2R",
      "braStringMidMid3R",
      "braStringMidEndR",
      "braStringBackR",
      "braStringRightEndR",
      "braStringRightStartR",
      "braStringRightL",
      "braStringMidMid1L",
      "braStringMidMid2L",
      "braStringMidMid3L",
      "braStringMidEndL",
      "braStringBackL",
      "braStringLeftEndL",
      "braStringLeftStartL",
      "braStringMidStartL",
      "braStringRightR"
   );
   public static final List<String> e = Arrays.asList("boyCam", "girlCam");
   public static boolean d = true;
   protected ResourceLocation[] c = this.a();
   protected Minecraft a = Minecraft.func_71410_x();

   protected cv() {
   }

   protected abstract ResourceLocation[] a();

   public abstract ResourceLocation b();

   public abstract ResourceLocation b(em var1);

   public ResourceLocation c(em var1) {
      return this.b(var1);
   }

   public ResourceLocation a(em var1) {
      try {
         if (var1.field_70170_p instanceof gj) {
            return this.c[0];
         }
      } catch (RuntimeException var2) {
         throw b(var2);
      }

      try {
         if ((Integer)var1.func_184212_Q().func_187225_a(em.D) > this.c.length) {
            System.out.println("Girl doesn't have an outfit Nr." + var1.func_184212_Q().func_187225_a(em.D) + " so im just making her nude lol");
            return this.c[0];
         }
      } catch (RuntimeException var3) {
         throw b(var3);
      }

      return this.c[var1.func_184212_Q().func_187225_a(em.D)];
   }

   public ResourceLocation g(em var1) {
      return this.b();
   }

   @Override
   public void setMolangQueries(IAnimatable var1, double var2) {
      try {
         if (Minecraft.func_71410_x().field_71441_e != null) {
            super.setMolangQueries(var1, var2);
         }
      } catch (RuntimeException var4) {
         throw b(var4);
      }
   }

   public void a(T param1, Integer param2, AnimationEvent param3) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 000: aload 0
      // 001: aload 1
      // 002: aload 2
      // 003: aload 3
      // 004: invokespecial com/trolmastercard/velvet/cm.setLivingAnimations (Lsoftware/bernie/geckolib3/core/IAnimatable;Ljava/lang/Integer;Lsoftware/bernie/geckolib3/core/event/predicate/AnimationEvent;)V
      // 007: aload 0
      // 008: invokevirtual com/trolmastercard/velvet/cv.getAnimationProcessor ()Lsoftware/bernie/geckolib3/core/processor/AnimationProcessor;
      // 00b: astore 4
      // 00d: aload 0
      // 00e: aload 1
      // 00f: aload 4
      // 011: invokevirtual com/trolmastercard/velvet/cv.a (Lcom/trolmastercard/velvet/em;Lsoftware/bernie/geckolib3/core/processor/AnimationProcessor;)V
      // 014: aload 1
      // 015: getfield com/trolmastercard/velvet/em.field_70170_p Lnet/minecraft/world/World;
      // 018: instanceof com/trolmastercard/velvet/gj
      // 01b: ifeq 023
      // 01e: return
      // 01f: invokestatic com/trolmastercard/velvet/cv.b (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 022: athrow
      // 023: aload 1
      // 024: invokevirtual com/trolmastercard/velvet/em.func_184212_Q ()Lnet/minecraft/network/datasync/EntityDataManager;
      // 027: getstatic com/trolmastercard/velvet/em.G Lnet/minecraft/network/datasync/DataParameter;
      // 02a: invokevirtual net/minecraft/network/datasync/EntityDataManager.func_187225_a (Lnet/minecraft/network/datasync/DataParameter;)Ljava/lang/Object;
      // 02d: checkcast java/lang/Boolean
      // 030: invokevirtual java/lang/Boolean.booleanValue ()Z
      // 033: ifeq 060
      // 036: aload 1
      // 037: aload 1
      // 038: invokevirtual com/trolmastercard/velvet/em.o ()Lnet/minecraft/util/math/Vec3d;
      // 03b: getfield net/minecraft/util/math/Vec3d.field_72450_a D
      // 03e: aload 1
      // 03f: invokevirtual com/trolmastercard/velvet/em.o ()Lnet/minecraft/util/math/Vec3d;
      // 042: getfield net/minecraft/util/math/Vec3d.field_72448_b D
      // 045: aload 1
      // 046: invokevirtual com/trolmastercard/velvet/em.o ()Lnet/minecraft/util/math/Vec3d;
      // 049: getfield net/minecraft/util/math/Vec3d.field_72449_c D
      // 04c: aload 1
      // 04d: invokevirtual com/trolmastercard/velvet/em.I ()Ljava/lang/Float;
      // 050: invokevirtual java/lang/Float.floatValue ()F
      // 053: fconst_0
      // 054: bipush 3
      // 055: bipush 1
      // 056: invokevirtual com/trolmastercard/velvet/em.func_180426_a (DDDFFIZ)V
      // 059: goto 060
      // 05c: invokestatic com/trolmastercard/velvet/cv.b (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 05f: athrow
      // 060: aload 1
      // 061: getfield com/trolmastercard/velvet/em.C Lsoftware/bernie/geckolib3/core/controller/AnimationController;
      // 064: ifnull 09f
      // 067: aload 1
      // 068: getfield com/trolmastercard/velvet/em.C Lsoftware/bernie/geckolib3/core/controller/AnimationController;
      // 06b: aload 1
      // 06c: getfield com/trolmastercard/velvet/em.field_70170_p Lnet/minecraft/world/World;
      // 06f: instanceof com/trolmastercard/velvet/gj
      // 072: ifne 08a
      // 075: goto 07c
      // 078: invokestatic com/trolmastercard/velvet/cv.b (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 07b: athrow
      // 07c: aload 1
      // 07d: invokevirtual com/trolmastercard/velvet/em.y ()Lcom/trolmastercard/velvet/fp;
      // 080: ifnonnull 094
      // 083: goto 08a
      // 086: invokestatic com/trolmastercard/velvet/cv.b (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 089: athrow
      // 08a: ldc2_w 5.0
      // 08d: goto 09c
      // 090: invokestatic com/trolmastercard/velvet/cv.b (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 093: athrow
      // 094: aload 1
      // 095: invokevirtual com/trolmastercard/velvet/em.y ()Lcom/trolmastercard/velvet/fp;
      // 098: getfield com/trolmastercard/velvet/fp.transitionTick I
      // 09b: i2d
      // 09c: putfield software/bernie/geckolib3/core/controller/AnimationController.transitionLengthTicks D
      // 09f: aload 0
      // 0a0: aload 1
      // 0a1: aload 4
      // 0a3: aload 3
      // 0a4: invokevirtual com/trolmastercard/velvet/cv.a (Lcom/trolmastercard/velvet/em;Lsoftware/bernie/geckolib3/core/processor/AnimationProcessor;Lsoftware/bernie/geckolib3/core/event/predicate/AnimationEvent;)V
      // 0a7: aload 1
      // 0a8: instanceof com/trolmastercard/velvet/e2
      // 0ab: ifeq 0ca
      // 0ae: aload 1
      // 0af: invokevirtual com/trolmastercard/velvet/em.h ()Z
      // 0b2: ifne 0ca
      // 0b5: goto 0bc
      // 0b8: invokestatic com/trolmastercard/velvet/cv.b (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 0bb: athrow
      // 0bc: aload 1
      // 0bd: invokevirtual com/trolmastercard/velvet/em.ah ()I
      // 0c0: ifne 0d7
      // 0c3: goto 0ca
      // 0c6: invokestatic com/trolmastercard/velvet/cv.b (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 0c9: athrow
      // 0ca: aload 0
      // 0cb: aload 4
      // 0cd: invokevirtual com/trolmastercard/velvet/cv.a (Lsoftware/bernie/geckolib3/core/processor/AnimationProcessor;)V
      // 0d0: goto 111
      // 0d3: invokestatic com/trolmastercard/velvet/cv.b (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 0d6: athrow
      // 0d7: aload 0
      // 0d8: aload 4
      // 0da: aload 1
      // 0db: getfield com/trolmastercard/velvet/em.m Lnet/minecraft/network/datasync/EntityDataManager;
      // 0de: getstatic com/trolmastercard/velvet/e2.X Lnet/minecraft/network/datasync/DataParameter;
      // 0e1: invokevirtual net/minecraft/network/datasync/EntityDataManager.func_187225_a (Lnet/minecraft/network/datasync/DataParameter;)Ljava/lang/Object;
      // 0e4: checkcast net/minecraft/item/ItemStack
      // 0e7: aload 1
      // 0e8: getfield com/trolmastercard/velvet/em.m Lnet/minecraft/network/datasync/EntityDataManager;
      // 0eb: getstatic com/trolmastercard/velvet/e2.T Lnet/minecraft/network/datasync/DataParameter;
      // 0ee: invokevirtual net/minecraft/network/datasync/EntityDataManager.func_187225_a (Lnet/minecraft/network/datasync/DataParameter;)Ljava/lang/Object;
      // 0f1: checkcast net/minecraft/item/ItemStack
      // 0f4: aload 1
      // 0f5: getfield com/trolmastercard/velvet/em.m Lnet/minecraft/network/datasync/EntityDataManager;
      // 0f8: getstatic com/trolmastercard/velvet/e2.U Lnet/minecraft/network/datasync/DataParameter;
      // 0fb: invokevirtual net/minecraft/network/datasync/EntityDataManager.func_187225_a (Lnet/minecraft/network/datasync/DataParameter;)Ljava/lang/Object;
      // 0fe: checkcast net/minecraft/item/ItemStack
      // 101: aload 1
      // 102: getfield com/trolmastercard/velvet/em.m Lnet/minecraft/network/datasync/EntityDataManager;
      // 105: getstatic com/trolmastercard/velvet/e2.W Lnet/minecraft/network/datasync/DataParameter;
      // 108: invokevirtual net/minecraft/network/datasync/EntityDataManager.func_187225_a (Lnet/minecraft/network/datasync/DataParameter;)Ljava/lang/Object;
      // 10b: checkcast net/minecraft/item/ItemStack
      // 10e: invokevirtual com/trolmastercard/velvet/cv.a (Lsoftware/bernie/geckolib3/core/processor/AnimationProcessor;Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;)V
      // 111: return
      // try (8 -> 17): 17 java/lang/RuntimeException
      // try (19 -> 43): 44 java/lang/RuntimeException
      // try (46 -> 55): 56 java/lang/RuntimeException
      // try (49 -> 61): 62 java/lang/RuntimeException
      // try (58 -> 66): 66 java/lang/RuntimeException
      // try (73 -> 84): 85 java/lang/RuntimeException
      // try (81 -> 90): 91 java/lang/RuntimeException
      // try (87 -> 97): 97 java/lang/RuntimeException
   }

   public static Vec3d d(em var0) {
      return a(new Vec3d(var0.field_70142_S, var0.field_70137_T, var0.field_70136_U), var0.func_174791_d());
   }

   public static Vec3d a(em var0, Vec3d var1) {
      return a(var1, var0.func_174791_d());
   }

   public static Vec3d a(Vec3d var0, Vec3d var1) {
      Vec3d var2 = var1.func_178788_d(var0);
      Vec3d var3 = new Vec3d(Math.abs(var2.field_72450_a), Math.abs(var2.field_72448_b), Math.abs(var2.field_72449_c));
      double var4 = var3.field_72450_a / (var3.field_72450_a + var3.field_72448_b + var3.field_72449_c);
      double var6 = var3.field_72448_b / (var3.field_72450_a + var3.field_72448_b + var3.field_72449_c);
      double var8 = var3.field_72449_c / (var3.field_72450_a + var3.field_72448_b + var3.field_72449_c);

      Vec3d var10000;
      Vec3d var10001;
      byte var10002;
      label51: {
         try {
            var10000 = new Vec3d;
            var10001 = var10000;
            if (var2.field_72450_a > 0.0) {
               var10002 = 1;
               break label51;
            }
         } catch (RuntimeException var17) {
            throw b(var17);
         }

         var10002 = -1;
      }

      var10001./* $VF: Unable to resugar constructor */<init>(
         var10002 * var4, (var2.field_72448_b > 0.0 ? 1 : -1) * var6, (var2.field_72449_c > 0.0 ? 1 : -1) * var8
      );
      Vec3d var10 = var10000;
      double var11 = var10.field_72448_b / 2.0 + 0.5;
      float var13 = (float)b6.b(-180.0, 0.0, var11);
      if (Float.isNaN(var13)) {
         var13 = -90.0F;
      }

      label43: {
         try {
            if (var11 < 0.5) {
               var18 = 0.0F;
               break label43;
            }
         } catch (RuntimeException var16) {
            throw b(var16);
         }

         var18 = (float)b6.b(0.0, 16.0, -var11);
      }

      float var14 = var18;
      if (Float.isNaN(var14)) {
         var14 = 0.0F;
      }

      float var15 = (float)(4.0 - Math.sin((Math.PI / 2) + var11 * 2.0 * Math.PI) * 4.0);
      if (Float.isNaN(var15)) {
         var15 = 8.0F;
      }

      return new Vec3d(gc.c(var13), var14, var15);
   }

   void a(AnimationProcessor<T> var1, ItemStack var2, ItemStack var3, ItemStack var4, ItemStack var5) {
      cv var10000;
      AnimationProcessor var10001;
      boolean var10002;
      label40: {
         try {
            var10000 = this;
            var10001 = var1;
            if (!var2.func_190926_b()) {
               var10002 = true;
               break label40;
            }
         } catch (RuntimeException var8) {
            throw b(var8);
         }

         var10002 = false;
      }

      label33: {
         try {
            var10000.c(var10001, var10002);
            this.b(var1, var3.func_77973_b() instanceof ItemArmor);
            var10000 = this;
            var10001 = var1;
            if (!var4.func_190926_b()) {
               var10002 = true;
               break label33;
            }
         } catch (RuntimeException var7) {
            throw b(var7);
         }

         var10002 = false;
      }

      label26: {
         try {
            var10000.d(var10001, var10002);
            var10000 = this;
            var10001 = var1;
            if (!var5.func_190926_b()) {
               var10002 = true;
               break label26;
            }
         } catch (RuntimeException var6) {
            throw b(var6);
         }

         var10002 = false;
      }

      var10000.a(var10001, var10002);
   }

   protected void a(AnimationProcessor<T> var1) {
      this.c(var1, false);
      this.b(var1, false);
      this.d(var1, false);
      this.a(var1, false);
   }

   void c(AnimationProcessor var1, boolean var2) {
      cv var10000;
      String[] var10001;
      boolean var10002;
      label16: {
         try {
            this.a(this.c(), var2, var1);
            var10000 = this;
            var10001 = this.g();
            if (!var2) {
               var10002 = true;
               break label16;
            }
         } catch (RuntimeException var3) {
            throw b(var3);
         }

         var10002 = false;
      }

      var10000.a(var10001, var10002, var1);
   }

   void b(AnimationProcessor<T> var1, boolean var2) {
      cv var10000;
      String[] var10001;
      boolean var10002;
      label16: {
         try {
            this.a(this.f(), var2, var1);
            var10000 = this;
            var10001 = this.a();
            if (!var2) {
               var10002 = true;
               break label16;
            }
         } catch (RuntimeException var3) {
            throw b(var3);
         }

         var10002 = false;
      }

      var10000.a(var10001, var10002, var1);
   }

   void d(AnimationProcessor<T> var1, boolean var2) {
      cv var10000;
      String[] var10001;
      boolean var10002;
      label16: {
         try {
            this.a(this.h(), var2, var1);
            var10000 = this;
            var10001 = this.e();
            if (!var2) {
               var10002 = true;
               break label16;
            }
         } catch (RuntimeException var3) {
            throw b(var3);
         }

         var10002 = false;
      }

      var10000.a(var10001, var10002, var1);
   }

   void a(AnimationProcessor<T> var1, boolean var2) {
      cv var10000;
      String[] var10001;
      boolean var10002;
      label16: {
         try {
            this.a(this.b(), var2, var1);
            var10000 = this;
            var10001 = this.d();
            if (!var2) {
               var10002 = true;
               break label16;
            }
         } catch (RuntimeException var3) {
            throw b(var3);
         }

         var10002 = false;
      }

      var10000.a(var10001, var10002, var1);
   }

   void a(String[] var1, boolean var2, AnimationProcessor<T> var3) {
      for (String var7 : var1) {
         this.a(var7, var2, var3);
      }
   }

   void a(String var1, boolean var2, AnimationProcessor<T> var3) {
      try {
         if (var3.getBone(var1) == null) {
            return;
         }
      } catch (RuntimeException var4) {
         throw b(var4);
      }

      IBone var10000;
      boolean var10001;
      label22: {
         try {
            var10000 = var3.getBone(var1);
            if (!var2) {
               var10001 = true;
               break label22;
            }
         } catch (RuntimeException var5) {
            throw b(var5);
         }

         var10001 = false;
      }

      var10000.setHidden(var10001);
   }

   protected boolean f(T var1) {
      UUID var2 = var1.ae();

      try {
         if (var2 == null) {
            return true;
         }
      } catch (RuntimeException var6) {
         throw b(var6);
      }

      World var3 = var1.field_70170_p;
      AbstractClientPlayer var4 = (AbstractClientPlayer)var3.func_152378_a(var2);

      try {
         if (var4 == null) {
            return true;
         }
      } catch (RuntimeException var5) {
         throw b(var5);
      }

      return "default".equals(var4.func_175154_l());
   }

   void a(T param1, AnimationProcessor<T> param2) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 00: aload 0
      // 01: aload 1
      // 02: invokevirtual com/trolmastercard/velvet/cv.f (Lcom/trolmastercard/velvet/em;)Z
      // 05: istore 3
      // 06: aload 2
      // 07: ldc_w "rightArmAlex"
      // 0a: invokevirtual software/bernie/geckolib3/core/processor/AnimationProcessor.getBone (Ljava/lang/String;)Lsoftware/bernie/geckolib3/core/processor/IBone;
      // 0d: iload 3
      // 0e: invokeinterface software/bernie/geckolib3/core/processor/IBone.setHidden (Z)V 2
      // 13: aload 2
      // 14: ldc_w "rightLowerArmAlex"
      // 17: invokevirtual software/bernie/geckolib3/core/processor/AnimationProcessor.getBone (Ljava/lang/String;)Lsoftware/bernie/geckolib3/core/processor/IBone;
      // 1a: iload 3
      // 1b: invokeinterface software/bernie/geckolib3/core/processor/IBone.setHidden (Z)V 2
      // 20: aload 2
      // 21: ldc_w "rightArmSteve"
      // 24: invokevirtual software/bernie/geckolib3/core/processor/AnimationProcessor.getBone (Ljava/lang/String;)Lsoftware/bernie/geckolib3/core/processor/IBone;
      // 27: iload 3
      // 28: ifne 33
      // 2b: bipush 1
      // 2c: goto 34
      // 2f: invokestatic com/trolmastercard/velvet/cv.b (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 32: athrow
      // 33: bipush 0
      // 34: invokeinterface software/bernie/geckolib3/core/processor/IBone.setHidden (Z)V 2
      // 39: aload 2
      // 3a: ldc_w "rightLowerArmSteve"
      // 3d: invokevirtual software/bernie/geckolib3/core/processor/AnimationProcessor.getBone (Ljava/lang/String;)Lsoftware/bernie/geckolib3/core/processor/IBone;
      // 40: iload 3
      // 41: ifne 4c
      // 44: bipush 1
      // 45: goto 4d
      // 48: invokestatic com/trolmastercard/velvet/cv.b (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 4b: athrow
      // 4c: bipush 0
      // 4d: invokeinterface software/bernie/geckolib3/core/processor/IBone.setHidden (Z)V 2
      // 52: aload 2
      // 53: ldc_w "leftArmAlex"
      // 56: invokevirtual software/bernie/geckolib3/core/processor/AnimationProcessor.getBone (Ljava/lang/String;)Lsoftware/bernie/geckolib3/core/processor/IBone;
      // 59: iload 3
      // 5a: invokeinterface software/bernie/geckolib3/core/processor/IBone.setHidden (Z)V 2
      // 5f: aload 2
      // 60: ldc_w "leftLowerArmAlex"
      // 63: invokevirtual software/bernie/geckolib3/core/processor/AnimationProcessor.getBone (Ljava/lang/String;)Lsoftware/bernie/geckolib3/core/processor/IBone;
      // 66: iload 3
      // 67: invokeinterface software/bernie/geckolib3/core/processor/IBone.setHidden (Z)V 2
      // 6c: aload 2
      // 6d: ldc_w "leftArmSteve"
      // 70: invokevirtual software/bernie/geckolib3/core/processor/AnimationProcessor.getBone (Ljava/lang/String;)Lsoftware/bernie/geckolib3/core/processor/IBone;
      // 73: iload 3
      // 74: ifne 7f
      // 77: bipush 1
      // 78: goto 80
      // 7b: invokestatic com/trolmastercard/velvet/cv.b (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 7e: athrow
      // 7f: bipush 0
      // 80: invokeinterface software/bernie/geckolib3/core/processor/IBone.setHidden (Z)V 2
      // 85: aload 2
      // 86: ldc_w "leftLowerArmSteve"
      // 89: invokevirtual software/bernie/geckolib3/core/processor/AnimationProcessor.getBone (Ljava/lang/String;)Lsoftware/bernie/geckolib3/core/processor/IBone;
      // 8c: iload 3
      // 8d: ifne 98
      // 90: bipush 1
      // 91: goto 99
      // 94: invokestatic com/trolmastercard/velvet/cv.b (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 97: athrow
      // 98: bipush 0
      // 99: invokeinterface software/bernie/geckolib3/core/processor/IBone.setHidden (Z)V 2
      // 9e: aload 2
      // 9f: ldc_w "steve"
      // a2: invokevirtual software/bernie/geckolib3/core/processor/AnimationProcessor.getBone (Ljava/lang/String;)Lsoftware/bernie/geckolib3/core/processor/IBone;
      // a5: astore 4
      // a7: aload 4
      // a9: ifnull cd
      // ac: aload 4
      // ae: aload 1
      // af: invokevirtual com/trolmastercard/velvet/em.y ()Lcom/trolmastercard/velvet/fp;
      // b2: getfield com/trolmastercard/velvet/fp.hasPlayer Z
      // b5: ifne c7
      // b8: goto bf
      // bb: invokestatic com/trolmastercard/velvet/cv.b (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // be: athrow
      // bf: bipush 1
      // c0: goto c8
      // c3: invokestatic com/trolmastercard/velvet/cv.b (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // c6: athrow
      // c7: bipush 0
      // c8: invokeinterface software/bernie/geckolib3/core/processor/IBone.setHidden (Z)V 2
      // cd: return
      // try (4 -> 21): 21 java/lang/RuntimeException
      // try (24 -> 32): 32 java/lang/RuntimeException
      // try (35 -> 53): 53 java/lang/RuntimeException
      // try (56 -> 64): 64 java/lang/RuntimeException
      // try (72 -> 79): 80 java/lang/RuntimeException
      // try (74 -> 84): 84 java/lang/RuntimeException
   }

   protected boolean e(T var1) {
      return true;
   }

   protected void a(T param1, AnimationProcessor<T> param2, AnimationEvent param3) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 00: aload 1
      // 01: getfield com/trolmastercard/velvet/em.field_70170_p Lnet/minecraft/world/World;
      // 04: instanceof com/trolmastercard/velvet/gj
      // 07: ifeq 0f
      // 0a: return
      // 0b: invokestatic com/trolmastercard/velvet/cv.b (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 0e: athrow
      // 0f: aload 0
      // 10: aload 1
      // 11: invokevirtual com/trolmastercard/velvet/cv.e (Lcom/trolmastercard/velvet/em;)Z
      // 14: ifne 1c
      // 17: return
      // 18: invokestatic com/trolmastercard/velvet/cv.b (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 1b: athrow
      // 1c: aload 1
      // 1d: invokevirtual com/trolmastercard/velvet/em.y ()Lcom/trolmastercard/velvet/fp;
      // 20: getstatic com/trolmastercard/velvet/fp.NULL Lcom/trolmastercard/velvet/fp;
      // 23: if_acmpeq 4d
      // 26: aload 1
      // 27: invokevirtual com/trolmastercard/velvet/em.y ()Lcom/trolmastercard/velvet/fp;
      // 2a: getstatic com/trolmastercard/velvet/fp.ATTACK Lcom/trolmastercard/velvet/fp;
      // 2d: if_acmpeq 4d
      // 30: goto 37
      // 33: invokestatic com/trolmastercard/velvet/cv.b (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 36: athrow
      // 37: aload 1
      // 38: invokevirtual com/trolmastercard/velvet/em.y ()Lcom/trolmastercard/velvet/fp;
      // 3b: getstatic com/trolmastercard/velvet/fp.BOW Lcom/trolmastercard/velvet/fp;
      // 3e: if_acmpeq 4d
      // 41: goto 48
      // 44: invokestatic com/trolmastercard/velvet/cv.b (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 47: athrow
      // 48: return
      // 49: invokestatic com/trolmastercard/velvet/cv.b (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 4c: athrow
      // 4d: aload 3
      // 4e: ldc_w software/bernie/geckolib3/model/provider/data/EntityModelData
      // 51: invokevirtual software/bernie/geckolib3/core/event/predicate/AnimationEvent.getExtraDataOfType (Ljava/lang/Class;)Ljava/util/List;
      // 54: bipush 0
      // 55: invokeinterface java/util/List.get (I)Ljava/lang/Object; 2
      // 5a: checkcast software/bernie/geckolib3/model/provider/data/EntityModelData
      // 5d: astore 4
      // 5f: aload 2
      // 60: ldc_w "neck"
      // 63: invokevirtual software/bernie/geckolib3/core/processor/AnimationProcessor.getBone (Ljava/lang/String;)Lsoftware/bernie/geckolib3/core/processor/IBone;
      // 66: astore 5
      // 68: aload 5
      // 6a: aload 4
      // 6c: getfield software/bernie/geckolib3/model/provider/data/EntityModelData.netHeadYaw F
      // 6f: ldc_w 0.5
      // 72: fmul
      // 73: ldc_w 0.017453292
      // 76: fmul
      // 77: invokeinterface software/bernie/geckolib3/core/processor/IBone.setRotationY (F)V 2
      // 7c: aload 2
      // 7d: ldc_w "head"
      // 80: invokevirtual software/bernie/geckolib3/core/processor/AnimationProcessor.getBone (Ljava/lang/String;)Lsoftware/bernie/geckolib3/core/processor/IBone;
      // 83: astore 6
      // 85: aload 6
      // 87: aload 4
      // 89: getfield software/bernie/geckolib3/model/provider/data/EntityModelData.netHeadYaw F
      // 8c: ldc_w 0.017453292
      // 8f: fmul
      // 90: invokeinterface software/bernie/geckolib3/core/processor/IBone.setRotationY (F)V 2
      // 95: aload 6
      // 97: aload 4
      // 99: getfield software/bernie/geckolib3/model/provider/data/EntityModelData.headPitch F
      // 9c: ldc_w 0.017453292
      // 9f: fmul
      // a0: invokeinterface software/bernie/geckolib3/core/processor/IBone.setRotationX (F)V 2
      // a5: aload 2
      // a6: ldc_w "body"
      // a9: invokevirtual software/bernie/geckolib3/core/processor/AnimationProcessor.getBone (Ljava/lang/String;)Lsoftware/bernie/geckolib3/core/processor/IBone;
      // ac: ifnonnull bd
      // af: aload 2
      // b0: ldc_w "dd"
      // b3: invokevirtual software/bernie/geckolib3/core/processor/AnimationProcessor.getBone (Ljava/lang/String;)Lsoftware/bernie/geckolib3/core/processor/IBone;
      // b6: goto c4
      // b9: invokestatic com/trolmastercard/velvet/cv.b (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // bc: athrow
      // bd: aload 2
      // be: ldc_w "body"
      // c1: invokevirtual software/bernie/geckolib3/core/processor/AnimationProcessor.getBone (Ljava/lang/String;)Lsoftware/bernie/geckolib3/core/processor/IBone;
      // c4: astore 7
      // c6: aload 7
      // c8: fconst_0
      // c9: invokeinterface software/bernie/geckolib3/core/processor/IBone.setRotationY (F)V 2
      // ce: return
      // try (0 -> 5): 5 java/lang/RuntimeException
      // try (7 -> 12): 12 java/lang/RuntimeException
      // try (14 -> 22): 23 java/lang/RuntimeException
      // try (18 -> 29): 30 java/lang/RuntimeException
      // try (25 -> 33): 33 java/lang/RuntimeException
      // try (58 -> 78): 78 java/lang/RuntimeException
   }

   public ItemStack a(em var1, String var2) {
      try {
         if (Arrays.asList(this.c()).contains(var2)) {
            return (ItemStack)var1.m.func_187225_a(e2.X);
         }
      } catch (RuntimeException var4) {
         throw b(var4);
      }

      try {
         if (Arrays.asList(this.f()).contains(var2)) {
            return (ItemStack)var1.m.func_187225_a(e2.T);
         }
      } catch (RuntimeException var6) {
         throw b(var6);
      }

      try {
         if (Arrays.asList(this.h()).contains(var2)) {
            return (ItemStack)var1.m.func_187225_a(e2.U);
         }
      } catch (RuntimeException var3) {
         throw b(var3);
      }

      try {
         if (Arrays.asList(this.b()).contains(var2)) {
            return (ItemStack)var1.m.func_187225_a(e2.W);
         }
      } catch (RuntimeException var5) {
         throw b(var5);
      }

      return ItemStack.field_190927_a;
   }

   private static RuntimeException b(RuntimeException var0) {
      return var0;
   }
}
