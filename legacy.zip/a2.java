package org.velvet;

import net.minecraft.util.ResourceLocation;
import software.bernie.geckolib3.model.AnimatedGeoModel;

public class a2 extends AnimatedGeoModel<aj> {
   public ResourceLocation c(aj var1) {
      return new ResourceLocation("velvet", "geo/west/winchester.geo.json");
   }

   public ResourceLocation b(aj var1) {
      return new ResourceLocation("velvet", "textures/items/winchester/winchester.png");
   }

   public ResourceLocation a(aj var1) {
      return new ResourceLocation("velvet", "animations/west/winchester.animation.json");
   }
}
