package org.velvet;

import javax.annotation.Nonnull;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.Vec3d;
import software.bernie.geckolib3.core.event.predicate.AnimationEvent;
import software.bernie.geckolib3.core.processor.AnimationProcessor;
import software.bernie.geckolib3.core.processor.IBone;

public class ce extends cv {
   public static final float h = 7.0F;
   public static final float k = 0.75F;
   static final float l = gc.c(140.0F);
   static final float m = gc.c(35.0F);
   static final float i = 90.0F;
   static final float g = gc.c(45.0F);
   static final float f = gc.c(-45.0F);
   public static final ResourceLocation j = new ResourceLocation("velvet", "textures/entity/manglelie/manglelie.png");

   @Override
   protected ResourceLocation[] a() {
      return new ResourceLocation[]{
         new ResourceLocation("velvet", "geo/manglelie/manglelie.geo.json"),
         new ResourceLocation("velvet", "geo/manglelie/manglelie.geo.json"),
         new ResourceLocation("velvet", "geo/galath/galath_con_mang.geo.json")
      };
   }

   @Override
   public ResourceLocation a(em var1) {
      try {
         if (var1.field_70170_p instanceof gj) {
            return this.c[0];
         }
      } catch (RuntimeException var2) {
         throw a(var2);
      }

      try {
         if (c(var1)) {
            return this.c[2];
         }
      } catch (RuntimeException var3) {
         throw a(var3);
      }

      return this.c[var1.func_184212_Q().func_187225_a(em.D)];
   }

   public static boolean c(em var0) {
      return fp.a(var0, fp.THREESOME_SLOW, fp.THREESOME_FAST, fp.THREESOME_CUM);
   }

   @Override
   public ResourceLocation b() {
      return j;
   }

   @Override
   public ResourceLocation b(em var1) {
      return new ResourceLocation("velvet", "animations/manglelie/manglelie.animation.json");
   }

   @Override
   public void a(em var1, Integer var2, AnimationEvent var3) {
      super.a(var1, var2, var3);
      a(var1, this.getAnimationProcessor(), var3.getPartialTick());
      this.b(var1);
      this.d(var1);
      this.a(var1);
      this.e(var1);
   }

   void e(em var1) {
      try {
         if (this.a.func_147113_T()) {
            return;
         }
      } catch (RuntimeException var8) {
         throw a(var8);
      }

      try {
         if (c(var1)) {
            return;
         }
      } catch (RuntimeException var10) {
         throw a(var10);
      }

      f_ var2 = f8.a(var1, false);

      try {
         if (var2 == null) {
            return;
         }
      } catch (RuntimeException var7) {
         throw a(var7);
      }

      try {
         if (!fp.a(var2.y(), fp.CORRUPT_CUM, fp.CARRY_FAST, fp.CORRUPT_INTRO, fp.CORRUPT_SLOW)) {
            return;
         }
      } catch (RuntimeException var9) {
         throw a(var9);
      }

      AnimationProcessor var3 = this.getAnimationProcessor();
      IBone var4 = var3.getBone("legR");
      var4.setRotationY(var4.getRotationY() + f);
      IBone var5 = var3.getBone("lowerArmR");
      IBone var6 = var3.getBone("lowerArmL");
      var5.setRotationX(var5.getRotationX() + f);
      var6.setRotationX(var6.getRotationX() + f);
   }

   void a(em var1) {
      try {
         if (!(var1 instanceof f8)) {
            return;
         }
      } catch (RuntimeException var5) {
         throw a(var5);
      }

      try {
         if (c(var1)) {
            return;
         }
      } catch (RuntimeException var8) {
         throw a(var8);
      }

      f8 var2 = (f8)var1;
      f_ var3 = var2.a(false);

      try {
         if (var3 == null) {
            return;
         }
      } catch (RuntimeException var7) {
         throw a(var7);
      }

      IBone var4 = this.getAnimationProcessor().getBone("body");

      IBone var10000;
      float var10001;
      float var10002;
      label32: {
         try {
            var10000 = var4;
            var10001 = var3.bw;
            if (this.a.func_147113_T()) {
               var10002 = 0.0F;
               break label32;
            }
         } catch (RuntimeException var6) {
            throw a(var6);
         }

         var10002 = var4.getRotationY();
      }

      var10000.setRotationY(var10001 + var10002);
      var4.setScaleX(var3.bm);
      var4.setScaleY(var3.bm);
      var4.setScaleZ(var3.bm);
   }

   Vec3d a(@Nonnull Entity var1) {
      return ak.a(var1, this.a.func_184121_ak()).func_72441_c(0.0, var1.func_70047_e(), 0.0);
   }

   void d(em param1) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 000: getstatic com/trolmastercard/velvet/ClientProxy.IS_PRELOADING Z
      // 003: ifeq 00b
      // 006: return
      // 007: invokestatic com/trolmastercard/velvet/ce.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 00a: athrow
      // 00b: aload 1
      // 00c: invokestatic com/trolmastercard/velvet/ce.c (Lcom/trolmastercard/velvet/em;)Z
      // 00f: ifeq 017
      // 012: return
      // 013: invokestatic com/trolmastercard/velvet/ce.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 016: athrow
      // 017: aload 0
      // 018: getfield com/trolmastercard/velvet/ce.a Lnet/minecraft/client/Minecraft;
      // 01b: invokevirtual net/minecraft/client/Minecraft.func_147113_T ()Z
      // 01e: ifeq 026
      // 021: return
      // 022: invokestatic com/trolmastercard/velvet/ce.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 025: athrow
      // 026: aload 1
      // 027: checkcast com/trolmastercard/velvet/f8
      // 02a: astore 2
      // 02b: aload 2
      // 02c: invokevirtual com/trolmastercard/velvet/f8.r ()Z
      // 02f: ifne 037
      // 032: return
      // 033: invokestatic com/trolmastercard/velvet/ce.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 036: athrow
      // 037: aload 2
      // 038: bipush 0
      // 039: invokevirtual com/trolmastercard/velvet/f8.a (Z)Lcom/trolmastercard/velvet/f_;
      // 03c: astore 3
      // 03d: aload 3
      // 03e: ifnonnull 046
      // 041: return
      // 042: invokestatic com/trolmastercard/velvet/ce.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 045: athrow
      // 046: aload 0
      // 047: invokevirtual com/trolmastercard/velvet/ce.getAnimationProcessor ()Lsoftware/bernie/geckolib3/core/processor/AnimationProcessor;
      // 04a: astore 4
      // 04c: aload 4
      // 04e: ldc "armL"
      // 050: invokevirtual software/bernie/geckolib3/core/processor/AnimationProcessor.getBone (Ljava/lang/String;)Lsoftware/bernie/geckolib3/core/processor/IBone;
      // 053: astore 5
      // 055: aload 4
      // 057: ldc "armR"
      // 059: invokevirtual software/bernie/geckolib3/core/processor/AnimationProcessor.getBone (Ljava/lang/String;)Lsoftware/bernie/geckolib3/core/processor/IBone;
      // 05c: astore 6
      // 05e: aload 4
      // 060: ldc "lowerArmL"
      // 062: invokevirtual software/bernie/geckolib3/core/processor/AnimationProcessor.getBone (Ljava/lang/String;)Lsoftware/bernie/geckolib3/core/processor/IBone;
      // 065: astore 7
      // 067: aload 4
      // 069: ldc "lowerArmR"
      // 06b: invokevirtual software/bernie/geckolib3/core/processor/AnimationProcessor.getBone (Ljava/lang/String;)Lsoftware/bernie/geckolib3/core/processor/IBone;
      // 06e: astore 8
      // 070: aload 4
      // 072: ldc "elbowR"
      // 074: invokevirtual software/bernie/geckolib3/core/processor/AnimationProcessor.getBone (Ljava/lang/String;)Lsoftware/bernie/geckolib3/core/processor/IBone;
      // 077: astore 9
      // 079: aload 4
      // 07b: ldc "elbowL"
      // 07d: invokevirtual software/bernie/geckolib3/core/processor/AnimationProcessor.getBone (Ljava/lang/String;)Lsoftware/bernie/geckolib3/core/processor/IBone;
      // 080: astore 10
      // 082: aload 2
      // 083: invokevirtual com/trolmastercard/velvet/f8.b ()Lnet/minecraft/entity/Entity;
      // 086: astore 11
      // 088: aload 11
      // 08a: ifnonnull 095
      // 08d: bipush 1
      // 08e: goto 096
      // 091: invokestatic com/trolmastercard/velvet/ce.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 094: athrow
      // 095: bipush 0
      // 096: istore 12
      // 098: iload 12
      // 09a: ifne 0ae
      // 09d: aload 2
      // 09e: aload 0
      // 09f: aload 11
      // 0a1: invokevirtual com/trolmastercard/velvet/ce.a (Lnet/minecraft/entity/Entity;)Lnet/minecraft/util/math/Vec3d;
      // 0a4: putfield com/trolmastercard/velvet/f8.R Lnet/minecraft/util/math/Vec3d;
      // 0a7: goto 0ae
      // 0aa: invokestatic com/trolmastercard/velvet/ce.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 0ad: athrow
      // 0ae: invokestatic net/minecraft/client/Minecraft.func_175610_ah ()I
      // 0b1: i2f
      // 0b2: fstore 14
      // 0b4: fload 14
      // 0b6: fconst_0
      // 0b7: fcmpl
      // 0b8: ifne 0be
      // 0bb: fconst_1
      // 0bc: fstore 14
      // 0be: aload 2
      // 0bf: getfield com/trolmastercard/velvet/f8.aj Z
      // 0c2: iload 12
      // 0c4: if_icmpne 0d3
      // 0c7: aload 2
      // 0c8: fconst_0
      // 0c9: putfield com/trolmastercard/velvet/f8.V F
      // 0cc: goto 0e2
      // 0cf: invokestatic com/trolmastercard/velvet/ce.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 0d2: athrow
      // 0d3: aload 2
      // 0d4: dup
      // 0d5: getfield com/trolmastercard/velvet/f8.V F
      // 0d8: ldc_w 1.5
      // 0db: fload 14
      // 0dd: fdiv
      // 0de: fadd
      // 0df: putfield com/trolmastercard/velvet/f8.V F
      // 0e2: aload 2
      // 0e3: getfield com/trolmastercard/velvet/f8.V F
      // 0e6: fconst_1
      // 0e7: fcmpl
      // 0e8: iflt 0fd
      // 0eb: aload 2
      // 0ec: fconst_0
      // 0ed: putfield com/trolmastercard/velvet/f8.V F
      // 0f0: aload 2
      // 0f1: iload 12
      // 0f3: putfield com/trolmastercard/velvet/f8.aj Z
      // 0f6: goto 0fd
      // 0f9: invokestatic com/trolmastercard/velvet/ce.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 0fc: athrow
      // 0fd: aload 2
      // 0fe: getfield com/trolmastercard/velvet/f8.V F
      // 101: fconst_0
      // 102: fcmpl
      // 103: ifne 137
      // 106: iload 12
      // 108: ifeq 126
      // 10b: goto 112
      // 10e: invokestatic com/trolmastercard/velvet/ce.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 111: athrow
      // 112: aload 0
      // 113: aload 3
      // 114: aload 6
      // 116: aload 5
      // 118: aload 7
      // 11a: aload 8
      // 11c: invokevirtual com/trolmastercard/velvet/ce.a (Lcom/trolmastercard/velvet/f_;Lsoftware/bernie/geckolib3/core/processor/IBone;Lsoftware/bernie/geckolib3/core/processor/IBone;Lsoftware/bernie/geckolib3/core/processor/IBone;Lsoftware/bernie/geckolib3/core/processor/IBone;)Lcom/trolmastercard/velvet/ce$a;
      // 11f: goto 132
      // 122: invokestatic com/trolmastercard/velvet/ce.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 125: athrow
      // 126: aload 0
      // 127: aload 2
      // 128: aload 3
      // 129: aload 8
      // 12b: aload 7
      // 12d: aload 4
      // 12f: invokevirtual com/trolmastercard/velvet/ce.a (Lcom/trolmastercard/velvet/f8;Lcom/trolmastercard/velvet/f_;Lsoftware/bernie/geckolib3/core/processor/IBone;Lsoftware/bernie/geckolib3/core/processor/IBone;Lsoftware/bernie/geckolib3/core/processor/AnimationProcessor;)Lcom/trolmastercard/velvet/ce$a;
      // 132: astore 13
      // 134: goto 176
      // 137: aload 0
      // 138: aload 3
      // 139: aload 6
      // 13b: aload 5
      // 13d: aload 7
      // 13f: aload 8
      // 141: invokevirtual com/trolmastercard/velvet/ce.a (Lcom/trolmastercard/velvet/f_;Lsoftware/bernie/geckolib3/core/processor/IBone;Lsoftware/bernie/geckolib3/core/processor/IBone;Lsoftware/bernie/geckolib3/core/processor/IBone;Lsoftware/bernie/geckolib3/core/processor/IBone;)Lcom/trolmastercard/velvet/ce$a;
      // 144: aload 0
      // 145: aload 2
      // 146: aload 3
      // 147: aload 8
      // 149: aload 7
      // 14b: aload 4
      // 14d: invokevirtual com/trolmastercard/velvet/ce.a (Lcom/trolmastercard/velvet/f8;Lcom/trolmastercard/velvet/f_;Lsoftware/bernie/geckolib3/core/processor/IBone;Lsoftware/bernie/geckolib3/core/processor/IBone;Lsoftware/bernie/geckolib3/core/processor/AnimationProcessor;)Lcom/trolmastercard/velvet/ce$a;
      // 150: aload 2
      // 151: getfield com/trolmastercard/velvet/f8.aj Z
      // 154: ifeq 166
      // 157: aload 2
      // 158: getfield com/trolmastercard/velvet/f8.V F
      // 15b: f2d
      // 15c: invokestatic com/trolmastercard/velvet/b6.c (D)D
      // 15f: goto 170
      // 162: invokestatic com/trolmastercard/velvet/ce.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 165: athrow
      // 166: dconst_1
      // 167: aload 2
      // 168: getfield com/trolmastercard/velvet/f8.V F
      // 16b: f2d
      // 16c: invokestatic com/trolmastercard/velvet/b6.c (D)D
      // 16f: dsub
      // 170: d2f
      // 171: invokestatic com/trolmastercard/velvet/ce$a.a (Lcom/trolmastercard/velvet/ce$a;Lcom/trolmastercard/velvet/ce$a;F)Lcom/trolmastercard/velvet/ce$a;
      // 174: astore 13
      // 176: aload 6
      // 178: aload 13
      // 17a: invokestatic com/trolmastercard/velvet/ce$a.access$000 (Lcom/trolmastercard/velvet/ce$a;)Lcom/trolmastercard/velvet/f7;
      // 17d: getfield com/trolmastercard/velvet/f7.a F
      // 180: invokeinterface software/bernie/geckolib3/core/processor/IBone.setRotationX (F)V 2
      // 185: aload 6
      // 187: aload 13
      // 189: invokestatic com/trolmastercard/velvet/ce$a.access$000 (Lcom/trolmastercard/velvet/ce$a;)Lcom/trolmastercard/velvet/f7;
      // 18c: getfield com/trolmastercard/velvet/f7.c F
      // 18f: invokeinterface software/bernie/geckolib3/core/processor/IBone.setRotationY (F)V 2
      // 194: aload 6
      // 196: aload 13
      // 198: invokestatic com/trolmastercard/velvet/ce$a.access$000 (Lcom/trolmastercard/velvet/ce$a;)Lcom/trolmastercard/velvet/f7;
      // 19b: getfield com/trolmastercard/velvet/f7.b F
      // 19e: invokeinterface software/bernie/geckolib3/core/processor/IBone.setRotationZ (F)V 2
      // 1a3: aload 5
      // 1a5: aload 13
      // 1a7: invokestatic com/trolmastercard/velvet/ce$a.access$100 (Lcom/trolmastercard/velvet/ce$a;)Lcom/trolmastercard/velvet/f7;
      // 1aa: getfield com/trolmastercard/velvet/f7.a F
      // 1ad: invokeinterface software/bernie/geckolib3/core/processor/IBone.setRotationX (F)V 2
      // 1b2: aload 5
      // 1b4: aload 13
      // 1b6: invokestatic com/trolmastercard/velvet/ce$a.access$100 (Lcom/trolmastercard/velvet/ce$a;)Lcom/trolmastercard/velvet/f7;
      // 1b9: getfield com/trolmastercard/velvet/f7.c F
      // 1bc: invokeinterface software/bernie/geckolib3/core/processor/IBone.setRotationY (F)V 2
      // 1c1: aload 5
      // 1c3: aload 13
      // 1c5: invokestatic com/trolmastercard/velvet/ce$a.access$100 (Lcom/trolmastercard/velvet/ce$a;)Lcom/trolmastercard/velvet/f7;
      // 1c8: getfield com/trolmastercard/velvet/f7.b F
      // 1cb: invokeinterface software/bernie/geckolib3/core/processor/IBone.setRotationZ (F)V 2
      // 1d0: aload 7
      // 1d2: aload 13
      // 1d4: invokestatic com/trolmastercard/velvet/ce$a.access$200 (Lcom/trolmastercard/velvet/ce$a;)Lcom/trolmastercard/velvet/f7;
      // 1d7: getfield com/trolmastercard/velvet/f7.a F
      // 1da: invokeinterface software/bernie/geckolib3/core/processor/IBone.setRotationX (F)V 2
      // 1df: aload 7
      // 1e1: aload 13
      // 1e3: invokestatic com/trolmastercard/velvet/ce$a.access$200 (Lcom/trolmastercard/velvet/ce$a;)Lcom/trolmastercard/velvet/f7;
      // 1e6: getfield com/trolmastercard/velvet/f7.c F
      // 1e9: invokeinterface software/bernie/geckolib3/core/processor/IBone.setRotationY (F)V 2
      // 1ee: aload 7
      // 1f0: aload 13
      // 1f2: invokestatic com/trolmastercard/velvet/ce$a.access$200 (Lcom/trolmastercard/velvet/ce$a;)Lcom/trolmastercard/velvet/f7;
      // 1f5: getfield com/trolmastercard/velvet/f7.b F
      // 1f8: invokeinterface software/bernie/geckolib3/core/processor/IBone.setRotationZ (F)V 2
      // 1fd: aload 8
      // 1ff: aload 13
      // 201: invokestatic com/trolmastercard/velvet/ce$a.access$300 (Lcom/trolmastercard/velvet/ce$a;)Lcom/trolmastercard/velvet/f7;
      // 204: getfield com/trolmastercard/velvet/f7.a F
      // 207: invokeinterface software/bernie/geckolib3/core/processor/IBone.setRotationX (F)V 2
      // 20c: aload 8
      // 20e: aload 13
      // 210: invokestatic com/trolmastercard/velvet/ce$a.access$300 (Lcom/trolmastercard/velvet/ce$a;)Lcom/trolmastercard/velvet/f7;
      // 213: getfield com/trolmastercard/velvet/f7.c F
      // 216: invokeinterface software/bernie/geckolib3/core/processor/IBone.setRotationY (F)V 2
      // 21b: aload 8
      // 21d: aload 13
      // 21f: invokestatic com/trolmastercard/velvet/ce$a.access$300 (Lcom/trolmastercard/velvet/ce$a;)Lcom/trolmastercard/velvet/f7;
      // 222: getfield com/trolmastercard/velvet/f7.b F
      // 225: invokeinterface software/bernie/geckolib3/core/processor/IBone.setRotationZ (F)V 2
      // 22a: aload 5
      // 22c: aload 13
      // 22e: invokestatic com/trolmastercard/velvet/ce$a.access$400 (Lcom/trolmastercard/velvet/ce$a;)F
      // 231: invokeinterface software/bernie/geckolib3/core/processor/IBone.setScaleY (F)V 2
      // 236: aload 6
      // 238: aload 13
      // 23a: invokestatic com/trolmastercard/velvet/ce$a.access$500 (Lcom/trolmastercard/velvet/ce$a;)F
      // 23d: invokeinterface software/bernie/geckolib3/core/processor/IBone.setScaleY (F)V 2
      // 242: aload 9
      // 244: aload 13
      // 246: invokestatic com/trolmastercard/velvet/ce$a.access$600 (Lcom/trolmastercard/velvet/ce$a;)F
      // 249: invokeinterface software/bernie/geckolib3/core/processor/IBone.setRotationY (F)V 2
      // 24e: aload 10
      // 250: aload 13
      // 252: invokestatic com/trolmastercard/velvet/ce$a.access$700 (Lcom/trolmastercard/velvet/ce$a;)F
      // 255: invokeinterface software/bernie/geckolib3/core/processor/IBone.setRotationY (F)V 2
      // 25a: return
      // try (0 -> 3): 3 java/lang/RuntimeException
      // try (5 -> 9): 9 java/lang/RuntimeException
      // try (11 -> 16): 16 java/lang/RuntimeException
      // try (21 -> 25): 25 java/lang/RuntimeException
      // try (31 -> 34): 34 java/lang/RuntimeException
      // try (66 -> 70): 70 java/lang/RuntimeException
      // try (74 -> 81): 82 java/lang/RuntimeException
      // try (93 -> 101): 101 java/lang/RuntimeException
      // try (111 -> 122): 123 java/lang/RuntimeException
      // try (125 -> 132): 133 java/lang/RuntimeException
      // try (130 -> 143): 143 java/lang/RuntimeException
      // try (154 -> 176): 176 java/lang/RuntimeException
   }

   ce.a a(@Nonnull f8 param1, @Nonnull f_ param2, IBone param3, IBone param4, AnimationProcessor param5) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 000: new com/trolmastercard/velvet/ce$a
      // 003: dup
      // 004: aconst_null
      // 005: invokespecial com/trolmastercard/velvet/ce$a.<init> (Lcom/trolmastercard/velvet/ce$b;)V
      // 008: astore 6
      // 00a: aload 6
      // 00c: new com/trolmastercard/velvet/f7
      // 00f: dup
      // 010: getstatic com/trolmastercard/velvet/ce.m F
      // 013: fconst_0
      // 014: aload 3
      // 015: invokeinterface software/bernie/geckolib3/core/processor/IBone.getRotationZ ()F 1
      // 01a: invokespecial com/trolmastercard/velvet/f7.<init> (FFF)V
      // 01d: invokestatic com/trolmastercard/velvet/ce$a.access$202 (Lcom/trolmastercard/velvet/ce$a;Lcom/trolmastercard/velvet/f7;)Lcom/trolmastercard/velvet/f7;
      // 020: pop
      // 021: aload 6
      // 023: new com/trolmastercard/velvet/f7
      // 026: dup
      // 027: getstatic com/trolmastercard/velvet/ce.l F
      // 02a: fconst_0
      // 02b: aload 4
      // 02d: invokeinterface software/bernie/geckolib3/core/processor/IBone.getRotationZ ()F 1
      // 032: invokespecial com/trolmastercard/velvet/f7.<init> (FFF)V
      // 035: invokestatic com/trolmastercard/velvet/ce$a.access$302 (Lcom/trolmastercard/velvet/ce$a;Lcom/trolmastercard/velvet/f7;)Lcom/trolmastercard/velvet/f7;
      // 038: pop
      // 039: aload 2
      // 03a: getfield com/trolmastercard/velvet/f_.aE F
      // 03d: aload 5
      // 03f: ldc_w "upperBody"
      // 042: invokevirtual software/bernie/geckolib3/core/processor/AnimationProcessor.getBone (Ljava/lang/String;)Lsoftware/bernie/geckolib3/core/processor/IBone;
      // 045: invokeinterface software/bernie/geckolib3/core/processor/IBone.getRotationX ()F 1
      // 04a: fadd
      // 04b: fstore 7
      // 04d: aload 0
      // 04e: getfield com/trolmastercard/velvet/ce.a Lnet/minecraft/client/Minecraft;
      // 051: invokevirtual net/minecraft/client/Minecraft.func_184121_ak ()F
      // 054: fstore 8
      // 056: aload 2
      // 057: fload 8
      // 059: invokestatic com/trolmastercard/velvet/dh.a (Lcom/trolmastercard/velvet/f_;F)Lnet/minecraft/util/math/Vec3d;
      // 05c: astore 9
      // 05e: aload 1
      // 05f: ldc "armR"
      // 061: invokevirtual com/trolmastercard/velvet/f8.b (Ljava/lang/String;)Lnet/minecraft/util/math/Vec3d;
      // 064: aload 9
      // 066: invokevirtual net/minecraft/util/math/Vec3d.func_178787_e (Lnet/minecraft/util/math/Vec3d;)Lnet/minecraft/util/math/Vec3d;
      // 069: astore 10
      // 06b: aload 1
      // 06c: ldc "armL"
      // 06e: invokevirtual com/trolmastercard/velvet/f8.b (Ljava/lang/String;)Lnet/minecraft/util/math/Vec3d;
      // 071: aload 9
      // 073: invokevirtual net/minecraft/util/math/Vec3d.func_178787_e (Lnet/minecraft/util/math/Vec3d;)Lnet/minecraft/util/math/Vec3d;
      // 076: astore 11
      // 078: aload 10
      // 07a: aload 1
      // 07b: getfield com/trolmastercard/velvet/f8.R Lnet/minecraft/util/math/Vec3d;
      // 07e: invokestatic com/trolmastercard/velvet/be.a (Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/math/Vec3d;)Lcom/trolmastercard/velvet/bm;
      // 081: astore 12
      // 083: aload 11
      // 085: aload 1
      // 086: getfield com/trolmastercard/velvet/f8.R Lnet/minecraft/util/math/Vec3d;
      // 089: invokestatic com/trolmastercard/velvet/be.a (Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/math/Vec3d;)Lcom/trolmastercard/velvet/bm;
      // 08c: astore 13
      // 08e: aload 2
      // 08f: fload 8
      // 091: invokestatic com/trolmastercard/velvet/f_.a (Lcom/trolmastercard/velvet/f_;F)Ljava/lang/Float;
      // 094: astore 14
      // 096: aload 14
      // 098: ifnonnull 0b0
      // 09b: aload 2
      // 09c: getfield com/trolmastercard/velvet/f_.field_70758_at F
      // 09f: aload 2
      // 0a0: getfield com/trolmastercard/velvet/f_.field_70759_as F
      // 0a3: fload 8
      // 0a5: f2d
      // 0a6: invokestatic com/trolmastercard/velvet/b6.b (FFD)F
      // 0a9: goto 0b5
      // 0ac: invokestatic com/trolmastercard/velvet/ce.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 0af: athrow
      // 0b0: aload 14
      // 0b2: invokevirtual java/lang/Float.floatValue ()F
      // 0b5: fstore 15
      // 0b7: fload 15
      // 0b9: invokestatic com/trolmastercard/velvet/gc.c (F)F
      // 0bc: fstore 16
      // 0be: aload 1
      // 0bf: fload 8
      // 0c1: invokevirtual com/trolmastercard/velvet/f8.b (F)F
      // 0c4: fstore 17
      // 0c6: fconst_1
      // 0c7: fload 17
      // 0c9: invokestatic java/lang/Math.min (FF)F
      // 0cc: f2d
      // 0cd: invokestatic com/trolmastercard/velvet/b6.e (D)D
      // 0d0: d2f
      // 0d1: fstore 18
      // 0d3: fload 18
      // 0d5: fconst_1
      // 0d6: fcmpl
      // 0d7: ifeq 0e0
      // 0da: fconst_0
      // 0db: fstore 19
      // 0dd: goto 0fe
      // 0e0: fload 17
      // 0e2: ldc_w 28.0
      // 0e5: fmul
      // 0e6: ldc_w 28.0
      // 0e9: fsub
      // 0ea: ldc_w 32.0
      // 0ed: fdiv
      // 0ee: fstore 19
      // 0f0: fconst_0
      // 0f1: fload 19
      // 0f3: ldc_w 0.5
      // 0f6: fsub
      // 0f7: invokestatic java/lang/Math.max (FF)F
      // 0fa: fconst_2
      // 0fb: fmul
      // 0fc: fstore 19
      // 0fe: fload 19
      // 100: f2d
      // 101: invokestatic com/trolmastercard/velvet/b6.h (D)D
      // 104: d2f
      // 105: fstore 20
      // 107: fconst_0
      // 108: ldc 90.0
      // 10a: fload 18
      // 10c: invokestatic com/trolmastercard/velvet/b6.a (FFF)F
      // 10f: invokestatic com/trolmastercard/velvet/gc.c (F)F
      // 112: fstore 21
      // 114: aload 1
      // 115: aload 1
      // 116: getfield com/trolmastercard/velvet/f8.R Lnet/minecraft/util/math/Vec3d;
      // 119: fload 8
      // 11b: invokevirtual com/trolmastercard/velvet/f8.a (Lnet/minecraft/util/math/Vec3d;F)Z
      // 11e: istore 22
      // 120: iload 22
      // 122: ifeq 23b
      // 125: aload 6
      // 127: new com/trolmastercard/velvet/f7
      // 12a: dup
      // 12b: fload 7
      // 12d: fneg
      // 12e: aload 12
      // 130: getfield com/trolmastercard/velvet/bm.a F
      // 133: fadd
      // 134: ldc 90.0
      // 136: invokestatic com/trolmastercard/velvet/gc.c (F)F
      // 139: fadd
      // 13a: aload 12
      // 13c: getfield com/trolmastercard/velvet/bm.c F
      // 13f: fconst_0
      // 140: invokespecial com/trolmastercard/velvet/f7.<init> (FFF)V
      // 143: invokestatic com/trolmastercard/velvet/ce$a.access$002 (Lcom/trolmastercard/velvet/ce$a;Lcom/trolmastercard/velvet/f7;)Lcom/trolmastercard/velvet/f7;
      // 146: pop
      // 147: aload 6
      // 149: new com/trolmastercard/velvet/f7
      // 14c: dup
      // 14d: fload 7
      // 14f: fneg
      // 150: aload 13
      // 152: getfield com/trolmastercard/velvet/bm.a F
      // 155: fadd
      // 156: ldc 90.0
      // 158: invokestatic com/trolmastercard/velvet/gc.c (F)F
      // 15b: fadd
      // 15c: aload 13
      // 15e: getfield com/trolmastercard/velvet/bm.c F
      // 161: f2d
      // 162: ldc_w -20.0
      // 165: invokestatic com/trolmastercard/velvet/gc.c (F)F
      // 168: f2d
      // 169: aload 12
      // 16b: getfield com/trolmastercard/velvet/bm.c F
      // 16e: fload 16
      // 170: fconst_1
      // 171: fmul
      // 172: fadd
      // 173: f2d
      // 174: invokestatic java/lang/Math.cos (D)D
      // 177: dmul
      // 178: dadd
      // 179: fload 21
      // 17b: fconst_2
      // 17c: fdiv
      // 17d: fconst_0
      // 17e: fload 20
      // 180: invokestatic com/trolmastercard/velvet/b6.a (FFF)F
      // 183: f2d
      // 184: dadd
      // 185: d2f
      // 186: fconst_0
      // 187: invokespecial com/trolmastercard/velvet/f7.<init> (FFF)V
      // 18a: invokestatic com/trolmastercard/velvet/ce$a.access$102 (Lcom/trolmastercard/velvet/ce$a;Lcom/trolmastercard/velvet/f7;)Lcom/trolmastercard/velvet/f7;
      // 18d: pop
      // 18e: aload 6
      // 190: fconst_1
      // 191: aload 12
      // 193: getfield com/trolmastercard/velvet/bm.c F
      // 196: invokestatic java/lang/Math.abs (F)F
      // 199: fload 16
      // 19b: invokestatic java/lang/Math.abs (F)F
      // 19e: fsub
      // 19f: invokestatic java/lang/Math.abs (F)F
      // 1a2: ldc_w 0.1909
      // 1a5: fmul
      // 1a6: fadd
      // 1a7: invokestatic com/trolmastercard/velvet/ce$a.access$402 (Lcom/trolmastercard/velvet/ce$a;F)F
      // 1aa: pop
      // 1ab: aload 6
      // 1ad: ldc 90.0
      // 1af: invokestatic com/trolmastercard/velvet/gc.c (F)F
      // 1b2: invokestatic com/trolmastercard/velvet/ce$a.access$702 (Lcom/trolmastercard/velvet/ce$a;F)F
      // 1b5: pop
      // 1b6: aload 6
      // 1b8: invokestatic com/trolmastercard/velvet/ce$a.access$200 (Lcom/trolmastercard/velvet/ce$a;)Lcom/trolmastercard/velvet/f7;
      // 1bb: fload 21
      // 1bd: fconst_0
      // 1be: fload 20
      // 1c0: invokestatic com/trolmastercard/velvet/b6.a (FFF)F
      // 1c3: putfield com/trolmastercard/velvet/f7.b F
      // 1c6: fload 19
      // 1c8: f2d
      // 1c9: ldc2_w 0.5
      // 1cc: dcmpl
      // 1cd: ifle 1ff
      // 1d0: goto 1d7
      // 1d3: invokestatic com/trolmastercard/velvet/ce.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 1d6: athrow
      // 1d7: aload 6
      // 1d9: invokestatic com/trolmastercard/velvet/ce$a.access$200 (Lcom/trolmastercard/velvet/ce$a;)Lcom/trolmastercard/velvet/f7;
      // 1dc: getstatic com/trolmastercard/velvet/ce.m F
      // 1df: getstatic com/trolmastercard/velvet/ce.g F
      // 1e2: f2d
      // 1e3: dconst_0
      // 1e4: fload 19
      // 1e6: ldc_w 0.5
      // 1e9: fsub
      // 1ea: fconst_2
      // 1eb: fmul
      // 1ec: f2d
      // 1ed: invokestatic com/trolmastercard/velvet/b6.h (D)D
      // 1f0: invokestatic com/trolmastercard/velvet/b6.b (DDD)D
      // 1f3: d2f
      // 1f4: fadd
      // 1f5: putfield com/trolmastercard/velvet/f7.a F
      // 1f8: goto 34a
      // 1fb: invokestatic com/trolmastercard/velvet/ce.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 1fe: athrow
      // 1ff: fload 19
      // 201: fconst_0
      // 202: fcmpl
      // 203: ifeq 34a
      // 206: fload 19
      // 208: f2d
      // 209: ldc2_w 0.5
      // 20c: dcmpg
      // 20d: ifge 34a
      // 210: goto 217
      // 213: invokestatic com/trolmastercard/velvet/ce.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 216: athrow
      // 217: aload 6
      // 219: invokestatic com/trolmastercard/velvet/ce$a.access$200 (Lcom/trolmastercard/velvet/ce$a;)Lcom/trolmastercard/velvet/f7;
      // 21c: getstatic com/trolmastercard/velvet/ce.m F
      // 21f: dconst_0
      // 220: getstatic com/trolmastercard/velvet/ce.g F
      // 223: f2d
      // 224: fload 19
      // 226: fconst_2
      // 227: fmul
      // 228: f2d
      // 229: invokestatic com/trolmastercard/velvet/b6.h (D)D
      // 22c: invokestatic com/trolmastercard/velvet/b6.b (DDD)D
      // 22f: d2f
      // 230: fadd
      // 231: putfield com/trolmastercard/velvet/f7.a F
      // 234: goto 34a
      // 237: invokestatic com/trolmastercard/velvet/ce.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 23a: athrow
      // 23b: aload 6
      // 23d: new com/trolmastercard/velvet/f7
      // 240: dup
      // 241: fload 7
      // 243: fneg
      // 244: aload 13
      // 246: getfield com/trolmastercard/velvet/bm.a F
      // 249: fadd
      // 24a: ldc 90.0
      // 24c: invokestatic com/trolmastercard/velvet/gc.c (F)F
      // 24f: fadd
      // 250: aload 13
      // 252: getfield com/trolmastercard/velvet/bm.c F
      // 255: fconst_0
      // 256: invokespecial com/trolmastercard/velvet/f7.<init> (FFF)V
      // 259: invokestatic com/trolmastercard/velvet/ce$a.access$102 (Lcom/trolmastercard/velvet/ce$a;Lcom/trolmastercard/velvet/f7;)Lcom/trolmastercard/velvet/f7;
      // 25c: pop
      // 25d: aload 6
      // 25f: new com/trolmastercard/velvet/f7
      // 262: dup
      // 263: fload 7
      // 265: fneg
      // 266: aload 12
      // 268: getfield com/trolmastercard/velvet/bm.a F
      // 26b: fadd
      // 26c: ldc 90.0
      // 26e: invokestatic com/trolmastercard/velvet/gc.c (F)F
      // 271: fadd
      // 272: aload 12
      // 274: getfield com/trolmastercard/velvet/bm.c F
      // 277: f2d
      // 278: ldc_w 20.0
      // 27b: invokestatic com/trolmastercard/velvet/gc.c (F)F
      // 27e: f2d
      // 27f: aload 13
      // 281: getfield com/trolmastercard/velvet/bm.c F
      // 284: fload 16
      // 286: fconst_1
      // 287: fmul
      // 288: fadd
      // 289: f2d
      // 28a: invokestatic java/lang/Math.cos (D)D
      // 28d: dmul
      // 28e: dadd
      // 28f: d2f
      // 290: fload 21
      // 292: fconst_2
      // 293: fdiv
      // 294: fconst_0
      // 295: fload 20
      // 297: invokestatic com/trolmastercard/velvet/b6.a (FFF)F
      // 29a: fsub
      // 29b: fconst_0
      // 29c: invokespecial com/trolmastercard/velvet/f7.<init> (FFF)V
      // 29f: invokestatic com/trolmastercard/velvet/ce$a.access$002 (Lcom/trolmastercard/velvet/ce$a;Lcom/trolmastercard/velvet/f7;)Lcom/trolmastercard/velvet/f7;
      // 2a2: pop
      // 2a3: aload 6
      // 2a5: fconst_1
      // 2a6: aload 13
      // 2a8: getfield com/trolmastercard/velvet/bm.c F
      // 2ab: invokestatic java/lang/Math.abs (F)F
      // 2ae: fload 16
      // 2b0: invokestatic java/lang/Math.abs (F)F
      // 2b3: fsub
      // 2b4: invokestatic java/lang/Math.abs (F)F
      // 2b7: ldc_w 0.1909
      // 2ba: fmul
      // 2bb: fadd
      // 2bc: invokestatic com/trolmastercard/velvet/ce$a.access$502 (Lcom/trolmastercard/velvet/ce$a;F)F
      // 2bf: pop
      // 2c0: aload 6
      // 2c2: ldc 90.0
      // 2c4: invokestatic com/trolmastercard/velvet/gc.c (F)F
      // 2c7: invokestatic com/trolmastercard/velvet/ce$a.access$602 (Lcom/trolmastercard/velvet/ce$a;F)F
      // 2ca: pop
      // 2cb: aload 6
      // 2cd: invokestatic com/trolmastercard/velvet/ce$a.access$300 (Lcom/trolmastercard/velvet/ce$a;)Lcom/trolmastercard/velvet/f7;
      // 2d0: fload 21
      // 2d2: fconst_0
      // 2d3: fload 20
      // 2d5: invokestatic com/trolmastercard/velvet/b6.a (FFF)F
      // 2d8: fneg
      // 2d9: putfield com/trolmastercard/velvet/f7.b F
      // 2dc: fload 19
      // 2de: f2d
      // 2df: ldc2_w 0.5
      // 2e2: dcmpl
      // 2e3: ifle 30e
      // 2e6: aload 6
      // 2e8: invokestatic com/trolmastercard/velvet/ce$a.access$300 (Lcom/trolmastercard/velvet/ce$a;)Lcom/trolmastercard/velvet/f7;
      // 2eb: getstatic com/trolmastercard/velvet/ce.l F
      // 2ee: getstatic com/trolmastercard/velvet/ce.g F
      // 2f1: f2d
      // 2f2: dconst_0
      // 2f3: fload 19
      // 2f5: ldc_w 0.5
      // 2f8: fsub
      // 2f9: fconst_2
      // 2fa: fmul
      // 2fb: f2d
      // 2fc: invokestatic com/trolmastercard/velvet/b6.h (D)D
      // 2ff: invokestatic com/trolmastercard/velvet/b6.b (DDD)D
      // 302: d2f
      // 303: fadd
      // 304: putfield com/trolmastercard/velvet/f7.a F
      // 307: goto 34a
      // 30a: invokestatic com/trolmastercard/velvet/ce.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 30d: athrow
      // 30e: fload 19
      // 310: fconst_0
      // 311: fcmpl
      // 312: ifeq 34a
      // 315: fload 19
      // 317: f2d
      // 318: ldc2_w 0.5
      // 31b: dcmpg
      // 31c: ifge 34a
      // 31f: goto 326
      // 322: invokestatic com/trolmastercard/velvet/ce.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 325: athrow
      // 326: aload 6
      // 328: invokestatic com/trolmastercard/velvet/ce$a.access$300 (Lcom/trolmastercard/velvet/ce$a;)Lcom/trolmastercard/velvet/f7;
      // 32b: getstatic com/trolmastercard/velvet/ce.l F
      // 32e: dconst_0
      // 32f: getstatic com/trolmastercard/velvet/ce.g F
      // 332: f2d
      // 333: fload 19
      // 335: fconst_2
      // 336: fmul
      // 337: f2d
      // 338: invokestatic com/trolmastercard/velvet/b6.h (D)D
      // 33b: invokestatic com/trolmastercard/velvet/b6.b (DDD)D
      // 33e: d2f
      // 33f: fadd
      // 340: putfield com/trolmastercard/velvet/f7.a F
      // 343: goto 34a
      // 346: invokestatic com/trolmastercard/velvet/ce.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 349: athrow
      // 34a: aload 6
      // 34c: invokestatic com/trolmastercard/velvet/ce$a.access$000 (Lcom/trolmastercard/velvet/ce$a;)Lcom/trolmastercard/velvet/f7;
      // 34f: dup
      // 350: getfield com/trolmastercard/velvet/f7.c F
      // 353: fload 16
      // 355: fadd
      // 356: putfield com/trolmastercard/velvet/f7.c F
      // 359: aload 6
      // 35b: invokestatic com/trolmastercard/velvet/ce$a.access$100 (Lcom/trolmastercard/velvet/ce$a;)Lcom/trolmastercard/velvet/f7;
      // 35e: dup
      // 35f: getfield com/trolmastercard/velvet/f7.c F
      // 362: fload 16
      // 364: fadd
      // 365: putfield com/trolmastercard/velvet/f7.c F
      // 368: aload 6
      // 36a: areturn
      // try (67 -> 77): 77 java/lang/RuntimeException
      // try (136 -> 226): 227 java/lang/RuntimeException
      // try (138 -> 247): 247 java/lang/RuntimeException
      // try (249 -> 258): 259 java/lang/RuntimeException
      // try (253 -> 277): 277 java/lang/RuntimeException
      // try (279 -> 385): 385 java/lang/RuntimeException
      // try (387 -> 396): 397 java/lang/RuntimeException
      // try (391 -> 414): 415 java/lang/RuntimeException
   }

   ce.a a(f_ var1, IBone var2, IBone var3, IBone var4, IBone var5) {
      float var6 = var1.aE;
      ce.a var7 = new ce.a();

      try {
         if (var6 > 0.0F) {
            var7.c = new f7(var2.getRotationX() - var6, var2.getRotationY() - var6 * -25.0F / 45.0F, var2.getRotationZ() + var6 * 12.5F / 45.0F);
            var7.g = new f7(var3.getRotationX() - var6, var3.getRotationY() + var6 * 15.0F / 45.0F, var3.getRotationZ());
            var7.b = new f7(var4.getRotationX(), var4.getRotationY(), var4.getRotationZ());
            var7.h = new f7(var5.getRotationX(), var5.getRotationY(), var5.getRotationZ());
            return var7;
         }
      } catch (RuntimeException var8) {
         throw a(var8);
      }

      var7.h = new f7(var5.getRotationX() + 2.0F * var6, var5.getRotationY(), var5.getRotationZ());
      var7.b = new f7(var4.getRotationX() + 2.2222223F * var6, var4.getRotationY(), var4.getRotationZ());
      var7.c = new f7(var2.getRotationX() - var6, var2.getRotationY(), var2.getRotationZ() + var6 * 5.0F / 45.0F);
      var7.g = new f7(var3.getRotationX() - var6, var3.getRotationY(), var3.getRotationZ() - var6 * 5.0F / 45.0F);
      return var7;
   }

   void b(em var1) {
      try {
         if (ClientProxy.IS_PRELOADING) {
            return;
         }
      } catch (RuntimeException var16) {
         throw a(var16);
      }

      try {
         if (this.a.func_147113_T()) {
            return;
         }
      } catch (RuntimeException var24) {
         throw a(var24);
      }

      f8 var2 = (f8)var1;

      try {
         if (!dh.b(var2)) {
            return;
         }
      } catch (RuntimeException var23) {
         throw a(var23);
      }

      f_ var3 = var2.a(false);

      try {
         if (var3 == null) {
            return;
         }
      } catch (RuntimeException var22) {
         throw a(var22);
      }

      AnimationProcessor var4 = this.getAnimationProcessor();
      float var5 = var3.aE;
      var4.getBone("rotationTool").setRotationX(var5);
      IBone var6 = var4.getBone("head");
      IBone var7 = var4.getBone("upperBody");
      IBone var8 = var4.getBone("boobs");

      label87: {
         try {
            if (var5 > 0.0F) {
               var7.setRotationX(-1.1111112F * var5);
               var6.setRotationX(0.1333F * var5);
               var8.setRotationX(var5 * 22.5F / 45.0F);
               break label87;
            }
         } catch (RuntimeException var21) {
            throw a(var21);
         }

         var7.setRotationX(-1.6666666F * var5);
         var6.setRotationX(var5 * 0.666F);
      }

      float var9 = be.a(var2.T, var2.af);
      float var10 = be.a(var2.ai, var2.W);
      float var11 = Minecraft.func_175610_ah();
      if (var11 == 0.0F) {
         var11 = 1.0F;
      }

      float var10000;
      float var10001;
      label112: {
         try {
            var10000 = 7.0F;
            if (Math.abs(var9) < 7.0F) {
               var10001 = var9;
               break label112;
            }
         } catch (RuntimeException var20) {
            throw a(var20);
         }

         try {
            if (var9 > 0.0F) {
               var10001 = 7.0F;
               break label112;
            }
         } catch (RuntimeException var19) {
            throw a(var19);
         }

         var10001 = -7.0F;
      }

      float var12 = var10000 * var10001 * (1.0F / var11);

      label113: {
         try {
            var10000 = 7.0F;
            if (Math.abs(var10) < 7.0F) {
               var10001 = var10;
               break label113;
            }
         } catch (RuntimeException var18) {
            throw a(var18);
         }

         try {
            if (var10 > 0.0F) {
               var10001 = 7.0F;
               break label113;
            }
         } catch (RuntimeException var17) {
            throw a(var17);
         }

         var10001 = -7.0F;
      }

      float var13 = var10000 * var10001 * (1.0F / var11);
      float var14 = var2.T + var12;
      float var15 = var2.ai + var13;
      var6.setRotationY(var6.getRotationY() + var14);
      var6.setRotationX(var6.getRotationX() + var15);
      var2.T = var14;
      var2.ai = var15;
   }

   public static void a(em var0, AnimationProcessor var1, float var2) {
      try {
         if (ClientProxy.IS_PRELOADING) {
            return;
         }
      } catch (RuntimeException var4) {
         throw a(var4);
      }

      boolean var3 = dh.a(var0);
      e(var1, var3);
      f(var1, var3);
      b(var0, var1, var2);
   }

   static void b(em param0, AnimationProcessor param1, float param2) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 00: aload 0
      // 01: instanceof com/trolmastercard/velvet/f8
      // 04: ifne 0c
      // 07: return
      // 08: invokestatic com/trolmastercard/velvet/ce.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 0b: athrow
      // 0c: bipush 0
      // 0d: istore 3
      // 0e: iload 3
      // 0f: bipush 3
      // 10: if_icmpge 5a
      // 13: aload 1
      // 14: new java/lang/StringBuilder
      // 17: dup
      // 18: invokespecial java/lang/StringBuilder.<init> ()V
      // 1b: ldc_w "cockStage"
      // 1e: invokevirtual java/lang/StringBuilder.append (Ljava/lang/String;)Ljava/lang/StringBuilder;
      // 21: iload 3
      // 22: invokevirtual java/lang/StringBuilder.append (I)Ljava/lang/StringBuilder;
      // 25: invokevirtual java/lang/StringBuilder.toString ()Ljava/lang/String;
      // 28: invokevirtual software/bernie/geckolib3/core/processor/AnimationProcessor.getBone (Ljava/lang/String;)Lsoftware/bernie/geckolib3/core/processor/IBone;
      // 2b: astore 4
      // 2d: aload 4
      // 2f: ifnull 54
      // 32: aload 4
      // 34: iload 3
      // 35: aload 0
      // 36: checkcast com/trolmastercard/velvet/f8
      // 39: getfield com/trolmastercard/velvet/f8.an I
      // 3c: if_icmple 4e
      // 3f: goto 46
      // 42: invokestatic com/trolmastercard/velvet/ce.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 45: athrow
      // 46: bipush 1
      // 47: goto 4f
      // 4a: invokestatic com/trolmastercard/velvet/ce.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 4d: athrow
      // 4e: bipush 0
      // 4f: invokeinterface software/bernie/geckolib3/core/processor/IBone.setHidden (Z)V 2
      // 54: iinc 3 1
      // 57: goto 0e
      // 5a: return
      // try (0 -> 4): 4 java/lang/RuntimeException
      // try (22 -> 30): 31 java/lang/RuntimeException
      // try (24 -> 35): 35 java/lang/RuntimeException
   }

   static void f(AnimationProcessor var0, boolean var1) {
      IBone var10000;
      boolean var10001;
      label16: {
         try {
            var10000 = var0.getBone("skirt");
            if (!var1) {
               var10001 = true;
               break label16;
            }
         } catch (RuntimeException var2) {
            throw a(var2);
         }

         var10001 = false;
      }

      var10000.setHidden(var10001);
   }

   static void e(AnimationProcessor var0, boolean var1) {
      IBone var10000;
      boolean var10001;
      label28: {
         try {
            var0.getBone("cheekRBelowSkirt").setHidden(var1);
            var0.getBone("cheekLBelowSkirt").setHidden(var1);
            var0.getBone("sideRNoSkirt").setHidden(var1);
            var10000 = var0.getBone("sideRSkirt");
            if (!var1) {
               var10001 = true;
               break label28;
            }
         } catch (RuntimeException var3) {
            throw a(var3);
         }

         var10001 = false;
      }

      label21: {
         try {
            var10000.setHidden(var10001);
            var0.getBone("sideLNoSkirt").setHidden(var1);
            var10000 = var0.getBone("sideLSkirt");
            if (!var1) {
               var10001 = true;
               break label21;
            }
         } catch (RuntimeException var2) {
            throw a(var2);
         }

         var10001 = false;
      }

      var10000.setHidden(var10001);
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static class a {
      private f7 c;
      private f7 g;
      private f7 h;
      private f7 b;
      private float f = 1.0F;
      private float a = 1.0F;
      private float e = 0.0F;
      private float d = 0.0F;

      private a() {
      }

      static ce.a a(ce.a var0, ce.a var1, float var2) {
         ce.a var3 = new ce.a();
         var3.c = b6.a(var0.c, var1.c, var2);
         var3.g = b6.a(var0.g, var1.g, var2);
         var3.h = b6.a(var0.h, var1.h, var2);
         var3.b = b6.a(var0.b, var1.b, var2);
         var3.f = b6.a(var0.f, var1.f, var2);
         var3.a = b6.a(var0.a, var1.a, var2);
         var3.e = b6.a(var0.e, var1.e, var2);
         var3.d = b6.a(var0.d, var1.d, var2);
         return var3;
      }
   }
}
