package org.velvet;

@FunctionalInterface
public interface gt {
   float a(em var1);
}
