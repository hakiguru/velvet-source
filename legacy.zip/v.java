package org.velvet;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.UUID;
import java.util.Map.Entry;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.world.World;
import net.minecraft.world.storage.WorldSavedData;
import net.minecraftforge.event.world.WorldEvent.Load;
import net.minecraftforge.event.world.WorldEvent.Save;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent.Phase;
import net.minecraftforge.fml.common.gameevent.TickEvent.ServerTickEvent;
import org.apache.logging.log4j.Level;

public class v extends WorldSavedData {
   public static boolean f = true;
   public static final float c = 60.0F;
   public static final String e = "velvet:galath_owner_ship";
   public static final String d = "velvet:ownershipdata";
   public static final String g = "velvet:mangownershipdata";
   static final long a = 0L;
   static gl<UUID, UUID> h = new gl<>();
   static HashMap<UUID, Long> b = new HashMap<>();
   static HashSet<UUID> i = new HashSet<>();

   public v() {
      super("velvet:galath_owner_ship");
   }

   public v(String var1) {
      super("velvet:galath_owner_ship");
   }

   public static void a() {
      i.clear();
      h.b();
   }

   public static void e(UUID var0) {
      UUID var1 = f(var0);

      try {
         if (var1 == null) {
            return;
         }
      } catch (RuntimeException var2) {
         throw a(var2);
      }

      i.add(var1);
   }

   public static boolean b(UUID var0) {
      return i.contains(var0);
   }

   public static boolean c(f_ var0) {
      UUID var1 = h.b(var0.f());

      try {
         if (var1 == null) {
            return false;
         }
      } catch (RuntimeException var7) {
         throw a(var7);
      }

      World var2 = var0.field_70170_p;
      EntityPlayer var3 = var2.func_152378_a(var1);

      try {
         if (var3 == null) {
            return true;
         }
      } catch (RuntimeException var5) {
         throw a(var5);
      }

      try {
         if (var3.field_71093_bK != var0.field_71093_bK) {
            return false;
         }
      } catch (RuntimeException var6) {
         throw a(var6);
      }

      try {
         return !(var3.func_70032_d(var0) > 60.0F);
      } catch (RuntimeException var4) {
         throw a(var4);
      }
   }

   public static boolean b(EntityPlayer var0, f_ var1) {
      return var1.f().equals(h.c(var0.getPersistentID()));
   }

   public static void a(f_ var0) {
      f8 var1 = var0.a(true);

      try {
         if (var1 != null) {
            var0.field_70170_p.func_72900_e(var1);
         }
      } catch (RuntimeException var7) {
         throw a(var7);
      }

      UUID var2 = h.b(var0.f());

      try {
         if (var2 == null) {
            var0.field_70170_p.func_72900_e(var0);
            return;
         }
      } catch (RuntimeException var6) {
         throw a(var6);
      }

      World var3 = var0.field_70170_p;
      EntityPlayer var4 = var3.func_152378_a(var2);

      try {
         var0.field_70170_p.func_72900_e(var0);
         h.a(var2);
         if (var4 != null) {
            ge.b.sendTo(new gf(false), (EntityPlayerMP)var4);
         }
      } catch (RuntimeException var5) {
         throw a(var5);
      }
   }

   public static boolean c(UUID var0) {
      try {
         if (h.c(var0) != null) {
            return true;
         }
      } catch (RuntimeException var1) {
         throw a(var1);
      }

      return false;
   }

   public static UUID f(UUID var0) {
      return h.b(var0);
   }

   public static UUID b(f_ var0) {
      try {
         if (var0 == null) {
            return null;
         }
      } catch (RuntimeException var1) {
         throw a(var1);
      }

      return f(var0.f());
   }

   public static UUID a(UUID var0) {
      return h.c(var0);
   }

   public static UUID b(EntityPlayer var0) {
      try {
         if (var0 == null) {
            return null;
         }
      } catch (RuntimeException var1) {
         throw a(var1);
      }

      return a(var0.getPersistentID());
   }

   public static void a(UUID var0, UUID var1) {
      h.a(var0, var1);
   }

   public static void a(EntityPlayer var0, f_ var1) {
      try {
         if (var0 == null) {
            return;
         }
      } catch (RuntimeException var2) {
         throw a(var2);
      }

      try {
         if (var1 == null) {
            return;
         }
      } catch (RuntimeException var3) {
         throw a(var3);
      }

      a(var0.getPersistentID(), var1.f());
   }

   public static void d(UUID var0) {
      h.a(var0);
   }

   public static void a(EntityPlayer var0) {
      try {
         if (var0 == null) {
            return;
         }
      } catch (RuntimeException var1) {
         throw a(var1);
      }

      d(var0.getPersistentID());
   }

   public static boolean a(UUID var0, World var1) {
      Long var2 = b.get(var0);

      try {
         if (!b(var0)) {
            return false;
         }
      } catch (RuntimeException var5) {
         throw a(var5);
      }

      try {
         if (var2 == null) {
            return true;
         }
      } catch (RuntimeException var3) {
         throw a(var3);
      }

      try {
         if (var1.func_82737_E() - var2 > 0L) {
            return true;
         }
      } catch (RuntimeException var4) {
         throw a(var4);
      }

      return false;
   }

   public static void a(UUID var0, Long var1) {
      try {
         if (var0 == null) {
            Main.LOGGER.log(Level.WARN, "tried to save last cum dosage time on NULL player");
            return;
         }
      } catch (RuntimeException var2) {
         throw a(var2);
      }

      b.put(var0, var1);
   }

   @SubscribeEvent
   public void a(ServerTickEvent var1) {
      try {
         if (var1.phase != Phase.END) {
            return;
         }
      } catch (RuntimeException var11) {
         throw a(var11);
      }

      World var2 = FMLCommonHandler.instance().getMinecraftServerInstance().func_130014_f_();
      ArrayList var3 = new ArrayList();

      for (Entry var5 : h.c()) {
         UUID var6 = (UUID)var5.getKey();
         UUID var7 = (UUID)var5.getValue();
         EntityPlayer var8 = var2.func_152378_a(var6);

         try {
            if (var8 == null) {
               continue;
            }
         } catch (RuntimeException var10) {
            throw a(var10);
         }

         try {
            if (em.a(var7) == null) {
               var3.add(var8);
            }
         } catch (RuntimeException var9) {
            throw a(var9);
         }
      }

      for (EntityPlayer var13 : var3) {
         h.a(var13.getPersistentID());
         ge.b.sendTo(new gf(false), (EntityPlayerMP)var13);
      }
   }

   @SubscribeEvent
   public void a(Save var1) {
      World var2 = var1.getWorld();
      var2.func_175693_T().func_75745_a("velvet:galath_owner_ship", this);
      this.func_76185_a();
   }

   @SubscribeEvent
   public void a(Load var1) {
      World var2 = var1.getWorld();
      var2.func_175693_T().func_75742_a(v.class, "velvet:galath_owner_ship");
   }

   public void func_76184_a(NBTTagCompound param1) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:174)
      //
      // Bytecode:
      // 000: aload 1
      // 001: ldc "velvet:ownershipdata"
      // 003: invokevirtual net/minecraft/nbt/NBTTagCompound.func_74775_l (Ljava/lang/String;)Lnet/minecraft/nbt/NBTTagCompound;
      // 006: astore 2
      // 007: aload 2
      // 008: ldc_w "amount"
      // 00b: invokevirtual net/minecraft/nbt/NBTTagCompound.func_74762_e (Ljava/lang/String;)I
      // 00e: istore 3
      // 00f: bipush 0
      // 010: istore 4
      // 012: iload 4
      // 014: iload 3
      // 015: if_icmpge 0aa
      // 018: aload 2
      // 019: new java/lang/StringBuilder
      // 01c: dup
      // 01d: invokespecial java/lang/StringBuilder.<init> ()V
      // 020: ldc_w "master"
      // 023: invokevirtual java/lang/StringBuilder.append (Ljava/lang/String;)Ljava/lang/StringBuilder;
      // 026: iload 4
      // 028: invokevirtual java/lang/StringBuilder.append (I)Ljava/lang/StringBuilder;
      // 02b: invokevirtual java/lang/StringBuilder.toString ()Ljava/lang/String;
      // 02e: invokevirtual net/minecraft/nbt/NBTTagCompound.func_186857_a (Ljava/lang/String;)Ljava/util/UUID;
      // 031: astore 5
      // 033: aload 2
      // 034: new java/lang/StringBuilder
      // 037: dup
      // 038: invokespecial java/lang/StringBuilder.<init> ()V
      // 03b: ldc_w "galath"
      // 03e: invokevirtual java/lang/StringBuilder.append (Ljava/lang/String;)Ljava/lang/StringBuilder;
      // 041: iload 4
      // 043: invokevirtual java/lang/StringBuilder.append (I)Ljava/lang/StringBuilder;
      // 046: invokevirtual java/lang/StringBuilder.toString ()Ljava/lang/String;
      // 049: invokevirtual net/minecraft/nbt/NBTTagCompound.func_186857_a (Ljava/lang/String;)Ljava/util/UUID;
      // 04c: astore 6
      // 04e: aload 2
      // 04f: new java/lang/StringBuilder
      // 052: dup
      // 053: invokespecial java/lang/StringBuilder.<init> ()V
      // 056: ldc_w "lastcumdosage"
      // 059: invokevirtual java/lang/StringBuilder.append (Ljava/lang/String;)Ljava/lang/StringBuilder;
      // 05c: iload 4
      // 05e: invokevirtual java/lang/StringBuilder.append (I)Ljava/lang/StringBuilder;
      // 061: invokevirtual java/lang/StringBuilder.toString ()Ljava/lang/String;
      // 064: invokevirtual net/minecraft/nbt/NBTTagCompound.func_74763_f (Ljava/lang/String;)J
      // 067: lstore 7
      // 069: aload 5
      // 06b: ifnull 07a
      // 06e: aload 6
      // 070: ifnonnull 08c
      // 073: goto 07a
      // 076: invokestatic com/trolmastercard/velvet/v.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 079: athrow
      // 07a: getstatic com/trolmastercard/velvet/Main.LOGGER Lorg/apache/logging/log4j/Logger;
      // 07d: ldc_w "OMFG WHOOP WHOOP SAVING DIDNT WORK CORRECTLY AAAAAAAAAAA"
      // 080: invokeinterface org/apache/logging/log4j/Logger.fatal (Ljava/lang/String;)V 2
      // 085: goto 0a4
      // 088: invokestatic com/trolmastercard/velvet/v.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 08b: athrow
      // 08c: getstatic com/trolmastercard/velvet/v.h Lcom/trolmastercard/velvet/gl;
      // 08f: aload 5
      // 091: aload 6
      // 093: invokevirtual com/trolmastercard/velvet/gl.a (Ljava/lang/Object;Ljava/lang/Object;)V
      // 096: getstatic com/trolmastercard/velvet/v.b Ljava/util/HashMap;
      // 099: aload 5
      // 09b: lload 7
      // 09d: invokestatic java/lang/Long.valueOf (J)Ljava/lang/Long;
      // 0a0: invokevirtual java/util/HashMap.put (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
      // 0a3: pop
      // 0a4: iinc 4 1
      // 0a7: goto 012
      // 0aa: aload 1
      // 0ab: ldc "velvet:mangownershipdata"
      // 0ad: invokevirtual net/minecraft/nbt/NBTTagCompound.func_74775_l (Ljava/lang/String;)Lnet/minecraft/nbt/NBTTagCompound;
      // 0b0: astore 4
      // 0b2: bipush 0
      // 0b3: istore 5
      // 0b5: aload 4
      // 0b7: new java/lang/StringBuilder
      // 0ba: dup
      // 0bb: invokespecial java/lang/StringBuilder.<init> ()V
      // 0be: ldc_w "mang"
      // 0c1: invokevirtual java/lang/StringBuilder.append (Ljava/lang/String;)Ljava/lang/StringBuilder;
      // 0c4: iload 5
      // 0c6: invokevirtual java/lang/StringBuilder.append (I)Ljava/lang/StringBuilder;
      // 0c9: invokevirtual java/lang/StringBuilder.toString ()Ljava/lang/String;
      // 0cc: invokevirtual net/minecraft/nbt/NBTTagCompound.func_186855_b (Ljava/lang/String;)Z
      // 0cf: ifne 0d9
      // 0d2: goto 100
      // 0d5: invokestatic com/trolmastercard/velvet/v.a (Ljava/lang/RuntimeException;)Ljava/lang/RuntimeException;
      // 0d8: athrow
      // 0d9: getstatic com/trolmastercard/velvet/v.i Ljava/util/HashSet;
      // 0dc: aload 4
      // 0de: new java/lang/StringBuilder
      // 0e1: dup
      // 0e2: invokespecial java/lang/StringBuilder.<init> ()V
      // 0e5: ldc_w "mang"
      // 0e8: invokevirtual java/lang/StringBuilder.append (Ljava/lang/String;)Ljava/lang/StringBuilder;
      // 0eb: iload 5
      // 0ed: invokevirtual java/lang/StringBuilder.append (I)Ljava/lang/StringBuilder;
      // 0f0: invokevirtual java/lang/StringBuilder.toString ()Ljava/lang/String;
      // 0f3: invokevirtual net/minecraft/nbt/NBTTagCompound.func_186857_a (Ljava/lang/String;)Ljava/util/UUID;
      // 0f6: invokevirtual java/util/HashSet.add (Ljava/lang/Object;)Z
      // 0f9: pop
      // 0fa: iinc 5 1
      // 0fd: goto 0b5
      // 100: aload 1
      // 101: ldc "velvet:mangownershipdata"
      // 103: new net/minecraft/nbt/NBTTagCompound
      // 106: dup
      // 107: invokespecial net/minecraft/nbt/NBTTagCompound.<init> ()V
      // 10a: invokevirtual net/minecraft/nbt/NBTTagCompound.func_74782_a (Ljava/lang/String;Lnet/minecraft/nbt/NBTBase;)V
      // 10d: aload 1
      // 10e: ldc "velvet:ownershipdata"
      // 110: new net/minecraft/nbt/NBTTagCompound
      // 113: dup
      // 114: invokespecial net/minecraft/nbt/NBTTagCompound.<init> ()V
      // 117: invokevirtual net/minecraft/nbt/NBTTagCompound.func_74782_a (Ljava/lang/String;Lnet/minecraft/nbt/NBTBase;)V
      // 11a: return
      // try (46 -> 50): 51 java/lang/RuntimeException
      // try (48 -> 57): 57 java/lang/RuntimeException
      // try (77 -> 89): 89 java/lang/RuntimeException
   }

   public NBTTagCompound func_189551_b(NBTTagCompound var1) {
      NBTTagCompound var2 = new NBTTagCompound();
      var2.func_74768_a("amount", h.e());
      int var3 = 0;

      for (Entry var5 : h.c()) {
         UUID var6 = (UUID)var5.getKey();
         UUID var7 = (UUID)var5.getValue();
         Long var8 = b.get(var6);
         if (var8 == null) {
            var8 = 0L;
         }

         var2.func_186854_a("galath" + var3, var7);
         var2.func_186854_a("master" + var3, var6);
         var2.func_74772_a("lastcumdosage" + var3, var8);
         var3++;
      }

      NBTTagCompound var10 = new NBTTagCompound();
      var3 = 0;

      for (UUID var12 : i) {
         var10.func_186854_a("mang" + var3++, var12);
      }

      var1.func_74782_a("velvet:ownershipdata", var2);
      var1.func_74782_a("velvet:mangownershipdata", var10);
      return var1;
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }
}
